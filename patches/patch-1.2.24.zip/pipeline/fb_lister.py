"""
Liet ke video/reel cua mot Facebook page (Pha 1 - RE, de LOC).

Cuon tab /{page}/reels/ -> gom {id, href, view, thumbnail} -> index.json.
Tieu de/caption day du KHONG lay o day (lam giau o Pha 2 khi mo tung reel).

BEN:
- Gom TICH LUY qua tung buoc cuon (FB dung virtual list, hay go phan tu ngoai
  man hinh khoi DOM) -> khong mat reel da luot qua.
- Merge voi index cu theo id -> GIU trang thai da tai (khong dem lap, khong mat tien do).

Neo DOM: anchor href chua '/reel/<so>' + <img> ben trong + innerText la so view.
KHONG neo class CSS (FB xao tron). Neu FB doi giao dien -> sua rieng ham _COLLECT_JS.

Kiem THAT:
  python -m pipeline.fb_lister https://www.facebook.com/tuoitho89x/reels/
"""
import json
import os
import re
import time

from fb_session import CDP, list_targets, open_session, PROFILE_DIR

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_DIR = os.path.join(ROOT, "facebook")

# JS gom reel dang hien tren DOM (goi lai moi buoc cuon)
#
# LOC RAC (do THAT 2026-07-25): quet ca `document` thi dinh CA reel trong khung THONG BAO /
# quang cao / goi y cua TAI KHOAN Chrome ("Chưa đọc…", "Bạn có thể xem thước phim…") —
# nhung reel nay KHONG phai cua page dang cao, nhung lai chui vao index cua page do va
# xuat hien o MOI page (do 9 page: cung dinh id 876407008498573). Hau qua that: backlog
# chon phai reel la -> dung video sai gu / 2 page cung dung 1 reel.
# 2 tang chan (khong neo class FB — class doi lien tuc):
#   1. bo anchor nam trong vung UI (navigation/banner/dialog/menu/complementary)
#   2. reel THAT trong luoi luon co <img> thumbnail; muc thong bao thi khong
_COLLECT_JS = r'''(function(){
  var out=[]; var seen={};
  var SKIP='[role="navigation"],[role="banner"],[role="dialog"],[role="menu"],[role="complementary"],[role="alert"]';
  document.querySelectorAll('a[href*="/reel/"]').forEach(function(a){
    var m = a.href.match(/\/reel\/(\d+)/);
    if(!m) return; var id=m[1]; if(seen[id]) return;
    try{ if(a.closest && a.closest(SKIP)) return; }catch(e){}
    var img = a.querySelector('img');
    if(!img) return;                       // khong co thumbnail = khong phai o luoi reel
    var src = img.src || '';               // emoji/icon UI khong phai thumbnail reel
    if(!/^http/.test(src) || /static\.[^\/]*fbcdn\.net|emoji\.php|\/rsrc\.php/.test(src)) return;
    seen[id]=1;
    out.push({
      id: id,
      href: a.href.split('?')[0],
      view_text: (a.innerText||'').trim().split('\n')[0].slice(0,20),
      thumb: img.src
    });
  });
  return out;
})()'''

# JS boc fetch + XHR de GHI LAI request GraphQL that FB tu ban (tu do doc_id/fb_dtsg).
# Bam response FB that -> FB xoay doc_id cung khong gay (moi lan cao lai bat lai).
_WRAP_JS = r'''(function(){
  if(window.__csCapInstalled) return 'already';
  window.__csCap = [];
  function rec(u,b){try{if(u&&u.indexOf('/api/graphql')>=0&&b){window.__csCap.push(String(b));if(window.__csCap.length>60)window.__csCap.shift();}}catch(e){}}
  var of=window.fetch;
  window.fetch=function(i,n){try{var u=(typeof i==='string')?i:(i&&i.url)||'';if(n&&n.body)rec(u,n.body);}catch(e){}return of.apply(this,arguments);};
  var oo=XMLHttpRequest.prototype.open, osd=XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open=function(m,u){this.__u=u;return oo.apply(this,arguments);};
  XMLHttpRequest.prototype.send=function(b){try{rec(this.__u,b);}catch(e){}return osd.apply(this,arguments);};
  window.__csCapInstalled=true; return 'installed';
})()'''


def page_slug(url: str) -> str:
    """Lay slug page tu URL:
      .../tuoitho89x/reels/            -> tuoitho89x
      .../profile.php?id=123&sk=...    -> id123  (page dang SO: slug RIENG theo id)

    GOC BUG (2026-07-24): truoc day moi profile.php?id=... deu tra "page" -> N page
    NGUON khac nhau DON CHUNG 1 thu muc facebook/page/ -> keo CUNG 1 reel (loi 'same UID').
    Nay tach theo id so -> moi page nguon 1 kho rieng."""
    mid = re.search(r"profile\.php\?id=(\d+)", url)
    if mid:
        return "id" + mid.group(1)
    m = re.search(r"facebook\.com/([^/?#]+)", url)
    slug = m.group(1) if m else "page"
    # bo cac path khong phai ten page
    if slug in ("reel", "watch", "profile.php"):
        slug = "page"
    return slug


def parse_views(text: str):
    """'19K' -> 19000 ; '1.2M' -> 1200000 ; '1,2Tr' -> 1200000 ; '' -> None.

    Ho tro v(nghin) K/N + trieu M/Tr + ty B. Tra None neu khong doc duoc.
    """
    if not text:
        return None
    t = text.strip().replace(",", ".")
    m = re.match(r"^([\d.]+)\s*([a-zA-Z]*)$", t)
    if not m:
        return None
    try:
        num = float(m.group(1))
    except ValueError:
        return None
    unit = m.group(2).lower()
    mult = {
        "": 1, "k": 1e3, "n": 1e3, "nghin": 1e3,
        "m": 1e6, "tr": 1e6, "trieu": 1e6,
        "b": 1e9, "t": 1e9, "ty": 1e9,
    }.get(unit, 1)
    return int(num * mult)


def _index_path(slug: str) -> str:
    return os.path.join(FB_DIR, slug, "index.json")


def load_index(slug: str) -> dict:
    p = _index_path(slug)
    if os.path.isfile(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"page": slug, "reels": {}}


def save_index(slug: str, data: dict) -> str:
    p = _index_path(slug)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    return p


def _real_thumb(u) -> bool:
    """True neu la thumbnail REEL that (scontent CDN), khong phai icon/emoji cua UI.

    Muc thong bao co <img> nhung la EMOJI sprite
    (static.xx.fbcdn.net/images/emoji.php/... , rsrc.php) -> khong tinh la thumbnail.
    """
    s = str(u or "")
    if not s.startswith("http"):
        return False
    return not re.search(r"static\.[^/]*fbcdn\.net|emoji\.php|/rsrc\.php", s)


def is_junk(r: dict) -> bool:
    """Muc RAC lot vao index: reel cua khung thong bao/quang cao, KHONG phai cua page.

    Dau van tay (do that tren 9 page): khong co thumbnail REEL that VA view_text la CHU
    ("Chưa đọc…", "Bạn có thể xem thước phim…") chu khong phai so view ("36K").
    Reel that ma thumbnail chua kip tai thi view_text van doc ra so -> GIU.
    """
    if _real_thumb(r.get("thumb")):
        return False
    vt = (r.get("view_text") or "").strip()
    return len(vt) > 3 and parse_views(vt) is None


def purge_junk(slug: str) -> int:
    """Don muc rac da lot vao index cu. Tra so muc da xoa."""
    idx = load_index(slug)
    reels = idx.get("reels") or {}
    bad = [rid for rid, r in reels.items() if is_junk(r) and not r.get("downloaded")]
    for rid in bad:
        reels.pop(rid, None)
    if bad:
        idx["count"] = len(reels)
        save_index(slug, idx)
    return len(bad)


def _merge_save(slug: str, page_url: str, acc: dict) -> dict:
    """Merge acc {id->reel} vao index cu (GIU trang thai da tai) roi luu."""
    idx = load_index(slug)
    reels = idx.get("reels", {})
    for rid, r in acc.items():
        if is_junk(r) and rid not in reels:
            continue                       # chan tu cong vao, khong de rac sinh soi
        old = reels.get(rid, {})
        vtext = r.get("view_text")
        reels[rid] = {
            "id": rid,
            "href": r.get("href"),
            "thumb": r.get("thumb"),
            "view_text": vtext,
            "views": parse_views(vtext),
            # dua dai (giay) neu API co -> tien phan loai dang lo sau nay
            "length": r.get("length") if r.get("length") is not None else old.get("length"),
            # giu nguyen trang thai/tien do neu da co
            "status": old.get("status", "listed"),
            "downloaded": old.get("downloaded", False),
            "caption": old.get("caption"),
        }
    idx.update({
        "page": slug,
        "page_url": page_url,
        "scraped_at": int(time.time()),
        "count": len(reels),
        "reels": reels,
    })
    save_index(slug, idx)
    return idx


def list_reels_scroll(page_url: str, port: int = None, max_scroll: int = 60,
                      stable_rounds: int = 4, pause: float = 2.0,
                      progress=None) -> dict:
    """CACH CU: cuon DOM + gom reel. Ben nhung cham (render + pause moi lan)."""
    from fb_session import DEFAULT_PORT
    port = port or DEFAULT_PORT
    open_session(port)  # bao dam Chrome song (khong login ho)
    slug = page_slug(page_url)

    targets = list_targets(port)
    if not targets:
        raise RuntimeError("Khong co tab Chrome. Mo phien va dang nhap truoc.")
    c = CDP(targets[0]["webSocketDebuggerUrl"])
    try:
        c.navigate(page_url, wait=4.0)
        acc = {}          # id -> reel dict (tich luy)
        last_size = -1
        stable = 0
        for i in range(max_scroll):
            for r in (c.eval(_COLLECT_JS) or []):
                acc[r["id"]] = r
            if progress:
                progress(len(acc), i + 1)
            if len(acc) == last_size:
                stable += 1
                if stable >= stable_rounds:
                    break
            else:
                stable = 0
            last_size = len(acc)
            c.eval("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(pause)
    finally:
        c.close()
    return _merge_save(slug, page_url, acc)


def _pager_js(fields: dict) -> str:
    """Sinh JS phan trang IN-PAGE: nhan (cursor, cnt) -> {n, cursor, more, rows}.

    Dung lai TOAN BO fields cua request that (co fb_dtsg/doc_id/id collection),
    chi thay variables.count + variables.cursor. fetch trong trang -> cookie tu dinh.
    """
    return r'''(async function(cursor, cnt){
      var f=%s; var v=JSON.parse(f.variables); v.count=cnt; v.cursor=cursor; f.variables=JSON.stringify(v);
      var body=Object.keys(f).map(function(k){return encodeURIComponent(k)+'='+encodeURIComponent(f[k]);}).join('&');
      var r=await fetch('/api/graphql/',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:body});
      var txt=await r.text(); var j=null; var ls=txt.split('\n');
      for(var L=0;L<ls.length;L++){try{j=JSON.parse(ls[L]);break;}catch(e){}}
      if(!j)return{err:'noparse'};
      var agg=j.data&&j.data.node&&j.data.node.aggregated_fb_shorts; if(!agg)return{err:'nonode'};
      var es=agg.edges||[]; var pi=agg.page_info||{}; var out={n:es.length,cursor:pi.end_cursor||null,more:!!pi.has_next_page,rows:[]};
      for(var i=0;i<es.length;i++){try{var nd=es[i].profile_reel_node.node; var m=nd.attachments[0].media;
        out.rows.push({id:m.id, href:(m.permalink_url||m.shareable_url||'').split('?')[0],
          views:m.play_count_reduced||null, length:m.length_in_second||null,
          thumb:(m.thumbnailImage&&m.thumbnailImage.uri)||m.first_frame_thumbnail||null});}catch(e){}}
      return out;
    })''' % json.dumps(fields)


def list_reels_api(page_url: str, port: int = None, max_pages: int = 500,
                   progress=None) -> dict:
    """CACH NHANH: goi API noi bo FB (GraphQL) bang cookie phien -> phan trang cursor.

    Do THAT: ~10 reel/nhip ~1.5-2s (khong render), ~3-4x nhanh hon cuon.
    RAISE neu khong bat duoc request (de goi list_reels_scroll thay).
    """
    import urllib.parse
    from fb_session import DEFAULT_PORT
    port = port or DEFAULT_PORT
    open_session(port)
    slug = page_slug(page_url)
    targets = list_targets(port)
    if not targets:
        raise RuntimeError("Khong co tab Chrome. Mo phien va dang nhap truoc.")
    c = CDP(targets[0]["webSocketDebuggerUrl"])
    try:
        c.navigate(page_url, wait=5.0)
        c.eval(_WRAP_JS)
        # cuon vai nhip cho FB TU ban request phan trang that -> ta bat lay
        fields = None
        for _ in range(6):
            c.eval("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(2.2)
            caps = c.eval("window.__csCap || []") or []
            for b in caps:
                f = dict(urllib.parse.parse_qsl(b))
                if "ReelsRendererPaginationQuery" in f.get("fb_api_req_friendly_name", ""):
                    fields = f
                    break
            if fields:
                break
        if not fields or "variables" not in fields:
            raise RuntimeError("Khong bat duoc request reel GraphQL (co the FB doi giao dien).")

        # newest: gom luon reel dang hien tren DOM (nhung cai truoc cursor dau)
        acc = {}
        for r in (c.eval(_COLLECT_JS) or []):
            acc[r["id"]] = r

        start_cursor = json.loads(fields["variables"]).get("cursor")
        pager = _pager_js(fields)
        cursor = start_cursor
        for pg in range(max_pages):
            res = c.eval(pager + "(%s, 30)" % json.dumps(cursor))
            if not res or res.get("err"):
                # het duong API -> dung lai voi nhung gi da co (khong coi la loi neu da co data)
                if pg == 0 and not acc:
                    raise RuntimeError("API tra loi: %s" % (res or {}).get("err"))
                break
            for row in res.get("rows", []):
                rid = row.get("id")
                if not rid:
                    continue
                old = acc.get(rid, {})
                acc[rid] = {
                    "id": rid,
                    "href": row.get("href") or old.get("href"),
                    "thumb": row.get("thumb") or old.get("thumb"),
                    "view_text": row.get("views") or old.get("view_text"),
                    "length": row.get("length"),
                }
            if progress:
                progress(len(acc), pg + 1)
            cursor = res.get("cursor")
            if not res.get("more") or not cursor or res.get("n", 0) == 0:
                break
    finally:
        c.close()
    return _merge_save(slug, page_url, acc)


# Chu Facebook hien khi NGUON khong xem duoc (bi xoa / doi quyen rieng tu / chan).
# Cao ra 0 reel co HAI nghia rat khac nhau: (a) trinh cao hong, (b) nguon da chet.
# Truoc day ca hai deu bao "0 reel" nhu nhau -> khong biet duong nao ma sua.
_DEAD_KW = (
    "không xem được nội dung này",
    "nội dung này hiện không",
    "content isn't available",
    "content is no longer available",
    "trang này hiện không khả dụng",
    "page isn't available",
    "this page isn't available",
    "tạm thời bị chặn",
    "temporarily blocked",
)


def source_problem(port: int = None) -> str:
    """Doc CHU tren tab Chrome hien tai -> ly do nguon khong cao duoc ('' neu khong ro).

    Chi goi khi da cao ra 0 reel (khong ton them lan tai trang nao)."""
    try:
        from fb_session import DEFAULT_PORT
        tg = list_targets(port or DEFAULT_PORT)
        if not tg:
            return ""
        c = CDP(tg[0]["webSocketDebuggerUrl"])
        try:
            txt = (c.eval("document.body.innerText") or "")[:4000].lower()
        finally:
            c.close()
        for kw in _DEAD_KW:
            if kw in txt:
                return ("Nguồn KHÔNG xem được (đã xoá, đổi sang riêng tư, hoặc bị chặn) — "
                        "Facebook báo: \"Bạn hiện không xem được nội dung này\". "
                        "Đổi link nguồn khác cho page này.")
        return ""
    except Exception:
        return ""


def list_reels(page_url: str, port: int = None, max_scroll: int = 500,
               stable_rounds: int = 4, pause: float = 2.0,
               progress=None) -> dict:
    """Liet ke reel cua page -> index.json. Uu tien API noi bo (nhanh), gay -> cuon.

    Giu nguyen chu ky cu (moi noi goi khong doi). max_scroll = so trang API (10/trang)
    HOAC so lan cuon o duong du phong -> mac dinh 500 = LAY HET (early-stop khi het reel).
    Tat API: env CS_LIST_API=0.
    """
    if os.environ.get("CS_LIST_API", "1") != "0":
        try:
            return list_reels_api(page_url, port=port, max_pages=max_scroll,
                                  progress=progress)
        except Exception as e:
            print("  [list] API loi (%s) -> cuon du phong" % e, flush=True)
    res = list_reels_scroll(page_url, port=port, max_scroll=max_scroll,
                            stable_rounds=stable_rounds, pause=pause,
                            progress=progress)
    # Ra 0 reel -> hoi lai trang xem co phai NGUON DA CHET khong (tab dang o dung trang do).
    if not (res or {}).get("count"):
        why = source_problem(port)
        if why:
            res["problem"] = why
            print("  [list] %s" % why, flush=True)
    return res


if __name__ == "__main__":
    import sys
    url = sys.argv[1] if len(sys.argv) > 1 else "https://www.facebook.com/tuoitho89x/reels/"

    def _p(n, step):
        print("  ...da gom %d reel (buoc cuon %d)" % (n, step), flush=True)

    res = list_reels(url, progress=_p)
    print("XONG: %d reel -> %s" % (res["count"], _index_path(res["page"])))
    # in 5 reel nhieu view nhat
    top = sorted(res["reels"].values(), key=lambda x: x.get("views") or 0, reverse=True)[:5]
    for r in top:
        print("  %8s view | %s" % (r.get("view_text"), r["href"]))
