# -*- coding: utf-8 -*-
"""
DANG REEL BANG CHROME (CDP) — thay cho Graph API token.

Vi sao co: token FB hay bi Meta khoa ("API access blocked" code 200). Duong Chrome
dang NHU NGUOI THAT bang chinh phien Chrome da dang nhap -> khong phu thuoc token.
Bonus: composer co o TIEU DE + o THE ma Graph API KHONG co.

TAT CA ky thuat duoi day DO THAT trong POC 2026-07-25 (reel_id 1571663527918104,
verify Graph API 200). Xem docs/hook-chu-va-dang-bang-chrome.md.

LUONG (composer Business Suite, 3 buoc Tao -> Chinh sua -> Chia se):
  1. mo tab  business.facebook.com/latest/reels_composer?asset_id=<page_id>
  2. hook HTMLInputElement.prototype.click  (chan hop thoai file cua Windows)
  3. click "Them video" -> FB goi input.click() -> ta giu duoc node input
  4. DOM.setFileInputFiles(node, mp4)  -> cho upload 100%
  5. tieu de  : NATIVE SETTER + input/change event   (o <input> React)
  6. mo ta+tag: Input.insertText                     (o div[role=textbox])
  7. the      : Input.insertText + Enter  -> moi the thanh 1 chip
  8. "Tiep" -> "Tiep" -> chon "Chi su dung am thanh goc" -> "Chia se ngay"
  9. nut "Chia se" o FOOTER: PHAI dispatchMouseEvent (element.click() KHONG an)

BA BAY (dung sua lai cho "gon" keo hong):
  - `element.click()` khong bam duoc nut submit cuoi -> Input.dispatchMouseEvent.
  - Text trung nhau: "Chia se" khop CA tab breadcrumb LAN nut footer -> loc theo
    kich thuoc + lay cai `top` LON NHAT.
  - KHONG bam "Quay lai": React reset sach o mo ta.
"""
import json
import os
import time

import fb_session as S

COMPOSER = "https://business.facebook.com/latest/reels_composer?asset_id=%s"

UPLOAD_WAIT = int(os.environ.get("CS_CHROME_UPLOAD_WAIT", "600"))   # cho upload (giay)
STEP_WAIT = float(os.environ.get("CS_CHROME_STEP_WAIT", "6"))       # cho doi buoc


# ────────────────── doi chieu voi Graph truoc khi bao that bai ──────────────────
def _graph_check(page_id, kind, since_ts, caption="", title=""):
    """Hoi Facebook xem bai da len chua. KHONG BAO GIO nem loi ra ngoai —
    duong Chrome phai chay duoc ca khi khong co token."""
    try:
        import fb_verify
        return fb_verify.check_posted(page_id, kind, since_ts, caption, title)
    except Exception as exc:
        return {"state": "error", "why": "khong kiem duoc bang token: %s" % str(exc)[:90]}


def _verdict_note(v):
    """Cau nhac nguoi dung, khac nhau theo muc do chac chan."""
    st = (v or {}).get("state")
    if st == "not_found":
        return "token da kiem: page CHUA co bai moi -> thu lai duoc"
    if st == "unsure":
        return "CAN THAN: %s -> xem page truoc khi thu lai" % (v.get("why") or "")
    return "CHUA kiem duoc bang token (%s) -> XEM PAGE truoc khi thu lai, co the bai DA LEN" % (
        (v or {}).get("why") or st)


# ─────────────────────────── JS dung chung ───────────────────────────
_HOOK = """
(() => {
  if (window.__cs_hooked) return 'hooked';
  window.__cs_hooked = 1; window.__cs_grabbed = null;
  const orig = HTMLInputElement.prototype.click;
  HTMLInputElement.prototype.click = function () {
    if (this.type === 'file') { window.__cs_grabbed = this; return; }   // chan native dialog
    return orig.apply(this, arguments);
  };
  return 'ok';
})()
"""

# Click theo TEXT. `bottom=1` -> lay phan tu THAP NHAT tren man hinh (nut footer,
# tranh trung ten voi tab breadcrumb o dau trang).
_CLICK_TEXT = """
(() => {
  const want = %s, bottom = %s;
  let cands = [...document.querySelectorAll('div[role=button],button,span')]
    .filter(e => want.includes((e.innerText || '').trim()));
  if (bottom) cands = cands.filter(e => { const r = e.getBoundingClientRect();
                                          return r.width > 40 && r.height > 20; });
  if (!cands.length) return 'NOTFOUND';
  cands = cands.map(e => ({e, r: e.getBoundingClientRect()}));
  cands.sort((a, b) => bottom ? b.r.top - a.r.top : a.r.top - b.r.top);
  const el = cands[0].e.closest('div[role=button],button') || cands[0].e;
  if (el.getAttribute('aria-disabled') === 'true') return 'DISABLED';
  el.click();
  return 'ok';
})()
"""

# Toa do TAM cua element tim theo text (doc TU DOM, khong hardcode) -> de dispatch chuot that.
_RECT_TEXT = """
(() => {
  let c = [...document.querySelectorAll('div[role=button],button')]
    .filter(e => (e.innerText || '').trim() === %s)
    .map(e => ({e, r: e.getBoundingClientRect()}))
    .filter(x => x.r.width > 40 && x.r.height > 20)
    .sort((a, b) => b.r.top - a.r.top);
  if (!c.length) return null;
  c[0].e.scrollIntoView({block: 'center'});
  const r = c[0].e.getBoundingClientRect();
  return JSON.stringify({x: r.left + r.width / 2, y: r.top + r.height / 2});
})()
"""

# O <input> React: native setter + input/change (Input.insertText KHONG an - da do).
_SET_INPUT = """
(() => {
  const e = [...document.querySelectorAll('input')]
    .find(x => ((x.getAttribute('aria-label') || '') + (x.placeholder || '')).includes(%s));
  if (!e) return 'NOTFOUND';
  const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  e.focus(); set.call(e, %s);
  e.dispatchEvent(new Event('input', {bubbles: true}));
  e.dispatchEvent(new Event('change', {bubbles: true}));
  return e.value;
})()
"""

_FOCUS = """
(() => {
  const e = [...document.querySelectorAll(%s)]
    .find(x => ((x.getAttribute('aria-label') || '') + (x.placeholder || '')).includes(%s));
  if (!e) return 'NOTFOUND';
  e.focus(); e.click(); return 'ok';
})()
"""

# Chon radio theo CAU MO TA (vd "Chi su dung am thanh goc").
_PICK_RADIO = """
(() => {
  for (const r of document.querySelectorAll('div[role=radio],input[type=radio]')) {
    let p = r, hit = false;
    for (let i = 0; i < 6 && p; i++, p = p.parentElement) {
      const s = (p.innerText || '').trim();
      if (s.includes(%s)) { hit = true; break; }
      if (s.length > 200) break;
    }
    if (hit) { (r.closest('div[role=radio]') || r).click(); return 'ok'; }
  }
  return 'NOTFOUND';
})()
"""

_UPLOAD_PCT = """
(() => {
  const t = document.body.innerText;
  const m = t.match(/(\\d{1,3})\\s*%/);
  return JSON.stringify({pct: m ? +m[1] : -1, safe: t.includes('an toàn để đăng')});
})()
"""

# ── CHIA SE LEN NHOM (buoc cuoi, sau khi da upload) ────────────────────────────
# BAY: dung tim o nhap nhom bang aria-label chua "nhom" — no bat trung CONG TAC
# (aria-label="Chia se len nhom"), bam vao la TAT NGUOC thu vua bat.
_GROUP_SWITCH = """
(() => {
  const e = [...document.querySelectorAll('[role=switch]')].find(
    x => ((x.getAttribute('aria-label') || '') + (x.innerText || '')).includes('Chia sẻ lên nhóm'));
  if (!e) return 'NOTFOUND';
  e.scrollIntoView({block: 'center'});
  const r = e.getBoundingClientRect();
  return JSON.stringify({x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2),
                         on: e.getAttribute('aria-checked') === 'true'});
})()
"""

_GROUP_COMBO = """
(() => {
  const e = document.querySelector('[role=combobox]');
  if (!e) return 'NOTFOUND';
  e.scrollIntoView({block: 'center'});
  const r = e.getBoundingClientRect();
  return JSON.stringify({x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2),
                         open: e.getAttribute('aria-expanded') === 'true',
                         txt: (e.innerText || '').trim().slice(0, 300)});
})()
"""

# Thuoc tinh `id` cua [role=option] CHINH LA group_id — do that 2026-07-27, kiem chung
# bang cach mo facebook.com/groups/<id>: 3/3 ra dung ten nhom.
_GROUP_OPTS = """
(() => {
  const out = [...document.querySelectorAll('[role=option]')].map(o => {
    const t = (o.innerText || '').replace(/\\n+/g, ' | ');
    const nm = t.split('|')[0].trim();
    const mm = t.match(/([\\d.,]+)\\s*thành viên/);
    return {id: o.id || '', name: nm,
            members: mm ? +mm[1].replace(/[.,]/g, '') : 0,
            sel: o.getAttribute('aria-selected') === 'true'};
  });
  return JSON.stringify(out.filter(x => x.id && x.name));
})()
"""

_GROUP_OPT_RECT = """
(() => {
  const o = [...document.querySelectorAll('[role=option]')].find(x => x.id === %s);
  if (!o) return 'NOTFOUND';
  o.scrollIntoView({block: 'center'});
  const r = o.getBoundingClientRect();
  if (r.width < 2 || r.height < 2) return 'HIDDEN';
  return JSON.stringify({x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2),
                         sel: o.getAttribute('aria-selected') === 'true'});
})()
"""


def _log(msg):
    """Ghi nhat ky — KHONG BAO GIO duoc nem loi.

    DO THAT 2026-07-27: ten nhom tieng Viet ("HỒI ỨC") + stdout cp1252 (console Windows,
    khi khong co PYTHONIOENCODING) -> print() nem UnicodeEncodeError NGAY GIUA
    share_to_groups -> khau chon nhom chet -> bai dang MAT NHOM ma khong ro ly do.
    Mot ham ghi log khong duoc phep lam hong nghiep vu.
    """
    try:
        print("[chrome-post] %s" % msg, flush=True)
    except Exception:
        try:
            s = str(msg).encode("ascii", "replace").decode("ascii")
            print("[chrome-post] %s" % s, flush=True)
        except Exception:
            pass


def _tab_for(port, url):
    """Mo tab moi toi url, tra ve target."""
    import urllib.request
    req = urllib.request.Request("http://127.0.0.1:%d/json/new?%s" % (port, url), method="PUT")
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def _close_tab(port, tid):
    """Dong tab vua dang xong, nhung LUON chua lai 1 tab mac dinh.

    Neu day la tab CUOI CUNG thi dong xong Chrome tat theo -> mat phien dang nhap,
    bai ke tiep trong kho cho se fail 'Chrome chua mo'. Nen mo truoc 1 tab trang.
    """
    import urllib.request
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/list" % port, timeout=8) as r:
            pages = [t for t in json.loads(r.read().decode("utf-8"))
                     if t.get("type") == "page"]
        if len([t for t in pages if t.get("id") != tid]) == 0:
            _tab_for(port, "about:blank")          # giu Chrome song
    except Exception:
        pass
    try:
        urllib.request.urlopen("http://127.0.0.1:%d/json/close/%s" % (port, tid), timeout=8)
    except Exception:
        pass


def _real_click(c, x, y):
    """Click CHUOT THAT (nut submit cuoi KHONG nhan element.click())."""
    c.send("Input.dispatchMouseEvent", {"type": "mouseMoved", "x": x, "y": y})
    time.sleep(0.1)
    for typ in ("mousePressed", "mouseReleased"):
        c.send("Input.dispatchMouseEvent", {"type": typ, "x": x, "y": y,
                                            "button": "left", "clickCount": 1})
        time.sleep(0.1)


def _wait_text(c, words, timeout=90):
    """Cho toi khi trang HIEN 1 trong cac cum tu (composer render xong).

    KHONG duoc cho theo do dai innerText: sidebar Business Suite da co san vai tram ky tu
    nen dieu kien do thoa SOM khi composer con dang quay vong -> tim nut khong thay (da do that).
    """
    js = ("(() => { const t = document.body.innerText; return %s.some(w => t.includes(w)) ? 1 : 0; })()"
          % json.dumps(list(words)))
    end = time.time() + timeout
    while time.time() < end:
        try:
            if c.eval(js):
                return True
        except Exception:
            pass
        time.sleep(2)
    return False


def _enter(c):
    for typ in ("keyDown", "keyUp"):
        c.send("Input.dispatchKeyEvent", {"type": typ, "key": "Enter", "code": "Enter",
                                          "windowsVirtualKeyCode": 13})
    time.sleep(0.6)


_LAST_STEP = """
(() => {
  const t = document.body.innerText || '';
  const sw = [...document.querySelectorAll('[role=switch]')].some(
    x => ((x.getAttribute('aria-label') || '') + (x.innerText || '')).includes('Chia sẻ lên nhóm'));
  const au = t.includes('Chỉ sử dụng âm thanh gốc') || t.includes('Cho phép remix');
  const sc = t.includes('Chia sẻ ngay') || t.includes('Lên lịch');
  return JSON.stringify({sw: sw, au: au, sc: sc});
})()
"""


def _at_last_step(c) -> bool:
    """Buoc CUOI cua composer = noi co am thanh goc / lich dang / chia se len nhom."""
    try:
        d = json.loads(c.eval(_LAST_STEP) or "{}")
    except Exception:
        return False
    return bool(d.get("sw") or d.get("au") or d.get("sc"))


def _esc(c):
    for typ in ("keyDown", "keyUp"):
        c.send("Input.dispatchKeyEvent", {"type": typ, "key": "Escape", "code": "Escape",
                                          "windowsVirtualKeyCode": 27})
    time.sleep(0.8)


_GROUP_INPUT = """
(() => {
  const e = document.querySelector('[role=combobox]');
  if (!e) return 'NOTFOUND';
  const i = e.querySelector('input') || e;
  i.focus();
  return JSON.stringify({len: (i.value || '').length});
})()
"""


def _group_filter(c, text: str) -> bool:
    """Go TEN nhom vao o loc cua danh sach nhom.

    Vi sao can: danh sach nhom TAI DUNG DOM — do that 2026-07-27, page co 26 nhom nhung
    moi luc chi ve ~13 the, cuon cung khong tich luy (13 -> 15 -> 13). Nhom nam sau danh
    sach thi khong bao gio co the de bam. Go ten vao o loc thi no hien ra.
    """
    raw = c.eval(_GROUP_INPUT)
    if raw == "NOTFOUND" or not raw:
        return False
    try:
        n = int(json.loads(raw).get("len") or 0)
    except Exception:
        n = 40
    for _ in range(min(n, 60) + 2):        # xoa chu loc cu truoc khi go chu moi
        for typ in ("keyDown", "keyUp"):
            c.send("Input.dispatchKeyEvent", {"type": typ, "key": "Backspace",
                                              "code": "Backspace", "windowsVirtualKeyCode": 8})
    if text:
        c.send("Input.insertText", {"text": text})
    time.sleep(4)
    return True


def _group_switch_off(c):
    """Tat lai cong tac 'Chia se len nhom'. Bat ma khong chon nhom nao thi FB co the
    chan nut 'Chia se' -> bai khong len duoc."""
    try:
        raw = c.eval(_GROUP_SWITCH)
        if raw not in ("NOTFOUND", "", None):
            p = json.loads(raw)
            if p.get("on"):
                _real_click(c, p["x"], p["y"])
                time.sleep(2)
    except Exception:
        pass


def open_group_list(c, log=None) -> dict:
    """O buoc CUOI: bat cong tac + mo o 'Chon nhom' -> {opts: [{id,name,members}], why}.

    Dung chung cho CA hai duong: dang bai (tick nhom) va quet nhom (chi doc).
    """
    log = log or _log
    # Cong tac chi hien khi buoc CUOI da render xong — do that: co lan hien ngay, co lan
    # cham vai chuc giay. Kiem mot phat la bao nham "page khong co nhom".
    raw = ""
    for _ in range(15):
        raw = c.eval(_GROUP_SWITCH) or ""
        if raw and raw != "NOTFOUND":
            break
        time.sleep(3)
    if raw == "NOTFOUND" or not raw:
        try:
            tail = (c.eval("document.body.innerText") or "")[-260:].replace("\n", " / ")
        except Exception:
            tail = ""
        return {"opts": [],
                "why": "khong thay muc 'Chia se len nhom' sau 45s (man hinh: %s)" % tail}
    sw = json.loads(raw)
    if not sw.get("on"):
        _real_click(c, sw["x"], sw["y"])
        time.sleep(4)

    raw = c.eval(_GROUP_COMBO)
    if raw == "NOTFOUND" or not raw:
        return {"opts": [], "why": "bat cong tac roi nhung khong thay o 'Chon nhom'"}
    cb = json.loads(raw)
    if not cb.get("open"):
        _real_click(c, cb["x"], cb["y"])
        time.sleep(5)

    opts = []
    for _ in range(3):
        try:
            opts = json.loads(c.eval(_GROUP_OPTS) or "[]")
        except Exception:
            opts = []
        if opts:
            break
        time.sleep(3)
    if not opts:
        return {"opts": [], "why": "page chua tham gia nhom nao"}
    return {"opts": opts, "why": ""}


_GROUP_OPEN = """
(() => {
  let n = 0;
  document.querySelectorAll('[role=option]').forEach(o => {
    const r = o.getBoundingClientRect();
    if (r.width > 2 && r.height > 2) n++;
  });
  const cb = document.querySelector('[role=combobox]');
  return JSON.stringify({n: n, exp: !!(cb && cb.getAttribute('aria-expanded') === 'true')});
})()
"""


_BLUR = """
(() => {
  try { if (document.activeElement && document.activeElement.blur)
          document.activeElement.blur(); } catch (e) {}
  ['keydown', 'keyup'].forEach(t => document.dispatchEvent(
    new KeyboardEvent(t, {key: 'Escape', code: 'Escape', keyCode: 27,
                          which: 27, bubbles: true})));
  return 'ok';
})()
"""

# Diem TRONG an toan de bam ra ngoai danh sach: tieu de cot xem truoc. Chon phan tu co
# CHU RIENG (khong phai nut, khong phai nhan cua cong tac — bam nham nhan la TAT cong tac
# vua bat). Bam tam phan tu, va chi nhan phan tu HEP de khong trum sang o chon nhom.
_BLANK_SPOT = r"""
(() => {
  const e = [...document.querySelectorAll('span,h2,h3,div')].find(x => {
    const t = (x.innerText || '').trim();
    if (!/^(Bản xem trước thước phim|Bản xem trước|Ai có thể xem thước phim này\?)/.test(t))
      return false;
    const r = x.getBoundingClientRect();
    return r.width > 40 && r.width < 460 && r.height > 8 && r.height < 90 && r.top > 40;
  });
  if (!e) return 'NOTFOUND';
  const r = e.getBoundingClientRect();
  return JSON.stringify({x: Math.round(r.x + r.width / 2),
                         y: Math.round(r.y + r.height / 2)});
})()
"""


def _close_group_list(c, log=None) -> bool:
    """Dong han danh sach nhom. True = da sach.

    Vi sao PHAI co: danh sach con mo thi cu bam nut gui roi vao LOP PHU (chi de dong no)
    chu khong trung nut -> cho het gio roi bao loi tren bai CHUA HE gui. Duong ANH da dinh
    dung loi nay (treo 180s, Graph xac nhan bai khong len).

    DO THAT 2026-07-27: Escape dong duoc khi danh sach VUA MO, nhung SAU KHI DA TICK nhom
    thi 6 lan Escape van khong an (n=13, exp=true) -> phai co cach 2 va 3.
    KHONG dung cach "bam lai o combobox" (duong anh dung duoc): o composer reel no la
    TOGGLE, bam vao lai MO RA (do that: n 13 -> 13).
    """
    log = log or _log

    def st():
        try:
            return json.loads(c.eval(_GROUP_OPEN) or "{}")
        except Exception:
            return None

    for i in range(6):
        s = st()
        if s is None:
            return True                      # khong doc duoc thi dung chan buoc dang
        if not s.get("n") and not s.get("exp"):
            return True
        log("con danh sach nhom mo (%d muc) -> dong (lan %d)" % (s.get("n", 0), i + 1))
        # Khau DON DEP: hong o day khong duoc phep lam hong ca bai dang.
        try:
            if i == 0:
                _esc(c)                      # cach 1: phim Escape that
            elif i == 1:
                c.eval(_BLUR)                # cach 2: bo focus + Escape o tang document
            else:
                raw = c.eval(_BLANK_SPOT)    # cach 3: bam ra vung TRONG ngoai danh sach
                p = json.loads(raw) if raw not in ("NOTFOUND", "", None) else {}
                if "x" in p and "y" in p:
                    _real_click(c, p["x"], p["y"])
                else:
                    _esc(c)
        except Exception as e:
            log("loi khi dong danh sach nhom (bo qua): %s" % str(e)[:120])
        time.sleep(1.6)
    return False


def share_to_groups(c, page_id: str, n_max: int = 0, log=None) -> dict:
    """O buoc CUOI cua composer: bat 'Chia se len nhom' + tick nhom theo luat xoay vong.

    Tra {groups: [{id,name}], why: 'ly do neu khong kem nhom'}.
    KHONG BAO GIO nem loi: page khong co nhom thi bai VAN dang binh thuong (nguoi dung
    chot: "khong co nhom thi van dang, chi bao la khong kem nhom").
    """
    log = log or _log
    import fb_groups

    def off_and_quit(why):
        _group_switch_off(c)
        return {"groups": [], "why": why}

    r0 = open_group_list(c, log)
    opts = r0["opts"]
    if not opts:
        return off_and_quit(r0["why"])

    # prune=False: composer TAI DUNG DOM, moi luc chi ve ~13 the du page co 26 nhom ->
    # ghi de kieu day-du se AN MAT nhung nhom chua duoc ve (do that: kho 26 -> 13).
    fb_groups.set_groups(page_id, opts, prune=False)
    want = fb_groups.pick(page_id, n_max or fb_groups.GROUP_MAX, advance=False)
    log("nhom: page co %d, luot nay chon %s"
        % (len(opts), ", ".join(g.get("name", "") for g in want)))

    picked = []
    for g in want:
        r = c.eval(_GROUP_OPT_RECT % json.dumps(str(g["id"])))
        if r in ("NOTFOUND", "HIDDEN", "", None):
            # danh sach co the DONG sau moi lan tick -> mo lai roi thu them 1 lan
            try:
                cb2 = json.loads(c.eval(_GROUP_COMBO) or "{}")
                if cb2 and not cb2.get("open"):
                    _real_click(c, cb2["x"], cb2["y"])
                    time.sleep(4)
            except Exception:
                pass
            r = c.eval(_GROUP_OPT_RECT % json.dumps(str(g["id"])))
        if r in ("NOTFOUND", "HIDDEN", "", None):
            # Chua co the -> LOC THEO TEN. Danh sach tai dung DOM nen nhom nam sau khong
            # bao gio duoc ve san; go ten thi no hien. Van tick theo ID: loc "NHUNG CAU NOI
            # HAY" ra 7 nhom ten gan giong nhau, bam theo ten la trung nham nhom khac.
            _group_filter(c, (g.get("name") or "")[:18])
            r = c.eval(_GROUP_OPT_RECT % json.dumps(str(g["id"])))
        if r in ("NOTFOUND", "HIDDEN", "", None):
            log("canh bao: khong tick duoc nhom %s (%s)" % (g.get("name"), g.get("id")))
            continue
        p = json.loads(r)
        if not p.get("sel"):
            _real_click(c, p["x"], p["y"])
            time.sleep(1.8)
        # xac nhan da tick THAT (doc lai aria-selected), khong tin cu bam
        try:
            cur = {o["id"]: o for o in json.loads(c.eval(_GROUP_OPTS) or "[]")}
            if not (cur.get(str(g["id"])) or {}).get("sel"):
                log("canh bao: bam roi nhung nhom %s chua duoc chon" % g.get("name"))
                continue
        except Exception:
            pass
        picked.append(g)

    _group_filter(c, "")                       # xoa chu loc, tra danh sach ve nguyen trang
    _esc(c)                                    # dong danh sach truoc khi bam Chia se
    # Nhich dung so nhom TICK DUOC -> nhom hut se duoc thu lai o bai sau.
    # NGOAI LE: tick duoc 0 thi VAN phai nhich 1. Khong thi con tro dung yen, moi bai sau
    # deu thu lai dung 3 nhom do va deu truot -> page co 23 nhom ma VINH VIEN khong kem
    # nhom nao, lai khong bao loi. Duong anh khong dinh vi pick_from() chi lay nhom dang hien.
    fb_groups.advance(page_id, len(picked) or 1)
    if not picked:
        return off_and_quit("co %d nhom nhung khong tick duoc nhom nao" % len(opts))
    # Doi chieu voi chinh giao dien: FB tu ghi "Da chon N nhom". Lech = co nhom tuot ma
    # ta khong biet -> ghi ro thay vi bao dai thang loi.
    try:
        import re as _re
        txt = json.loads(c.eval(_GROUP_COMBO) or "{}").get("txt") or ""
        m = _re.search(r"[Đđ]ã chọn\s+(\d+)\s+nhóm", txt)
        if m and int(m.group(1)) != len(picked):
            log("canh bao: ta tick %d nhom nhung FB bao '%s'" % (len(picked), m.group(0)))
    except Exception:
        pass
    return {"groups": picked, "why": ""}


def scan_groups(page_id: str, video: str, port: int = S.DEFAULT_PORT,
                keep_tab: bool = False) -> dict:
    """QUET danh sach nhom cua 1 page: di het composer toi buoc cuoi de doc, KHONG DANG.

    Phai upload video that vi muc chon nhom chi hien SAU khi da co video (do that
    2026-07-27) -> moi page ton ~1-2 phut. Video dung gi cung duoc, no khong bao gio
    duoc gui di. Tra {page_id, groups, why, seconds}.
    """
    import fb_groups
    if not os.path.isfile(video):
        raise ChromePostError("Khong thay file video de quet: %s" % video)
    if not S.is_alive(port):
        raise ChromePostError("Chrome chua mo (cong CDP %d)." % port)

    t0 = time.time()
    tab = _tab_for(port, COMPOSER % page_id)
    c = S.CDP(tab["webSocketDebuggerUrl"])
    try:
        c.send("DOM.enable"); c.send("Runtime.enable"); c.send("Page.enable")
        if not _wait_text(c, ["Thêm video", "File phương tiện"], timeout=120):
            t = (c.eval("document.body.innerText") or "")[:2000].lower()
            if "không khả dụng" in t or "isn't available" in t:
                raise ChromePostError("Tai khoan Chrome KHONG co quyen vao page nay")
            raise ChromePostError("Composer khong render sau 120s")

        c.eval(_HOOK)
        if c.eval(_CLICK_TEXT % (json.dumps(["Thêm video"]), "0")) != "ok":
            raise ChromePostError("Khong thay nut 'Them video'")
        for _ in range(15):
            time.sleep(1)
            if c.eval("window.__cs_grabbed ? 1 : 0"):
                break
        r = c.send("Runtime.evaluate", {"expression": "window.__cs_grabbed",
                                        "returnByValue": False})
        c.send("DOM.setFileInputFiles", {"objectId": r["result"]["objectId"], "files": [video]})
        end = time.time() + UPLOAD_WAIT
        ok_up = False
        while time.time() < end:
            time.sleep(3)
            try:
                d = json.loads(c.eval(_UPLOAD_PCT) or "{}")
            except Exception:
                d = {}
            if d.get("safe") or d.get("pct") == 100:
                ok_up = True
                break
        if not ok_up:
            raise ChromePostError("Upload video khong xong sau %ds" % UPLOAD_WAIT)

        c.eval(_SET_INPUT % (json.dumps("tiêu đề"), json.dumps("quét nhóm")))
        if not _at_last_step(c):
            for _ in range(4):
                c.eval(_CLICK_TEXT % (json.dumps(["Tiếp"]), "1"))
                time.sleep(STEP_WAIT)
                if _at_last_step(c):
                    break
        res = open_group_list(c)
        opts = res["opts"]
        if opts:
            fb_groups.set_groups(page_id, opts)
        _group_switch_off(c)          # tra giao dien ve nguyen trang
        _log("quet nhom page %s: %d nhom" % (page_id, len(opts)))
        return {"page_id": page_id, "groups": opts, "why": res["why"],
                "seconds": round(time.time() - t0, 1)}
    finally:
        try:
            c.close()
        except Exception:
            pass
        if not keep_tab:
            _close_tab(port, tab["id"])


# ── CHIA SE LEN NHOM cho BAI VIET ANH (giao dien KHAC HAN Reels) ──────────────
# DO THAT 2026-07-27:
#   - Nam trong dropdown "Dang len" ([role=combobox] co aria-haspopup=listbox), khong phai
#     cong tac nhu Reels. Mo ra moi thay muc "Dang len Nhom Facebook".
#   - Luc dau chi hien 1 nhom; phai bam "Xem them cac nhom" -> ra 7 nhom. CUON KHONG RA
#     THEM (NOSCROLL) du kho co 26 -> chi chon duoc trong so hien ra.
#   - O tick KHONG mang group_id (chi co id React kieu js_q4) -> nhan dien bang MA ANH
#     DAI DIEN (co o ca 2 ben) chu khong bang ten: danh sach nay co ca
#     "CAU NOI HAY Y NGHIA @" lan "CAU NOI HAY Y NGHIA".
#   - Van gioi han 3: bam nhom thu 4 khong an, FB ghi "Chon toi da 3 nhom de dang bai viet".
_PH_DD = """
(() => {
  const e = [...document.querySelectorAll('[role=combobox]')]
    .find(x => x.getAttribute('aria-haspopup') === 'listbox');
  if (!e) return 'NOTFOUND';
  e.scrollIntoView({block: 'center'});
  const r = e.getBoundingClientRect();
  return JSON.stringify({x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2)});
})()
"""

_PH_MORE = """
(() => {
  const e = [...document.querySelectorAll('div[role=button],a,span')]
    .find(x => /Xem thêm các nhóm/.test((x.innerText || '').trim())
               && x.getBoundingClientRect().width > 10);
  if (!e) return 'NOTFOUND';
  e.scrollIntoView({block: 'center'});
  const r = e.getBoundingClientRect();
  return JSON.stringify({x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2)});
})()
"""

_PH_ROWS = r"""
(() => {
  const out = [];
  document.querySelectorAll('[role=checkbox],input[type=checkbox]').forEach(e => {
    const box = e.closest('label,li,div[role=listitem]') || e.parentElement;
    if (!box) return;
    const t = (box.innerText || '').replace(/\n+/g, ' | ');
    if (!/Nhóm/.test(t)) return;                       // bo o tick khong phai nhom
    const img = box.querySelector('img');
    const m = img ? (img.src || '').match(/\/(\d+_\d+_\d+)_n\./) : null;
    const r = e.getBoundingClientRect();
    out.push({name: t.split('|')[0].trim(), cover: m ? m[1] : '',
              checked: e.getAttribute('aria-checked') === 'true' || e.checked === true,
              x: Math.round(r.x + r.width / 2), y: Math.round(r.y + r.height / 2),
              vis: r.width > 2 && r.height > 2});
  });
  return JSON.stringify(out);
})()
"""


def share_to_groups_photo(c, page_id: str, n_max: int = 0, log=None) -> dict:
    """Bai viet ANH: mo dropdown "Dang len" -> "Xem them cac nhom" -> tick theo xoay vong.

    Tra {groups: [{id,name}], why}. KHONG BAO GIO nem loi — page khong co nhom thi bai
    van dang binh thuong.
    """
    log = log or _log
    import fb_groups

    def rows():
        try:
            return json.loads(c.eval(_PH_ROWS) or "[]")
        except Exception:
            return []

    raw = c.eval(_PH_DD)
    if raw in ("NOTFOUND", "", None):
        return {"groups": [], "why": "khong thay o 'Dang len' de mo danh sach nhom"}
    p = json.loads(raw)
    _real_click(c, p["x"], p["y"])
    time.sleep(5)

    if not rows():                              # danh sach nhom nam sau nut "Xem them"
        m = c.eval(_PH_MORE)
        if m not in ("NOTFOUND", "", None):
            pm = json.loads(m)
            _real_click(c, pm["x"], pm["y"])
            time.sleep(7)
    cur = [r for r in rows() if r.get("vis")]
    if not cur:
        return {"groups": [], "why": "page chua tham gia nhom nao (hoac FB khong hien muc nhom)"}

    # Chi xoay vong TRONG SO nhom dang hien — composer anh khong cho cuon ra them.
    present = {r["cover"] for r in cur if r["cover"]} | {r["name"] for r in cur}
    # kind="photo": bai anh co danh sach nhom RIENG (suggested_groups, 7 nhom) khac
    # danh sach cua reel (26) -> phai xoay vong bang so rieng, khong thi hai luong pha nhau.
    want = fb_groups.pick_from(page_id, present, n_max or fb_groups.GROUP_MAX,
                               advance_cur=False, kind="photo")
    if not want:
        return {"groups": [], "why": "%d nhom tren man hinh khong khop kho da quet "
                                     "(quet lai nhom?)" % len(cur)}
    def find(g, rs):
        """Tim dong cua nhom g. Uu tien MA ANH DAI DIEN; het cach moi khop ten."""
        for r in rs:
            if g.get("cover") and r.get("cover") == g["cover"]:
                return r
        # Khop ten CHI khi duy nhat 1 dong trung — dung sach nay co nhung nhom ten gan
        # giong het nhau ("CAU NOI HAY Y NGHIA @" vs "CAU NOI HAY Y NGHIA"), tick nham
        # la dang vao nhom khac. Nhieu dong trung ten -> BO QUA con hon dang sai cho.
        nm = (g.get("name") or "").strip()
        if not nm:
            return None
        same = [r for r in rs if (r.get("name") or "").strip() == nm]
        if len(same) == 1:
            return same[0]
        if same:
            log("bo qua nhom %r: %d dong trung ten ma nhom nay khong co ma anh de phan biet"
                % (nm[:40], len(same)))
        return None

    picked = []
    for g in want:
        # DOC LAI vi tri NGAY TRUOC moi cu bam: tick xong Facebook SAP XEP LAI danh sach
        # (nhom da chon nhay len dau) -> toa do doc tu dau bi lech, bam truot sang dong
        # khac hoac vao cho trong. Do that 2026-07-27: dung toa do cu thi nhom thu 3 truot.
        row = find(g, [r for r in rows() if r.get("vis")])
        if not row:
            log("canh bao: khong thay dong nhom %s tren man hinh" % g.get("name"))
            continue
        if not row.get("checked"):
            _real_click(c, row["x"], row["y"])
            time.sleep(2)
        got = find(g, rows())
        if not (got or {}).get("checked"):
            log("canh bao: bam roi nhung nhom %s chua duoc tick" % g.get("name"))
            continue
        picked.append(g)
    # Nhich con tro dung so nhom da tick de bai sau di tiep, khong lap lai nhom cu.
    # Tick duoc 0 ma van co nhom de thu (want khac rong) thi VAN nhich 1 — khong thi con
    # tro dung yen va bai sau lai thu dung nhung nhom vua truot. Cung ly do voi duong reel;
    # o day nhe hon vi FB xoay danh sach goi y theo thoi gian nen thuong tu thoat ket.
    fb_groups.advance(page_id, len(picked) or 1, kind="photo")

    # PHAI DONG dropdown truoc khi ra. Khong dong thi lop phu con do -> cu bam "Dang"
    # dau tien roi vao lop phu (chi de dong no) chu KHONG trung nut -> cho 180s roi bao
    # loi trong khi bai chua he duoc gui. Do that 2026-07-27: bai dau tien cua lot chay
    # 22h chet dung kieu nay (Graph xac nhan bai KHONG len).
    _esc(c)
    for _ in range(6):
        try:
            cb = json.loads(c.eval(_PH_DD) or "{}")
        except Exception:
            break
        if not [r for r in rows() if r.get("vis")]:     # khong con dong nhom nao hien
            break
        _real_click(c, cb["x"], cb["y"])                # bam lai chinh o do de dong
        time.sleep(1.5)
    time.sleep(1)
    return {"groups": picked,
            "why": "" if picked else "co %d nhom nhung khong tick duoc nhom nao" % len(cur)}


class ChromePostError(RuntimeError):
    """Loi doc duoc de ghi thang vao pipeline item."""


def post_reel(page_id: str, video: str, caption: str = "", title: str = "",
              tags=None, port: int = S.DEFAULT_PORT, audio_mode: str = "original_only",
              shot_dir: str = "", keep_tab: bool = False,
              share_groups: bool = True, group_max: int = 0) -> dict:
    """Dang 1 reel len page bang Chrome. Tra {ok, page_id, video, seconds, groups}.

    audio_mode  : 'original_only' (mac dinh, "Chi su dung am thanh goc")
                | 'remix' (cho remix)  | 'none' (khong cho phep)
    shot_dir    : co thi chup man hinh khi LOI (bang chung, theo rule #1).
    share_groups: tick nhom theo luat xoay vong (Facebook gioi han 3 nhom/bai).
                  Page khong co nhom -> van dang binh thuong, chi bao khong kem nhom.
    Nem ChromePostError voi ly do DOC DUOC neu that bai.
    """
    if not os.path.isfile(video):
        raise ChromePostError("Khong thay file video: %s" % video)
    if not S.is_alive(port):
        raise ChromePostError("Chrome chua mo (cong CDP %d). Mo phien Chrome truoc." % port)
    if not S.logged_in(port):
        raise ChromePostError("Chrome chua dang nhap Facebook (thieu cookie c_user).")

    tags = [t for t in (tags or []) if str(t).strip()]
    t0 = time.time()
    tab = _tab_for(port, COMPOSER % page_id)
    c = S.CDP(tab["webSocketDebuggerUrl"])

    def shot(name):
        if not shot_dir:
            return ""
        try:
            import base64
            os.makedirs(shot_dir, exist_ok=True)
            r = c.send("Page.captureScreenshot", {"format": "png"}, timeout=60)
            p = os.path.join(shot_dir, "%s_%s.png" % (page_id, name))
            open(p, "wb").write(base64.b64decode(r["data"]))
            return p
        except Exception:
            return ""

    def fail(msg, step):
        p = shot("loi_" + step)
        _close_tab(port, tab["id"]) if not keep_tab else None
        raise ChromePostError("%s (buoc: %s)%s" % (msg, step, (" · anh: %s" % p) if p else ""))

    def _why_no_composer():
        """DOC chu FB dang hien -> ly do THAT, thay vi doan 'mang cham / FB doi giao dien'.

        Ca hay gap nhat: tai khoan dang nhap trong Chrome KHONG quan tri page do (token
        Graph la System User cua BM, KHAC tai khoan nguoi that dang nhap trinh duyet) ->
        FB tra "Rat tiec, noi dung nay hien khong kha dung". Do that 2026-07-27."""
        try:
            t = (c.eval("document.body.innerText") or "")[:3000].lower()
        except Exception:
            return ""
        if "không khả dụng" in t or "isn't available" in t or "not available" in t:
            return ("TAI KHOAN CHROME KHONG CO QUYEN vao page nay (FB bao 'noi dung nay hien "
                    "khong kha dung'). Token Graph vao duoc khong co nghia trinh duyet vao duoc "
                    "— day la 2 tai khoan khac nhau. Dang nhap Chrome bang tai khoan QUAN TRI "
                    "page, hoac dang page nay bang duong Token")
        if "đăng nhập" in t or "log in" in t or "log into" in t:
            return "Chrome CHUA DANG NHAP Facebook (hoac phien het han) — dang nhap lai o tab Tai khoan"
        if "tạm thời bị chặn" in t or "temporarily blocked" in t:
            return "Tai khoan Chrome dang BI FB CHAN tam thoi — cho roi thu lai"
        return ""

    try:
        c.send("DOM.enable"); c.send("Runtime.enable"); c.send("Page.enable")
        if not _wait_text(c, ["Thêm video", "File phương tiện"], timeout=120):
            fail(_why_no_composer()
                 or "Composer Reels khong render sau 120s (mang cham / FB doi giao dien?)",
                 "mo_composer")

        # ── 1. nap video ──
        c.eval(_HOOK)
        if c.eval(_CLICK_TEXT % (json.dumps(["Thêm video"]), "0")) != "ok":
            fail("Khong thay nut 'Them video' (composer doi giao dien?)", "them_video")
        grabbed = False
        for _ in range(15):
            time.sleep(1)
            if c.eval("window.__cs_grabbed ? 1 : 0"):
                grabbed = True
                break
        if not grabbed:
            fail("Khong bat duoc o chon file (hook input.click that bai)", "hook_input")
        r = c.send("Runtime.evaluate", {"expression": "window.__cs_grabbed", "returnByValue": False})
        c.send("DOM.setFileInputFiles", {"objectId": r["result"]["objectId"], "files": [video]})
        _log("da nap %s" % os.path.basename(video))

        # cho upload xong. LUU Y: input.files doc ra 0 du upload THAT thanh cong ->
        # bam vao % tien do / cau "an toan de dang", KHONG bam vao input.files.
        end = time.time() + UPLOAD_WAIT
        ok_up = False
        while time.time() < end:
            time.sleep(3)
            try:
                d = json.loads(c.eval(_UPLOAD_PCT) or "{}")
            except Exception:
                d = {}
            if d.get("safe") or d.get("pct") == 100:
                ok_up = True
                break
        if not ok_up:
            fail("Upload video khong xong sau %ds" % UPLOAD_WAIT, "upload")
        _log("upload xong (%.0fs)" % (time.time() - t0))

        # ── 2. tieu de / mo ta / the (dien MOT LUOT, KHONG quay lai buoc) ──
        if title:
            v = c.eval(_SET_INPUT % (json.dumps("tiêu đề"), json.dumps(title)))
            if v == "NOTFOUND":
                _log("canh bao: khong thay o Tieu de, bo qua")
        if caption:
            if c.eval(_FOCUS % (json.dumps("div[role=textbox],textarea"),
                                json.dumps("văn bản"))) == "NOTFOUND":
                fail("Khong thay o Mo ta", "mo_ta")
            c.send("Input.insertText", {"text": caption})
            time.sleep(1)
        if tags:
            if c.eval(_FOCUS % (json.dumps("input,div[role=textbox]"),
                                json.dumps("từ khóa"))) == "ok":
                for tg in tags[:10]:
                    c.send("Input.insertText", {"text": str(tg).lstrip("#")})
                    time.sleep(0.5)
                    _enter(c)
            else:
                _log("canh bao: khong thay o The, bo qua")

        # ── 3. Bam "Tiep" CHO TOI KHI toi buoc cuoi ──
        # Truoc day bam cung 2 lan: co lan FB tra nut o trang thai DISABLED (dang luu nhap)
        # -> cu bam la mat 1 buoc -> ket o buoc giua, khong thay muc chon nhom. Do that
        # 2026-07-27: cung 1 luong, lan chay nay du 2 lan, lan sau thieu.
        if not _at_last_step(c):
            for i in range(4):
                r = c.eval(_CLICK_TEXT % (json.dumps(["Tiếp"]), "1"))
                time.sleep(STEP_WAIT)
                if _at_last_step(c):
                    break
                _log("chua toi buoc cuoi sau lan bam 'Tiep' thu %d (ket qua: %s)" % (i + 1, r))
        if not _at_last_step(c):
            _log("canh bao: khong chac da toi buoc cuoi")

        # ── 4. am thanh goc + dang ngay ──
        want = {"original_only": "Chỉ sử dụng âm thanh gốc",
                "remix": "Cho phép remix và sử dụng âm thanh gốc",
                "none": "Không cho phép remix hoặc sử dụng âm thanh gốc"}.get(
                    audio_mode, "Chỉ sử dụng âm thanh gốc")
        if c.eval(_PICK_RADIO % json.dumps(want)) != "ok":
            _log("canh bao: khong chon duoc '%s' (giu mac dinh FB)" % want)
        time.sleep(1.5)
        c.eval(_CLICK_TEXT % (json.dumps(["Chia sẻ ngay"]), "0"))
        time.sleep(1.5)

        # ── 4b. chia se len nhom (khong co nhom -> van dang binh thuong) ──
        gres = {"groups": [], "why": "tat theo cau hinh"}
        if share_groups:
            try:
                gres = share_to_groups(c, page_id, n_max=group_max)
            except Exception as e:      # khau phu: KHONG duoc lam hong ca bai dang
                gres = {"groups": [], "why": "loi khi chon nhom: %s" % str(e)[:200]}
                _log("canh bao: %s" % gres["why"])
                # Loi GIUA CHUNG de lai giao dien do dang: cong tac co the DANG BAT ma
                # khong nhom nao duoc chon -> FB CHAN nut "Chia se" -> bai khong bao gio
                # len. Tra ve trang thai an toan roi moi di tiep.
                try:
                    _esc(c)
                    _group_switch_off(c)
                except Exception:
                    pass
        if gres["groups"]:
            _log("se chia se len %d nhom: %s"
                 % (len(gres["groups"]), ", ".join(g["name"] for g in gres["groups"])))
        else:
            _log("khong kem nhom (%s)" % (gres.get("why") or "khong ro"))

        # ── 5. nut "Chia se" FOOTER: PHAI chuot that ──
        _close_group_list(c)          # chot chan: lop phu con mo thi cu bam se truot
        raw = c.eval(_RECT_TEXT % json.dumps("Chia sẻ"))
        if not raw:
            fail("Khong thay nut 'Chia se' o footer", "nut_chia_se")
        pt = json.loads(raw)
        t_send = int(time.time())          # moc gui: cua so de doi chieu voi Graph
        _real_click(c, pt["x"], pt["y"])
        _log("da bam Chia se, cho FB xu ly...")

        # DO THAT: FB ket thuc theo 2 KIEU khac nhau (tuy luc) — phai chap nhan CA HAI:
        #   (a) chuyen trang sang Lich noi dung (roi composer)
        #   (b) O LAI composer nhung hien hop "Dang xu ly thuoc phim ... he thong se dang"
        #       + nut "Xong"  -> BAI DA GUI THANH CONG (da verify Graph: reel 890127297020837).
        # Chi cho (a) la bao FAIL oan tren bai DA DANG -> se dang lai lan 2 = TRUNG BAI.
        # 180s (truoc 120s): bai co kem nhom thi FB xu ly lau hon. Bao FAIL oan tren bai
        # DA LEN thi lan chay sau se DANG TRUNG — cho lau hon la doi mot chieu an toan.
        done = False
        for _ in range(36):
            time.sleep(5)
            if "reels_composer" not in (c.eval("location.href") or ""):
                done = True
                break
            if c.eval("(() => { const t = document.body.innerText; "
                      "return t.includes('Đang xử lý thước phim') || "
                      "t.includes('hệ thống sẽ đăng thước phim') ? 1 : 0; })()"):
                done = True
                c.eval(_CLICK_TEXT % (json.dumps(["Xong"]), "0"))     # dong hop thoai
                break
        if not done:
            # Giao dien im KHONG co nghia la bai chua len (do that 29/07: 7/7 bai bao
            # loi nay deu da len dung gio hen). Hoi thang Graph truoc khi bao that bai —
            # bao FAIL oan -> nguoi dung bam Thu lai -> DANG TRUNG.
            v = _graph_check(page_id, "reel", t_send, caption, title)
            if v.get("state") == "posted":
                _log("giao dien khong bao gi nhung Graph XAC NHAN da len (%s)"
                     % v.get("id"))
                return {"ok": True, "page_id": page_id, "video": video,
                        "seconds": round(time.time() - t0, 1),
                        "groups": gres.get("groups") or [],
                        "groups_why": gres.get("groups_why") or gres.get("why") or "",
                        "verified_by": "graph", "post_id": v.get("id")}
            fail("Bam 'Chia se' nhung khong thay dau hieu da gui sau 180s (%s)"
                 % _verdict_note(v), "cho_dang")
        _log("DANG XONG (%.0fs)" % (time.time() - t0))
        return {"ok": True, "page_id": page_id, "video": video,
                "seconds": round(time.time() - t0, 1),
                "groups": gres.get("groups") or [],
                "groups_why": gres.get("why") or ""}
    finally:
        try:
            c.close()
        except Exception:
            pass
        if not keep_tab:
            _close_tab(port, tab["id"])


POST_COMPOSER = "https://business.facebook.com/latest/composer?asset_id=%s"


def post_photo(page_id: str, image: str, caption: str = "", port: int = S.DEFAULT_PORT,
               shot_dir: str = "", keep_tab: bool = False,
               share_groups: bool = True, group_max: int = 0) -> dict:
    """Dang 1 BAI VIET ANH len page bang Chrome (composer bai viet, KHONG phai Reels).

    Cung ky thuat voi post_reel: hook input.click -> setFileInputFiles -> insertText caption
    -> nut "Dang" o FOOTER bang chuot that.
    """
    if not os.path.isfile(image):
        raise ChromePostError("Khong thay file anh: %s" % image)
    if not S.is_alive(port):
        raise ChromePostError("Chrome chua mo (cong CDP %d)." % port)
    if not S.logged_in(port):
        raise ChromePostError("Chrome chua dang nhap Facebook.")

    t0 = time.time()
    tab = _tab_for(port, POST_COMPOSER % page_id)
    c = S.CDP(tab["webSocketDebuggerUrl"])

    def shot(name):
        if not shot_dir:
            return ""
        try:
            import base64
            os.makedirs(shot_dir, exist_ok=True)
            r = c.send("Page.captureScreenshot", {"format": "png"}, timeout=60)
            p = os.path.join(shot_dir, "%s_%s.png" % (page_id, name))
            open(p, "wb").write(base64.b64decode(r["data"]))
            return p
        except Exception:
            return ""

    def fail(msg, step):
        p = shot("loi_photo_" + step)
        if not keep_tab:
            _close_tab(port, tab["id"])
        raise ChromePostError("%s (buoc: %s)%s" % (msg, step, (" · anh: %s" % p) if p else ""))

    try:
        c.send("DOM.enable"); c.send("Runtime.enable"); c.send("Page.enable")
        if not _wait_text(c, ["Thêm ảnh/video", "Thêm ảnh", "File phương tiện"], timeout=120):
            # Doc chu FB dang hien -> ly do THAT (hay gap: tai khoan Chrome khong quan tri page).
            _t = ""
            try:
                _t = (c.eval("document.body.innerText") or "")[:3000].lower()
            except Exception:
                pass
            if "không khả dụng" in _t or "isn't available" in _t or "not available" in _t:
                fail("TAI KHOAN CHROME KHONG CO QUYEN vao page nay (FB bao 'noi dung nay hien "
                     "khong kha dung') — dang nhap Chrome bang tai khoan QUAN TRI page", "mo_composer")
            fail("Composer bai viet khong render sau 120s", "mo_composer")

        c.eval(_HOOK)
        if c.eval(_CLICK_TEXT % (json.dumps(["Thêm ảnh/video", "Thêm ảnh"]), "0")) != "ok":
            fail("Khong thay nut 'Them anh/video'", "them_anh")
        grabbed = False
        for _ in range(15):
            time.sleep(1)
            if c.eval("window.__cs_grabbed ? 1 : 0"):
                grabbed = True
                break
        if not grabbed:
            fail("Khong bat duoc o chon file anh", "hook_input")
        r = c.send("Runtime.evaluate", {"expression": "window.__cs_grabbed", "returnByValue": False})
        c.send("DOM.setFileInputFiles", {"objectId": r["result"]["objectId"], "files": [image]})
        _log("da nap anh %s" % os.path.basename(image))
        time.sleep(6)

        if caption:
            # O soan cua composer BAI VIET khong chac co role=textbox / aria-label 'văn bản'
            # (da do that) -> thu lan luot nhieu kieu selector, lay o TO nhat con nhin thay.
            picked = c.eval(r"""
            (() => {
              const sels = ['div[role=textbox]', '[contenteditable="true"]', 'textarea'];
              let best = null, area = 0;
              for (const s of sels) {
                for (const e of document.querySelectorAll(s)) {
                  const r = e.getBoundingClientRect();
                  if (r.width < 80 || r.height < 20) continue;      // bo o an / o ti hon
                  const a = r.width * r.height;
                  if (a > area) { area = a; best = e; }
                }
                if (best) break;                                    // uu tien selector dung truoc
              }
              if (!best) return 'NOTFOUND';
              best.focus(); best.click();
              return best.tagName + '/' + (best.getAttribute('role') || 'editable');
            })()
            """)
            if picked == "NOTFOUND":
                fail("Khong thay o soan noi dung", "o_soan")
            _log("o soan: %s" % picked)
            c.send("Input.insertText", {"text": caption})
            time.sleep(1.5)

        # ── chia se len nhom (bai anh CO muc nay, giao dien khac Reels) ──
        gres = {"groups": [], "why": "tắt theo cấu hình"}
        if share_groups:
            try:
                gres = share_to_groups_photo(c, page_id, n_max=group_max)
            except Exception as e:     # khau phu: KHONG duoc lam hong ca bai dang
                gres = {"groups": [], "why": "loi khi chon nhom: %s" % str(e)[:200]}
                _log("canh bao: %s" % gres["why"])
        if gres["groups"]:
            _log("se chia se len %d nhom: %s"
                 % (len(gres["groups"]), ", ".join(g["name"] for g in gres["groups"])))
        else:
            _log("khong kem nhom (%s)" % (gres.get("why") or "khong ro"))

        # CHOT CHAN: con lop phu danh sach nhom thi cu bam "Dang" se roi vao lop phu (chi
        # de dong no) chu khong trung nut -> cho 180s roi bao loi tren bai CHUA HE gui.
        for _ in range(6):
            try:
                if not json.loads(c.eval(_PH_ROWS) or "[]"):
                    break
            except Exception:
                break
            _log("con lop phu chon nhom -> dong truoc khi bam Dang")
            _esc(c)
            time.sleep(1.5)

        raw = c.eval(_RECT_TEXT % json.dumps("Đăng"))
        if not raw:
            fail("Khong thay nut 'Dang' o footer", "nut_dang")
        pt = json.loads(raw)
        t_send = int(time.time())          # moc gui: cua so de doi chieu voi Graph
        _real_click(c, pt["x"], pt["y"])
        _log("da bam Dang, cho FB xu ly...")

        # DO THAT: dang xong FB hien hop "Đã đăng bài viết của bạn" + moi TAO QUANG CAO
        # (khong chuyen trang) -> phai nhan chuoi nay, roi bam "Để sau" de dong hop.
        # FB ket thuc dang anh theo NHIEU kieu (do that): chuyen trang · hop "Đã đăng bài
        # viết của bạn" + moi tao quang cao · chi don gian dong composer. Nhan THIEU kieu =
        # bao FAIL OAN tren bai DA LEN -> bam lai la DANG TRUNG. Nen: gom nhieu dau hieu,
        # cho lau hon, va cuoi cung con kiem "composer da sach chua".
        _SIGNS = ["Đã đăng bài viết", "đã được đăng", "Đang xử lý", "Bài viết của bạn",
                  "Tạo quảng cáo", "Tăng cấp bài viết", "Your post", "has been posted"]
        done = False
        for _ in range(36):                                   # ~180s
            time.sleep(5)
            if "composer" not in (c.eval("location.href") or ""):
                done = True
                break
            if c.eval("(() => { const t = document.body.innerText; return %s"
                      ".some(s => t.includes(s)) ? 1 : 0; })()" % json.dumps(_SIGNS)):
                done = True
                for lb in (["Để sau"], ["Xong"], ["Đóng"]):   # dong hop moi quang cao
                    if c.eval(_CLICK_TEXT % (json.dumps(lb), "0")) == "ok":
                        break
                break
            # Composer da SACH (khong con nut Dang + khong con noi dung vua go) = da gui.
            if c.eval("(() => { const t = document.body.innerText; "
                      "return (!t.includes('Đăng') && !t.includes('Thêm ảnh')) ? 1 : 0; })()"):
                done = True
                _log("composer da dong (khong con nut Dang) -> coi nhu da gui")
                break
        if not done:
            v = _graph_check(page_id, "photo", t_send, caption)
            if v.get("state") == "posted":
                _log("giao dien khong bao gi nhung Graph XAC NHAN da len (%s)"
                     % v.get("id"))
                return {"ok": True, "page_id": page_id, "image": image,
                        "seconds": round(time.time() - t0, 1),
                        "groups": gres.get("groups") or [],
                        "groups_why": gres.get("why") or "",
                        "verified_by": "graph", "post_id": v.get("id")}
            fail("Bam 'Dang' nhung khong thay dau hieu da gui sau 180s (%s)"
                 % _verdict_note(v), "cho_dang")
        _log("DANG ANH XONG (%.0fs)" % (time.time() - t0))
        return {"ok": True, "page_id": page_id, "image": image,
                "seconds": round(time.time() - t0, 1),
                "groups": gres.get("groups") or [],
                "groups_why": gres.get("why") or ""}
    finally:
        try:
            c.close()
        except Exception:
            pass
        if not keep_tab:
            _close_tab(port, tab["id"])


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Dang 1 reel len page bang Chrome (CDP).")
    ap.add_argument("--page-id", required=True)
    ap.add_argument("--video", required=True)
    ap.add_argument("--caption", default="")
    ap.add_argument("--title", default="")
    ap.add_argument("--tags", default="", help="cach nhau bang dau phay")
    ap.add_argument("--audio", default="original_only",
                    choices=["original_only", "remix", "none"])
    ap.add_argument("--shot-dir", default="")
    ap.add_argument("--no-groups", action="store_true",
                    help="khong chia se len nhom (mac dinh CO, toi da 3 nhom/bai)")
    a = ap.parse_args()
    out = post_reel(a.page_id, a.video, a.caption, a.title,
                    [t.strip() for t in a.tags.split(",") if t.strip()],
                    audio_mode=a.audio, shot_dir=a.shot_dir,
                    share_groups=not a.no_groups)
    print(json.dumps(out, ensure_ascii=False))
