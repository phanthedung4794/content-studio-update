# -*- coding: utf-8 -*-
"""
Lam lai video TONG QUAT cho reel BAT KY (khong hardcode prompt).
Quy trinh (dua tren scratchpad da nghiem thu 1 video):
  1. chep loi (faster-whisper) -> cot truyen + moc cau
  2. video goc -> chia canh (dedup/gop) + LUU 1 frame dai dien/canh (goc_XX.jpg)
  3. VISION (GPT-4o nhin tung frame dai dien) -> prompt anh BAM KHUNG GOC (mac dinh).
     Fallback 'story': LLM doc cot truyen -> N canh (lech khung, chi khi thieu OPENAI/frame)
  4. gommo_client -> anh (banana_2 vip 1k) + clip i2v (veo fast / kling / Ken Burns)
  5. ghep: crossfade + lam cham cho day cua so (bam nhip video goc) + long AUDIO GOC (che do B)
Che do A (giong+nhac moi) CHUA lam o day -> tam dung che do B.

Ket qua: out_path (mp4 doc). IDEMPOTENT theo thu muc work (co roi thi bo qua).
CHUA CHAY THAT qua orchestration (ton credit) -> can nghiem thu lan dau cung nguoi dung.
"""
import base64
import glob
import json
import os
import re
import shutil
import subprocess
import time

import requests

from gommo_client import GommoClient, download
import script_gen

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MUSIC_DIR = os.path.join(ROOT, "assets", "music")

# STYLE trung tinh (KHONG khoa noi dung/boi canh) -> ap cho MOI nguon. Noi dung/boi canh
# do VISION mo ta tu chinh video goc (thanh pho/que/dem... deu dung). Chi ap phong cach ve.
# CHON qua tham so `style`: 'real' (giong that = MAC DINH, hop page anh nguoi that) |
# 'cartoon' (mau nuoc hoat hinh, hop page hoai niem). Truoc day HARDCODE 'cartoon' ->
# moi page deu ra hoat hinh; gio chon duoc theo nguon.
# DANH SACH KIEU ANH (khop 79AI, dong bo voi image_post.py). Value = duoi prompt them vao.
_TAIL = " Vertical 9:16 composition, full bleed edge to edge. No text, no words, no letters."
STYLES = {
    "real": (" Photorealistic, realistic natural lighting, true-to-life skin and textures, "
             "candid documentary photography look, sharp focus, high detail, cinematic color." + _TAIL),
    "cartoon": (" Hand-painted watercolor illustration, soft warm cinematic lighting, fine "
                "painterly texture, gentle nostalgic tone." + _TAIL),
    "hoat_hinh": (" cute simple hand-drawn cartoon illustration, thin clean black ink outlines, "
                  "adorable characters, gentle expressions, soft warm color accents, cozy tender mood." + _TAIL),
    "chan_dung_dien_anh": (" cinematic portrait, dramatic moody lighting, shallow depth of field, "
                           "film still, ultra detailed, atmospheric." + _TAIL),
    "anime": (" Japanese anime style, clean crisp line art, cel shading, expressive eyes, "
              "vibrant colors, studio anime key visual." + _TAIL),
    "mau_nuoc": (" soft watercolor painting, delicate translucent washes, textured watercolor "
                 "paper, gentle bleeding colors, hand painted." + _TAIL),
    "pixar_3d": (" 3D animated character render, Pixar Disney style, soft global illumination, "
                 "cute rounded shapes, subsurface scattering, high quality render." + _TAIL),
    "son_dau": (" classical oil painting, visible textured brush strokes, rich warm tones, "
                "canvas texture, painterly." + _TAIL),
    "ngam_doi": (" minimalist 2D cartoon illustration, STRICTLY grayscale black white and gray "
                 "only, no color, simple rounded egg-shaped heads with minimal facial features, "
                 "a dramatic warm glowing spotlight halo behind the characters, long dark shadows "
                 "on the floor, dark vignette background, emotional cinematic mood, clean thin "
                 "black ink line art." + _TAIL),
    "theo_mo_ta": (_TAIL),
}
# Nhan tieng Viet cho o chon "Kieu anh" (UI doc qua endpoint /fb-post/styles).
STYLE_LABELS = {
    "real": "Thật (giống ảnh thật)", "cartoon": "Màu nước hoài niệm",
    "hoat_hinh": "Hoạt hình dễ thương", "chan_dung_dien_anh": "Chân dung điện ảnh",
    "anime": "Anime Nhật Bản", "mau_nuoc": "Tranh màu nước",
    "pixar_3d": "Hoạt hình 3D (Pixar)", "son_dau": "Tranh sơn dầu",
    "ngam_doi": "Đen trắng xúc động (Ngẫm Đời)",
    "theo_mo_ta": "Theo mô tả (không thêm)",
}
DEFAULT_STYLE = "real"
STYLE = STYLES["cartoon"]   # tuong thich nguoc (code cu con tham chieu STYLE)
BLEED = (" Full bleed, fills the entire vertical 9:16 frame edge to edge, no black bars, "
         "no border, no vignette, no letterbox, no matte.")

# So luong 79AI xu SONG SONG (concurrency/account). Do that account credit ~2 lane;
# mua subscription (12 lane) thi dat REMAKE_LANES=12. Dung cho ca ve anh lan i2v.
# MAC DINH 1: song song o cap PAGE (10 page = 10 luong), moi page 1 i2v/luc -> tong <=10 task
# 79 (<12 concurrent cua goi) -> KHONG BAO GIO flood, khong can khoa lien-tien-trinh. Muon nhanh
# hon cho 1 video le (Xuong tay) thi REMAKE_LANES=2. Xem docs/song-song-nhieu-luong.md.
LANES = max(1, int(os.environ.get("REMAKE_LANES", "1")))

# Tham so BAT BUOC tung model i2v (do that tu 79AI: kling can duration, seedance can
# resolution, hailuo khong nhan 9:16). Dung cho FALLBACK khi model chinh het tai nguyen.
VIDEO_PARAMS = {
    # GROK Heavy (server grokai RIENG -> khong nghen nhu veo; do that: 97s, giu nhan vat, motion
    # tro chuyen tot, 1000cr/720p6s). Mode 'normal' (tranh extremely-crazy/spicy). i2v (startImage).
    "grok_video_heavy": {"mode": "normal", "resolution": "720p", "duration": "6"},
    # veo FAST (khong Lite): cung model/chat luong, uu tien CAO -> nhanh + do treo (+~50% gia).
    # DO THAT 2026-07: veo 1080p -> LOI backend #453422 (that bai that). 720p CHAY ngon
    # (SUCCESSFUL 165s, 0 credit). Grok cung 720p OK. -> giu 720p cho ca 2 (on dinh + free).
    "veo_3_1":         {"mode": "fast", "resolution": "720p", "duration": "8"},
    "hailuo_2_3":      {"mode": "fast", "resolution": "720p", "duration": "6"},
    "kling_video_2_6": {"mode": "standard", "duration": "8"},
    "kling_video_2_5": {"mode": "standard", "duration": "8"},
}
# [KHONG CON DUNG] Truoc day _gen_one_clip nhay model khi treo/loi. Da BO: model do NGUOI DUNG
# chon (veo/grok/kenburns), i2v KHONG tu chuyen model, KHONG tu rot Ken Burns (tranh nhoi hang
# doi 79 -> treo). Giu bien de tuong thich; khong tham chieu o dau. Xem docs/song-song-nhieu-luong.md.
FALLBACK_CHAIN = ["veo_3_1", "grok_video_heavy"]
# CHO LAU (goi co HANG DOI UU TIEN 12+30 slot) — KHONG timeout-giet, KHONG tu chuyen model,
# KHONG tu rot Ken Burns. Mac dinh 3600s (1h) = "cho gan nhu vo han" nhung van co tran chong treo.
# Het 1h -> submit LAI CUNG model (bounded REMAKE_I2V_RESUBMIT). Xem docs/song-song-nhieu-luong.md.
I2V_WAIT = int(os.environ.get("REMAKE_I2V_WAIT", "3600"))
# So lan submit LAI CUNG model khi 79 bao FAIL/tu choi (task CHET). KHONG doi model, KHONG Ken Burns.
I2V_RESUBMIT = max(1, int(os.environ.get("REMAKE_I2V_RESUBMIT", "3")))
# So VONG cho toi da khi het I2V_WAIT ma task VAN dang chay (task con song -> KHONG submit lai
# de tranh mo coi/flood). Tong cho ~ I2V_MAX_WAITS x I2V_WAIT. Het -> GIU .task, raise resumable.
I2V_MAX_WAITS = max(1, int(os.environ.get("REMAKE_I2V_MAX_WAITS", "3")))
# ANH: so lan that bai THAT (status=ERROR/khong submit duoc) truoc khi raise bao nguoi dung.
# LICH SU: 4 -> 2 (yeu cau "lan 2 van loi thi bao NGAY, khong AM THAM thu them") -> 4 lai.
# Yeu cau do nham vao chu AM THAM, khong phai con so: nguoi dung khong muon tool lang le
# nuot loi. Nhung 2 lan cach nhau 4 GIAY thi voi loi NGAU NHIEN luc 79AI nghen gan nhu chac
# chan truot ca hai (do that 28/07: phai chay 3 luot moi du 5 anh, moi luot truot MOT canh
# KHAC nhau -> loi ngau nhien, khong phai bi chan noi dung). Nay giai quyet dung goc:
#   - loi CO DINH (bi chan noi dung / model tat han) -> bao NGAY, khong thu lai lan nao
#     (thu lai cung prompt tren cung model la vo ich, chi to lau);
#   - loi NGAU NHIEN -> thu toi IMG_RESUBMIT lan, GIAN CACH TANG DAN (_IMG_BACKOFF), va
#     moi lan deu bao ra COT TIEN TRINH kem ly do that -> nhieu lan hon nhung KHONG am tham.
IMG_RESUBMIT = max(1, int(os.environ.get("REMAKE_IMG_RESUBMIT", "4")))
# Cho bao lau truoc moi lan gui lai. Co dinh 4s la qua ngan: 79AI dang nghen thi 4s sau van
# nghen. Tang dan de lan thu cuoi roi vao luc may da nha bot.
_IMG_BACKOFF = (5, 20, 60, 120)
# So vong CHO TIEP (khong submit lai) khi anh con song nhung qua IMG_WAIT (xem _gen_one_image
# block=True, pass 2 cua gen_media). Tong cho toi da ~ IMG_MAX_WAITS x REMAKE_IMG_WAIT.
IMG_MAX_WAITS = max(1, int(os.environ.get("REMAKE_IMG_MAX_WAITS", "3")))


_PROGRESS = None          # callback(step_msg) -> cap nhat tien trinh len UI (fb_pipeline)


def set_progress(cb):
    """Dang ky callback nhan MOC tien trinh nguoi-doc (vd cap nhat step cua item pipeline).
    None de tat. fb_auto dat = ham cap nhat step cua item dang lam -> UI hien 'Dang tao
    anh 3/7', 'Dang ghep video'... thay vi step co dinh 'download'."""
    global _PROGRESS
    _PROGRESS = cb


def _log(m):
    print(m, flush=True)


def _prog(m):
    """MOC tien trinh NGUOI-DOC (tieng Viet co dau): in stdout (nhat ky job) + day len UI qua
    callback. Chi dung cho cac CHANG quan trong nguoi dung theo doi, khong phai moi dong debug."""
    print(m, flush=True)
    cb = _PROGRESS
    if cb:
        try:
            cb(m)
        except Exception:
            pass


def _dur(path):
    """Do dai (giay) 1 file media qua ffprobe."""
    return float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", path]).decode().strip())


def _ff(args, **kw):
    """Chay ffmpeg BAT stderr -> loi DOC DUOC. Thay cho subprocess.run(..., check=True):
    str(CalledProcessError) chi ra 'Command ... returned non-zero exit status' (VO DUNG,
    giau ly do). Ham nay raise kem 3 dong stderr cuoi cua ffmpeg -> khach/dev thay ly do that
    (vd 'Stream map matches no streams' = nguon cam, 'moov atom not found' = file tai cut)."""
    r = subprocess.run(args, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", **kw)
    if r.returncode != 0:
        err = (r.stderr or r.stdout or "").strip()
        tail = " | ".join([l for l in err.splitlines() if l.strip()][-3:])[:300]
        raise RuntimeError("ffmpeg loi: " + (tail or "khong ro (rc=%d)" % r.returncode))
    return r


def _has_audio(path):
    """Video co luong AUDIO khong (reel tai bang DASH co the mat fragment audio -> mp4 cam)."""
    try:
        out = subprocess.check_output([
            "ffprobe", "-v", "error", "-select_streams", "a", "-show_entries",
            "stream=index", "-of", "csv=p=0", path]).decode().strip()
        return bool(out)
    except Exception:
        return True    # khong chac -> gia dinh co (dau '?' o map van lo an toan)


# ── Nguon TINH hay CO CHUYEN DONG? ────────────────────────────────────────────
# Nguon la ANH TINH + chuyen canh (slideshow) thi lam i2v la LANG PHI: tra tien/quota
# cho "motion" ma anh goc von khong he chuyen dong. Ken Burns (zoom/pan cuc bo, ffmpeg,
# 0 credit) cho ket qua tuong duong ma khong ton gi.
# DO THAT thay vi hoi LLM: do tren 33 page that (2026-07-27) cho thay nhan `san_xuat`
# cua Gemini KHONG dung duoc cho viec nay — page `chuyencongso69` bi gan 'hoat_hinh'
# nhung do ra still=0.97/median=0.0022 = anh tinh hoan toan.
# Nguong lay tu KHOANG TRONG that giua 2 nhom (still 0.51 -> 0.61):
#     tinh  <=> still_ratio >= 0.55  VA  median < 0.012
# Ca hai dieu kien cung dong y tren toan bo 33 page, khong ca nao nhap nhang. Nghieng ve
# phia GIU i2v khi lung chung: nhan nham 'tinh' lam video xau di, nhan nham 'dong' chi ton
# them luot (hai it hon).
STILL_FRAME = 0.010      # lech giua 2 khung duoi muc nay = coi nhu khung Y HET nhau
STILL_RATIO = 0.55
STILL_MEDIAN = 0.012
# THUOC THU BA (them 28/07) — CHUYEN DONG CUC BO. Hai thuoc tren deu lay TRUNG BINH ca khung,
# nen phim HOAT HINH co nen bat dong (nha, san, troi) + nhan vat cu dong trong mot vung nho bi
# nen "pha loang" -> doc nham thanh anh tinh. Do that tren 24 video nguon: bai 4501779026731394
# (me cui trai chieu, animation ro rang) ra still=0.564 -> BI GAN TINH -> mat i2v, ra Ken Burns;
# bai 2082267142668079 con oan hon (p99=0.418 = dong manh nhat nhom). Phan vi 99 cua |lech| tach
# rat sach: tinh THAT 0.008 | bai bi oan 0.086 | ca nhom dong 0.18-0.53 -> nguong 0.04 nam giua
# khoang trong, nghieng ve GIU i2v (nhan nham 'tinh' lam video xau; nhan nham 'dong' chi ton luot).
STILL_P99 = 0.04
# Cache _motion.json co khoa phien ban: ban 1 do bang thuoc cu (co ket qua SAI) -> gap v khac
# thi DO LAI, khong dung lai ket qua cu.
MOTION_V = 2
# Do CA video thay vi 10 giay dau (bo 2 giay): 10 giay dau khong dai dien — dung o bai tren,
# doan dau it dong nen still=0.564 (tinh), do ca video ra 0.490 (dong). Tran 240 khung = 60 giay
# o 4fps, du dai ma van nhanh (~1s).
MOTION_MAX_FRAMES = 240


def motion_stats(video_path, work=None):
    """Do do CHUYEN DONG cua video nguon -> {still_ratio, median, mean, static:bool}.

    Lay 40 khung o 4fps (10 giay, bo 2 giay dau), so lech TRUNG BINH giua 2 khung lien
    tiep. Slideshow tinh -> phan lon cap khung giong het (lech ~0). Ket qua CACHE trong
    work (`_motion.json`) de chay lai/noi tiep khong do lai. Loi -> tra None (caller giu
    nguyen model nguoi dung chon, KHONG doan bua)."""
    cache = os.path.join(work, "_motion.json") if work else None
    if cache and os.path.isfile(cache):
        try:
            old = json.load(open(cache, encoding="utf-8"))
            if old.get("v") == MOTION_V:      # ban cu do bang thuoc thieu p99 -> do lai
                return old
        except Exception:
            pass
    import tempfile
    td = tempfile.mkdtemp()
    try:
        import numpy as np
        from PIL import Image
        _ff(["ffmpeg", "-v", "error", "-y", "-ss", "2", "-i", video_path, "-vf",
             "setparams=color_primaries=bt709,fps=4,scale=160:-1",
             "-frames:v", str(MOTION_MAX_FRAMES), os.path.join(td, "m%03d.jpg")])
        fs = sorted(glob.glob(os.path.join(td, "m*.jpg")))
        if len(fs) < 6:
            return None
        g = [np.asarray(Image.open(f).convert("L"), dtype=np.float32) for f in fs]
        d, p99 = [], []
        for i in range(1, len(g)):
            a = np.abs(g[i] - g[i - 1]) / 255.0
            d.append(float(a.mean()))
            p99.append(float(np.percentile(a, 99)))   # vung DONG NHAT giua 2 khung
        d.sort(); p99.sort()
        st = {
            "v": MOTION_V,
            "still_ratio": round(sum(1 for x in d if x < STILL_FRAME) / len(d), 3),
            "median": round(d[len(d) // 2], 4),
            "mean": round(sum(d) / len(d), 4),
            "p99": round(p99[len(p99) // 2], 4),
        }
        # CA BA thuoc phai cung dong y moi goi la tinh. p99 la thuoc quyet dinh cho phim hoat
        # hinh nen bat dong: no nhin vung DONG NHAT nen khong bi nen tinh pha loang.
        st["static"] = (st["still_ratio"] >= STILL_RATIO and st["median"] < STILL_MEDIAN
                        and st["p99"] < STILL_P99)
        if cache:
            try:
                json.dump(st, open(cache, "w", encoding="utf-8"))
            except Exception:
                pass
        return st
    except Exception as e:
        _log("[motion] do that bai (%s) -> giu nguyen model da chon" % str(e)[:80])
        return None
    finally:
        shutil.rmtree(td, ignore_errors=True)


def transcribe(video_path, work):
    """Chep loi -> [{start,end,text}] + story."""
    tj = os.path.join(work, "transcript.json")
    if os.path.isfile(tj):
        segs = json.load(open(tj, encoding="utf-8"))
    else:
        from faster_whisper import WhisperModel
        wav = os.path.join(work, "audio.wav")
        _ff(["ffmpeg", "-v", "error", "-y", "-i", video_path,
             "-ac", "1", "-ar", "16000", wav])
        m = WhisperModel("small", device="cpu", compute_type="int8")
        segs = [{"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()}
                for s in m.transcribe(wav, language="vi", vad_filter=True)[0]]
        json.dump(segs, open(tj, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    story = " ".join(s["text"] for s in segs)
    return segs, story


def gen_scene_prompts(story, n_scenes, work, scene_texts=None, context=None):
    """LLM DOC CA TRUYEN -> N canh {img, mot} (nhat quan nhan vat, KHAC nhau tung canh).

    scene_texts (hybrid): N doan LOI THOAI theo thu tu thoi gian -> moi canh minh hoa DUNG
    doan cua no (khop loi + nhip video). None -> chia deu tu cot truyen.
    context: 1 cau boi canh TONG rut tu video goc (era/vung/khong khi) -> grounding, tranh
    westernize; ghim vao moi canh. Cache ra work/scenes.json.
    """
    pf = os.path.join(work, "scenes.json")
    if os.path.isfile(pf):
        return json.load(open(pf, encoding="utf-8"))
    ctx = (context or "").strip()
    system = (
        "Ban la dao dien hinh anh cho video ke chuyen hoai niem Viet Nam. Doc HET cot truyen "
        "roi dung hinh cho tung canh. QUY TAC BAT BUOC: (1) Khoa DANH TINH nhan vat — moi nhan "
        "vat co mo ta ngoai hinh CO DINH (tuoi, toc, trang phuc, dac diem) lap lai Y HET o moi "
        "canh co nhan vat do (tranh moi canh ve mot kieu). (2) Moi canh KHAC NHAU ro rang "
        "(khoanh khac/goc nhin/hanh dong khac) — TUYET DOI khong lap lai cung mot canh. "
        "(3) Giu dung boi canh van hoa, khong doi sang phuong Tay. Tra ve JSON thuan tuy."
        + (" Boi canh tong the video: %s." % ctx if ctx else ""))
    if scene_texts:
        blocks = "\n".join('%d. "%s"' % (i + 1, (t or "").strip()) for i, t in enumerate(scene_texts))
        want = len(scene_texts)
        user = (f"COT TRUYEN DAY DU (loi ke/thoai ca video):\n\"{story}\"\n\n"
                f"Video co {want} canh LIEN TIEP theo thoi gian, moi canh ung 1 doan loi:\n{blocks}\n\n"
                f"Voi MOI canh tao 1 hinh minh hoa DUNG noi dung/khong khi doan loi do, nhat "
                f"quan trong ca mach truyen:\n"
                f"- img: mo ta ANH tieng Anh (nhan vat + hanh dong + boi canh khop doan loi; "
                f"lap lai mo ta nhan vat de khop cac canh khac)\n"
                f"- mot: mo ta CHUYEN DONG nhe tieng Anh cho i2v (cham, khong rung lac)\n"
                f'Tra ve JSON: {{"scenes":[{{"img":"...","mot":"..."}}, ...]}} — DUNG {want} canh, '
                f"dung thu tu tren, khong giai thich.")
    else:
        want = n_scenes
        user = (f"Cot truyen (loi thoai/ke): \"{story}\"\n\n"
                f"Chia thanh {n_scenes} canh KE TIEP theo dien bien, MOI canh KHAC nhau. Moi canh cho:\n"
                f"- img: mo ta ANH tieng Anh (nhan vat + boi canh + hanh dong; lap lai mo ta nhan vat)\n"
                f"- mot: mo ta CHUYEN DONG nhe tieng Anh cho i2v (cham, khong rung lac)\n"
                f'Tra ve JSON: {{"scenes":[{{"img":"...","mot":"..."}}, ...]}} — dung {n_scenes} canh, '
                f"khong giai thich.")
    txt = script_gen._chat_text(system, user, max_tokens=2200)
    m = re.search(r"\{.*\}", txt, re.S)
    data = json.loads(m.group(0)) if m else {"scenes": []}
    scenes = data.get("scenes", [])[:want]
    if len(scenes) < want:
        raise RuntimeError("LLM tra it canh hon yeu cau (%d/%d)" % (len(scenes), want))
    if ctx:                              # ghim boi canh tong vao moi canh (grounding chac)
        for sc in scenes:
            sc["img"] = "%s. %s" % (ctx, sc.get("img", ""))
    json.dump(scenes, open(pf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return scenes


# ── PHAN TICH VIDEO GOC (video-driven, TONG QUAT moi noi dung) ──────────────
def _dhash(path, size=8):
    """Hash tri giac 1 anh -> so 64 bit (so sanh 2 frame co khac 'slide' khong)."""
    from PIL import Image
    img = Image.open(path).convert("L").resize((size + 1, size))
    px = list(img.getdata())
    bits = 0
    for r in range(size):
        for c in range(size):
            bits = (bits << 1) | (1 if px[r * (size + 1) + c] < px[r * (size + 1) + c + 1] else 0)
    return bits


def _ham(a, b):
    return bin(a ^ b).count("1")


# Prompt MEM (khong hoi tuoi/gioi/sac toc tung nguoi -> tranh bo loc tu choi). Boi canh
# van GIU (khong westernize) + BOI CANH TONG rut rieng tu video ghep vao -> giu chat Viet.
# DA TUNG CHI CO MOT VI DU "1990s rural Vietnamese countryside" -> chinh no moi cho model
# tra ve lang que ke ca video quay trong van phong. Nay dua 2 vi du TRAI NGUOC nhau.
_CONTEXT_PROMPT = ("In ONE short English phrase, state the overall SETTING, ERA, region/culture and "
                   "mood of this video for consistent art direction. Report what you actually SEE — "
                   "do not default to a rural or nostalgic setting. Examples of the format: "
                   "'modern Vietnamese open-plan office, satirical comedy' or "
                   "'1990s rural Vietnamese countryside, warm nostalgic'. Output only the phrase.")


def _openai_vision(text, img_b64_list, max_tokens=400, timeout=90):
    """1 loi goi GPT-4o vision (1+ anh + text). Tra text tra loi."""
    ok = os.environ.get("OPENAI_API_KEY", "").strip()
    if not ok:
        raise RuntimeError("Thieu OPENAI_API_KEY de phan tich video (vision).")
    content = [{"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,%s" % b}}
               for b in img_b64_list]
    content.append({"type": "text", "text": text})
    base = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/") + "/chat/completions"
    r = requests.post(base, json={"model": os.environ.get("OPENAI_MODEL") or "gpt-4o",
                                  "max_tokens": max_tokens, "messages": [{"role": "user", "content": content}]},
                      timeout=timeout, headers={"Authorization": "Bearer %s" % ok, "Content-Type": "application/json"})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def _b64(p):
    return base64.b64encode(open(p, "rb").read()).decode()


def _video_context(frame_paths):
    """Boi canh TONG cua video (video-derived, 1 cau) -> grounding cho moi canh."""
    try:
        return _openai_vision(_CONTEXT_PROMPT, [_b64(p) for p in frame_paths[:3]], max_tokens=60)
    except Exception:
        return ""


# ── VISION per-frame + SO DANG KY LUY TIEN: bam KHUNG GOC + nhat quan nhan vat/do vat/con vat ──
# VISION bam khung (do that: 2 dua dap xe -> ve 2 dua dap xe). Van de: ta MOI frame COO LAP ->
# cung 1 nguoi moi canh ve 1 kieu. GIAI: SO DANG KY LUY TIEN — duyet canh THEO THU TU; canh nao
# sinh them nhan vat/con vat/do vat MOI thi KHOA vao so; canh sau xuat hien lai thi tai dung DUNG
# mo ta da khoa. Moi canh chi ve dung thuc the co mat. Boi canh khoa MEM (chong drift Tay, doi
# khi chuyen cho). Vd: canh1 2 dua -> khoa; canh2 them 2 dua moi -> khoa them; canh3 them nguoi
# cha -> khoa cha; canh4 chi 4 dua canh1+2 -> hien dung 4 dua do.

# CHI lam diu vai tu goi cam (banana KHONG chan boy/girl). KHONG xoa boy/girl nua vi lam MAT
# gioi tinh -> anh ra sai gioi (anh ra nu). Giu boy/girl de model ve dung gioi.
_SOFTEN = [("cheekily", "gently"), ("grins", "smiles")]

# Chuyen dong nhe cho i2v: CHONG morph mat/drift (i2v hay ve lai mat -> anime "Naruto").
# CHONG i2v tu bia mieng-noi: model native-audio (vd veo_3_1) hay tu sinh nhan vat map may
# mieng + audio rieng (tieng Anh) cho canh nguoi/kich tinh DU prompt khong yeu cau — pipeline
# cat audio do (_fit_scene -an) roi ghep audio THAT (goc/TTS) o assemble() nen AM THANH dung,
# nhung HINH van con mieng-noi khong khop -> nhin nhu "noi tieng Anh". _MOTION la nhanh MAC
# DINH (gemini_scene_prompts KHONG di qua bo phan loai _dialogue_per_window) nen phai tu cam
# noi o day; _MOTION_TALK (duoi) la nhanh CO CHU DICH rieng, KHONG dung.
_MOTION = ("Gentle subtle motion: slight natural movement of the subject and a slow gentle "
           "camera push-in, cinematic and smooth. Keep faces, identities and composition "
           "stable; no morphing, no distortion, no shaking. The character's mouth stays "
           "closed and still, not talking or speaking; no lip movement, no dialogue, no "
           "vocalization — a silent, quiet moment.")

# Canh CO thoai VA CO NGUOI: nhan vat MAP MAY MIENG nhu dang noi chuyen (khong phai lip-sync tung
# chu, chi "trong nhu dang noi"). Van chong morph. Gan theo _dialogue_per_window (canh nao co loi).
_MOTION_TALK = ("The characters are talking to each other, their mouths moving as if speaking and "
                "smiling, with small natural head and hand gestures, as if having a real "
                "conversation; a slow gentle camera push-in, cinematic and smooth. Keep faces, "
                "identities and composition stable; no morphing, no distortion, no shaking. "
                "Do NOT add any new people beyond those already in the image.")

# Canh KHONG CO NGUOI (phong canh/vat the) — dU audio co voiceover, i2v TUYET DOI khong duoc
# bia them nguoi (bug: canh cai loa bi gan 'characters talking' -> veo de ra 2 nguoi + drift style).
_MOTION_SCENERY = ("Gentle subtle motion of the scenery only: soft moving light, drifting clouds or "
                   "smoke, a slow gentle camera push-in, cinematic and smooth. Do NOT add any people "
                   "or characters; keep it an empty scenery shot. Keep the composition and art style "
                   "stable; no morphing, no distortion, no shaking.")

# Tu khoa NGUOI trong prompt anh -> quyet dinh canh co nguoi hay khong (chong bia nguoi vao phong canh).
_PEOPLE_RE = re.compile(
    r"\b(man|men|woman|women|boy|boys|girl|girls|child|children|kid|kids|person|people|villager|"
    r"villagers|family|grandmother|grandfather|grandma|grandpa|mother|father|parents|lady|ladies|"
    r"human|figure|figures|crowd|elderly|couple|baby|infant|teenager|worker|farmer|monk|soldier)\b",
    re.I)


# Bo cum PHU DINH truoc khi kiem (hau to "do not add unrelated people" dinh chu 'people' -> duong tinh gia).
_NEG_PEOPLE_RE = re.compile(r"(do not add[^.]*?\bpeople\b|no people\b|any people\b|unrelated people\b|"
                            r"people or characters)", re.I)


def _scene_has_people(sc):
    """Canh co nguoi khong? Doc prompt anh (img) SAU khi bo cum phu dinh. Chong gan 'talking'
    cho canh phong canh/vat the (bug: canh loa bi veo bia 2 nguoi vao)."""
    txt = _NEG_PEOPLE_RE.sub("", sc.get("img", ""))
    return bool(_PEOPLE_RE.search(txt))


def apply_talk_motion(scenes, segs, bounds, adur):
    """Gan motion theo canh (sua scenes tai cho):
    - CO thoai VA CO NGUOI -> map may mieng (nhu dang noi).
    - CO NGUOI, khong thoai -> nhe (giu identity).
    - KHONG CO NGUOI -> scenery (CAM bia nguoi) — du audio co voiceover.
    Bug cu: canh khong nguoi (loa/phong canh) + audio co tieng -> 'characters talking' -> veo de nguoi."""
    texts = _dialogue_per_window(segs, bounds, adur)
    for i, sc in enumerate(scenes):
        has_speech = bool(i < len(texts) and (texts[i] or "").strip())
        has_people = _scene_has_people(sc)
        if not has_people:
            sc["mot"] = _MOTION_SCENERY
        elif has_speech:
            sc["mot"] = _MOTION_TALK
        else:
            sc["mot"] = _MOTION
    return scenes

# Prompt duyet TUNG frame theo thu tu (co so dang ky hien tai) -> nhan dien thuc the co mat +
# khoa thuc the MOI + ta canh (bam khung). Gioi tinh ro (khong "anh ra nu"); khong nhan A/B/C.
_REG_PROMPT = (
    "This is frame %d of %d from ONE video (%s) whose recurring "
    "characters, animals and objects must stay consistent across scenes.\n"
    "ALREADY REGISTERED entities (reuse each EXACTLY, do NOT change or re-describe its look):\n%s\n\n"
    "Look ONLY at THIS frame and return JSON with three keys:\n"
    '"present": array of the ID NUMBERS of already-registered entities that actually appear here.\n'
    '"new": array of entities that appear but are NOT yet registered; for each give '
    '{"kind":"person|animal|object","desc":"fixed canonical description"}. For a person state '
    "GENDER (a boy / a girl / a man / a woman), age, hair, face, build, and clothing WITH colors. "
    "For an animal/object give type, colors, shape, pattern.\n"
    '"scene": ONE paragraph to RECREATE this frame (poses, actions, setting/background, camera '
    "framing, colors, lighting, art style); refer to entities by what they are, do NOT restate their "
    "fixed appearance. Describe the setting ACTUALLY VISIBLE in this frame — never invent a rural or "
    "1990s setting that is not there; keep it Vietnamese, NOT European; do not mention any letters as "
    "visible text.\n"
    "Output ONLY the JSON, no preface.")


def _reg_lines(registry):
    return "\n".join("%d. [%s] %s" % (e["id"], e["kind"], e["desc"]) for e in registry) or "(none yet)"


def _soften(p):
    for a, b in _SOFTEN:
        p = re.sub(a, b, p, flags=re.I)
    return p


def _build_registry(frame_paths, setting=""):
    """Duyet frame THEO THU TU -> SO DANG KY LUY TIEN. Tra (registry, per_scene).

    registry=[{id,kind,desc}] (khoa dan khi thuc the xuat hien LAN DAU); per_scene[i]=
    {present:[id...], scene:str}. Tuan tu (buoc i doc so sau i-1) nen KHONG song song.
    `setting` = boi canh doc tu chinh video; de trong thi noi chung chung, KHONG ep lang que.
    """
    what = (setting or "").strip() or "keep whatever setting and era the frames actually show"
    registry, per_scene = [], []
    for i, fp in enumerate(frame_paths):
        prompt = _REG_PROMPT % (i + 1, len(frame_paths), what, _reg_lines(registry))
        try:
            txt = _openai_vision(prompt, [_b64(fp)], max_tokens=700)
            m = re.search(r"\{.*\}", txt, re.S)
            d = json.loads(m.group(0)) if m else {}
        except Exception as e:
            _log("  canh %d so-dang-ky loi: %s" % (i, str(e)[:60])); d = {}
        present = []
        for pid in (d.get("present") or []):
            try:
                pid = int(pid)
                if 1 <= pid <= len(registry):
                    present.append(pid)
            except Exception:
                pass
        nnew = 0
        for ne in (d.get("new") or []):                 # thuc the MOI -> khoa vao so
            if isinstance(ne, dict) and ne.get("desc"):
                nid = len(registry) + 1
                registry.append({"id": nid, "kind": (ne.get("kind") or "person"),
                                 "desc": _soften(ne["desc"]).strip()})
                present.append(nid); nnew += 1
        per_scene.append({"present": sorted(set(present)), "scene": (d.get("scene") or "").strip()})
        _log("  canh %d: co mat=%s, +%d moi (so dang ky=%d)"
             % (i, sorted(set(present)), nnew, len(registry)))
    return registry, per_scene


def vision_scene_prompts(work, n, setting=""):
    """VISION + SO DANG KY LUY TIEN: moi canh ve DUNG thuc the co mat (khoa dan khi xuat hien moi),
    tai dung DUNG mo ta cho thuc the cu -> nhan vat/do vat/con vat nhat quan xuyen suot 8 canh.
    Moi canh {img: khoa thuc the co mat + mo ta canh, mot: chuyen dong nhe}. Cache scenes+registry.json.
    """
    pf = os.path.join(work, "scenes.json")
    if os.path.isfile(pf):
        return json.load(open(pf, encoding="utf-8"))
    frames = [os.path.join(work, "goc_%02d.jpg" % i) for i in range(n)]
    missing = [i for i, f in enumerate(frames) if not os.path.isfile(f)]
    if missing:
        raise RuntimeError("thieu frame dai dien goc_XX.jpg: %s" % missing)
    if not setting:                      # chua biet boi canh -> doc TU CHINH frame goc
        setting = _video_context(frames)
    registry, per_scene = _build_registry(frames, setting)
    json.dump({"registry": registry, "per_scene": per_scene, "setting": setting},
              open(os.path.join(work, "registry.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    by_id = {e["id"]: e for e in registry}
    scenes = []
    for i in range(n):
        ps = per_scene[i] if i < len(per_scene) else {"present": [], "scene": ""}
        ents = [by_id[pid] for pid in ps.get("present", []) if pid in by_id]
        lock = ""
        if ents:                                        # khoa DUNG thuc the co mat trong canh nay
            lock = ("Keep each of these entities IDENTICAL to its established look across scenes: "
                    + " ".join(e["desc"].rstrip(".") + "." for e in ents) + " ")
        img = (lock + "Scene: " + ps.get("scene", "")).strip()
        img += _scene_suffix(setting)
        scenes.append({"img": img, "mot": _MOTION})
    json.dump(scenes, open(pf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return scenes


# GHIM CUNG model, KHONG dung alias "-latest": do THAT 29/07 phat hien "gemini-flash-latest"
# AM THAM tro sang "gemini-3.6-flash" (dat: $1.50/$7.50 moi 1M token input/output, CON co
# "thinking token" an — 1 video 40s/6 canh ton ~381d). "gemini-3.1-flash-lite" RE HON ~10 LAN
# ($0.25/$1.50, KHONG co thinking token), da do that cung 1 video: chat luong scene-breakdown
# tuong duong, gia ~36d/video. Neu Google doi gia/model nay, sua o day (dung GEMINI_MODEL env
# de doi khong can sua code).
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.1-flash-lite")


def gemini_generate(parts, gen_config=None, tries=4, timeout=180):
    """1 call Gemini generateContent (parts = list [{inline_data}|{text}]). Retry 503/429/timeout
    (backoff 4->20s) vi Gemini hay 503 tam thoi. Tra text tra loi hoac raise sau khi het luot."""
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Thieu GEMINI_API_KEY")
    url = ("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s"
           % (GEMINI_MODEL, key))
    body = {"contents": [{"parts": parts}], "generationConfig": gen_config or {}}
    last = None
    for att in range(tries):
        try:
            r = requests.post(url, json=body, timeout=timeout)
            if r.status_code in (429, 500, 502, 503, 504):
                last = "HTTP %d" % r.status_code
                time.sleep(min(20, 4 * (att + 1)))
                continue
            r.raise_for_status()
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]
        except requests.exceptions.RequestException as e:
            last = str(e)[:80]
            time.sleep(min(20, 4 * (att + 1)))
    raise RuntimeError("Gemini that bai sau %d lan: %s" % (tries, last))

_GEM_SCENE = (
    "Ban XEM VIDEO ngan nay de VE LAI thanh video moi (giu cot truyen + giong goc, chi thay HINH).\n"
    "Video co %d CANH, moc thoi gian (giay) tung canh:\n%s\n"
    'LOI THOAI (transcript): "%s"\n\n'
    "Voi MOI canh theo DUNG THU TU, viet 1 PROMPT tieng ANH de tao ANH tai hien khoanh khac chinh "
    "cua canh do. Mo ta: nguoi (neu ro GIOI TINH: a boy / a girl / a man / a woman; tuoi, toc, khuon "
    "mat, dang nguoi, QUAN AO kem MAU), con vat, do vat, tu the, hanh dong, boi canh/hau canh, goc "
    "may, anh sang, mau sac.\n"
    "CUC KY QUAN TRONG: moi nhan vat / con vat / do vat lap lai phai GIU NGUYEN DIEN MAO Y HET qua "
    "TAT CA cac canh (cung nguoi = cung khuon mat, toc, quan ao).\n"
    "BOI CANH: ta DUNG boi canh co THAT trong video (van phong, quan ca phe, lop hoc, pho thi, nong "
    "thon...). TUYET DOI KHONG tu bien thanh lang que / thap nien 1990 / hoai niem neu video KHONG "
    "he nhu vay. Giu chat Viet Nam, KHONG chuyen sang chau Au.\n"
    "Chi ve dung thuc the thuc su xuat hien; KHONG them nguoi la. KHONG ve bat ky chu/text/caption nao.\n"
    'Tra JSON THUAN (khong markdown): {"boi_canh":"<MOT cum tieng Anh ngan ta boi canh + thoi dai + '
    'vung mien + khong khi CHUNG cua video, vd \'modern Vietnamese open-plan office, satirical comedy\' '
    'hoac \'1990s rural Vietnamese countryside, warm nostalgic\'>", '
    '"scenes":[{"img":"..."}, ...] } dung %d phan tu, theo thu tu canh.')

# Chot chan chong "Au hoa" khi KHONG doc duoc boi canh that tu video. CHU Y: chi khang dinh
# chat Viet, KHONG ep nong thon/thap nien 1990 — ep la ep sai moi page khong phai hoai niem.
_SETTING_FALLBACK = "Vietnamese setting, not European"


def _scene_suffix(setting=""):
    """Duoi dan vao MOI prompt anh. `setting` lay TU CHINH VIDEO NGUON.

    LOI DA TUNG MAC (28/07, page 'Góc Khuất Công Sở' = hai cong so): chuoi
    "1990s rural Vietnamese setting" bi GAN CUNG o day nen moi page deu bi keo ve lang que —
    canh tu ta la "office with tall glass windows" van bi ve ra duong dat, nha tranh, bo song.
    Boi canh phai do VIDEO quyet dinh, khong phai do code quyet dinh san.
    """
    s = (setting or "").strip().rstrip(".") or _SETTING_FALLBACK
    # NHAN VAT NGUOI VIET — phai noi RIENG, khong duoc nam lan trong boi canh.
    # DO THAT 30/07: truoc day chi dan "nguoi Viet" di kem chuoi mac dinh
    # "Vietnamese setting"; khi boi canh lay TU VIDEO (vd "European-style mansion") thi mat
    # luon chi dan do -> anh ra nhan vat nguoi nuoc ngoai. Boi canh va DAN TOC nhan vat la
    # hai thu khac nhau: nha kieu Au van co the la gia dinh nguoi Viet giau.
    return (" %s. Vietnamese people, Vietnamese faces. Draw only the entities described; "
            "do not add unrelated people; do not render any letters, labels or captions." % s)


def _gem_ready_video(video_path, work):
    """Tra duong dan video <19MB de gui inline Gemini. Video goc qua lon -> transcode PROXY nhe
    (chi de PHAN TICH, khong dung lam output). Tra None neu that bai."""
    try:
        if os.path.getsize(video_path) <= 19 * 1024 * 1024:
            return video_path
    except OSError:
        return None
    proxy = os.path.join(work, "gem_proxy.mp4")
    if os.path.isfile(proxy) and os.path.getsize(proxy) > 1000:
        return proxy
    try:                                                  # nen ve ~480p, crf cao -> nhe cho analyze
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", video_path, "-vf", "scale=-2:480",
                        "-c:v", "libx264", "-crf", "32", "-preset", "veryfast",
                        "-c:a", "aac", "-b:a", "64k", proxy], check=True)
        if os.path.getsize(proxy) <= 19 * 1024 * 1024:
            return proxy
    except Exception:
        pass
    return None


# CODE CHET tu khi co `content_pack` (1 call ra ca hook/title/caption/tags) — KHONG con ai
# goi. GIU lai phong khi can, nhung DA BO persona "hoai niem / tam su tuoi tho / doi song que":
# de nguyen thi ai noi lai day vao luong se dinh y nguyen loi da sua o _PACK (do that 28/07).
_VIRAL_CAP = (
    "Ban la chuyen gia viet caption VIRAL cho video reel Facebook, viet duoc MOI giong dieu "
    "(hai huoc, cham biem, tam su, hoai niem) — chon giong theo DUNG noi dung caption goc, "
    "KHONG mac dinh keo ve lang que / tuoi tho.\n"
    "Duoi la caption GOC cua 1 video. Hay VIET LAI (TUYET DOI khong copy nguyen van) "
    "thanh caption tieng Viet CO DAU:\n"
    "- Dong DAU la cau HOOK khien nguoi dang luot phai DUNG LAI xem (khoi to mo / cham cam xuc / cau "
    "hoi gan). Ngan, manh.\n"
    "- 2-4 dong, giu DUNG chu de va cam xuc goc, gan gui that long, khong sao rong khong noi qua.\n"
    "- TUYET DOI khong nhac ten kenh / link / keu goi subscribe-follow / nguon. Toi da 2-3 emoji.\n"
    "- Ket bang 3-5 hashtag xu huong HOP CHU DE (chu de cong so thi #congso #tanlam; chu de tuoi "
    "tho thi #hoainiem #tuoitho) + #xuhuong.\n"
    "Chi TRA VE dung caption cuoi cung, khong giai thich, khong tieu de.\n\nCAPTION GOC:\n\"\"\"%s\"\"\"")


def viral_caption(original, timeout=60):
    """Gemini VIET LAI caption cho VIRAL (hook giu nguoi xem, bo quang ba kenh). KHONG copy nguyen van.
    Fallback: tra `original` neu thieu key / loi (da retry trong gemini_generate)."""
    base = (original or "").strip()
    if not base:
        return base
    try:
        txt = gemini_generate([{"text": _VIRAL_CAP % base[:1500]}],
                              gen_config={"temperature": 0.85}, timeout=timeout)
        out = (txt or "").strip().strip('"').strip()
        return out or base
    except Exception:
        return base


# PERSONA CU ep "hoai niem / tam su / doi song que" cho MOI page -> video hai cong so
# (caption goc "5h30 belike") ra hook "5H30 SANG o QUE / RAT DOI BINH YEN" + tus ta tieng ga
# gay, khoi bep. Do that 28/07. Giong dieu phai BAM NOI DUNG, khong phai gan san trong code.
_PACK = (
    "Ban la chuyen gia noi dung reel Facebook tieng Viet, viet duoc MOI giong dieu: hai huoc,\n"
    "cham biem, tam su, hoai niem, gay can... Chon giong theo DUNG noi dung video.\n"
    "BOI CANH VIDEO (do he thong xem video that ma ra): %s\n"
    "Duoi la caption GOC cua 1 video. Hay tao GOI DANG BAI, tra ve DUNG 1 JSON (khong markdown, "
    "khong giai thich) voi 4 khoa:\n"
    '{"hook": "...", "title": "...", "caption": "...", "tags": ["...", "..."]}\n'
    "- hook: chu CHAY TREN DAU VIDEO trong 3 giay dau, giu nguoi xem dung lai. TOI DA 9 TU, "
    "chia 2 dong bang ky tu \\n, VIET HOA cac tu khoa manh. Phai gay to mo / cham cam xuc / doi "
    "nghich. KHONG dau cau thua, KHONG emoji, KHONG hashtag.\n"
    "  BAT BUOC tieng Viet CO DAU DAY DU (vi du dung: \"ĐÀN ÔNG có TIỀN,\\nĐÀN BÀ đổi KHÁC\" — "
    "vi du SAI vi mat dau: \"DAN ONG co TIEN\").\n"
    "- title: tieu de ngan cho o Tieu De cua Facebook (toi da 60 ky tu, khong hashtag, khong emoji).\n"
    "- caption: 2-4 dong tam su, dong dau la hook manh, giu dung chu de goc, toi da 2-3 emoji, "
    "KHONG nhac ten kenh / link / keu goi follow. KHONG kem hashtag (hashtag de rieng o 'tags').\n"
    "- tags: 4-6 tu khoa KHONG dau '#', khong dau tieng Viet, khong khoang trang, PHAI hop noi "
    "dung video (video cong so thi congso/sepvsnhanvien; video tuoi tho thi hoainiem/tuoitho).\n"
    "CAM BIA: chi viet ve thu CO trong boi canh + caption goc. Caption goc ngan/kho hieu thi bam "
    "BOI CANH, TUYET DOI khong tu chuyen sang lang que / tuoi tho / hoai niem neu video khong nhu vay.\n"
    "TAT CA tieng Viet CO DAU (tru 'tags'). Chi tra JSON.\n\nCAPTION GOC:\n\"\"\"%s\"\"\"")


def _first_json(txt):
    """Boc JSON dau tien trong text (Gemini hay bo them ```json ... ``` hoac chu thua).

    LOI THAT (do 2026-07-25): cat tu '{' dau den '}' cuoi thi khi Gemini tra HAI khoi
    JSON lien nhau (`{...}\\n{...}`) hoac co chu sau JSON -> json.loads nem
    "Extra data" -> ca luot tao bai anh chet. Nay doc bang raw_decode: lay DUNG khoi
    JSON dau tien, ke ben phai co gi cung ke.
    """
    s = (txt or "").strip()
    s = re.sub(r"```[a-zA-Z]*\s*", " ", s).replace("```", " ").strip()
    dec = json.JSONDecoder()
    for i, ch in enumerate(s):
        if ch != "{":
            continue
        try:
            return dec.raw_decode(s, i)[0]
        except ValueError:
            continue
    raise ValueError("khong thay JSON")


def video_setting(work):
    """Boi canh video (Gemini doc tu chinh video) da luu o work dir. Chua co -> ''."""
    f = os.path.join(work, "setting.txt")
    try:
        return open(f, encoding="utf-8").read().strip()
    except OSError:
        return ""


def content_pack(original, timeout=90, context=""):
    """1 CALL Gemini -> ca 4 thu dung cho 1 bai dang:
        {hook, title, caption, tags[]}

    `context` = boi canh THAT cua video (xem `video_setting`). Thieu no thi Gemini chi co
    caption goc de bam — caption goc thuong rat ngan ("5h30 belike") nen no se BIA ra noi
    dung, va truoc day bia theo huong hoai niem lang que vi persona ep san. Xem _PACK.

    hook    = chu chay tren dau VIDEO (band 3s dau / suot video)
    title   = o Tieu de (chi duong Chrome co; Graph API khong co o nay)
    caption = tus
    tags    = o The (Chrome) — KHONG co dau '#'

    Goi 1 lan re hon 4 lan VA giu giong nhat quan giua hook voi tus.
    Loi/thieu key -> fallback an toan tu caption goc (KHONG bao gio nem)."""
    base = (original or "").strip()
    fallback = {"hook": "", "title": "", "caption": base, "tags": ["xuhuong", "viral"]}
    if not base:
        return fallback
    try:
        ctx = (context or "").strip() or "(chua doc duoc — bam sat caption goc, dung tu bia them)"
        txt = gemini_generate([{"text": _PACK % (ctx[:200], base[:1500])}],
                              gen_config={"temperature": 0.85}, timeout=timeout)
        d = _first_json(txt)
        tags = [re.sub(r"[^0-9a-zA-Z_]", "", str(t).lstrip("#"))[:24]
                for t in (d.get("tags") or [])]
        tags = [t for t in tags if t][:6]
        for must in ("xuhuong", "viral"):                 # LUON co 2 tag nay (dedup)
            if must not in [t.lower() for t in tags]:
                tags.append(must)
        return {"hook": (d.get("hook") or "").strip()[:80],
                "title": (d.get("title") or "").strip()[:60],
                "caption": (d.get("caption") or base).strip(),
                "tags": tags}
    except Exception as exc:
        print("[pack] Gemini loi (%s) -> dung caption goc" % str(exc)[:80], flush=True)
        return fallback


def gemini_scene_prompts(video_path, work, n, bounds=None, windows=None, story=""):
    """Gemini XEM NGUYEN video (hinh dong + tieng) -> viet prompt anh cho N canh trong 1 call.
    Uu the vs vision per-frame: thay ca luong + nhat quan nhan vat tu nhien (khong can so dang ky
    tuan tu N call). Cache scenes.json. Tra [{img, mot}] hoac RuntimeError (caller fallback)."""
    pf = os.path.join(work, "scenes.json")
    if os.path.isfile(pf):
        return json.load(open(pf, encoding="utf-8"))
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Thieu GEMINI_API_KEY")
    mp4 = _gem_ready_video(video_path, work)
    if not mp4:
        raise RuntimeError("Khong chuan bi duoc video <19MB cho Gemini")
    # moc thoi gian tung canh (de Gemini can canh dung khoanh khac)
    if bounds:
        rng = []
        for i in range(n):
            s = bounds[i] if i < len(bounds) else 0
            e = (bounds[i] + windows[i]) if (windows and i < len(windows)) else (
                bounds[i + 1] if i + 1 < len(bounds) else s + 3)
            rng.append("canh %d: %.1f-%.1fs" % (i + 1, s, e))
        moc = "\n".join(rng)
    else:
        moc = "%d canh chia deu" % n
    prompt = _GEM_SCENE % (n, moc, (story or "").strip()[:900], n)
    b64 = base64.b64encode(open(mp4, "rb").read()).decode()
    txt = gemini_generate(
        [{"inline_data": {"mime_type": "video/mp4", "data": b64}}, {"text": prompt}],
        gen_config={"responseMimeType": "application/json", "temperature": 0.15})
    data = json.loads(txt)
    arr = data.get("scenes") if isinstance(data, dict) else data
    if not isinstance(arr, list) or not arr:
        raise RuntimeError("Gemini tra scenes rong")
    # BOI CANH lay tu chinh video (Gemini vua xem no) — KHONG gan cung nua. Thieu -> chot chan
    # chi giu "chat Viet", khong ep lang que.
    setting = ((data.get("boi_canh") or "").strip() if isinstance(data, dict) else "")[:160]
    _prog("Bối cảnh đọc từ video gốc: %s" % (setting or "(không đọc được → giữ mặc định)"))
    if setting:      # de khau viet hook/tus (content_pack) dung lai — xem `video_setting`
        try:
            open(os.path.join(work, "setting.txt"), "w", encoding="utf-8").write(setting)
        except OSError:
            pass
    suffix = _scene_suffix(setting)
    scenes = []
    for i in range(n):
        img = ""
        if i < len(arr) and isinstance(arr[i], dict):
            img = (arr[i].get("img") or "").strip()
        if not img:                                       # thieu canh -> tai dung canh truoc/mo ta chung
            img = scenes[-1]["img"] if scenes else ((setting or _SETTING_FALLBACK) + " scene.")
        img = _soften(img)
        img += suffix
        scenes.append({"img": img, "mot": _MOTION})
    json.dump(scenes, open(pf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return scenes


def video_scene_bounds(video_path, work, max_scenes=24, segs=None, fps_sample=1, dhash_thresh=14):
    """Phan tich NHIP video goc -> ranh gioi canh (theo slide THAT) + do dai + boi canh TONG.

    So canh TU BAM theo so slide that (gop thong minh bam moc cau) -> khop nhip loi/gio.
    KHONG mo ta tung frame (2 slide giong nhau -> 2 prompt trung -> ve trung). Chi lay 1 boi
    canh TONG (era/vung/khong khi) de LLM grounding. Cache vbounds.json (idempotent).
    Tra ve (bounds, windows, context): bounds = moc bat dau moi canh; windows = do dai canh.
    """
    vb_f = os.path.join(work, "vbounds.json")
    if os.path.isfile(vb_f):
        d = json.load(open(vb_f, encoding="utf-8"))
        return d["bounds"], d["windows"], d.get("context", "")
    adur = _dur(video_path)
    kf = os.path.join(work, "_kf")
    os.makedirs(kf, exist_ok=True)
    # `setparams=color_primaries=bt709` dat DAU chuoi loc: mot so reel FB ghi the mau HONG
    # (prim:reserved) -> swscale tu choi khi ep sang JPEG ("Unsupported input, Error number
    # -129") -> 0 frame -> ca video dung THAT BAI ngay buoc chia canh. Video the mau binh
    # thuong khong bi anh huong (ghi de dung gia tri dang co).
    _ff(["ffmpeg", "-v", "error", "-y", "-i", video_path, "-vf",
         "setparams=color_primaries=bt709,fps=%d" % fps_sample,
         "-q:v", "3", os.path.join(kf, "f_%04d.jpg")])
    frames = sorted(glob.glob(os.path.join(kf, "f_*.jpg")))
    if not frames:
        raise RuntimeError("Khong tach duoc frame tu video goc.")
    # loc slide RIENG (frame khac han frame giu truoc) + DEDUP slide LAP LAI o xa (slideshow
    # lap 1 canh 2 lan -> so voi MOI slide da giu, nguong chat rep_thresh -> bo slide lap).
    rep_thresh = max(6, dhash_thresh - 6)
    kept, kept_h, last = [], [], None
    for i, f in enumerate(frames):
        h = _dhash(f)
        if last is not None and _ham(h, last) <= dhash_thresh:
            continue                                   # con trong cung 1 slide
        if any(_ham(h, kh) <= rep_thresh for kh in kept_h):
            last = h; continue                         # slide LAP lai o xa -> bo
        kept.append((i / float(fps_sample), f)); kept_h.append(h); last = h
    if not kept:
        kept = [(0.0, frames[0])]
    # GOP THONG MINH: giu cat o CANH CHINH (trung moc doi cau/giong) hoac canh LON (>=2.5s);
    # gop canh vun/phu vao canh truoc. Tua nhip goc, khong truot qua nhu ep 6 canh.
    if segs and len(kept) > 4:
        starts = sorted(float(s.get("start", 0)) for s in segs
                        if s.get("start") is not None and float(s.get("start", 0)) > 0)
        kt = [t for t, _ in kept] + [adur]
        merged = [kept[0]]
        cur_start = kept[0][0]
        for i in range(1, len(kept)):
            dur = kt[i + 1] - kt[i]
            near_narr = any(abs(kept[i][0] - st) < 1.2 for st in starts)   # giong chuyen canh
            too_long = (kt[i] - cur_start) >= 7.0    # canh gop qua dai -> ep cat
            if near_narr or dur >= 2.5 or too_long:
                merged.append(kept[i]); cur_start = kept[i][0]             # else: gop (bo qua)
        kept = merged
    if len(kept) > max_scenes and max_scenes > 0:
        pick = sorted(set(round(k * (len(kept) - 1) / (max_scenes - 1)) for k in range(max_scenes))) \
            if max_scenes > 1 else [0]
        kept = [kept[j] for j in pick]
    bounds = [t for t, _ in kept]
    times = bounds + [adur]
    windows = [max(1.0, times[i + 1] - times[i]) for i in range(len(kept))]
    _log("phan tich NHIP video goc: %d slide -> %d canh" % (len(frames), len(kept)))
    # LUU 1 frame DAI DIEN moi canh (goc_%02d.jpg, ben trong work) -> VISION ta lai de VE
    # bam KHUNG GOC (thay story-driven lech khung). Frame giu la slide dau canh (da dedup).
    for i, (_, fp) in enumerate(kept):
        try:
            shutil.copy(fp, os.path.join(work, "goc_%02d.jpg" % i))
        except OSError:
            pass
    # Bo OpenAI: context chi dung cho 'story' mode (thu cong). Gemini (mac dinh) KHONG can.
    # Chi goi _video_context (OpenAI) khi THAT SU chay story mode -> tinh lazy o nhanh do.
    context = ""

    json.dump({"bounds": bounds, "windows": windows, "context": context},
              open(vb_f, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    shutil.rmtree(kf, ignore_errors=True)
    return bounds, windows, context


def _dialogue_per_window(segs, bounds, adur):
    """Gan loi thoai vao tung cua so canh [bounds[i], bounds[i+1]) theo moc cau whisper.

    Cua so rong (khong cau nao roi vao) -> lay cau gan giua nhat. Tra list text dung thu tu canh.
    """
    edges = list(bounds) + [adur]
    out = []
    for i in range(len(bounds)):
        lo, hi = edges[i], edges[i + 1]
        txt = " ".join(s.get("text", "").strip() for s in (segs or [])
                       if lo - 0.01 <= float(s.get("start", 0)) < hi).strip()
        if not txt and segs:
            near = min(segs, key=lambda s: abs(float(s.get("start", 0)) - (lo + hi) / 2))
            txt = near.get("text", "").strip()
        out.append(txt)
    return out


def _img_err_msg(info):
    """Rut LY DO THAT tu response 79AI khi anh loi.

    DO THAT 2026-07-28: response `check_image` co field **`message`** (task dang chay tra
    "Dang xu ly.."), va `credit_refund` cho biet co duoc hoan hay khong. Truoc day cho
    nay raise cut mot chu "anh loi" -> nuot dung cai field duy nhat noi VI SAO -> thong bao
    cuoi cung ra "anh that bai sau 2 lan: anh loi" (lap chinh no, vo dung) -> khong ai chan
    duoc goc, nen cung mot loi quay lai mai."""
    msg = str(info.get("message") or "").strip()
    parts = [msg or "79AI bao loi nhung khong kem ly do"]
    if info.get("model"):
        parts.append("model=%s" % info["model"])
    if info.get("server_ai"):
        parts.append("may=%s" % info["server_ai"])
    if info.get("credit_refund"):
        parts.append("da hoan %s cr" % info["credit_refund"])
    return " · ".join(parts)


def _wait_image(c, iid, timeout=900):
    w = 0
    while w < timeout:
        info = c.check_image(iid)
        if info.get("status") == "SUCCESS" and info.get("url"):
            return info["url"]
        if info.get("status") == "ERROR":
            raise RuntimeError(_img_err_msg(info))
        time.sleep(12); w += 12
    raise TimeoutError("anh qua gio")


def _wait_video(c, vid, timeout=1500):
    w = 0
    while w < timeout:
        info = c.check_video(vid)
        st = str(info.get("status") or "").upper()
        msg = str(info.get("message") or "").lower()
        # het tai nguyen model -> BAO NGAY de fallback (dung cho timeout 25')
        if "NOT_RESOURCE" in st or "không khả dụng" in msg or "khong kha dung" in msg:
            raise _NotResources(info.get("message") or "NOT_RESOURCES")
        url = GommoClient._video_url(info)
        if "FAIL" in st or "ERROR" in st:
            raise RuntimeError("clip loi: " + str(info.get("message") or "")[:150])
        if url and "PENDING" not in st and "PROCESS" not in st and "QUEUE" not in st:
            return url
        time.sleep(12); w += 12
    raise TimeoutError("clip qua gio")


# Tu khoa 79/veo (Google) BAO BI TU CHOI NOI DUNG (khac treo/het tai nguyen). Refusal la loi
# VINH VIEN cho prompt do tren model do -> co the NHAY model khac (grok loc khac). Treo/resource
# thi GIU model (tranh flood). Xem _gen_one_clip.
_REFUSAL_KW = ("nguy hiem", "nguy hiểm", "tu khoa", "từ kh\xf3a", "dangerous",
               "generation failed", "unsafe", "sensitive", "policy", "violat", "flagged",
               "khong an toan", "kh\xf4ng an to\xe0n", "tu choi", "từ chối")

# 79AI TAT HAN goi dich vu cho 1 MODEL (khac "het tai nguyen tam thoi" — day la lenh dung
# han cua nha cung cap: "Hien goi dich vu Model X khong kha dung. Vui long chon Model khac").
# Thu lai CUNG model la VO ICH -> nhay model khac NGAY (khong doi du I2V_RESUBMIT lan nhu refusal).
_UNAVAILABLE_KW = ("không khả dụng", "khong kha dung", "chọn model khác",
                    "chon model khac", "not available", "service unavailable")


def _is_refusal(msg):
    m = (msg or "").lower()
    return any(k in m for k in _REFUSAL_KW)


def _is_unavailable(msg):
    m = (msg or "").lower()
    return any(k in m for k in _UNAVAILABLE_KW)


class _NotResources(RuntimeError):
    """Model i2v het tai nguyen -> chuyen model khac."""


def _gen_one_image(c, sc, urlf, tries=None, style=DEFAULT_STYLE, img_model=None, block=False):
    """Ve 1 anh khung dau (idempotent qua urlf + `.task` resume — DONG BO voi _gen_one_clip).

    - Lan dau (block=False): submit -> LUU id_base ra `<urlf>.task` NGAY (giu duoc neu process
      chet) -> cho 1 vong toi da REMAKE_IMG_WAIT (mac dinh 15'). Van dang xu ly (chua xong, chua
      loi that) -> tra None (KHONG tinh la loi, GIU .task) de gen_media NHAY sang canh KE TIEP
      thay vi dung khung o day; canh nay duoc quay lai o pass 2 (xem gen_media).
    - Pass 2 (block=True): CHO TIEP CUNG task da luu (KHONG submit anh moi), toi da IMG_MAX_WAITS
      vong (~IMG_MAX_WAITS x REMAKE_IMG_WAIT).
    - LOI THAT (79 tra status=ERROR hoac khong submit duoc id) -> tinh 1 lan that bai, toi da
      IMG_RESUBMIT (mac dinh 2) lan roi raise NGAY bao nguoi dung (khong am tham thu them lan 3/4).
    """
    if os.path.isfile(urlf):
        return open(urlf).read().strip()
    tries = IMG_RESUBMIT if tries is None else tries
    if img_model == "gpt-image-2":
        # OpenAI (dong bo, ngoai 79AI) — khong .task/resume can thiet (1 call la xong).
        # i2v van can URL (khong nhan file cuc bo) -> ve xong upload NGUOC len CDN 79AI
        # (client.upload_image, KHONG ton credit AI) roi ghi URL do vao urlf — tu do
        # moi khau sau (i2v, ghep) coi nhu anh 79AI binh thuong, khong biet nguon khac.
        import openai_image
        # The loai tranh dat o DAU + nhac lai o CUOI (xem _style_prefix/_anti_photo): kieu
        # pixar_3d ban chat gan anh chup, chi de nhan STYLES o giua thi model ve ra NGUOI THAT
        # (do that 30/07, dinh 5 lan tren duong dialogue). Ap cho CA duong nay theo rule
        # "sua song song moi duong" — vo hai voi mau_nuoc/hoat_hinh (chung khong the lan).
        prompt = (_style_prefix(style) + sc["img"]
                  + STYLES.get(style, STYLES[DEFAULT_STYLE]) + BLEED + _anti_photo(style))
        quality = os.environ.get("REMAKE_IMG_MODE") or "low"
        # ANH MAU dung chung ca video (img_ref.png trong work dir): canh dau ve bang chu, cac
        # canh sau ve THEO MAU -> giu dung kieu VA giu khuon mat nhan vat. Khoa lien tien-trinh
        # bang file .lock: gen_media chay SONG SONG nhieu lane, khong khoa thi ca N lane cung
        # thay "chua co mau" roi ve N kieu khac nhau.
        # Cho nguoi dung THAY luc dang xep hang cho han muc OpenAI (truoc day cot tien trinh
        # dung im vai phut -> nhin nhu treo).
        openai_image.PROGRESS = _prog
        # Ngan sach cho khi VAN dinh 429 (sau cau chi): job NEN cho thoai mai hon duong dong
        # bo qua HTTP. 120s cu la qua ngan khi nhieu video chay cung luc.
        ai_wait = float(os.environ.get("REMAKE_OPENAI_WAIT", "420"))
        work_dir = os.path.dirname(urlf)
        refp = os.path.join(work_dir, "img_ref.png")
        reflk = refp + ".lock"
        fails = 0
        while True:
            try:
                ref = None
                if os.path.isfile(refp) and os.path.getsize(refp) > 1000:
                    try:
                        ref = open(refp, "rb").read()
                    except OSError:
                        ref = None
                if ref:
                    png = openai_image.generate_from_ref(
                        prompt + " Keep EXACTLY the same art style, rendering technique and "
                                 "character appearance as the reference image; only the "
                                 "scene/action changes.",
                        ref, ratio="9:16", quality=quality, max_wait_s=ai_wait)
                else:
                    png = openai_image.generate(prompt, ratio="9:16", quality=quality,
                                                max_wait_s=ai_wait)
                tmp = urlf + ".openai.png"
                with open(tmp, "wb") as f:
                    f.write(png)
                _crop_png_to_ratio(tmp)      # OpenAI tra 2:3, khong cat -> clip co vien den
                up = c.upload_image(tmp)
                try:
                    os.remove(tmp)
                except OSError:
                    pass
                url = up.get("url") or up.get("image") or up.get("src")
                if not url:
                    raise RuntimeError("upload 79AI khong tra URL: %s" % str(up)[:150])
                open(urlf, "w").write(url)
                return url
            except Exception as e:
                msg = str(e)
                # Loi TAN CUNG cua OpenAI -> thu lai o day cung vo ich. CHI hai thu that su
                # tan cung: HET TIEN va THIEU KEY. Nguoi dung khong lam gi thi 10 phut nua
                # van the.
                #
                # "chặn tốc độ" TUNG nam trong danh sach nay (27/07) — SAI, va do that 30/07
                # cho thay hau qua: 3 video chet voi "that bai sau 1 lan", vut ca 4-5 anh DA
                # VE XONG (da tra tien), trong khi chan toc do la trang thai TAM THOI het sau
                # vai chuc giay. Dung nguyen nhom voi "79AI dang nghen" -> phai duoc thu lai
                # theo _IMG_BACKOFF nhu nhanh 79AI (xem [[nha-cung-cap-chap-chon-dung-giam-so-lan]]).
                # Ke cau chi rate_gate() o openai_image, 429 gio la ngoai le hiem.
                terminal = any(k in msg for k in ("hết quota", "Thiếu OPENAI_API_KEY"))
                fails += 1
                if terminal or fails >= tries:
                    # [:400] (truoc [:150]) — 150 ky tu cat cut ngay giua than loi, nuot mat
                    # doan OpenAI noi "Please try again in Xs" = phan huu ich nhat.
                    raise RuntimeError("anh (gpt-image-2) that bai sau %d lan: %s" % (fails, msg[:400]))
                # Chan toc do thi cho LAU hon loi thuong (5→20→60→120s) — cho 4s roi ban lai
                # ngay chi to lam tran day them.
                wait_s = _IMG_BACKOFF[min(fails - 1, len(_IMG_BACKOFF) - 1)]
                _log("  anh (gpt-image-2) loi (%s) -> cho %ds roi gui lai (%d/%d)"
                     % (msg[:200], wait_s, fails, tries))
                _prog("Ảnh OpenAI lỗi (%s) → chờ %ds rồi vẽ lại (%d/%d)"
                      % (("chặn tốc độ" if "chặn tốc độ" in msg else "lỗi tạm"), wait_s, fails, tries))
                time.sleep(wait_s)
    # Model/mode ve anh CHON DUOC qua tham so (uu tien) hoac env. DO THAT 2026-07-26 (79AI nghen
    # nang luc do): thu SONG SONG moi to hop mien phi -> banana_pro (cu, moi mode) KET 8'+ (9/10
    # to hop van PENDING); 3.0-omni XONG 26s (1k) / 51s (2k) — nhanh nhat, cung 0cr trong goi.
    # -> DOI MAC DINH sang 3.0-omni. banana_pro/seedream_4_5 van chon duoc qua tham so/env khi can.
    img_model = img_model or os.environ.get("REMAKE_IMG_MODEL", "3.0-omni")
    # 3.0-omni KHONG co "mode" (do that: modes=[] tu image_models()) -> gui mode se bi API
    # bo qua hoac loi vo ich; cac model khac (banana_pro/seedream_4_5) van can "vip".
    img_mode = os.environ.get("REMAKE_IMG_MODE") or (None if img_model == "3.0-omni" else "vip")
    img_res = os.environ.get("REMAKE_IMG_RES", "1k")
    img_wait = int(os.environ.get("REMAKE_IMG_WAIT", "900"))
    taskf = urlf + ".task"
    failsf = urlf + ".fails"
    vid = open(taskf).read().strip() or None if os.path.isfile(taskf) else None
    # fails PHAI ben qua CA 2 pass (khong reset ve 0 khi pass 1 tra None roi pass 2 goi lai) —
    # neu khong, 1 canh dinh 1 loi that o pass 1 roi treo (None) se duoc CAP LAI het IMG_RESUBMIT
    # o pass 2 -> vuot qua tran 2 lan da hua voi nguoi dung. Luu dem ra file canh .task.
    fails = int(open(failsf).read().strip() or 0) if os.path.isfile(failsf) else 0
    waits = 0     # so vong CHO THEM khi anh VAN song (block=True, pass 2) — bounded IMG_MAX_WAITS
    while True:
        if not vid:
            r = c.create_image(model=img_model,
                               prompt=sc["img"] + STYLES.get(style, STYLES[DEFAULT_STYLE]) + BLEED,
                               ratio="9:16", mode=img_mode, resolution=img_res)
            info = r.get("imageInfo") or r.get("data") or r
            vid = info.get("id_base") or r.get("id_base")
            if not vid:
                fails += 1
                open(failsf, "w").write(str(fails))
                if fails >= tries:
                    try:
                        os.remove(failsf)
                    except OSError:
                        pass
                    raise RuntimeError("anh: 79AI tu choi submit sau %d lan: %s" % (fails, str(r)[:300]))
                wait_s = _IMG_BACKOFF[min(fails - 1, len(_IMG_BACKOFF) - 1)]
                _prog("79AI chưa nhận lệnh vẽ ảnh → chờ %ds rồi gửi lại (%d/%d)"
                      % (wait_s, fails, tries))
                time.sleep(wait_s); continue
            open(taskf, "w").write(vid)     # LUU id NGAY -> cuu duoc neu process chet giua chung
        try:
            url = _wait_image(c, vid, timeout=img_wait)
            open(urlf, "w").write(url)
            for f in (taskf, failsf):
                try:
                    os.remove(f)
                except OSError:
                    pass
            return url
        except TimeoutError:
            if not block:
                # con song, chua ro loi hay khong -> NHUONG cho canh khac (gen_media pass 1),
                # GIU .task (VA .fails) de quay lai (pass 2) resume DUNG task nay, KHONG submit lai.
                return None
            waits += 1
            if waits >= IMG_MAX_WAITS:
                raise TimeoutError("anh cho qua lau (%d x %ds) — GIU task de chay lai resume"
                                   % (waits, img_wait))
            _log("  anh van dang xu ly tren 79 (cho tiep, GIU task) - lan %d/%d" % (waits, IMG_MAX_WAITS))
            continue                        # vid GIU NGUYEN -> cho lai CUNG task
        except RuntimeError as e:
            # task DA CHET THAT (status=ERROR) -> an toan clear + submit LAI (loi THAT, tinh strike).
            # fails BEN qua ca 2 pass (ghi file) -> tran IMG_RESUBMIT la TONG cho ca doi canh,
            # khong bi reset ve 0 giua pass 1 va pass 2.
            vid = None
            try:
                os.remove(taskf)
            except OSError:
                pass
            emsg = str(e)
            # LOI CO DINH vs NGAU NHIEN — doi xung voi duong CLIP (_gen_one_clip da phan biet
            # tu 2026-07-26, duong ANH thi chua: bat doi xung dung kieu [[sua-song-song-4-duong]]).
            # Bi chan noi dung / model tat han -> gui lai CUNG prompt CUNG model la vo ich.
            fixed = _is_refusal(emsg) or _is_unavailable(emsg)
            fails += 1
            open(failsf, "w").write(str(fails))
            if fixed or fails >= tries:
                try:
                    os.remove(failsf)
                except OSError:
                    pass
                why = ("79AI TU CHOI noi dung (gui lai cung prompt se lai truot — sua mo ta "
                       "canh hoac doi Model ve anh)" if fixed
                       else "that bai %d lan" % fails)
                raise RuntimeError("anh %s: %s" % (why, emsg[:300]))
            wait_s = _IMG_BACKOFF[min(fails - 1, len(_IMG_BACKOFF) - 1)]
            # _prog (khong phai _log): hien len COT TIEN TRINH -> nguoi dung THAY tool dang
            # thu lai va thay VI SAO, thay vi tuong no treo roi tu nhien bao that bai.
            _prog("Ảnh lỗi (%s) → chờ %ds rồi gửi lại (%d/%d)"
                  % (emsg[:120], wait_s, fails, tries))
            time.sleep(wait_s); continue


MAX_STRETCH = float(os.environ.get("REMAKE_MAX_STRETCH", "1.5"))   # keo clip toi da 1.5x (het GIAT)


def _fit_scene(clip, target, seg_path, resample, threads=0):
    """Tao 1 doan video DUNG `target` giay tu clip i2v -> KHONG bi giat vi keo qua cham.
    - target <= clip*MAX_STRETCH: keo cham nhe (<=1.5x) cho day (motion muot, blend it).
    - target >  clip*MAX_STRETCH: clip keo toi 1.5x + NOI Ken-Burns zoom KHUNG CUOI cho phan du.
      (Truoc: keo thang 2-3x = motion bo + blend = GIAT. Freeze = do. Ken-Burns = muot, lien mach.)"""
    base = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1"
    enc = ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium", "-crf", "20", "-r", "30"]
    if threads:
        enc += ["-threads", str(threads)]         # 1 luong -> ne loi libx264 -22 'Terminating thread'
    cl = _dur(clip)
    if target <= cl * MAX_STRETCH + 0.05:
        stretch = max(1.0, target / cl)
        vf = "%s,setpts=%.4f*PTS,%s,trim=0:%.3f,setpts=PTS-STARTPTS,format=yuv420p" % (
            base, stretch, resample, target)
        _ff(["ffmpeg", "-v", "error", "-y", "-i", clip, "-vf", vf, "-an"] + enc + [seg_path])
        return seg_path
    # Phan CLIP: keo toi 1.5x. Phan DU: Ken-Burns khung cuoi.
    clip_dur = cl * MAX_STRETCH
    tail = max(0.4, target - clip_dur)
    pc, pk, lf, lst = seg_path + ".c.mp4", seg_path + ".k.mp4", seg_path + ".last.jpg", seg_path + ".txt"
    vf = "%s,setpts=%.4f*PTS,%s,trim=0:%.3f,setpts=PTS-STARTPTS,format=yuv420p" % (
        base, MAX_STRETCH, resample, clip_dur)
    _ff(["ffmpeg", "-v", "error", "-y", "-i", clip, "-vf", vf, "-an"] + enc + [pc])
    _ff(["ffmpeg", "-v", "error", "-y", "-sseof", "-0.2", "-i", clip, "-frames:v", "1",
         "-vf", base, lf])
    _ken_burns_clip(lf, pk, dur=tail)                 # zoom cham khung cuoi -> noi tiep muot
    with open(lst, "w", encoding="utf-8") as f:
        f.write("file '%s'\nfile '%s'\n" % (os.path.abspath(pc), os.path.abspath(pk)))
    _ff(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-an"]
        + enc + [seg_path])
    for p in (pc, pk, lf, lst):
        try:
            os.remove(p)
        except OSError:
            pass
    return seg_path


def _ken_burns_clip(img_src, clip_path, dur=8.0):
    """LUOI AN TOAN (khong i2v): zoom/pan cham tren ANH TINH -> clip 1080x1920. LUON chay,
    0 hang, 0 credit video. Dung khi moi model i2v treo/fail. Motion la camera (khong canh dong).
    """
    tmp = clip_path + ".src.jpg"
    if str(img_src).startswith("http"):
        download(img_src, tmp)
    else:
        shutil.copy(img_src, tmp)
    fps = 30
    frames = max(1, int(dur * fps))
    # scale len 2x roi zoompan xuong 1080x1920 -> zoom min muot, khong vo hat.
    vf = ("scale=2160:3840:force_original_aspect_ratio=increase,crop=2160:3840,"
          "zoompan=z='min(zoom+0.0012,1.12)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
          "d=%d:s=1080x1920:fps=%d,setsar=1,format=yuv420p" % (frames, fps))
    _ff(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-i", tmp, "-t", "%.3f" % dur,
         "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium",
         "-crf", "20", clip_path])
    try:
        os.remove(tmp)
    except OSError:
        pass
    return clip_path


def _gen_one_clip(c, sc, img_url, clip_path, clip_model, kb_dur=8.0):
    """i2v 1 canh — CHI dung model NGUOI DUNG chon. KHONG tu chuyen model, KHONG tu rot Ken Burns.

    - clip_model == 'kenburns': nguoi dung CHON Ken Burns -> ve tu anh (KHONG goi 79).
    - veo/grok: submit 1 lan -> LUU id_base ra `<clip>.task` NGAY (process chet van cuu duoc) ->
      cho LAU (I2V_WAIT ~1h, hang doi uu tien cua goi). RESUME: co `.task` san -> cho+tai, KHONG
      submit lai. 79 het tai nguyen / loi / cho qua lau -> submit LAI CUNG model (bounded
      I2V_RESUBMIT), KHONG nhay model (tranh nhoi hang cho -> treo), KHONG Ken Burns ngam. Het
      luot -> raise (canh loi -> reel loi RO -> nguoi dung tu chon lam lai / doi 'kenburns').
    DUNG hay CHO la QUYET DINH cua nguoi dung (nut Dung) — khong tu dong."""
    # Nguoi dung chon Ken Burns -> ve thang tu anh, khong dung 79 (0 cho, 0 quota).
    if clip_model == "kenburns":
        _ken_burns_clip(img_url, clip_path, dur=kb_dur)
        return "kenburns"
    taskf = clip_path + ".task"
    params = VIDEO_PARAMS.get(clip_model, {"mode": "fast", "resolution": "720p"})
    # RESUME: process truoc da submit + luu id (chet giua chung) -> DUNG lai id do, KHONG submit lai.
    vid = open(taskf).read().strip() or None if os.path.isfile(taskf) else None
    tries = 0        # so lan SUBMIT LAI (chi khi task CHET) — bounded I2V_RESUBMIT
    waits = 0        # so vong CHO them khi task VAN song (khong submit lai) — bounded I2V_MAX_WAITS
    refusals = 0     # so lan bi TU CHOI NOI DUNG -> du I2V_RESUBMIT thi NHAY grok (1 lan)
    switched = False # da nhay sang grok chua (chi nhay 1 lan)
    while True:
        if not vid:
            rv = c.create_video(model=clip_model, prompt=sc["mot"], ratio="9:16",
                                ref_image_urls=[img_url], **params)
            info = rv.get("videoInfo") or rv.get("data") or rv
            vid = (info or {}).get("id_base") or (rv.get("id_base") if isinstance(rv, dict) else None)
            if not vid:                    # 79 tu choi submit (thuong do het tai nguyen tam thoi)
                reason = (rv.get("error") or rv.get("message") or str(rv)[:90]) if isinstance(rv, dict) else str(rv)[:90]
                tries += 1
                if tries >= I2V_RESUBMIT:
                    raise RuntimeError("79AI tu choi i2v %s sau %d lan (%s)" % (clip_model, tries, reason))
                _prog("79AI bận (%s) → chờ rồi thử LẠI CÙNG model (%d/%d), KHÔNG đổi model" % (clip_model, tries, I2V_RESUBMIT))
                time.sleep(min(60, 15 * tries)); continue
            open(taskf, "w").write(vid)    # LUU id NGAY sau khi 79 nhan -> cuu duoc neu process chet
        try:
            url = _wait_video(c, vid, timeout=I2V_WAIT)   # cho LAU trong hang doi uu tien
            download(url, clip_path)
            try:
                os.remove(taskf)
            except OSError:
                pass
            return clip_model
        except TimeoutError:
            # HET GIO CHO nhung task CO THE VAN dang chay tren 79 -> TUYET DOI KHONG xoa .task /
            # submit lai (se de task MO COI + nhoi hang doi = FLOOD). Giu NGUYEN task, cho TIEP
            # (cung id). Het kien nhan -> GIU .task de lan chay sau RESUME (tai ve khi 79 xong).
            waits += 1
            if waits >= I2V_MAX_WAITS:
                raise RuntimeError("i2v %s cho qua lau (%d x %ds) — GIU task de chay lai resume, KHONG Ken Burns"
                                   % (clip_model, waits, I2V_WAIT))
            _prog("Clip %s vẫn đang xử lý trên 79 (chờ tiếp, GIỮ nguyên task) — KHÔNG đổi model, KHÔNG Ken Burns" % clip_model)
            continue                        # vid GIU NGUYEN -> _wait_video lai CUNG task, KHONG submit moi
        except (_NotResources, RuntimeError) as e:
            # task DA CHET -> an toan clear + submit LAI.
            vid = None
            try:
                os.remove(taskf)
            except OSError:
                pass
            emsg = str(e)
            # (0) GOI DICH VU TAT HAN cho model nay ("khong kha dung. Vui long chon model khac"):
            # KHAC "het tai nguyen tam thoi" — thu lai CUNG model la VO ICH (79AI da bao ro). Nhay
            # model NGAY (khong doi du I2V_RESUBMIT lan resubmit vo ich nhu nhanh (2) ben duoi).
            if _is_unavailable(emsg):
                if clip_model != "grok_video_heavy" and not switched:
                    _prog("Model %s không khả dụng (79AI báo tắt dịch vụ) → CHUYỂN NGAY sang grok"
                          % clip_model)
                    clip_model = "grok_video_heavy"
                    params = VIDEO_PARAMS.get(clip_model, {"mode": "fast", "resolution": "720p"})
                    switched, tries, refusals = True, 0, 0
                    time.sleep(2); continue
                raise RuntimeError(("model %s không khả dụng (đã thử chuyển sang grok)" % clip_model
                                    if switched else "model %s không khả dụng" % clip_model)
                                   + " — chọn model khác/Ken Burns")
            # (1) BI TU CHOI NOI DUNG (veo loc gat "prompt nguy hiem"): la loi VINH VIEN cho prompt do
            # tren model do. Sau I2V_RESUBMIT lan tu choi -> NHAY grok (loc khac, thuong qua). CHI
            # refusal moi nhay model; treo/het-tai-nguyen thi GIU model (nhanh (2) tranh flood).
            if _is_refusal(emsg):
                refusals += 1
                if refusals < I2V_RESUBMIT:
                    _prog("Bị từ chối nội dung (%d/%d) → làm mềm prompt, thử LẠI cùng model %s"
                          % (refusals, I2V_RESUBMIT, clip_model))
                    sc = dict(sc, mot=_soften(sc.get("mot", "")))   # lam mem prompt truoc khi thu lai
                    time.sleep(3); continue
                if clip_model != "grok_video_heavy" and not switched:
                    _prog("veo từ chối nội dung %d lần → CHUYỂN sang grok (chỉ khi bị từ chối, không phải treo)"
                          % refusals)
                    clip_model = "grok_video_heavy"
                    params = VIDEO_PARAMS.get(clip_model, {"mode": "fast", "resolution": "720p"})
                    switched, tries, refusals = True, 0, 0
                    time.sleep(3); continue
                raise RuntimeError("i2v bị từ chối nội dung %d lần (cả veo lẫn grok) — cảnh lỗi, đổi prompt/kiểu ảnh"
                                   % (refusals + I2V_RESUBMIT))
            # (2) KHONG phai refusal (treo/het tai nguyen/loi khac) -> GIU model, resubmit bounded (cu).
            tries += 1
            if tries >= I2V_RESUBMIT:
                raise RuntimeError("i2v %s that bai sau %d lan (%s) — canh loi, khong tu Ken Burns"
                                   % (clip_model, tries, emsg[:60]))
            _prog("Clip %s lỗi trên 79 (%s) → submit LẠI CÙNG model (%d/%d), KHÔNG Ken Burns"
                  % (clip_model, emsg[:40], tries, I2V_RESUBMIT))
            time.sleep(min(90, 20 * tries)); continue


def gen_media(scenes, work, clip_model="veo_3_1", style=DEFAULT_STYLE, lanes=None, img_model=None):
    """Ve anh + i2v SONG SONG (`lanes` lane, mac dinh LANES=1). IDEMPOTENT (resume qua .task/.txt).
    KHONG fallback model — model do NGUOI DUNG chon (veo/grok/kenburns), i2v cho lau + submit
    lai cung model (xem _gen_one_clip). style: 'real' (MAC DINH) | 'cartoon' ..."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    lanes = max(1, int(lanes or LANES))
    c = GommoClient()          # _post dung requests.post truc tiep -> thread-safe
    n = len(scenes)
    clip_of = lambda i: os.path.join(work, "clip_%02d.mp4" % i)
    urlf_of = lambda i: os.path.join(work, "img_%02d.txt" % i)
    done = lambda i: os.path.isfile(clip_of(i)) and os.path.getsize(clip_of(i)) > 1000
    have = sum(1 for i in range(n) if done(i))
    if have:                                   # RESUME: bao ro da co bao nhieu canh -> chi lam tiep phan thieu
        _prog("Đã có %d/%d cảnh làm sẵn → chỉ làm tiếp %d cảnh còn thiếu (giữ clip cũ)" % (have, n, n - have))
    # Bo dem tien trinh chay TRONG lock: cac lane song song bao xong -> dem/day len UI
    # tuan tu (fb_pipeline ghi CUNG 1 file, phai serialize de khoi hong).
    plock = threading.Lock()

    # Pha 1: ve anh (bo qua canh da co clip). Song song toi da LANES.
    # 2 PASS (yeu cau: canh timeout KHONG chan canh khac, KHONG gui lai cung canh ngay):
    #  - Pass 1: moi canh cho 1 vong (~15'). Con song (chua xong, chua loi that) -> tra None,
    #    GIU .task, NHUONG cho canh ke tiep (khong tinh la loi).
    #  - Pass 2: cac canh con "None" sau pass 1 -> CHO TIEP CUNG task da luu (block=True,
    #    khong submit lai), toi da IMG_MAX_WAITS vong. Loi THAT van tinh strike (IMG_RESUBMIT).
    todo_img = [i for i in range(n) if not done(i)]
    imgs = {}
    img_cnt = [n - len(todo_img)]          # tinh ca canh da co san (resume) -> "3/7" dung
    def _img(i, block=False):
        u = _gen_one_image(c, scenes[i], urlf_of(i), style=style, img_model=img_model, block=block)
        if u is None:
            return i, None
        with plock:
            img_cnt[0] += 1
            _prog("Đang tạo ảnh %d/%d" % (img_cnt[0], n))
        _log("scene%d anh xong (con %d cr)" % (i, c.credits())); return i, u
    # Anh da ve xong = co file .txt (URL) HOAC da co clip. Dung de bao ro trong thong bao loi:
    # canh loi lam ca bai hong, nhung anh da ve VAN NAM DO -> bam Thu lai la NOI TIEP, khong
    # ve lai tu dau. Truoc day thong bao chi co "anh that bai sau 2 lan" nen nguoi dung khong
    # biet dieu do, tuong mat sach cong lam.
    have_img = lambda: sum(1 for i in range(n) if done(i) or os.path.isfile(urlf_of(i)))
    if todo_img:
        _prog("Đang tạo ảnh 0/%d (chuẩn bị)" % n)
        try:
            pending = []
            with ThreadPoolExecutor(max_workers=lanes) as ex:
                for f in [ex.submit(_img, i) for i in todo_img]:
                    i, u = f.result()
                    (pending.append(i) if u is None else imgs.__setitem__(i, u))
            if pending:
                _prog("Còn %d ảnh đang xử lý trên 79 → chờ tiếp (không gửi lại, KHÔNG chặn cảnh khác)"
                      % len(pending))
                with ThreadPoolExecutor(max_workers=lanes) as ex:
                    for f in [ex.submit(_img, i, True) for i in pending]:
                        i, u = f.result(); imgs[i] = u
        except Exception as e:
            raise RuntimeError(
                "%s — đã vẽ xong %d/%d ảnh. Ảnh đã vẽ KHÔNG mất: bấm Thử lại là làm tiếp "
                "phần còn thiếu (phần đã có không tốn thêm)" % (str(e)[:300], have_img(), n))

    # Pha 2: i2v (bo qua canh da co clip). Song song toi da LANES.
    todo_clip = [i for i in range(n) if not done(i)]
    clip_cnt = [n - len(todo_clip)]
    def _clip(i):
        img_url = imgs.get(i) or open(urlf_of(i)).read().strip()
        used = _gen_one_clip(c, scenes[i], img_url, clip_of(i), clip_model)
        with plock:
            clip_cnt[0] += 1
            _prog("Đang tạo video từ ảnh %d/%d" % (clip_cnt[0], n))
        _log("scene%d clip xong (model %s, con %d cr)" % (i, used, c.credits()))
    if todo_clip:
        _prog("Đang chờ tạo video từ ảnh 0/%d" % n)
        with ThreadPoolExecutor(max_workers=lanes) as ex:
            for f in [ex.submit(_clip, i) for i in todo_clip]:
                f.result()          # propagate loi (neu co)
    return [clip_of(i) for i in range(n)]


def _group_scenes(segs, n, adur, min_win=1.2):
    """Chia transcript thanh n NHOM cau lien tiep (bam moc cau) -> [{text,start,end,dur}].

    Canh i phu nhom cau i -> vua khop TIMING (bien = moc cau) vua khop NOI DUNG (text
    nhom do dung de sinh prompt anh). Nguon duy nhat cho ca gen_scene_prompts lan assemble.
    """
    if not segs or n <= 1:
        return [{"text": "", "start": i * adur / n, "end": (i + 1) * adur / n,
                 "dur": adur / n} for i in range(n)]
    starts = sorted(set(float(s.get("start", 0)) for s in segs
                        if s.get("start") is not None and 0 < float(s.get("start", 0)) < adur))
    bnds = [0.0]
    for i in range(1, n):
        target = i * adur / n
        cand = [st for st in starts if st > bnds[-1] + min_win and st < adur - min_win]
        b = min(cand, key=lambda st: abs(st - target)) if cand else min(bnds[-1] + min_win, adur)
        bnds.append(b)
    bnds.append(adur)
    groups = []
    for i in range(n):
        lo, hi = bnds[i], bnds[i + 1]
        txt = " ".join(s.get("text", "").strip() for s in segs
                       if lo - 0.01 <= float(s.get("start", 0)) < hi).strip()
        if not txt and segs:                         # nhom rong -> cau gan giua nhat
            near = min(segs, key=lambda s: abs(float(s.get("start", 0)) - (lo + hi) / 2))
            txt = near.get("text", "").strip()
        groups.append({"text": txt, "start": lo, "end": hi, "dur": max(min_win, hi - lo)})
    return groups


def _scene_windows(segs, n, adur):
    """Do dai tung canh (giay) — dung chung nhom voi gen prompt (nhat quan timing)."""
    return [g["dur"] for g in _group_scenes(segs, n, adur)]


def assemble(clips, orig_video, out_path, work, segs=None, wins=None, xfade=0.6, threads=0):
    """Ghep muot (crossfade + lam cham cho day) + long AUDIO GOC (che do B).

    wins (uu tien) = do dai moi canh theo TIMING video goc (video-driven). Neu None ->
    tinh tu segs (bam moc cau). Neu ca hai None -> chia deu.
    """
    adur = float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", orig_video]).decode().strip())
    n = len(clips)
    if wins and len(wins) == n:
        segw = list(wins)                            # do dai canh theo video goc
    else:
        segw = _scene_windows(segs, n, adur)         # fallback: bam moc cau / chia deu
    wins = [s + xfade for s in segw]                 # them xfade de crossfade sang canh sau
    def cdur(p):
        return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries",
            "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", p]).decode().strip())
    # DO THAT (2026-07-23): clip Grok la 24fps, ep fps=30 -> ffmpeg NHAN DOI 1/4 khung
    # (240 khung/8s nhung chi 192 khac nhau) => CHUYEN CANH GIAT/LAC. Giai phap: minterpolate
    # BLEND hoa khung chen -> 238/238 khung khac nhau (het trung), chi cham hon ~2s/clip.
    # (mci muot nhat nhung >90s/clip @1080x1920 -> khong dung cho may khach.)
    # Env REMAKE_SMOOTH: blend (mac dinh) | dup (cu, nhanh nhat, con giat) | mci (muot nhat, RAT cham).
    _sm = os.environ.get("REMAKE_SMOOTH", "blend").lower()
    if _sm == "dup":
        _resample = "fps=30"
    elif _sm == "mci":
        _resample = "minterpolate=fps=30:mi_mode=mci:mc_mode=obmc:me_mode=bidir"
    else:
        _resample = "minterpolate=fps=30:mi_mode=blend"
    # Build TUNG doan canh dung do dai (fit): keo <=1.5x, du thi Ken-Burns khung cuoi (het GIAT).
    inputs, filt = [], []
    for i, cp in enumerate(clips):
        seg = os.path.join(work, "seg_%02d.mp4" % i)
        _fit_scene(cp, wins[i], seg, _resample, threads=threads)
        inputs += ["-i", seg]
        filt.append("[%d:v]setpts=PTS-STARTPTS[v%d]" % (i, i))
    prev = "v0"; acc = wins[0]
    for k in range(1, n):
        filt.append("[%s][v%d]xfade=transition=fade:duration=%.2f:offset=%.3f[x%d]"
                    % (prev, k, xfade, max(0.0, acc - xfade), k))
        prev = "x%d" % k; acc = acc + wins[k] - xfade
    # NGUON CAM (DASH mat fragment audio -> mp4 khong co tieng): dau '?' o map audio =
    # tuy chon -> ffmpeg BO QUA thay vi CHET "Stream map matches no streams" (loi khach hay gap
    # o khau ghep cuoi SAU khi da ve het clip). Nguon cam -> video ra IM (van xong, khong mat clip).
    if not _has_audio(orig_video):
        _prog("⚠ Video nguồn KHÔNG có tiếng (tải thiếu audio) → video sẽ im (không mất clip đã vẽ)")
    cmd = ["ffmpeg", "-v", "error", "-y"] + inputs + ["-i", orig_video,
        "-filter_complex", ";".join(filt), "-map", "[%s]" % prev, "-map", "%d:a?" % n,
        "-t", "%.3f" % adur, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium",
        "-crf", "20"] + (["-threads", str(threads)] if threads else []) + [
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out_path]
    _ff(cmd)
    for i in range(len(clips)):                       # don seg tam
        try:
            os.remove(os.path.join(work, "seg_%02d.mp4" % i))
        except OSError:
            pass
    return out_path


def _assemble_simple(clips, orig_video, out_path, work, wins=None):
    """LUOI AN TOAN cho GHEP: KHONG xfade, KHONG minterpolate. Chuan hoa moi clip -> 1080x1920
    30fps yuv420p (dup frame) roi CONCAT (cat thang) + long audio (map '?' -> nguon cam khong crash),
    encode `-threads 1` (chong libx264 loi -22 'Terminating thread'). Dung khi ghep muot (xfade+
    minterpolate) sap tren may khach -> video VAN xong tu clip DA VE (chi mat hieu ung chuyen canh muot).
    """
    n = len(clips)
    adur = _dur(orig_video)
    segw = list(wins) if (wins and len(wins) == n) else [adur / max(1, n)] * n
    base = ("scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,"
            "fps=30,format=yuv420p")
    enc = ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium", "-crf", "20", "-threads", "1"]
    parts, lst = [], os.path.join(work, "s_concat.txt")
    for i, cp in enumerate(clips):
        seg = os.path.join(work, "ssg_%02d.mp4" % i)
        cl = _dur(cp)
        stretch = max(1.0, segw[i] / cl) if cl > 0 else 1.0
        vf = "%s,setpts=%.4f*PTS,trim=0:%.3f,setpts=PTS-STARTPTS" % (base, stretch, segw[i])
        _ff(["ffmpeg", "-v", "error", "-y", "-i", cp, "-vf", vf, "-an"] + enc + [seg])
        parts.append(seg)
    with open(lst, "w", encoding="utf-8") as f:
        for p in parts:
            f.write("file '%s'\n" % os.path.abspath(p))
    concat = os.path.join(work, "s_concat.mp4")
    _ff(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c:v", "copy", concat])
    _ff(["ffmpeg", "-v", "error", "-y", "-i", concat, "-i", orig_video, "-map", "0:v", "-map", "1:a?",
         "-t", "%.3f" % adur, "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
         "-movflags", "+faststart", out_path])
    for p in parts + [concat, lst]:
        try:
            os.remove(p)
        except OSError:
            pass
    return out_path


def _default_voice_id():
    """Voice ElevenLabs de doc: uu tien roster (giong dang dung), roi giong dau."""
    try:
        import voice_roster
        for v in voice_roster.roster():
            if v.get("engine") == "eleven":
                return v.get("id")
    except Exception:
        pass
    try:
        import eleven_tts
        vs = eleven_tts.list_voices()
        return vs[0]["voice_id"] if vs else None
    except Exception:
        return None


def _pick_music():
    if os.path.isdir(MUSIC_DIR):
        pref = os.path.join(MUSIC_DIR, "nhac_nen_mau.m4a")
        if os.path.isfile(pref):
            return pref
        for fn in sorted(os.listdir(MUSIC_DIR)):
            if fn.lower().endswith((".mp3", ".m4a", ".ogg", ".wav")):
                return os.path.join(MUSIC_DIR, fn)
    return None


def make_voice_audio(story, work, voice_id=None):
    """Mode A: TTS giong MOI doc cot truyen + nhac nen ducked -> audio.m4a. Tra (path)."""
    import eleven_tts
    out = os.path.join(work, "voicemix.m4a")
    if os.path.isfile(out) and os.path.getsize(out) > 1000:
        return out
    vid = voice_id or _default_voice_id()
    if not vid:
        raise RuntimeError("Khong co voice ElevenLabs de doc (mode A).")
    voice_mp3 = os.path.join(work, "voice.mp3")
    if not (os.path.isfile(voice_mp3) and os.path.getsize(voice_mp3) > 1000):
        _log("TTS giong moi (ElevenLabs)...")
        eleven_tts.synth(story, vid, voice_mp3)
    music = _pick_music()
    if music:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", voice_mp3,
                        "-stream_loop", "-1", "-i", music, "-filter_complex",
                        "[1:a]volume=0.18[m];[0:a][m]amix=inputs=2:duration=first:normalize=0[a]",
                        "-map", "[a]", "-c:a", "aac", "-b:a", "192k", out], check=True)
    else:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", voice_mp3,
                        "-c:a", "aac", "-b:a", "192k", out], check=True)
    return out


# ============================================================================
# HUONG MOI (2026-07-29): nhan vat NOI THAT tieng Viet, Veo tu sinh audio cung
# luc voi video -> tu khop moi, KHONG can lip-sync rieng (omnihuman_1_5/
# kling_video_lipsync: dat + rui ro, xem SKILL.md). Da nghiem thu THAT tren
# reel 2051533612116989 (139-142s, 18 canh). Cong thuc day du + bay da dinh:
# .claude/skills/remake-nhan-vat-noi-that/SKILL.md — DOC TRUOC KHI SUA O DAY.
# ============================================================================

#  ĐO THẬT 30/07 — vì sao "hôm qua chuẩn mà nay loạn":
#  Prompt cũ chỉ nói "a SHORT visual description (setting, character with consistent
#  appearance/clothing, action)". Chữ "short" + không có ví dụ + không bắt buộc gì cả →
#  Gemini tuỳ nghi. Video 5 cảnh (hôm qua) nó tả kỹ: "In a rural village courtyard at night
#  under a crescent moon and fireflies, a father holding rolled mats points up to the roof
#  while talking to his two excited children" -> anh ve ra khop canh, nhan vat do troi.
#  Video 8-11 canh (hom nay) no rut gon con: "The pregnant woman throws a document onto the
#  table." -> KHONG boi canh, KHONG ngoai hinh, KHONG trang phuc -> model ve tu bia het ->
#  8 canh = 8 nguoi khac nhau + canh khong khop goc.
#  ⇒ Hom qua la MAY, khong phai dung. Nay ep bang: bang NHAN VAT dung chung + yeu cau do dai
#  toi thieu cho visual + vi du TOT/XAU (few-shot) + tran do dai thoai cho vua 8 giay.
_GEM_UNIFIED = (
    "Watch and LISTEN to this full video carefully - both spoken dialogue/narration AND "
    "background music AND visual scene changes, all together. Produce a precise scene-by-scene "
    "breakdown. For EACH distinct narrative beat, give: start-end timestamp (seconds), the EXACT "
    "Vietnamese dialogue/narration spoken (word for word, empty string if none), a visual "
    "description in ENGLISH, whether background music is present and its mood, and the DELAY in "
    "seconds between when the shot starts and when speech actually starts (0 if immediate).\n"
    "\nRULES FOR `visual` (each scene is drawn as a SEPARATE image by a text-to-image model "
    "that has NO memory of the other scenes - so each description must stand alone):\n"
    "1. 25-60 words. Never a bare one-line action.\n"
    "2. MUST state WHERE it happens concretely (which room, furniture, lighting, time of day).\n"
    "3. MUST name every visible person using the EXACT role label from `nhan_vat` below, and "
    "repeat their key look (hair + outfit + colour) inline.\n"
    "4. MUST state camera framing (wide shot / medium shot / close-up) and who is where.\n"
    # nguoi_noi: DO THAT 30/07 — `visual` liet ke 2-3 vai TRONG KHUNG nhung KHONG noi AI DANG
    # NOI cau do, nen prompt gui Veo chi ghi "chi mot nguoi noi" -> VEO TU CHON nguoi -> co
    # canh SAI NGUOI NOI (nguoi dung: "nhan vat noi cung chua khop"). Bat Gemini chi ro.
    "5. Also give `nguoi_noi` for the scene: the EXACT role label of the ONE person who speaks "
    "that line (empty string if nobody speaks). This is required - the video generator needs "
    "to know whose mouth to move.\n"
    "GOOD: \"Medium shot in a warmly lit wood-panelled living room with a crystal chandelier: "
    "CON_DAU (long straight black hair, cream silk dress) sits on the burgundy velvet sofa while "
    "ME_CHONG (short curled hair, dark red ao dai) stands with folded arms beside her.\"\n"
    "BAD: \"The pregnant woman throws a document onto the table.\"  (no place, no look, no framing)\n"
    # ⚠️ CAU CHU LUC NAY TUNG GAY HAI: ban truoc viet "never put more than 22 words of dialogue
    # in a single scene" -> Gemini hieu la "RUT BOT thoai cho duoi 22 tu" chu khong phai "tach
    # thanh nhieu canh". DO THAT: Gemini chi chep 116/162 tu cua ban goc (giu 69%) — thoai mat
    # NGAY O BUOC CHEP LOI, truoc khi Veo doc. Nay noi RO: cam rut gon/dien dat lai, chi duoc
    # TACH THANH NHIEU CANH.
    "\nRULES FOR `dialogue` - THIS IS THE MOST IMPORTANT PART:\n"
    "1. Transcribe EVERY spoken word, VERBATIM. Do NOT shorten, summarise or paraphrase. "
    "Losing words is the worst possible error here.\n"
    # ⚠️ CAN CA HAI CHIEU. Do that 30/07: whisper chep DU tu (162/162) nhung SAI CHINH TA
    # ("Bac Lan oi"->"Bac la noi", "To giay"->"Tu gioi", "osin hau ha"->"o xin hau hao",
    # "Ba ngu thi rang chiu, lu lu ra day ham chau dich ton"->"Bang ngu thi dang chiu, lua lua
    # ra day ham cho dich con"); con Gemini tu nghe thi DUNG CHINH TA nhung THIEU 31% tu.
    # Dung whisper de chong THIEU, dung Gemini de chong SAI — khong duoc chi lay mot ben.
    "2. The reference transcript below comes from a speech recogniser on this exact audio. Use "
    "it so that NOTHING IS MISSED - it tells you how much is said. BUT it contains recognition "
    "errors (wrong Vietnamese words and diacritics, e.g. it may write 'Bac la noi' where the "
    "speaker clearly says 'Bac Lan oi'). CORRECT those errors using what you actually HEAR and "
    "what makes sense in context - the dialogue you output must be correct Vietnamese that a "
    "narrator can read aloud. Fix wording, never drop content.\n"
    # Do that: sau khi sua 1 vong van con cum VO NGHIA ("Co co vo khong" = "Co co vu khong",
    # "o xin" = "osin", "dich con" = "dich ton"). Bat kiem lai tung cau truoc khi tra.
    "2b. FINAL CHECK on every line: it must be meaningful Vietnamese a person would actually "
    "say. If a phrase looks like garbled recognition ('Co co vo khong', 'o xin hau ha', 'dich "
    "con', 'dang chiu', 'ham cho'), work out the intended words from context and family-drama "
    "conventions ('Co co vu khong', 'osin hau ha', 'chau dich ton', 'rang chiu', 'ham chau') "
    "and write THOSE. A nonsense line is a failure even if it matches the transcript.\n"
    "3. Each scene is voiced as ONE 8-second clip (Vietnamese fits ~20 words in 8s). If one "
    "person's line is longer than that, SPLIT IT ACROSS CONSECUTIVE SCENES at a clause "
    "boundary, keeping every word. NEVER drop words to make a line fit - add another scene "
    "instead. The total dialogue across all scenes must contain the full transcript.\n"
    "\n- nhan_vat: the CAST of the video. For each recurring person give a stable UPPERCASE "
    "role label (VI: CON_DAU, ME_CHONG, CHONG, EM_DAU...) and a fixed physical description: "
    "approximate age, hair (length/style/colour), outfit (garment + colour), build, one "
    "distinguishing feature. This is the character bible - the SAME description is reused in "
    "every scene so the person looks identical throughout.\n"
    # boi_canh + kieu_hinh: LAY TU CHINH VIDEO. Truoc day duong nay khong hoi 2 thu nay nen
    # anh ve ra bi ep ve "lang que Viet Nam" (mac dinh cua _scene_suffix) — video biet thu
    # noi that kieu Au van ra nha tranh gach bong. Gemini DANG xem video san -> 0 chi phi them.
    "ALSO report, for the video AS A WHOLE:\n"
    "- boi_canh: the setting/location in ENGLISH, specific (e.g. 'luxurious modern European-style "
    "mansion interior, ornate wood panelling and chandeliers' / 'poor 1990s rural Vietnamese "
    "village house'). Describe what you ACTUALLY SEE, do not assume Vietnamese countryside.\n"
    "- kieu_hinh: the ART STYLE of the footage, EXACTLY ONE of: real (live action / real people), "
    "pixar_3d (3D animated render, Pixar/Disney look), hoat_hinh (2D hand-drawn cartoon), "
    "anime (Japanese anime), mau_nuoc (watercolour painting), son_dau (oil painting), "
    "ngam_doi (black and white emotional), chan_dung_dien_anh (cinematic photo portrait).\n"
    # kieu_hinh_mo_ta: 8 nhan co dinh trong code KHONG du de tai tao dung "look" cua nguon
    # (vd nguon la 3D render chat luong cao kieu Disney hien dai — nhan 'pixar_3d' trong code
    # lai co "cute rounded shapes" nen ra tron trinh de thuong, khong giong). De Gemini TA
    # THAT look roi dung lam hau to prompt ve anh.
    "- kieu_hinh_mo_ta: 12-30 words in ENGLISH describing the exact visual look well enough to "
    "recreate it (render technique, lighting, skin/hair detail, colour palette, level of "
    "stylisation). Describe what you SEE, do not name a studio's marketing style.\n"
    'Tra JSON THUAN (khong markdown): {"boi_canh":"...","kieu_hinh":"...","kieu_hinh_mo_ta":"...",'
    '"nhan_vat":[{"vai":"CON_DAU","mo_ta":"woman ~28, long straight black hair, cream silk '
    'dress, slim"}, ...],'
    '"scenes":[{"start":0.0,"end":8.0,"dialogue":"...","nguoi_noi":"CON_DAU",'
    '"visual":"...","music":"...","delay":0.0}, ...]}')

# Tran tu thoai cho MOT clip 8 giay. Do that 30/07: canh 34 tu -> Veo noi khong het, bi CAT
# giua cau o ranh gioi clip (do muc am 0.4s cuoi: 4/8 canh con tieng to = dang noi bi cat).
# Tieng Viet noi tu nhien ~2.5 tu/giay -> 8s ≈ 20 tu; de 22 lam tran mem.
DLG_MAX_WORDS = int(os.environ.get("DLG_MAX_WORDS", "22"))


def _split_long_scenes(scenes, max_words=None):
    """LUOI AN TOAN: canh nao thoai dai qua 8 giay -> tach thanh nhieu canh noi tiep.

    Prompt DA yeu cau Gemini tu chia (<=22 tu/canh) nhung khong the tin no luon tuan —
    do that 30/07: 1 canh 34 tu -> Veo noi khong het -> CAT GIUA CAU o ranh gioi clip
    (4/8 canh dinh). Ham nay chia lai theo RANH GIOI CAU/CUM (. ! ? , ;) de khong cat giua
    cum tu, giu nguyen `visual`/`music` cho moi phan (cung mot canh, chi khac loi noi).
    Moc thoi gian chia deu theo so tu de `_music_bed` van tinh duoc khoang khong loi.
    """
    mw = int(max_words or DLG_MAX_WORDS)
    out = []
    for sc in scenes:
        dl = (sc.get("dialogue") or "").strip()
        words = dl.split()
        if len(words) <= mw or not _has_dialogue(dl):
            out.append(sc)
            continue
        # cat theo cum: gom tung menh de, day sang phan moi khi vuot tran
        parts, cur = [], []
        for chunk in re.split(r"(?<=[.!?,;])\s+", dl):
            if cur and len(" ".join(cur + [chunk]).split()) > mw:
                parts.append(" ".join(cur)); cur = [chunk]
            else:
                cur.append(chunk)
        if cur:
            parts.append(" ".join(cur))
        # cum don le van qua dai (cau khong dau) -> chia cung theo so tu
        fixed = []
        for p in parts:
            w = p.split()
            if len(w) <= mw:
                fixed.append(p)
            else:
                for k in range(0, len(w), mw):
                    fixed.append(" ".join(w[k:k + mw]))
        st, en = float(sc.get("start") or 0), float(sc.get("end") or 0)
        step = (en - st) / max(1, len(fixed))
        # img_key: cac phan tach ra CUNG MOT canh -> DUNG CHUNG 1 anh. Neu ve 2 anh rieng cho
        # cung mot `visual` thi 2 canh lien nhau se ra 2 nguoi hoi khac -> chuyen canh thay
        # mat doi, dung cai nguoi dung phan nan. Kem theo: tiet kiem tien ve anh.
        key = "g%03d" % len(out)
        for k, p in enumerate(fixed):
            s2 = dict(sc)
            s2["dialogue"] = p
            s2["start"] = round(st + k * step, 2)
            s2["end"] = round(st + (k + 1) * step, 2)
            s2["img_key"] = key
            if k:
                s2["delay"] = 0.0          # phan noi tiep: noi ngay, khong tre lai
            out.append(s2)
    return out


def _share_same_visual(scenes):
    """Canh LIEN NHAU co CUNG mo ta hinh -> dung CHUNG 1 anh (gan img_key giong nhau).

    Hai nguon sinh ra ca nay: (a) `_split_long_scenes` tach 1 canh dai thanh nhieu phan,
    (b) Gemini tu tra 2 canh lien nhau cung `visual` (chi khac loi thoai) — gap that.
    Neu ve 2 anh RIENG cho cung mot mo ta thi 2 canh lien nhau ra 2 nguoi hoi khac ->
    chuyen canh thay mat doi = dung cai nguoi dung phan nan "nhan vat khong nhat quan".
    Ham nay chay DUOC nhieu lan (idempotent) va xu ly ca ban phan tich CU khong co img_key.
    """
    def norm(v):
        return re.sub(r"\s+", " ", (v or "").strip().lower())

    prev_v, prev_key = None, None
    for i, sc in enumerate(scenes):
        v = norm(sc.get("visual"))
        if v and v == prev_v:
            sc["img_key"] = prev_key           # dung chung anh voi canh truoc
        else:
            prev_key = str(sc.get("img_key") or ("%02d" % i))
            sc["img_key"] = prev_key
        prev_v = v
    return scenes


def gemini_unified_scenes(video_path, work):
    """1 lan Gemini xem CA thoai+nhac+hinh -> [{start,end,dialogue,visual,music,delay}].
    Thay cach cu (video_scene_bounds + whisper transcript + LLM ta anh RIENG): 3 nguon do KHONG
    doi chieu duoc voi nhau -> de gan sai thoai cho sai canh (da dinh that, xem SKILL.md)."""
    vp = _gem_ready_video(video_path, work)
    if not vp:
        raise RuntimeError("Video qua lon, khong transcode duoc proxy de Gemini phan tich")
    # CHEP LOI BANG WHISPER TRUOC roi dua vao prompt lam VAN BAN GOC.
    # DO THAT 30/07: Gemini tu nghe chi chep 116/162 tu (mat 31% loi thoai) — nguoi dung bao
    # "thoai bi cat bot nhieu", va thu pham la BUOC CHEP LOI chu khong phai Veo (Veo giu 91%
    # nhung cai dua cho no da thieu). Whisper (local, 0d) chep DAY DU hon han: 162 tu.
    # Van de MOT lan goi Gemini (khong pha nguyen tac "1 nguon su that" cua SKILL Buoc 1):
    # Gemini van xem video de chia canh + gan AI NOI CAU NAO, chi khac la co san van ban dung.
    ref = ""
    try:
        segs, story = transcribe(video_path, work)
        ref = " ".join((s.get("text") or "").strip() for s in (segs or []))[:6000]
    except Exception as exc:
        _log("khong chep loi duoc bang whisper (%s) -> de Gemini tu nghe" % str(exc)[:80])
    prompt = _GEM_UNIFIED
    if ref:
        _prog("Da chep loi bang whisper (%d tu) -> dua cho Gemini lam van ban goc"
              % len(ref.split()))
        prompt += ("\n\nREFERENCE TRANSCRIPT (speech recogniser, use for exact wording; "
                   "every word here must appear in some scene's dialogue):\n" + ref)
    b64 = base64.b64encode(open(vp, "rb").read()).decode()
    txt = gemini_generate(
        [{"inline_data": {"mime_type": "video/mp4", "data": b64}}, {"text": prompt}])
    m = re.search(r"\{.*\}", txt, re.S)
    if not m:
        raise RuntimeError("Gemini khong tra JSON hop le: %s" % txt[:200])
    d = json.loads(m.group(0))
    scenes = d.get("scenes") or []
    # BOI CANH + KIEU HINH cua ca video: luu file RIENG (khong nhet vao scenes.json de khong
    # pha dinh dang cu — work dir da co san van doc duoc). remake_dialogue doc lai o duoi.
    for key, fn in (("boi_canh", "dlg_setting.txt"), ("kieu_hinh", "dlg_style.txt"),
                    ("kieu_hinh_mo_ta", "dlg_style_desc.txt")):
        v = (d.get(key) or "").strip()
        if v:
            with open(os.path.join(work, fn), "w", encoding="utf-8") as f:
                f.write(v)
    # BANG NHAN VAT (character bible) — nguon gay "nhan vat khong nhat quan": moi canh ve
    # anh RIENG, model khong nho canh truoc, nen mo ta nhan vat phai co trong MOI prompt.
    cast = [c for c in (d.get("nhan_vat") or []) if (c.get("vai") and c.get("mo_ta"))]
    if cast:
        with open(os.path.join(work, "dlg_cast.json"), "w", encoding="utf-8") as f:
            json.dump(cast, f, ensure_ascii=False, indent=2)
    n0 = len(scenes)
    scenes = _split_long_scenes(scenes)          # luoi an toan chong CAT GIUA CAU
    if len(scenes) != n0:
        _prog("Tach %d canh co thoai qua dai -> %d canh (moi clip 8s noi tron cau)"
              % (n0, len(scenes)))
    _share_same_visual(scenes)                   # canh cung mo ta hinh -> dung chung 1 anh
    with open(os.path.join(work, "unified_scenes.json"), "w", encoding="utf-8") as f:
        json.dump(scenes, f, ensure_ascii=False, indent=2)
    return scenes


def dialogue_cast_map(work) -> dict:
    """{vai: mo_ta} — de prompt clip noi ro AI dang noi (kem ngoai hinh nguoi do)."""
    try:
        cast = json.load(open(os.path.join(work, "dlg_cast.json"), encoding="utf-8"))
    except Exception:
        return {}
    return {str(c.get("vai") or "").strip(): str(c.get("mo_ta") or "").strip()
            for c in cast if c.get("vai")}


def dialogue_cast(work) -> str:
    """Bang nhan vat -> chuoi ghep vao MOI prompt anh ("" neu khong co).

    Vi sao BAT BUOC: moi canh la 1 lan goi text-to-image RIENG, model KHONG nho canh truoc.
    Do that 30/07: `visual` chi ghi "The pregnant woman throws a document onto the table" ->
    8 canh ra 8 nguoi khac nhau. Skill Buoc 2 da ghi: chi nhat quan NEU mo ta nhan vat duoc
    LAP LAI DAY DU trong moi prompt.
    """
    p = os.path.join(work, "dlg_cast.json")
    try:
        cast = json.load(open(p, encoding="utf-8"))
    except Exception:
        return ""
    parts = []
    for c in cast[:6]:                            # tran 6 nhan vat (prompt qua dai thi loang)
        vai = str(c.get("vai") or "").strip()
        mo = str(c.get("mo_ta") or "").strip().rstrip(".")
        if vai and mo:
            parts.append("%s = %s" % (vai, mo))
    if not parts:
        return ""
    return (" CHARACTERS - keep each person's face, hair and outfit IDENTICAL to this "
            "description: " + "; ".join(parts) + ".")


def dialogue_setting(work) -> str:
    """Boi canh Gemini doc ra tu video nguon ("" neu chua co)."""
    p = os.path.join(work, "dlg_setting.txt")
    try:
        return open(p, encoding="utf-8").read().strip()
    except OSError:
        return ""


def dialogue_art_style(work) -> str:
    """Kieu hinh Gemini nhan ra tu video nguon, doi ve khoa trong STYLES ("" neu khong ro)."""
    p = os.path.join(work, "dlg_style.txt")
    try:
        v = open(p, encoding="utf-8").read().strip().lower()
    except OSError:
        return ""
    return v if v in STYLES else ""


_ANIM_STYLES = ("pixar_3d", "hoat_hinh", "cartoon", "anime", "mau_nuoc", "son_dau")

# Cau MO DAU tuyen bo "day la tranh gi" — dat o KY TU DAU TIEN cua prompt.
# DO THAT 30/07 (dinh 3 lan lien): prompt dai 1837 ky tu, cum "3D animated" nam o ky tu 798
# (43% chieu dai) = BI CHON GIUA, trong khi 798 ky tu dau toan tu ta nguoi that ("long dark
# hair, white lace dress, burgundy velvet sofa") -> model ve ra ANH THAT du cuoi prompt da co
# chot phu dinh. Quy uoc text-to-image: MEDIUM/STYLE phai dung DAU.
_STYLE_PREFIX = {
    # pixar_3d la kieu DE TRUOT NHAT: "3D render chat luong cao" ban chat GAN anh that, nen
    # chi noi "3D animated, not a photograph" thi model van ve nguoi that (dinh 5 lan).
    # Phai nhan phan CACH DIEU — dac trung THAT cua phim Pixar/Disney: mat to, da MIN KHONG
    # LO CHAN LONG, ti le hoi khoa truong, be mat sach nhu do choi.
    "pixar_3d": ("A stylised 3D ANIMATED FEATURE FILM still (Pixar/Disney CGI): characters have "
                 "large expressive eyes, smooth poreless doll-like skin, slightly exaggerated "
                 "cartoon proportions, clean toy-like surfaces. This is NOT a photo of real "
                 "people, NOT live-action: "),
    "hoat_hinh": "A 2D hand-drawn cartoon illustration, NOT a photograph: ",
    "cartoon": "A 2D cartoon illustration, NOT a photograph: ",
    "anime": "A Japanese anime illustration, NOT a photograph: ",
    "mau_nuoc": "A watercolour painting, NOT a photograph: ",
    "son_dau": "An oil painting, NOT a photograph: ",
    "ngam_doi": "A black-and-white emotional illustration, NOT a colour photograph: ",
}


def _style_prefix(style) -> str:
    """Tuyen bo the loai tranh o DAU prompt ("" voi kieu anh that)."""
    return _STYLE_PREFIX.get(style or "", "")


def _anti_photo(style) -> str:
    """Chot PHU DINH cho cac kieu VE (khong phai anh that).

    DO THAT 30/07: prompt co day du nhan "3D animated character render, Pixar Disney style"
    + cau ta cua Gemini, VAN ra ANH THAT 4/5 lan. Ly do: cau ta cua Gemini chua "soft
    flattering CINEMATIC LIGHTING", "smooth facial features", "clean textures" — deu la tu
    khoa moi ANH CHUP. Model phai hoa giai mau thuan nen chon ngau nhien.
    Chot phu dinh dat o CUOI (vi tri cuoi co suc nang hon) de dut khoat.

    ⚠️ Va bai hoc ve NGHIEM THU: 1 anh thu ra dung KHONG chung minh duoc gi khi ket qua
    ngau nhien — phai thu NHIEU anh (>=4 canh khac nhau) roi nhin cung luc.
    """
    if (style or "") in _ANIM_STYLES:
        return (" IMPORTANT: this is a STYLISED ANIMATION frame, NOT a photograph. "
                "Not photorealistic, not live-action, no real human skin pores or photographic "
                "depth of field.")
    return ""


#  Tu khoa MOI ANH CHUP — phai bo khoi cau ta look khi kieu la TRANH.
#  DO THAT 30/07 (lan thu 4 dinh cung mot loi): prompt DA co "A 3D animated movie still, CGI
#  render, NOT a photograph" o DAU va "NOT a photograph" o CUOI, Gemini DA nhan dung
#  kieu_hinh='pixar_3d' — nhung cau ta cua no chua "REALISTIC SKIN TEXTURES" -> anh ra NGUOI
#  THAT 100%. Lan truoc cau ta la "smooth character facial features, vibrant clean textures"
#  (khong co "realistic skin") nen ra 3D. Tuc ket qua phu thuoc Gemini dung tu gi -> phai LOC.
_PHOTO_WORDS = re.compile(
    r"\b(photo-?realistic|photorealism|realistic skin[a-z ]*|real skin[a-z ]*|"
    r"skin pores?|photographic|photograph|dslr|bokeh|depth of field|"
    r"lifelike|hyper-?real(?:istic)?)\b", re.I)


def _strip_photo_words(desc: str) -> str:
    """Bo cac tu MOI ANH CHUP khoi cau ta look (chi khi kieu la tranh)."""
    out = _PHOTO_WORDS.sub("", desc or "")
    out = re.sub(r"\s*,\s*,", ",", out)
    out = re.sub(r"\s{2,}", " ", out).strip().strip(",").strip()
    return out


def dialogue_style_desc(work, style=None) -> str:
    """Cau TA LOOK that cua video nguon -> dung lam hau to prompt ve anh.

    Tin cay hon nhan co dinh: 8 nhan trong STYLES khong du do "look" (nguon 3D render chat
    luong cao bi nhan 'pixar_3d' keo ve "cute rounded shapes"). Tra "" neu chua co.
    """
    p = os.path.join(work, "dlg_style_desc.txt")
    try:
        v = open(p, encoding="utf-8").read().strip()
    except OSError:
        return ""
    if len(v) < 15 or len(v) > 400:          # qua ngan/qua dai = khong dung duoc
        return ""
    return ", " + v.rstrip(".") + "."


def _has_dialogue(dialogue) -> bool:
    """Canh nay CO loi thoai that khong?

    DO THAT 30/07 (video 1980385242704855): Gemini tra ve dialogue = "..." cho canh KHONG ai
    noi (3/11 canh). Chuoi do KHAC RONG nen kiem 'if dialogue.strip()' cho la CO thoai ->
    prompt hoa thanh 'noi ra dung van ban: "..."' -> Veo mieng map may vo nghia / tu bia loi.
    Dung mam cua loi cu "mieng noi tieng la khong khop audio". Nay bo het dau cau + khoang
    trang, con lai RONG thi coi la canh IM LANG.
    """
    s = (dialogue or "").strip()
    if not s:
        return False
    return bool(re.sub(r"[\s.,!?;:…\-–—\"'`()\[\]]+", "", s))


def _dialogue_prompt(dialogue, ctx, speaker="", speaker_desc=""):
    """`speaker`/`speaker_desc`: AI dang noi cau nay (vai + mo ta ngoai hinh).

    DO THAT 30/07: khong chi ro nguoi noi thi Veo TU CHON trong so 2-3 nguoi trong khung ->
    co canh sai nguoi mo mieng (nguoi dung: "nhan vat noi cung chua khop"). Cau
    "only ONE speaks at a time" KHONG du — no chi noi SO LUONG, khong noi LA AI.
    """
    if _has_dialogue(dialogue):
        who = ""
        if speaker:
            ai = ("%s (%s)" % (speaker, speaker_desc)) if speaker_desc else speaker
            who = ("ONLY %s speaks this line - that is the person whose mouth moves. "
                   "Everyone else in frame keeps their mouth completely CLOSED and still, "
                   "just listening/reacting. " % ai)
        return (
            "Wide/medium shot: %s. %sSpeak out loud in VIETNAMESE, natural emotional voice "
            "fitting the scene, saying exactly this Vietnamese text: \"%s\" Mouth moves "
            "naturally matching each word. Slow gentle camera push-in, cinematic and "
            "smooth. Keep face, identity and composition stable; no morphing, no distortion, "
            "no shaking." % (ctx, who, dialogue.strip()))
    return (
        "Wide/medium shot: %s. Natural physical motion matching the action described. Does "
        "not speak, mouth closed the entire time, silent. Slow gentle camera follow, cinematic "
        "and smooth. Keep face, identity and composition stable; no morphing, no distortion, "
        "no shaking." % ctx)


def _gen_dialogue_clip(c, img_url, dialogue, ctx, clip_path, clip_model="veo_3_1",
                       speaker="", speaker_desc=""):
    """Sinh 1 clip Veo NOI THAT tieng Viet (dialogue khac rong) hoac CHUYEN DONG CAM (dialogue
    rong). GIU audio Veo tu sinh lam audio CUOI CUNG (khong cat -an, khong ghep audio khac) -
    video+audio ra tu CUNG 1 lan sinh nen tu khop moi. Tran cung 8s/clip (khong dai hon duoc).

    Co RESUME (.task) + RETRY bounded (het tai nguyen tam thoi / tu choi noi dung) — GIONG het
    triet ly _gen_one_clip, nhung KHONG doi model (grok chua kiem chung co "noi theo van ban"
    giong veo_3_1 hay khong — do that 29/07: _NotResources tu Veo lam chet ca job vi ham cu
    khong bat loi nay)."""
    params = dict(VIDEO_PARAMS.get(clip_model, {"mode": "fast", "resolution": "720p"}))
    params["duration"] = "8"
    mot = _dialogue_prompt(dialogue, ctx, speaker, speaker_desc)
    taskf = clip_path + ".task"
    vid = open(taskf).read().strip() or None if os.path.isfile(taskf) else None
    tries = 0
    refusals = 0
    # waits: so vong CHO THEM khi task VAN song. THIEU no thi `except TimeoutError: continue`
    # thanh VONG VO HAN — 1 canh treo tren 79AI giu job "dang chay" mai mai, khong bao gio
    # raise resumable de lan sau chay lai. `_gen_one_clip` (duong san xuat cu) da co tran nay
    # tu lau; ham dialogue thi khong — code review 30/07 bat duoc.
    waits = 0
    while True:
        if not vid:
            rv = c.create_video(model=clip_model, prompt=mot, ratio="9:16",
                                ref_image_urls=[img_url], **params)
            info = rv.get("videoInfo") or rv.get("data") or rv
            vid = (info or {}).get("id_base") or (rv.get("id_base") if isinstance(rv, dict) else None)
            if not vid:
                reason = (rv.get("error") or rv.get("message") or str(rv)[:90]) if isinstance(rv, dict) else str(rv)[:90]
                tries += 1
                if tries >= I2V_RESUBMIT:
                    raise RuntimeError("79AI tu choi submit dialogue clip sau %d lan (%s)" % (tries, reason))
                _prog("79AI bận (%s) → chờ rồi thử LẠI (%d/%d)" % (reason[:40], tries, I2V_RESUBMIT))
                time.sleep(min(60, 15 * tries)); continue
            open(taskf, "w").write(vid)
        try:
            url = _wait_video(c, vid, timeout=I2V_WAIT)
            download(url, clip_path)
            try:
                os.remove(taskf)
            except OSError:
                pass
            return clip_path
        except TimeoutError:
            # Task CO THE VAN dang chay tren 79 -> TUYET DOI KHONG xoa .task / submit lai
            # (se de task mo coi + nhoi hang doi = flood). Cho TIEP cung id, nhung CO TRAN:
            # het kien nhan thi GIU .task va raise de lan chay sau RESUME dung task do.
            waits += 1
            if waits >= I2V_MAX_WAITS:
                raise RuntimeError(
                    "i2v dialogue cho qua lau (%d x %ds) — GIU task de chay lai resume"
                    % (waits, I2V_WAIT))
            _prog("Clip dialogue vẫn đang xử lý trên 79 (chờ tiếp %d/%d, GIỮ nguyên task)"
                  % (waits, I2V_MAX_WAITS))
            continue
        except (_NotResources, RuntimeError) as e:
            vid = None
            try:
                os.remove(taskf)
            except OSError:
                pass
            emsg = str(e)
            if _is_refusal(emsg):
                refusals += 1
                if refusals >= I2V_RESUBMIT:
                    raise RuntimeError("i2v dialogue bị từ chối nội dung %d lần — cảnh lỗi, sửa lời "
                                       "thoại/mô tả cảnh (câu quá gay gắt hay bị chặn)" % refusals)
                _prog("Bị từ chối nội dung (%d/%d) → làm mềm prompt, thử LẠI" % (refusals, I2V_RESUBMIT))
                mot = _soften(mot)
                time.sleep(3); continue
            tries += 1
            if tries >= I2V_RESUBMIT:
                raise RuntimeError("i2v dialogue thất bại sau %d lần (%s)" % (tries, emsg[:60]))
            _prog("Clip dialogue lỗi trên 79 (%s) → submit LẠI (%d/%d)" % (emsg[:40], tries, I2V_RESUBMIT))
            time.sleep(min(90, 20 * tries)); continue


def _crop_png_to_ratio(path, ratio=9.0 / 16.0):
    """Cat anh ve DUNG ty le (mac dinh 9:16, cat deu 2 ben). Tra True neu co cat.

    DO THAT 30/07: openai_image.SIZES chi co 3 kich thuoc, "9:16" bi ALIAS ve 1024x1536
    (2:3 = 0.667) — KHONG phai 9:16 (0.5625). Gui anh 2:3 cho Veo lam ra clip co VIEN DEN
    tren/duoi. Cat truoc khi upload thi Veo dung tron khung, khong sinh vien.
    Anh da co san hau to BLEED ("full bleed, no border") nen chu the nam giua -> cat 2 ben
    an toan. Anh 79AI ve dung 9:16 san nen ham nay khong cat gi (vo hai).
    """
    from PIL import Image
    try:
        im = Image.open(path)
        w, h = im.size
        if abs(w / float(h) - ratio) < 0.01:
            return False
        nw = int(round(h * ratio))
        if nw <= w:                                  # cat bot chieu NGANG
            x = (w - nw) // 2
            im.crop((x, 0, x + nw, h)).save(path)
        else:                                        # anh qua ngang -> cat chieu CAO
            nh = int(round(w / ratio))
            y = max(0, (h - nh) // 2)
            im.crop((0, y, w, min(h, y + nh))).save(path)
        return True
    except Exception as e:
        _log("  canh bao: khong cat duoc anh ve 9:16 (%s) -> gui nguyen ban" % str(e)[:80])
        return False


def _black_bars(src, w, h):
    """Do VIEN DEN trong clip -> tra chuoi filter crop, hoac "" neu khong co vien.

    DO THAT 30/07: OpenAI (gpt-image-2) CHI co 3 kich thuoc, "9:16" bi alias ve 1024x1536
    (ty le 2:3 = 0.667, KHAC 9:16 = 0.5625) -> Veo nhan anh sai ty le nen tu them vien den
    tren/duoi, va vien do nam TRONG pixel nen crop=720:1280 o duoi khong cat duoc gi.
    Do bang cropdetect tren nhieu frame roi lay ket qua chung.

    THAN TRONG (canh dem/canh toi that de bi cat oan):
      - chi cat khi vung con lai >= 55% chieu cao (khong bao gio cat qua nua khung),
      - chi cat khi vien DOI XUNG tren/duoi (lech <= 8px) = dau hieu letterbox that,
      - vien phai dang ke (>= 2% chieu cao) moi cat, khong thi bo qua.
    """
    try:
        p = subprocess.run(["ffmpeg", "-hide_banner", "-i", src, "-vf",
                            "cropdetect=limit=24:round=2:reset=0", "-frames:v", "48",
                            "-f", "null", "-"], capture_output=True, text=True, timeout=120)
    except Exception:
        return ""
    best = None
    for m in re.finditer(r"crop=(\d+):(\d+):(\d+):(\d+)", p.stderr or ""):
        cw, ch, cx, cy = (int(x) for x in m.groups())
        best = (cw, ch, cx, cy)                     # dong cuoi = ket qua tich luy on nhat
    if not best:
        return ""
    cw, ch, cx, cy = best
    if ch >= h * 0.98 and cw >= w * 0.98:           # khong co vien
        return ""
    if ch < h * 0.55 or cw < w * 0.55:              # cat qua sau -> nghi ngo, bo qua
        return ""
    if abs(cy - (h - ch - cy)) > 8 or abs(cx - (w - cw - cx)) > 8:
        return ""                                   # vien lech -> khong phai letterbox
    if (h - ch) < h * 0.02 and (w - cw) < w * 0.02:
        return ""                                   # vien qua nho, cat lam gi
    return "crop=%d:%d:%d:%d," % (cw, ch, cx, cy)


def _clip_gain_db(src, target=-20.0, lo=-6.0, hi=12.0):
    """Gain (dB) can bu cho 1 clip de am luong CAC CANH deu nhau.

    DO THAT 30/07: Veo sinh moi clip doc lap nen am luong lech nhau toi 24 dB (canh -24 dB
    lan canh -48 dB) -> nghe to nho that thuong. `loudnorm` sau khi GHEP khong chua duoc:
    no do ca file roi ap MOT gain chung, lech giua cac doan van y nguyen (do lai: 25.0 dB
    truoc -> 24.1 dB sau = gan nhu khong doi). Phai can bu TUNG CLIP truoc khi ghep.

    Chan gain trong [lo, hi]: canh gan im lang that (nhac nen se lap) khong bi keo len 30 dB
    thanh nhieu am, va canh to khong bi ha qua sau.
    """
    try:
        p = subprocess.run(["ffmpeg", "-hide_banner", "-i", src, "-af", "volumedetect",
                            "-f", "null", "-"], capture_output=True, text=True, timeout=120)
        m = re.search(r"mean_volume:\s*(-?[\d.]+) dB", p.stderr or "")
        if not m:
            return 0.0
        cur = float(m.group(1))
        if cur < -55:                    # im gan hoan toan -> de nguyen, keo len chi ra nhieu
            return 0.0
        return max(lo, min(hi, target - cur))
    except Exception:
        return 0.0


def _normalize_clip(src, dst, fps=24, w=720, h=1280, ar=48000, ac=2):
    """Ep DONG NHAT fps/resolution/sample_rate/SO KENH audio truoc khi ghep. Bay hay dinh nhat:
    audio MONO (trich tu file goc) lan voi audio STEREO (Veo luon stereo) -> concat demuxer hong
    am thanh AM THAM tu diem lech tro di (da dinh that, xem SKILL.md). Luon qua ham nay truoc khi
    ghep, ke ca clip da la Veo (phong khi model/mode sau nay doi thong so)."""
    # CAT VIEN DEN TRUOC khi scale: clip vao thuong DA dung 720x1280 nen scale+crop o duoi
    # khong lam gi, vien den van nam trong pixel -> video ra co 2 dai den tren/duoi.
    bars = _black_bars(src, w, h)
    # CAN BANG AM LUONG tung clip (xem _clip_gain_db): Veo sinh moi clip doc lap nen am luong
    # lech nhau toi 24 dB. Phai bu O DAY — loudnorm sau khi ghep chi ap 1 gain chung cho ca
    # file nen KHONG chua duoc do lech giua cac canh (do that: 25.0 dB -> 24.1 dB = vo ich).
    g = _clip_gain_db(src)
    cmd = ["ffmpeg", "-v", "error", "-y", "-i", src,
           "-vf", "%sscale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,setsar=1,fps=%d"
                  % (bars, w, h, w, h, fps)]
    if abs(g) > 0.5:
        cmd += ["-af", "volume=%.1fdB" % g]
    _ff(cmd + ["-c:v", "libx264", "-crf", "20", "-preset", "veryfast",
               "-c:a", "aac", "-ar", str(ar), "-ac", str(ac), dst])
    return dst


def _music_bed(video_path, scenes, work):
    """BUOC 6 cua SKILL.md — trich NHAC NEN thuan (KHONG LOI) tu audio goc.

    Vi sao khong ghep ca audio goc: mieng nhan vat khop voi tieng VEO tu sinh, ghep thoai goc
    de len la lech moi hoan toan (dung loi cu), va se co 2 giong noi chong nhau.
    Vi sao VAN can nhac goc: do that video 1980385242704855 — ban dung lai KHONG co nhac nen
    (goc -18.0 dB, ban moi -24..-48 dB) nen nghe TRONG hon han, va am luong cac canh lech toi
    24 dB. Nhac nen chay xuyen suot vua lap khoang trong vua lam am luong deu tai nguoi nghe.

    Cach lam: doc `scenes` (Gemini da cho moc gio + dialogue tung canh) -> lay cac KHOANG
    KHONG AI NOI dai >= MIN_GAP, cat ra, noi lai thanh mot doan nhac. Tra duong dan wav hoac
    None (khong du khoang khong loi -> bo qua, khong ep).

    ⚠️ Canh bao cua SKILL.md: khoang "khong loi" VAN co the chua tieng dong gan voi HANH DONG
    cu the cua video goc (tieng mo cong...) -> nghe lac que o canh khac. Giam thieu: chi lay
    khoang >= 1.2s, bo 0.25s hai dau (tranh duoi cau noi), va lam NEN rat nho (-22 dB) nen
    tieng dong con lai nghe nhu am thanh moi truong chu khong noi bat.
    """
    MIN_GAP = 1.2
    gaps, prev_end = [], 0.0
    for sc in sorted(scenes, key=lambda s: float(s.get("start") or 0)):
        st, en = float(sc.get("start") or 0), float(sc.get("end") or 0)
        if _has_dialogue(sc.get("dialogue")):
            if st - prev_end >= MIN_GAP:
                gaps.append((prev_end + 0.25, st - 0.25))
            prev_end = max(prev_end, en)
        else:
            # canh KHONG thoai: ca canh la khoang khong loi
            if en - st >= MIN_GAP:
                gaps.append((st + 0.25, en - 0.25))
            prev_end = max(prev_end, en)
    if not gaps:
        return None
    parts = []
    for k, (a, b) in enumerate(gaps[:12]):
        p = os.path.join(work, "bed_%02d.wav" % k)
        try:
            _ff(["ffmpeg", "-v", "error", "-y", "-ss", "%.2f" % a, "-t", "%.2f" % (b - a),
                 "-i", video_path, "-vn", "-ac", "2", "-ar", "48000", p])
            if os.path.isfile(p) and os.path.getsize(p) > 2000:
                parts.append(p)
        except Exception:
            continue
    if not parts:
        return None
    bed = os.path.join(work, "music_bed.wav")
    inputs, filt = [], ""
    for i, p in enumerate(parts):
        inputs += ["-i", p]
        filt += "[%d:a]" % i
    filt += "concat=n=%d:v=0:a=1[a]" % len(parts)
    try:
        _ff(["ffmpeg", "-v", "error", "-y"] + inputs +
            ["-filter_complex", filt, "-map", "[a]", bed])
    except Exception:
        return None
    return bed if os.path.isfile(bed) and os.path.getsize(bed) > 2000 else None


def assemble_dialogue(clips, out_path, work, video_path=None, scenes=None):
    """Ghep N clip da co san audio (Veo tu sinh) bang concat FILTER (KHONG phai concat demuxer -
    demuxer lech tham so am thanh la MAT TIENG AM THAM tu doan do tro di, video van chay binh
    thuong nen de tuong nham la OK — da dinh that, xem SKILL.md)."""
    norm = []
    for i, cp in enumerate(clips):
        np_ = os.path.join(work, "dlg_norm_%02d.mp4" % i)
        _normalize_clip(cp, np_)
        norm.append(np_)
    inputs, filt = [], ""
    for i, cp in enumerate(norm):
        inputs += ["-i", cp]
        filt += "[%d:v][%d:a]" % (i, i)
    filt += "concat=n=%d:v=1:a=1[outv][cata]" % len(norm)
    # NHAC NEN tu audio goc (BUOC 6 SKILL.md) — chi khi co du khoang khong loi.
    bed = _music_bed(video_path, scenes, work) if (video_path and scenes) else None
    n_in = len(norm)
    if bed:
        inputs += ["-stream_loop", "-1", "-i", bed]        # lap cho du do dai video moi
        # nhac RAT NHO (-22dB) lam nen; `shortest` cat theo phan thoai (khong keo dai video).
        # loudnorm sau khi tron -> am luong deu, het canh -48dB lan voi canh -24dB.
        # normalize=0 BAT BUOC: amix mac dinh CHIA BIEN DO theo so input -> nhac -22dB thanh
        # -28dB, doan im lang van nghe trong (do that: doan im con -35.8 dB). normalize=0 giu
        # nguyen muc tung nguon, nhac -16dB nghe ro lam nen ma khong de thoai.
        # Gain cua nhac nen tinh TRUOC bang phep do (khong dung loudnorm cho bed): loudnorm
        # 1-pass co giai doan "hoc" dau vao nen voi doan nhac ngan no bop gan het -> DOI CHUNG
        # do that: ban CO nhac va ban KHONG nhac chi lech 1.7 dB = nhac gan nhu khong vao.
        # Muc tieu -26 dB mean = thap hon thoai (~-16) khoang 10 dB: muc nhac nen phim,
        # nghe ro o doan im lang ma khong de loi thoai.
        g_bed = _clip_gain_db(bed, target=-26.0, lo=-24.0, hi=24.0)
        filt += (";[%d:a]volume=%.1fdB[bed];[cata][bed]amix=inputs=2:duration=first:"
                 "normalize=0:dropout_transition=0,loudnorm=I=-16:TP=-1.5:LRA=11[outa]"
                 % (n_in, g_bed))
        _prog("Ghep them NHAC NEN tu audio goc + can bang am luong")
    else:
        # khong co nhac nen thi VAN can bang am luong (canh lech nhau toi 24dB do that)
        filt += ";[cata]loudnorm=I=-16:TP=-1.5:LRA=11[outa]"
        _prog("Khong du khoang khong loi de lay nhac nen -> chi can bang am luong")
    _ff(["ffmpeg", "-v", "error", "-y"] + inputs + ["-filter_complex", filt,
         "-map", "[outv]", "-map", "[outa]",
         "-c:v", "libx264", "-crf", "20", "-preset", "veryfast",
         "-c:a", "aac", "-b:a", "192k", out_path])
    return out_path


def remake_dialogue(video_path, out_path, work, style=None, img_model=None,
                    clip_model="veo_3_1", lanes=None):
    """Remake video, nhan vat NOI THAT tieng Viet khop moi (xem SKILL.md cho cong thuc day du +
    bay da dinh). Khac remake() thuong (giong ke + B-roll tinh): day la cach cho nhan vat "dien"
    co thoai. IDEMPOTENT theo thu muc work — chay lai chi lam tiep phan thieu.
    img_model='gpt-image-2' -> ve bang OpenAI (re, on dinh); None -> 79AI banana_pro."""
    os.makedirs(work, exist_ok=True)
    if os.path.isfile(out_path) and os.path.getsize(out_path) > 1000:
        _prog("Video đã dựng xong từ trước → bỏ qua dựng")
        return {"ok": True, "out": out_path, "skipped": True}
    scenes_f = os.path.join(work, "unified_scenes.json")
    if os.path.isfile(scenes_f):
        scenes = json.load(open(scenes_f, encoding="utf-8"))
        _prog("Da co ban phan tich thong nhat (%d canh) -> dung lai" % len(scenes))
        # Work dir CU (phan tich truoc khi co luoi chong-cat-giua-cau) -> tach lai, NHUNG chi
        # khi CHUA dung clip nao: tach lam doi so canh, clip cu se lech index = video lon canh.
        if not glob.glob(os.path.join(work, "dlg_clip_*.mp4")):
            s2 = _split_long_scenes(scenes)
            if len(s2) != len(scenes):
                _prog("Tach %d canh thoai qua dai -> %d canh" % (len(scenes), len(s2)))
            # Ban phan tich CU khong co img_key -> gan lai, khong thi canh cung mo ta hinh
            # se ve 2 anh khac nhau (do that: 8 canh doi 8 anh trong khi chi can 6).
            scenes = _share_same_visual(s2)
            n_img = len(set(s.get("img_key") for s in scenes))
            if n_img != len(scenes):
                _prog("%d canh dung chung %d anh (canh cung mo ta hinh)" % (len(scenes), n_img))
            with open(scenes_f, "w", encoding="utf-8") as f:
                json.dump(scenes, f, ensure_ascii=False, indent=2)
    else:
        _prog("Dang phan tich nguon (Gemini xem ca thoai+nhac+hinh)")
        scenes = gemini_unified_scenes(video_path, work)
        _prog("Phan tich xong -> %d canh" % len(scenes))

    # BOI CANH lay TU VIDEO NGUON (khong ep san). LOI DA MAC 30/07: duong nay goi
    # _scene_suffix() KHONG tham so -> roi vao _SETTING_FALLBACK "Vietnamese setting" -> video
    # biet thu noi that kieu Au ve ra nha tranh gach bong manh tre. Duong remake() thuong da va
    # tu ban 1.2.25 (truyen setting), duong nay thi CHUA — dung kieu "chi va 1 trong N duong".
    setting = dialogue_setting(work)
    # BANG NHAN VAT ghep vao MOI prompt anh -> nhan vat giu nguyen mat/toc/trang phuc.
    cast = dialogue_cast(work)
    cast_map = dialogue_cast_map(work)
    if cast:
        _prog("Bang nhan vat: %s" % cast.split(": ", 1)[-1][:100])
    else:
        _prog("CANH BAO: khong co bang nhan vat -> nhan vat co the troi giua cac canh")
    # KIEU HINH: style='' hoac 'auto' = de Gemini nhan tu chinh video (nguoi dung khong phai
    # doan). Nguoi dung chon cu the thi TON TRONG lua chon do.
    # look_desc: cau ta look THAT cua nguon (tin cay hon nhan co dinh) — chi dung khi TU NHAN.
    # look_desc (cau ta look cua Gemini) DA BI BO khoi prompt anh.
    # DO THAT 30/07 — dinh 4 LAN LIEN: cau ta do co khi chua "realistic skin textures",
    # "cinematic lighting", "smooth facial features" = tu khoa MOI ANH CHUP, thang ca chuoi
    # "NOT a photograph" o dau VA cuoi prompt -> anh ra NGUOI THAT du Gemini nhan dung
    # kieu_hinh='pixar_3d'. Ket qua phu thuoc Gemini tinh co dung tu gi = KHONG DIEU KHIEN DUOC.
    # Duong chay TOT hom 29/07 KHONG he co look_desc — chi STYLES[style] + BLEED. Giu nhu vay.
    look_desc = ""
    if style in (None, "", "auto"):
        auto = dialogue_art_style(work)
        style = auto or DEFAULT_STYLE
        if auto:
            _prog("Kieu hinh nhan tu video nguon: %s" % STYLE_LABELS.get(auto, auto))
        else:
            _prog("Khong nhan ro kieu hinh video nguon -> dung mac dinh")
    if setting:
        _prog("Boi canh lay tu video nguon: %s" % setting[:90])

    import threading
    from concurrent.futures import ThreadPoolExecutor
    # SONG SONG trong 1 video (truoc day TUAN TU: 11 canh x ~2' = ~25 phut chi de doi).
    # GommoClient thread-safe (_post goi requests.post truc tiep) — giong gen_media.
    # MAC DINH 1 (giu luat cu "moi lan chay 1 i2v" cho MOI duong goi khong noi gi) — chi
    # duong nao CO CHU DICH nang len moi song song: tab "Lam 1 video" truyen --lanes 4.
    # Vi sao khong dat mac dinh 4: duong "Chuyen qua Xuong" day NHIEU reel 1 luot, 10 reel
    # x 4 = 40 task 79AI > 12 slot -> flood. Duong Star cung truyen 1 nhu cu.
    # Tran 4 chon theo: 79AI 12 task dong thoi (3 video song song van du), va nhom
    # "gpt-image" cua OpenAI ~5 anh/phut (4 lane la sat tran; generate() da tu cho + thu lai).
    lanes = max(1, int(lanes or os.environ.get("DLG_LANES", "1")))
    c = GommoClient()
    n = len(scenes)
    clip_of = lambda i: os.path.join(work, "dlg_clip_%02d.mp4" % i)
    have = sum(1 for i in range(n) if os.path.isfile(clip_of(i))
               and os.path.getsize(clip_of(i)) > 1000)
    if have:
        _prog("Da co %d/%d canh -> chi lam tiep %d canh con thieu" % (have, n, n - have))
    plock = threading.Lock()
    cnt = [have]
    # Khoa theo img_key: cac canh TACH RA tu cung mot canh dung CHUNG 1 anh. Khong khoa thi
    # 2 lane song song cung thay "chua co anh" -> ve 2 lan (ton tien + 2 anh khac nhau).
    ilocks = {}
    # ref_lock: TUAN TU HOA khau ve anh. Bat buoc vi anh mau (dlg_ref.png) sinh tu canh DAU:
    # neu 4 lane cung thay "chua co mau" thi ca 4 ve bang chu -> 4 kieu khac nhau, mat het tac
    # dung khoa kieu. Tuan tu hoa KHONG mat gi trong thuc te: OpenAI Tier 1 chi 5 anh/phut
    # (song song la an 429), con khau CHAM that (Veo dung clip) van song song nguyen.
    ref_lock = threading.Lock()

    def _img_lock(key):
        with plock:
            return ilocks.setdefault(key, threading.Lock())

    def _one(i):
        """Lam TRON 1 canh (ve anh -> dung clip). Tra (i, duong_dan) de con sap lai DUNG
        THU TU index — thu tu hoan thanh cua cac lane KHONG theo thu tu canh, tra ve theo
        thu tu xong la video bi LON CANH."""
        sc = scenes[i]
        clip_path = clip_of(i)
        if os.path.isfile(clip_path) and os.path.getsize(clip_path) > 1000:
            return i, clip_path
        # img_key co khi canh nay la 1 phan cua canh dai bi tach -> dung chung anh voi phan kia
        ikey = str(sc.get("img_key") or ("%02d" % i))
        img_url_f = os.path.join(work, "dlg_img_%s.txt" % ikey)
        # Khoa theo ikey: 2 canh tach ra tu cung 1 canh chay song song se cung thay "chua co
        # anh" -> ve 2 lan (ton tien + 2 anh khac nhau = chuyen canh doi mat). Khoa xong,
        # canh vao sau doc duoc file cua canh vao truoc.
        with _img_lock(ikey), ref_lock:
            if os.path.isfile(img_url_f):
                img_url = open(img_url_f, encoding="utf-8").read().strip()
            else:
                with plock:
                    _prog("Dang ve anh canh %d/%d" % (i + 1, n))
                # BUG DA DINH THAT (29/07): `style` nhan vao ham nhung KHONG duoc dung o day ->
                # anh LUON ra kieu mac dinh cua model ve du page cau hinh style khac.
                # GHEP nhan cung + cau ta cua Gemini, KHONG thay the nhau (do that 30/07: dung
                # RIENG cau ta cua Gemini -> OpenAI ve ra ANH THAT vi cau ta co "cinematic
                # lighting/smooth facial features"). `cast` = bang nhan vat, PHAI co trong MOI
                # prompt vi moi canh la 1 lan goi RIENG, model khong nho canh truoc.
                # The loai tranh dat o DAU (xem _style_prefix) VA nhac lai o CUOI
                # (_anti_photo) — giua prompt la mo ta canh/nhan vat, day toan tu ta nguoi
                # that nen neu chi de nhan style o giua thi model ve ra anh chup.
                prompt = (_style_prefix(style) + (sc.get("visual") or "") + cast
                          + STYLES.get(style, STYLES[DEFAULT_STYLE]) + look_desc
                          + BLEED + _scene_suffix(setting) + _anti_photo(style))
                if img_model == "gpt-image-2":
                    import openai_image
                    png = os.path.join(work, "dlg_src_%s.png" % ikey)
                    # ANH MAU = anh canh DAU cua CHINH video nay (dlg_ref.png), sinh tu dung
                    # style cua video do. Video den trang -> mau den trang -> cac canh sau den
                    # trang; video 3D -> mau 3D. KHONG phai mau co dinh dung chung giua cac
                    # video. Tac dung: giu DUNG KIEU VE + giu KHUON MAT nhan vat xuyen suot.
                    # Vi sao can: do that 30/07, kieu pixar_3d mo ta bang CHU khong du (cung
                    # prompt lan ra 3D lan ra nguoi that) vi "3D render chat luong cao" ban
                    # chat gan anh chup. Kieu de tach (mau_nuoc/hoat_hinh) thi khong bi.
                    refp = os.path.join(work, "dlg_ref.png")
                    ref = None
                    if os.path.isfile(refp) and os.path.getsize(refp) > 1000:
                        try:
                            ref = open(refp, "rb").read()
                        except OSError:
                            ref = None
                    if ref:
                        data = openai_image.generate_from_ref(
                            prompt + " Keep EXACTLY the same art style, rendering technique and "
                                     "character appearance (faces, hair, outfits) as the "
                                     "reference image; only the scene/action changes.",
                            ref, ratio="9:16", quality="low")
                    else:
                        data = openai_image.generate(prompt, ratio="9:16", quality="low")
                    open(png, "wb").write(data)
                    _crop_png_to_ratio(png)  # OpenAI tra 2:3, khong cat -> clip co vien den
                    if not ref:
                        # canh dau tien ve xong -> lam ANH MAU cho moi canh sau cua video nay
                        try:
                            shutil.copy(png, refp)
                            with plock:
                                _prog("Da co anh mau (canh %d) -> cac canh sau ve THEO MAU nay"
                                      % (i + 1))
                        except OSError:
                            pass
                    up = c.upload_image(png)
                    img_url = up.get("url") or up.get("url_preview")
                else:
                    rv = c.create_image(model="google_image_gen_banana_pro", prompt=prompt,
                                        ratio="9:16", mode="standard", resolution="1k")
                    info = c.wait_for_image(rv.get("id_base"))
                    img_url = info.get("url")
                open(img_url_f, "w", encoding="utf-8").write(img_url)
        with plock:
            _prog("Dang dung canh %d/%d (co thoai: %s)"
                  % (i + 1, n, "co" if _has_dialogue(sc.get("dialogue")) else "khong"))
        # nguoi_noi: chi RO ai mo mieng, khong thi Veo tu chon -> sai nguoi noi
        sp = str(sc.get("nguoi_noi") or "").strip()
        _gen_dialogue_clip(c, img_url, sc.get("dialogue", ""), sc.get("visual", ""),
                           clip_path, clip_model=clip_model,
                           speaker=sp, speaker_desc=cast_map.get(sp, ""))
        with plock:
            cnt[0] += 1
            _prog("Xong canh %d/%d" % (cnt[0], n))
        return i, clip_path

    _prog("Dung %d canh, %d canh CUNG LUC" % (n - have, lanes) if n - have else "Da co du canh")
    got = {}
    with ThreadPoolExecutor(max_workers=lanes) as ex:
        futs = [ex.submit(_one, i) for i in range(n)]
        errs = []
        for f in futs:
            try:
                i, p = f.result()
                got[i] = p
            except Exception as e:              # KHONG nuot: canh loi phai lam ca bai bao loi,
                errs.append(str(e)[:200])       # khong thi video ra THIEU canh ma trong nhu OK
        if errs:
            raise RuntimeError("%d/%d canh loi: %s" % (len(errs), n, " | ".join(errs[:3])))
    clip_paths = [got[i] for i in sorted(got)]  # DUNG THU TU canh, khong theo thu tu xong

    _prog("Dang ghep %d canh (concat filter)" % len(clip_paths))
    assemble_dialogue(clip_paths, out_path, work, video_path=video_path, scenes=scenes)
    return {"ok": True, "out": out_path, "n_scenes": len(scenes)}


def remake(video_path, out_path, n_scenes=6, clip_model="veo_3_1",
           audio_mode="B", voice_id=None, prompt_mode="gemini",
           style=DEFAULT_STYLE, lanes=None, img_model=None,
           auto_kenburns=True) -> dict:
    """Lam lai 1 video. audio_mode: 'B' giu audio goc | 'A' giong+nhac MOI.

    prompt_mode: 'gemini' (MAC DINH — Gemini xem NGUYEN video, mach truyen bam luong+loi thoai,
    1 call) | 'vision' (OpenAI nhin 1 frame dai dien/canh) | 'story' (LLM doc cot truyen).
    Fallback tu dong: gemini -> vision -> story (thieu GEMINI/OPENAI van chay). {ok,out}.
    """
    work = out_path + ".work"
    os.makedirs(work, exist_ok=True)
    if os.path.isfile(out_path) and os.path.getsize(out_path) > 1000:
        _prog("Video đã dựng xong từ trước → bỏ qua dựng, chỉ lên lịch")
        return {"ok": True, "out": out_path, "skipped": True}
    # BÁO RÕ NGAY ĐẦU: đã có bao nhiêu clip/ảnh trong work -> thấy rõ NỐI TIẾP hay làm lại từ đầu.
    _nclip = len(glob.glob(os.path.join(work, "clip_*.mp4")))
    _nimg = len(glob.glob(os.path.join(work, "img_*.txt")))
    _ntask = len(glob.glob(os.path.join(work, "*.task")))
    if _nclip or _nimg or _ntask:
        _prog("Kiểm tra: đã có %d clip + %d ảnh (+%d task 79 chờ tải) → NỐI TIẾP, không làm lại từ đầu"
              % (_nclip, _nimg, _ntask))
    else:
        _prog("Kiểm tra: CHƯA có cảnh nào (lần trước lỗi SỚM trước khi vẽ) → làm lại từ đầu")
    # (1) chep loi (cho audio/timing). (2) video goc -> moc slide THAT = ranh gioi/nhip canh
    # + LUU 1 frame dai dien/canh (goc_XX.jpg). (3) VISION nhin tung frame -> prompt bam KHUNG
    # GOC (thay story-driven lech khung). Canh da RIENG (dedup) nen khong trung anh.
    _prog("Đang chép lời thoại")
    segs, story = transcribe(video_path, work)
    _prog("Đang phân tích cảnh video gốc")
    # SO CANH theo ĐỘ DÀI video (~8s/canh = do dai clip veo) -> cua so canh khop clip, KHONG
    # keo cham. GOC BUG GIAT: cap cung =7 GOP NGUOC ~15 canh ngan thanh 7 cua so 18-22s ->
    # clip 8s bi setpts cham 2.2-2.75x -> motion bo + blend = giat. Nay cap = do_dai/8 (7..24).
    target_scenes = max(n_scenes, min(24, round(_dur(video_path) / 8.0)))
    bounds, windows, context = video_scene_bounds(video_path, work, max_scenes=target_scenes, segs=segs)
    n = len(bounds)
    _prog("Đang viết mô tả %d cảnh" % n)
    if prompt_mode == "gemini":
        # CHI Gemini (da retry 4 lan backoff trong gemini_generate). Gemini SAP -> RAISE ->
        # __main__ ghi item ERROR tren tool. KHONG rot OpenAI (da bo theo yeu cau user).
        _log("GEMINI: xem NGUYEN video -> prompt %d canh (KHONG fallback OpenAI)..." % n)
        scenes = gemini_scene_prompts(video_path, work, n, bounds=bounds, windows=windows, story=story)
    elif prompt_mode == "vision":             # tuy chon THU CONG (khong tu dong) — OpenAI per-frame
        scenes = vision_scene_prompts(work, n)
    else:                                     # 'story' — tuy chon THU CONG (OpenAI, tinh context lazy)
        frames = sorted(glob.glob(os.path.join(work, "goc_*.jpg")))
        context = _video_context(frames) if frames else ""
        scene_texts = _dialogue_per_window(segs, bounds, _dur(video_path))
        scenes = gen_scene_prompts(story, len(scene_texts), work, scene_texts=scene_texts, context=context)
    # canh co thoai -> nhan vat map may mieng nhu dang noi (khong lip-sync tung chu)
    apply_talk_motion(scenes, segs, bounds, _dur(video_path))
    # NGUON LA ANH TINH -> i2v la tra tien cho "motion" ma ban goc khong he co. Doi sang
    # Ken Burns (0 credit). KHONG lam ngam: bao ro so do + ly do o cot tien trinh, va chi
    # lam khi bat cong tac (rule cu: "i2v CHI model nguoi dung chon, KHONG tu doi model").
    if auto_kenburns and clip_model != "kenburns":
        _ms = motion_stats(video_path, work)
        if _ms and _ms.get("static"):
            _prog("Nguồn là ẢNH TĨNH + chuyển cảnh (đo: %d%% khung y hệt nhau, lệch giữa 2 "
                  "khung %.4f) → dùng Ken Burns thay i2v cho %d cảnh, tiết kiệm %d lượt %s"
                  % (round(_ms["still_ratio"] * 100), _ms["median"], n, n, clip_model))
            clip_model = "kenburns"
        elif _ms:
            _prog("Nguồn CÓ chuyển động thật (%d%% khung y hệt, lệch %.4f) → giữ i2v %s"
                  % (round(_ms["still_ratio"] * 100), _ms["median"], clip_model))
    clips = gen_media(scenes, work, clip_model, style=style, lanes=lanes, img_model=img_model)
    if audio_mode == "A":
        _prog("Đang tạo giọng đọc mới")
        audio_src = make_voice_audio(story, work, voice_id)   # story da co tu tren
    else:
        audio_src = video_path
    _prog("Đang ghép video + âm thanh")
    try:
        assemble(clips, audio_src, out_path, work, wins=windows)          # muot, da luong (nhanh)
    except Exception as e:
        # libx264 loi -22 'Terminating thread' = loi DA LUONG tren may khach. THU LAI ghep MUOT
        # nhung 1 LUONG (van xfade+minterpolate -> VAN MUOT, chi cham hon) truoc khi danh doi mo.
        _prog("Ghép mượt lỗi (%s) → thử lại ghép MƯỢT 1 luồng (né lỗi -22, vẫn mượt)" % str(e)[:60])
        try:
            assemble(clips, audio_src, out_path, work, wins=windows, threads=1)
        except Exception as e2:
            # Van loi -> GHEP AN TOAN (cat thang, threads 1): video VAN xong tu clip DA VE, khong
            # mat credit; chi mat hieu ung chuyen canh muot (chuyen canh = cat thang).
            _prog("Vẫn lỗi (%s) → ghép AN TOÀN cắt thẳng (giữ clip đã vẽ)" % str(e2)[:60])
            _assemble_simple(clips, audio_src, out_path, work, wins=windows)
    return {"ok": True, "out": out_path, "mode": audio_mode}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--scenes", type=int, default=6)
    ap.add_argument("--clip", default="veo_3_1")
    ap.add_argument("--audio", default="B")           # B giu tieng goc | A giong+nhac moi
    ap.add_argument("--prompt-mode", default="gemini") # gemini (xem nguyen video, MAC DINH) | vision (frame goc) | story | dialogue (nhan vat NOI THAT, xem SKILL.md)
    ap.add_argument("--style", default=DEFAULT_STYLE)  # real (giong that) | cartoon (hoat hinh)
    ap.add_argument("--img-model", default="")         # model VE ANH nguoi dung chon, '' = mac dinh
    ap.add_argument("--item-id", default="")           # ghi tien trinh vao fb_pipeline
    # So canh lam CUNG LUC trong 1 video. 0 = de mac dinh cua tung duong (remake: LANES=1;
    # nhan vat noi that: DLG_LANES=4). Duong Star van truyen --lanes 1 nhu cu -> moi page 1
    # i2v, N page = N task < 12 slot 79AI, khong flood.
    ap.add_argument("--lanes", type=int, default=0)
    # Nguon anh TINH -> tu dung Ken Burns thay i2v (do that, co bao ro o tien trinh).
    # Tat di neu muon LUON i2v du nguon tinh.
    ap.add_argument("--no-auto-kenburns", action="store_true")
    a = ap.parse_args()

    item = a.item_id

    def _st(status, **kw):
        if not item:
            return
        try:
            import fb_pipeline
            fb_pipeline.update(item, status=status, **kw)
        except Exception:
            pass

    _st("remaking", step="chép lời + sinh cảnh + vẽ ảnh")
    # TIEN TRINH SONG: duong fb_auto goi set_progress() nen cot tien trinh chay theo tung
    # chang ("Dang tao anh 3/7"...). Duong CLI nay TRUOC DAY khong goi -> nguoi dung nhin
    # mot dong duy nhat dung im suot 10-20 phut, khong biet dang lam gi hay treo. Bao nhieu
    # lan ghi cung khong sao: fb_pipeline.update() co lock lien tien-trinh.
    if item:
        set_progress(lambda m: _st("remaking", step=m))
    try:
        if a.prompt_mode == "dialogue":
            # Nhan vat NOI THAT tieng Viet, khop moi tu nhien (Veo tu sinh audio cung luc voi
            # video). Xem .claude/skills/remake-nhan-vat-noi-that/SKILL.md cho cong thuc day du.
            res = remake_dialogue(a.video, a.out, a.out + ".work",
                                  style=a.style, img_model=(a.img_model or None),
                                  clip_model=a.clip, lanes=(a.lanes or None))
        else:
            res = remake(a.video, a.out, a.scenes, a.clip, a.audio,
                         prompt_mode=a.prompt_mode, style=a.style, img_model=(a.img_model or None),
                         auto_kenburns=not a.no_auto_kenburns, lanes=(a.lanes or None))
    except Exception as exc:
        set_progress(None)
        _st("error", step="", error=str(exc)[:200])
        print("KETQUA:", json.dumps({"ok": False, "error": str(exc)[:200]},
                                    ensure_ascii=False), flush=True)
        raise
    set_progress(None)
    if res.get("ok"):
        _st("done", step="", out=res.get("out", ""))
    else:
        _st("error", step="", error=str(res)[:200])
    print("KETQUA:", json.dumps(res, ensure_ascii=False), flush=True)
