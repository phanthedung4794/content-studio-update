"""Ve anh bang OpenAI gpt-image-2 — goi THANG API OpenAI, KHONG qua 79AI.

Dung o 3 noi (deu di qua generate() ben duoi — sua o day la sua CA 3):
  - tab "Tao anh" (anh don le, dong bo)
  - fb_remake._gen_one_image  -> anh CANH cua video lam lai (Dang hang loat)
  - fb_image_post.make_image   -> anh cua BAI DANG ANH (Dang hang loat)

LUU Y kien truc: 79AI la BAT DONG BO (.task/resume/poll), OpenAI la DONG BO (1 call la xong)
-> nhanh nay khong can .task. Nhung anh ve xong VAN duoc upload nguoc len CDN 79AI
(fb_remake dong 860) de khau i2v dung lam anh tham chieu -> "chon OpenAI" KHONG co nghia
la thoat khoi 79AI hoan toan; khau i2v (anh -> video) van bat buoc qua 79AI.
"""
import base64
import json
import os
import random
import re
import time
import urllib.error
import urllib.request

API_URL = "https://api.openai.com/v1/images/generations"

# Ti le (ten dung chung voi 79AI: "9:16","1:1"...) -> size CO DINH OpenAI ho tro (chi 3
# kich thuoc). "9:16"/"16:9" (video doc/ngang) khong co size rieng -> alias ve 2:3/3:2
# gan nhat (anh se duoc crop lai o buoc dung video/ghep the nao cung khong sao).
SIZES = {"1:1": "1024x1024", "2:3": "1024x1536", "3:2": "1536x1024",
         "9:16": "1024x1536", "16:9": "1536x1024"}

# Gia USD/anh do THAT tu developers.openai.com/api/docs/pricing (2026-07-26, size 1024x1024).
_PRICE_USD = {"low": 0.011, "medium": 0.042, "high": 0.167}
USD_VND = 26000   # ty gia tham khao co dinh — chi de UI hien chi phi uoc tinh (~doi VND)

# BACKOFF khi OpenAI chan toc do (HTTP 429). DO THAT 2026-07-27: OpenAI gop chung 1 nhom
# gioi han ten "gpt-image" cho ca gpt-image-1 lan gpt-image-2, va gioi han theo TIER rat thap:
#   Tier 1 = 5 anh/phut · Tier 2 = 20 · Tier 3 = 50 · Tier 4 = 150 · Tier 5 = 250
# (nguon: developers.openai.com/api/docs/guides/rate-limits, fetch 2026-07-27)
# Moi video ~6-7 canh, hop Star mac dinh threads=0 (chay HET page cung luc) -> Tier 1 cham
# tran ngay lap tuc. Truoc day generate() KHONG he retry -> 429 la giet ca item, phi sach
# nhung anh da ve. Nay: cho roi thu lai, soi chieu mau cua gommo_client._post (79AI).
RATE_TRIES = int(os.environ.get("OPENAI_IMG_RATE_TRIES", "6"))
RATE_MAX_WAIT = int(os.environ.get("OPENAI_IMG_RATE_MAX_WAIT", "60"))
NET_TRIES = 2            # loi mang/timeout (khac rate limit) — thu lai vai lan roi thoi

# ══════════════════════════════════════════════════════════════════════════════
#  CAU CHI HAN MUC — dieu tiet TRUOC khi goi, thay vi ban loan roi an 429
#
#  DO THAT 30/07 (3 bai chet cung mot kieu): hop Star dat threads=6 + img_model=gpt-image-2
#  -> 6 video x ~6 canh = ~36 anh gan nhu CUNG LUC, trong khi Tier 1 chi 5 anh/PHUT va gioi
#  han do tinh theo TO CHUC (khong phai theo job). Retry o tung tien trinh KHONG cuu duoc:
#  moi tien trinh tu ngu rieng nhung tong nhu cau van vuot tran -> 429 keo dai -> het ngan
#  sach cho -> video chet giua chung DU 4-5 anh da ve xong (da tra tien).
#
#  Nay moi loi goi phai xin phep mot BANG LICH DUNG CHUNG (file + lock lien tien-trinh):
#  toi da IMG_PER_MIN anh trong 60 giay tinh CA MAY. Cho co trat tu = khong bao gio 429.
#  Nang tier OpenAI thi dat OPENAI_IMG_PER_MIN cao len (Tier 2 = 20, Tier 3 = 50...).
# ══════════════════════════════════════════════════════════════════════════════
IMG_PER_MIN = int(os.environ.get("OPENAI_IMG_PER_MIN", "5"))          # 0 = tat cau chi
GATE_MAX_WAIT = float(os.environ.get("OPENAI_IMG_GATE_MAX", "900"))   # tran cho o cong (giay)
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_GATE = os.path.join(os.environ.get("CS_FB_ROOT") or os.path.join(_ROOT, "facebook"),
                     "_openai_img_rate.json")
# Hook tien trinh: fb_remake gan `openai_image.PROGRESS = _prog` de nguoi dung THAY duoc
# "dang cho han muc" tren cot tien trinh, thay vi nhin mot dong dung im vai phut.
PROGRESS = None


class _Gate:
    """Khoa lien tien-trinh (lock-file) cho bang lich — cung khuon voi fb_slots._Lock."""

    def __init__(self, path, wait=8.0):
        self.lock, self.wait, self.fd = path + ".lock", wait, None

    def __enter__(self):
        t0 = time.time()
        while time.time() - t0 < self.wait:
            try:
                self.fd = os.open(self.lock, os.O_CREAT | os.O_EXCL | os.O_RDWR)
                return self
            except FileExistsError:
                try:                        # khoa mo coi (tien trinh chet giua chung)
                    if time.time() - os.path.getmtime(self.lock) > 30:
                        os.unlink(self.lock)
                except OSError:
                    pass
                time.sleep(0.05)
        return self                         # het gio cho -> chay tiep (tha con hon ket)

    def __exit__(self, *a):
        if self.fd is not None:
            os.close(self.fd)
            try:
                os.unlink(self.lock)
            except OSError:
                pass


def _gate_read() -> list:
    try:
        with open(_GATE, encoding="utf-8-sig") as f:      # utf-8-sig: file co BOM van doc duoc
            d = json.load(f)
        return [float(t) for t in d] if isinstance(d, list) else []
    except Exception:
        return []                            # hong/chua co -> coi nhu chua goi lan nao


def _gate_write(hist: list) -> None:
    try:
        os.makedirs(os.path.dirname(_GATE), exist_ok=True)
        tmp = "%s.%d.tmp" % (_GATE, os.getpid())
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(hist[-200:], f)
        os.replace(tmp, _GATE)
    except OSError:
        pass                                 # ghi hong -> cung KHONG duoc chan viec ve anh


def rate_gate() -> float:
    """Xin 1 suat goi API. Tra so giay da cho. KHONG BAO GIO raise (cau chi hong thi cu goi,
    da co lop retry 429 ben duoi lo tiep)."""
    if IMG_PER_MIN <= 0:
        return 0.0
    t0 = time.time()
    while True:
        now = time.time()
        with _Gate(_GATE):
            hist = [t for t in _gate_read() if now - t < 60.0 and t <= now + 5]
            if len(hist) < IMG_PER_MIN:
                hist.append(now)
                _gate_write(hist)
                return now - t0
            wait = max(0.5, 60.0 - (now - min(hist)) + 0.3)
        if (now - t0) + wait > GATE_MAX_WAIT:
            return now - t0                  # het kien nhan -> cu goi, 429 con co retry
        if PROGRESS:
            try:
                PROGRESS("Đang chờ hạn mức OpenAI (%d ảnh/phút cho cả máy) — còn ~%ds"
                         % (IMG_PER_MIN, round(wait)))
            except Exception:
                pass
        print("   (han muc OpenAI day -> cho %.0fs)" % wait, flush=True)
        time.sleep(min(wait, 15.0))


def price_vnd(quality: str) -> int:
    return round(_PRICE_USD.get(quality, _PRICE_USD["low"]) * USD_VND)


def _key() -> str:
    k = os.environ.get("OPENAI_API_KEY", "")
    if not k:
        raise RuntimeError("Thiếu OPENAI_API_KEY (điền ở Cài đặt → Quản lý key).")
    return k


def _parse_reset(v) -> float | None:
    """Header thoi gian cua OpenAI -> so GIAY. Chiu duoc '6m0s', '1.5s', '500ms', '30'."""
    if not v:
        return None
    s = str(v).strip().lower()
    parts = re.findall(r"([\d.]+)\s*(ms|h|m|s)", s)      # 'ms' phai dung TRUOC 'm'
    if parts:
        unit = {"ms": 0.001, "s": 1.0, "m": 60.0, "h": 3600.0}
        try:
            return sum(float(n) * unit[u] for n, u in parts)
        except (ValueError, KeyError):
            return None
    try:
        return float(s)                                  # 'retry-after: 30' (giay tran)
    except ValueError:
        return None


def _hdr(hdr, name: str):
    """Doc header KHONG phan biet hoa/thuong.

    `HTTPError.headers` that la HTTPMessage (.get da khong phan biet hoa thuong), nhung
    HTTPError co the duoc dung bang dict thuong (test, thu vien khac) — luc do .get('retry-after')
    se TRUOT header 'Retry-After' va ta am tham bo qua so giay OpenAI da bao. Chuan hoa cho chac.
    """
    if not hdr:
        return None
    try:
        v = hdr.get(name)
        if v is not None:
            return v
    except Exception:
        pass
    try:
        items = list(hdr.items())
    except Exception:
        return None
    low = name.lower()
    for k, v in items:
        if str(k).lower() == low:
            return v
    return None


def _err_info(e: urllib.error.HTTPError) -> tuple:
    """Doc than loi HTTPError DUNG 1 LAN (e.read() khong doc lai duoc).

    -> (etype, emsg, wait_giay|None). etype='insufficient_quota' nghia la HET TIEN/QUOTA:
    cho bao lau cung vo ich, phai nap tien -> KHONG duoc retry.
    """
    try:
        raw = e.read().decode("utf-8", "replace")
    except Exception:
        raw = ""
    etype = emsg = ""
    try:
        err = (json.loads(raw) or {}).get("error") or {}
        etype = str(err.get("type") or err.get("code") or "")
        emsg = str(err.get("message") or "")
    except Exception:
        pass
    if not emsg:
        emsg = raw[:400] or "(khong co than loi)"
    wait = None
    for h in ("retry-after", "x-ratelimit-reset-requests", "x-ratelimit-reset-tokens"):
        wait = _parse_reset(_hdr(e.headers, h))
        if wait is not None:
            break
    return etype, emsg, wait


def generate(prompt: str, ratio: str = "1:1", quality: str = "low",
             max_wait_s: float = 120.0) -> bytes:
    """Goi OpenAI images/generations -> tra ve BYTES PNG.

    Gap 429 (chan toc do) thi CHO roi thu lai toi RATE_TRIES lan — uu tien so giay OpenAI
    tu bao trong header (retry-after / x-ratelimit-reset-*), khong co thi backoff luy thua
    + jitter (khuyen nghi chinh thuc cua OpenAI: min 1s, max 60s).
    Het tien/quota (insufficient_quota) thi BAO NGAY, khong cho vo ich.

    max_wait_s = TRAN TONG thoi gian NGU cho rate-limit. Job nen (fb_remake/fb_image_post)
    de mac dinh 120s. Duong DONG BO qua HTTP (tab "Tao anh", server.py) PHAI truyen so nho
    (~25s) — khong thi request treo lau hon timeout cua trinh duyet/uvicorn, nguoi dung
    tuong app dung hinh.
    """
    size = SIZES.get(ratio, "1024x1024")
    q = quality if quality in _PRICE_USD else "low"
    body = json.dumps({"model": "gpt-image-2", "prompt": prompt, "size": size,
                        "quality": q, "n": 1}).encode("utf-8")

    # Xin suat TRUOC (xem _Gate) -> gan nhu khong bao gio dinh 429 nua.
    # KHONG cong thoi gian xep hang vao `slept`: `slept` la ngan sach cho khi GAP LOI, con
    # cho o cong la cho CO TRAT TU (dung nhu y muon). Cong vao thi gate cho 5' xong la lan
    # 429 dau tien da "het ngan sach" -> hong dung cai vua sua.
    rate_gate()
    rate_left, net_left, slept = RATE_TRIES, NET_TRIES, 0.0
    while True:
        req = urllib.request.Request(
            API_URL, data=body,
            headers={"Authorization": f"Bearer {_key()}", "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                data = json.loads(r.read().decode())
            break
        except urllib.error.HTTPError as e:
            etype, emsg, wait = _err_info(e)
            if etype == "insufficient_quota":
                raise RuntimeError(
                    "OpenAI hết quota/billing (nạp tiền hoặc kiểm tra gói tại "
                    "platform.openai.com/settings/organization/billing): %s" % emsg[:300])
            if e.code == 429 and rate_left > 0:
                done = RATE_TRIES - rate_left + 1                 # lan thu 1,2,3...
                # `is None` chu KHONG phai `not wait`: header "0s" (server bao thu lai NGAY)
                # la gia tri HOP LE nhung falsy -> truoc day bi coi nhu "khong co header" roi
                # ngu luy thua vo ich.
                if wait is None:
                    wait = min(RATE_MAX_WAIT, 2 ** done)          # 2,4,8,16,32,60
                # CLAMP >= 0: header la du lieu NGOAI, khong tin duoc. Retry-After am ->
                # time.sleep(so am) -> ValueError, ma ValueError KHONG chua chu "OpenAI" nen
                # pha vo chinh co che nhan dien nha cung cap vua xay (fbpShortErr + `terminal`).
                wait = max(0.0, min(RATE_MAX_WAIT, wait)) + random.uniform(0, 3)  # +jitter chong dong pha
                if slept + wait > max_wait_s:                     # het ngan sach cho -> bo cuoc
                    raise RuntimeError(
                        "OpenAI chặn tốc độ (rate limit) — đã chờ %.0fs (trần %.0fs) vẫn chưa qua. "
                        "Giảm 'Số luồng chạy SONG SONG' ở hộp Star, hoặc nâng tier OpenAI "
                        "(Tier 1 chỉ 5 ảnh/phút cho cả nhóm gpt-image): %s"
                        % (slept, max_wait_s, emsg[:300]))
                rate_left -= 1
                slept += wait
                print("   (OpenAI chan toc do -> cho %.0fs roi thu lai %d/%d...)"
                      % (wait, done, RATE_TRIES), flush=True)
                time.sleep(wait)
                continue
            if e.code == 429:
                raise RuntimeError(
                    "OpenAI chặn tốc độ (rate limit) — đã chờ và thử lại %d lần vẫn không qua. "
                    "Giảm 'Số luồng chạy SONG SONG' trong hộp Star, hoặc nâng tier OpenAI "
                    "(Tier 1 chỉ 5 ảnh/phút cho cả nhóm gpt-image): %s" % (RATE_TRIES, emsg[:300]))
            raise RuntimeError("OpenAI từ chối (HTTP %d, %s): %s"
                               % (e.code, etype or "khong ro loai", emsg[:300]))
        except urllib.error.URLError as e:
            if net_left > 0:
                net_left -= 1
                print("   (OpenAI loi mang: %s -> thu lai...)" % str(e.reason)[:80], flush=True)
                time.sleep(5)
                continue
            raise RuntimeError("OpenAI lỗi mạng: %s" % str(e.reason)[:200])

    item = (data.get("data") or [{}])[0]
    b64 = item.get("b64_json")
    if not b64:
        raise RuntimeError(f"OpenAI không trả ảnh: {str(data)[:300]}")
    return base64.b64decode(b64)


# ══════════════════════════════════════════════════════════════════════════════
#  VE ANH THEO ANH MAU (images/edits) — KHOA KIEU VE + KHOA NHAN VAT
#
#  VI SAO CAN: do that 30/07 tren kieu `pixar_3d`, mo ta bang CHU KHONG du. Cung mot
#  prompt (co "A stylised 3D ANIMATED FEATURE FILM still", co "NOT a photograph" o CA dau
#  lan cuoi, da bo het tu moi anh chup) ma gpt-image-2 lan ra 3D lan ra NGUOI THAT — luot
#  thu 1/1 dung, job that chi 1/3 dung. Ly do: "3D render chat luong cao" ban chat GAN anh
#  that, khong the tach bach bang tu ngu. Cac kieu de tach (mau_nuoc, hoat_hinh 2D) thi
#  chua bao gio bi — do la vi sao 2 video 29/07 chay tot.
#
#  Cho MODEL XEM 1 ANH MAU dat yeu cau thi no giu dung kieu, VA giu luon khuon mat nhan vat
#  (giai quyet ca "nhan vat khong nhat quan" — moi canh truoc day ve doc lap tu chu nen mat
#  moi canh mot nguoi).
# ══════════════════════════════════════════════════════════════════════════════
EDIT_URL = "https://api.openai.com/v1/images/edits"


def _multipart(fields: dict, files: dict):
    """Dung body multipart/form-data. files = {ten: (ten_file, bytes, content_type)}."""
    bnd = "----csboundary%d%d" % (int(time.time() * 1000), random.randint(1000, 9999))
    out = bytearray()
    for k, v in fields.items():
        out += ("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n"
                % (bnd, k, v)).encode("utf-8")
    for k, (fn, data, ct) in files.items():
        out += ("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\n"
                "Content-Type: %s\r\n\r\n" % (bnd, k, fn, ct)).encode("utf-8")
        out += data + b"\r\n"
    out += ("--%s--\r\n" % bnd).encode("utf-8")
    return bnd, bytes(out)


def generate_from_ref(prompt: str, ref_png: bytes, ratio: str = "1:1",
                      quality: str = "low", max_wait_s: float = 120.0) -> bytes:
    """Ve anh MOI dua tren ANH MAU (giu dung kieu ve + khuon mat nhan vat). Tra BYTES PNG.

    `ref_png`: bytes cua anh mau (PNG). Prompt nen ta canh MOI can ve, va noi ro "giu nguyen
    kieu ve va ngoai hinh nhan vat nhu anh mau".
    Retry 429 giong generate() (OpenAI gop chung nhom gioi han "gpt-image").
    """
    size = SIZES.get(ratio, "1024x1024")
    q = quality if quality in _PRICE_USD else "low"
    rate_gate()          # CUNG cau chi voi generate(): OpenAI gop chung nhom "gpt-image"
    rate_left, net_left, slept = RATE_TRIES, NET_TRIES, 0.0
    while True:
        bnd, body = _multipart(
            {"model": "gpt-image-2", "prompt": prompt, "size": size, "quality": q, "n": "1"},
            {"image": ("ref.png", ref_png, "image/png")})
        req = urllib.request.Request(
            EDIT_URL, data=body,
            headers={"Authorization": "Bearer %s" % _key(),
                     "Content-Type": "multipart/form-data; boundary=%s" % bnd})
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                data = json.loads(r.read().decode())
            break
        except urllib.error.HTTPError as e:
            etype, emsg, wait = _err_info(e)
            if etype == "insufficient_quota":
                raise RuntimeError("OpenAI hết quota/billing: %s" % emsg[:300])
            if e.code == 429 and rate_left > 0:
                done = RATE_TRIES - rate_left + 1
                if wait is None:
                    wait = min(RATE_MAX_WAIT, 2 ** done)
                wait = max(0.0, min(RATE_MAX_WAIT, wait)) + random.uniform(0, 3)
                if slept + wait > max_wait_s:
                    raise RuntimeError("OpenAI chặn tốc độ, hết ngân sách chờ (%.0fs): %s"
                                       % (max_wait_s, emsg[:200]))
                rate_left -= 1
                slept += wait
                print("   (OpenAI 429 -> chờ %.1fs rồi thử lại %d/%d)"
                      % (wait, done, RATE_TRIES), flush=True)
                time.sleep(wait)
                continue
            raise RuntimeError("OpenAI từ chối (HTTP %d, %s): %s"
                               % (e.code, etype or "khong ro loai", emsg[:300]))
        except urllib.error.URLError as e:
            if net_left > 0:
                net_left -= 1
                time.sleep(5)
                continue
            raise RuntimeError("OpenAI lỗi mạng: %s" % str(e.reason)[:200])

    item = (data.get("data") or [{}])[0]
    b64 = item.get("b64_json")
    if not b64:
        raise RuntimeError("OpenAI không trả ảnh (edits): %s" % str(data)[:300])
    return base64.b64decode(b64)
