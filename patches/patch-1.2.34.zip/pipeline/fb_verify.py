# -*- coding: utf-8 -*-
"""Hoi THANG Facebook xem bai DA LEN chua, truoc khi bao that bai.

Vi sao can: duong Chrome doc ket qua bang GIAO DIEN. Giao dien khong hien dau hieu
KHONG co nghia la bai chua len — do that 29/07: 7 bai bao "khong thay dau hieu da gui
sau 180s" nhung Graph xac nhan CA 7 deu len dung gio hen (lech 11-21 giay).

Bao FAIL oan nguy hiem hon bao OK oan:
  - FAIL oan  -> nguoi dung bam Thu lai -> DANG TRUNG tren page.
  - OK oan    -> mat 1 bai, lam lai duoc.
Nen khi Graph noi "co bai khop", tin Graph.

Duong Chrome KHONG bat buoc co token. Khong co token -> tra "no_token", ben goi giu
nguyen hanh vi cu (bao loi kem cau nhac kiem tay).
"""
import json
import re
import time
import urllib.parse
import urllib.request

import fb_graph

GRAPH = "https://graph.facebook.com/v21.0"

# Graph co the tre vai giay so voi luc FB nhan bai -> noi rong cua so ve phia truoc.
SLACK_BEFORE = 90
# Doi chieu noi dung: lay bay nhieu ky tu dau (da chuan hoa) lam van tay.
FINGERPRINT = 40


def _norm(s: str) -> str:
    """Bo dau cau/khoang trang/hashtag de so noi dung khong vap tieu tiet."""
    s = re.sub(r"#\S+", " ", str(s or ""))
    s = re.sub(r"[^0-9A-Za-zÀ-ỹà-ỹ]+", "", s)
    return s.lower()


def _fetch(page_id: str, token: str, kind: str) -> list:
    if kind == "photo":
        edge, fields = "photos", "id,created_time,name"
        extra = "&type=uploaded"
    else:
        edge, fields = "videos", "id,created_time,description,title"
        extra = ""
    url = ("%s/%s/%s?fields=%s&limit=8%s&access_token=%s"
           % (GRAPH, page_id, edge, fields, extra, urllib.parse.quote(token)))
    with urllib.request.urlopen(url, timeout=25) as r:
        return (json.load(r) or {}).get("data") or []


def _ts(created: str) -> int:
    """'2026-07-29T05:00:21+0000' -> epoch. Chuoi Graph LUON la UTC."""
    import calendar
    try:
        return calendar.timegm(time.strptime(str(created)[:19], "%Y-%m-%dT%H:%M:%S"))
    except Exception:
        return 0


def check_posted(page_id: str, kind: str = "reel", since_ts: int = 0,
                 caption: str = "", title: str = "", tries: int = 2) -> dict:
    """Tim bai moi tren page tu moc `since_ts`.

    state:
      posted    — chac chan da len (noi dung KHOP van tay caption/title)
      unsure    — co bai moi dung cua so gio nhung noi dung KHONG khop -> KHONG tu
                  coi la thanh cong, de nguoi dung ngo (bai cua ai do dang tay?)
      not_found — khong co bai nao moi -> bao loi that
      no_token  — page nay khong co token -> khong ket luan duoc gi
      error     — goi Graph hong -> cung khong ket luan duoc gi
    """
    try:
        token = fb_graph.page_token(page_id)
    except Exception as exc:
        return {"state": "error", "why": "doc token loi: %s" % exc}
    if not token:
        return {"state": "no_token", "why": "page chua co token trong tool"}

    floor = int(since_ts or 0) - SLACK_BEFORE
    want = _norm(caption)[:FINGERPRINT] or _norm(title)[:FINGERPRINT]
    newest = None

    for i in range(max(1, tries)):
        try:
            rows = _fetch(page_id, token, kind)
        except Exception as exc:
            if i + 1 >= tries:
                return {"state": "error", "why": "goi Graph loi: %s" % str(exc)[:120]}
            time.sleep(10)
            continue
        for it in rows:
            ts = _ts(it.get("created_time"))
            if ts < floor:
                continue
            body = _norm("%s %s" % (it.get("description") or it.get("name") or "",
                                    it.get("title") or ""))
            if want and want in body:
                return {"state": "posted", "id": it.get("id"), "created_ts": ts,
                        "created": it.get("created_time"), "match": "noi dung"}
            if newest is None or ts > newest.get("created_ts", 0):
                newest = {"id": it.get("id"), "created_ts": ts,
                          "created": it.get("created_time")}
        if newest:
            break
        if i + 1 < tries:
            time.sleep(10)

    if newest:
        # Khong co van tay de doi chieu (caption rong) thi gio khop la du.
        if not want:
            return dict(newest, state="posted", match="gio")
        return dict(newest, state="unsure",
                    why="co bai moi luc %s nhung noi dung khong khop caption"
                        % newest.get("created"))
    return {"state": "not_found", "why": "Graph khong thay bai nao moi tu %s"
                                         % time.strftime("%H:%M:%S", time.localtime(floor))}


if __name__ == "__main__":                                   # tu kiem, khong goi mang
    import sys
    try:                       # in tieng Viet ra file/console cp1252 se nem loi
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    ok = bad = 0

    def ck(name, got, want):
        global ok, bad
        g = got == want
        ok, bad = ok + g, bad + (not g)
        print("  %s %-46s got=%r" % ("OK  " if g else "FAIL", name, got))

    print("[fb_verify] tu kiem")
    ck("_ts doc dung gio UTC", _ts("2026-07-29T05:00:21+0000"), 1785301221)
    ck("_ts chuoi rac -> 0", _ts("xxx"), 0)
    ck("_norm bo hashtag", _norm("Xin chao #xuhuong #viral"), "xinchao")
    ck("_norm bo dau cau", _norm("A, b. C!"), "abc")
    ck("_norm giu dau tieng Viet", _norm("Mẹ già"), "mẹgià")
    ck("van tay khop du bi cat", _norm("Đừng để đến khi giật mình")[:10]
       in _norm("Đừng để đến khi giật mình nhìn lại, mới nhận ra"), True)
    print("=== %d OK / %d FAIL ===" % (ok, bad))
    raise SystemExit(1 if bad else 0)
