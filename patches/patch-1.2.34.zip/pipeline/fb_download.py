"""
Tai file MP4 reel + caption + thumbnail (Pha 2).

Luong:
1. Xuat cookie tu phien Chrome dang dang nhap (qua CDP) -> cookies.txt (Netscape).
   -> KHONG phai dong Chrome, dung dung phien nguoi dung da login.
2. yt-dlp (dung cookies.txt) tai video + LAY LUON metadata: description (caption),
   view_count, duration, thumbnail. Ghi ra downloads/<id>/{video.mp4, caption.txt, meta.json, thumb.jpg}.
3. Cap nhat index.json: downloaded=True, status='downloaded', caption.

BEN: co video.mp4 roi thi BO QUA tai lai (regen 1 reel khong ton cong).

Kiem THAT:
  python -m pipeline.fb_download tuoitho89x 845245898231225   # tai 1 reel
"""
import json
import os
import time

from fb_session import CDP, list_targets, open_session, DEFAULT_PORT
from fb_lister import FB_DIR, load_index, save_index, _index_path


class ReelDead(RuntimeError):
    """Reel nguon KHONG con tai duoc: bi xoa / chuyen rieng tu / chan vung.

    KHAC HAN loi TAM THOI (mang chap chon, HTTP 500, rate-limit) — thu lai bao nhieu lan
    cung vo ich, phai BO QUA va lam reel khac.
    """


# Chu yt-dlp tra ve khi reel khong con doc duoc.
# DO THAT 29/07 tren 2 reel khach bao loi (1271061945140780 "Cannot parse data",
# 526827166434152 "No video formats found"): yt-dlp MOI NHAT (2026.07.04) tra ve DUNG
# may chu nay, trong khi 3 reel cu VAN doc duoc binh thuong (11/7/11 dinh dang).
# -> KHONG phai yt-dlp cu (goi khach ghim 2025.6.30), ma REEL DA CHET. Suyt di cap nhat
# yt-dlp cho khach mot cach vo ich neu khong lam phep doi chung nay.
_DEAD_DL_KW = (
    "cannot parse data",
    "no video formats found",
    "video unavailable",
    "this video has been removed",
    "content isn't available",
    "content is no longer available",
    "private video",
    "requested content cannot be displayed",
    "unable to extract",
)


def dead_reason(err) -> str:
    """Loi nay co phai 'reel da chet' khong? -> tra tu khoa khop, '' neu la loi khac."""
    m = str(err or "").lower()
    return next((k for k in _DEAD_DL_KW if k in m), "")


def export_cookies(port: int = DEFAULT_PORT, out_path: str = None) -> str:
    """Xuat cookie facebook.com tu CDP ra file Netscape cho yt-dlp."""
    open_session(port)
    targets = list_targets(port)
    if not targets:
        raise RuntimeError("Khong co tab Chrome. Mo phien + dang nhap truoc.")
    c = CDP(targets[0]["webSocketDebuggerUrl"])
    try:
        c.send("Network.enable")
        cookies = c.send("Network.getAllCookies").get("cookies", [])
    finally:
        c.close()

    if out_path is None:
        out_path = os.path.join(FB_DIR, "_chrome_profile", "cookies.txt")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    lines = ["# Netscape HTTP Cookie File", ""]
    for ck in cookies:
        dom = ck.get("domain", "")
        if "facebook" not in dom and "fbcdn" not in dom:
            continue
        inc = "TRUE" if dom.startswith(".") else "FALSE"
        secure = "TRUE" if ck.get("secure") else "FALSE"
        exp = int(ck.get("expires") or 0)
        if exp <= 0:
            exp = int(time.time()) + 3600 * 24 * 30  # cookie phien -> gan han 30 ngay
        lines.append("\t".join([dom, inc, ck.get("path", "/"), secure,
                                str(exp), ck.get("name", ""), ck.get("value", "")]))
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return out_path


def download_reel(slug: str, reel_id: str, cookies: str = None,
                  quality: str = "best") -> dict:
    """Tai 1 reel + metadata. Tra ve dict {ok, dir, caption, views, skipped}."""
    import yt_dlp

    out_dir = os.path.join(FB_DIR, slug, "downloads", reel_id)
    os.makedirs(out_dir, exist_ok=True)
    video_path = os.path.join(out_dir, "video.mp4")

    if os.path.isfile(video_path) and os.path.getsize(video_path) > 0:
        # da co -> chi bao dam caption/meta (khong tai lai)
        cap = ""
        cp = os.path.join(out_dir, "caption.txt")
        if os.path.isfile(cp):
            cap = open(cp, encoding="utf-8").read()
        return {"ok": True, "skipped": True, "dir": out_dir, "caption": cap}

    if cookies is None:
        cookies = export_cookies()

    url = "https://www.facebook.com/reel/%s/" % reel_id
    # DO THAT (2026-07-23): luong PROGRESSIVE 'hd' cua FB HAY tra HTTP 500 (kho tai).
    # DASH (video+audio tach roi, ghep bang ffmpeg) tai duoc 720p on dinh. Nen:
    #   thu DASH merge TRUOC -> roi 'best' (progressive) -> cuoi cung 'sd' (chac chan tai).
    # Reel doi cu chi co progressive gop san -> 'bestvideo+bestaudio' fail selection ->
    # tu rot xuong 'best'. -> 1 chuoi lo het ca 2 loai reel + ne luong 500.
    if quality == "best":
        fmt_chain = ["bestvideo+bestaudio/best", "best", "sd"]
    else:
        fmt_chain = ["bestvideo[width<=720]+bestaudio/best[width<=720]",
                     "best[width<=720]/best", "sd"]
    base = {
        "outtmpl": os.path.join(out_dir, "video.%(ext)s"),
        "cookiefile": cookies,
        "merge_output_format": "mp4",
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "writethumbnail": True,
        # FB CDN hay chap chon -> retry nhieu tang (tai/manh/trich xuat/truy cap file).
        "retries": 8, "fragment_retries": 8,
        "extractor_retries": 3, "file_access_retries": 5,
    }
    info, last_err = None, None
    for fmt in fmt_chain:
        try:
            with yt_dlp.YoutubeDL({**base, "format": fmt}) as ydl:
                info = ydl.extract_info(url, download=True)
            break                                   # tai duoc -> thoat chuoi
        except yt_dlp.utils.DownloadError as e:
            last_err = e                            # format nay 500/loi -> thu format ke
            for f in os.listdir(out_dir):           # don file tai do
                if f.startswith("video."):
                    try:
                        os.remove(os.path.join(out_dir, f))
                    except OSError:
                        pass
            continue
    if info is None:
        why = dead_reason(last_err)
        if why:
            # Neu ro ID: nguoi dung nhin log/lưới la biet NGAY reel nao chet de doi nguon,
            # thay vi mot cau tieng Anh bao "please report this issue on github".
            raise ReelDead("Reel nguồn %s ĐÃ CHẾT (bị xoá / chuyển riêng tư / chặn vùng) — "
                           "Facebook không còn trả dữ liệu video [%s]" % (reel_id, why))
        raise last_err or RuntimeError("Khong tai duoc reel %s" % reel_id)

    caption = info.get("description") or ""
    meta = {
        "id": reel_id,
        "title": info.get("title"),
        "caption": caption,
        "views": info.get("view_count"),
        "duration": info.get("duration"),
        "upload_date": info.get("upload_date"),
        "url": url,
    }
    with open(os.path.join(out_dir, "caption.txt"), "w", encoding="utf-8") as f:
        f.write(caption)
    with open(os.path.join(out_dir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)

    # chuan hoa ten thumbnail -> thumb.jpg
    for ext in (".jpg", ".webp", ".png"):
        cand = os.path.join(out_dir, "video" + ext)
        if os.path.isfile(cand):
            os.replace(cand, os.path.join(out_dir, "thumb" + ext))
            break

    return {"ok": True, "skipped": False, "dir": out_dir,
            "caption": caption, "views": meta["views"]}


def download_many(slug: str, reel_ids, quality: str = "best", progress=None) -> dict:
    """Tai nhieu reel. Cap nhat index.json. Tra ve tong ket."""
    cookies = export_cookies()
    idx = load_index(slug)
    reels = idx.get("reels", {})
    done, skipped, failed = 0, 0, []
    for i, rid in enumerate(reel_ids):
        try:
            r = download_reel(slug, rid, cookies=cookies, quality=quality)
            if r.get("skipped"):
                skipped += 1
            else:
                done += 1
            if rid in reels:
                reels[rid]["downloaded"] = True
                reels[rid]["status"] = "downloaded"
                if r.get("caption"):
                    reels[rid]["caption"] = r["caption"]
        except Exception as e:
            failed.append({"id": rid, "error": str(e)})
        if progress:
            progress(i + 1, len(reel_ids), rid)
    idx["reels"] = reels
    save_index(slug, idx)
    return {"done": done, "skipped": skipped, "failed": failed,
            "total": len(reel_ids)}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--slug", help="ten page (slug)")
    ap.add_argument("--ids", help="danh sach reel_id, ngan cach bang dau phay")
    ap.add_argument("--quality", default="best", help="best | 720")
    ap.add_argument("pos", nargs="*", help="[slug reel_id] che do test 1 reel")
    a = ap.parse_args()

    if a.slug and a.ids:
        ids = [x.strip() for x in a.ids.split(",") if x.strip()]
        total = len(ids)

        def _p(i, n, rid):
            print("  [%d/%d] xong reel %s" % (i, n, rid), flush=True)

        print("Bat dau tai %d reel cua page %s ..." % (total, a.slug), flush=True)
        res = download_many(a.slug, ids, quality=a.quality, progress=_p)
        print("XONG: tai %d, bo qua %d, loi %d/%d"
              % (res["done"], res["skipped"], len(res["failed"]), res["total"]), flush=True)
        for f in res["failed"]:
            print("  LOI reel %s: %s" % (f["id"], f["error"]), flush=True)
    elif len(a.pos) >= 2:
        res = download_reel(a.pos[0], a.pos[1], quality=a.quality)
        print(json.dumps({k: v for k, v in res.items() if k != "caption"}, ensure_ascii=False))
        print("CAPTION:", (res.get("caption") or "")[:200])
        print("Files:", os.listdir(res["dir"]))
    else:
        print("Cach dung: fb_download.py --slug <slug> --ids <id1,id2,...>")
