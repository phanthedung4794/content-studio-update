# -*- coding: utf-8 -*-
"""
BAI DANG ANH (khong phai video): Gemini phan tich -> y tuong tranh + CHU tren anh + tus
-> 79AI ve tranh -> PIL ghi chu -> xep KHO CHO dang theo lich (giong video).

Vi sao tach khoi image_post.py: image_post lo phan VE + GHEP THE (thuan PIL/79AI, dung
chung cho tab "Tao anh" thu cong). Module nay lo phan NOI DUNG (Gemini) + DUONG DANG
(kho cho + lich), tai dung image_post chu KHONG chep lai.

QUY TAC CUNG #3: 79AI KHONG ve duoc chu tieng Viet -> chu do PIL ghi len (image_post.compose_card).

Gemini tra 1 JSON:
  {idea, text, caption, tags[]}
    idea    : mo ta tranh (TIENG ANH — 79AI hieu tot hon), KHONG chua chu/text
    text    : CHU ghi len anh (tieng Viet co dau, manh, danh vao cam xuc)
    caption : tus dang kem bai
    tags    : the/hashtag
"""
import json
import os
import re
import tempfile
import time

import fb_remake                     # dung chung gemini_generate + _first_json (DRY)
import image_post

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.environ.get("CS_FB_ROOT") or os.path.join(ROOT, "facebook")
OUT_DIR = os.path.join(FB_ROOT, "_image_posts")

# Model ve mac dinh: khop pipeline video (banana_pro vip 1k = 600cr, nhanh + on dinh nhat
# theo phep do 2026-07-24). Doi bang env neu can.
MODEL = os.environ.get("CS_IMGPOST_MODEL", "google_image_gen_banana_pro")
MODE = os.environ.get("CS_IMGPOST_MODE", "vip")
RES = os.environ.get("CS_IMGPOST_RES", "1k")

_PROMPT = (
    "Ban la chuyen gia lam BAI DANG ANH viral cho fanpage Facebook tieng Viet "
    "(hoai niem / tam su / ngam doi / doi song que).\n"
    "Chu de / noi dung nguon:\n\"\"\"%s\"\"\"\n\n"
    "Tao 1 bai dang ANH. Tra ve DUNG 1 JSON (khong markdown, khong giai thich):\n"
    '{"idea": "...", "text": "...", "caption": "...", "tags": ["...", "..."]}\n'
    "- idea: mo ta buc tranh bang TIENG ANH cho AI ve (bo cuc, nhan vat, boi canh, anh sang, "
    "cam xuc). Canh doi thuong Viet Nam, GIAU CAM XUC, de dong cam. TUYET DOI khong yeu cau "
    "ve chu/text/watermark trong tranh.\n"
    "- text: CHU se ghi len anh. 1-2 cau NGAN (toi da 20 tu), tieng Viet CO DAU DAY DU, danh "
    "THANG vao cam xuc nguoi doc (cham ky uc / xot xa / thuc tinh). Viet nhu loi tam su that "
    "long, KHONG sao rong. VD dung: \"Cha mẹ già rồi, còn về được mấy lần nữa?\"\n"
    "- caption: tus dang kem, 2-4 dong, dong dau la cau HOOK manh, tieng Viet CO DAU, toi da "
    "2-3 emoji, KHONG nhac ten kenh/link/keu goi follow, KHONG kem hashtag.\n"
    "- tags: 4-6 tu khoa KHONG dau '#', khong dau tieng Viet, khong khoang trang.\n"
    "Chi tra JSON.")


def content_pack(source_text, timeout=90):
    """Gemini -> {idea, text, caption, tags}. Loi/thieu key -> fallback an toan (khong nem)."""
    base = (source_text or "").strip()
    fb = {"idea": "", "text": "", "caption": base, "tags": ["xuhuong", "viral"]}
    if not base:
        return fb
    try:
        txt = fb_remake.gemini_generate([{"text": _PROMPT % base[:1500]}],
                                        gen_config={"temperature": 0.9}, timeout=timeout)
        d = fb_remake._first_json(txt)
        tags = [re.sub(r"[^0-9a-zA-Z_]", "", str(t).lstrip("#"))[:24] for t in (d.get("tags") or [])]
        tags = [t for t in tags if t][:6]
        for must in ("xuhuong", "viral"):
            if must not in [t.lower() for t in tags]:
                tags.append(must)
        return {"idea": (d.get("idea") or "").strip(),
                "text": (d.get("text") or "").strip()[:160],
                "caption": (d.get("caption") or base).strip(),
                "tags": tags}
    except Exception as exc:
        print("[img-pack] Gemini loi (%s) -> fallback" % str(exc)[:90], flush=True)
        return fb


# LECH KEY GIUA 2 MODULE (do that 2026-07-25): fb_remake dung 'real'/'cartoon',
# image_post dung 'anh_that'/'hoat_hinh'. Truyen thang 'real' -> build_prompt khong khop
# -> AM THAM roi ve mac dinh hoat hinh (chon "anh that" ma ra hoat hinh). Anh xa o day.
_STYLE_MAP = {"real": "anh_that", "cartoon": "hoat_hinh"}


def map_style(style):
    """Doi key kieu anh cua fb_remake -> key cua image_post. Khong biet -> giu nguyen."""
    s = (style or "").strip()
    s = _STYLE_MAP.get(s, s)
    return s if s in image_post.STYLES else image_post.DEFAULT_STYLE


def make_image(idea, text, style="real", ratio_key="facebook_post", out_dir="",
               model=MODEL, mode=MODE, resolution=RES):
    """79AI ve tranh theo `idea` -> PIL ghi `text` len -> tra duong dan anh.

    text rong -> anh KHONG chu (phu kin khung).
    """
    from gommo_client import GommoClient, download
    if not (idea or "").strip():
        raise ValueError("Thieu y tuong tranh (idea).")
    style = map_style(style)
    out_dir = out_dir or OUT_DIR
    os.makedirs(out_dir, exist_ok=True)
    client = GommoClient()
    # ti le tranh: co chu -> khop dai tranh (~70% duoi); khong chu -> phu kin
    ratios = []
    try:
        row = next((m for m in client.image_models() if m.get("model") == model), None)
        ratios = [o["value"] for o in (row or {}).get("ratios", [])]
    except Exception:
        ratios = []
    illo_ratio = image_post.pick_illustration_ratio(ratios or ["9:16", "1:1", "16:9"],
                                                    ratio_key, full=not text)
    prompt = image_post.build_prompt(idea, style)
    res = client.create_image(model=model, prompt=prompt, ratio=illo_ratio,
                             mode=mode or None, resolution=resolution or None)
    if res.get("error"):
        raise RuntimeError("79AI tu choi: %s" % (res.get("message") or res))
    info = res.get("imageInfo") or res.get("data") or res
    idb = info.get("id_base") or res.get("id_base")
    if not idb:
        raise RuntimeError("Khong lay duoc ma anh tu 79AI: %s" % res)
    done = client.wait_for_image(idb)
    out = os.path.join(out_dir, "imgpost_%d.png" % int(time.time() * 1000))
    with tempfile.TemporaryDirectory() as td:
        raw = os.path.join(td, "illo.png")
        download(done["url"], raw)
        if text:
            image_post.compose_card(raw, text, out, ratio_key)
        else:
            image_post.compose_plain(raw, out, ratio_key)
    return out


def build(source_text, style="real", ratio_key="facebook_post", out_dir=""):
    """1 phat: Gemini -> noi dung -> ve anh. Tra {image, text, caption, tags, idea}."""
    p = content_pack(source_text)
    if not p.get("idea"):
        raise RuntimeError("Gemini khong tra duoc y tuong tranh (thieu GEMINI_API_KEY?)")
    img = make_image(p["idea"], p["text"], style=style, ratio_key=ratio_key, out_dir=out_dir)
    return {"image": img, **p}


def run_for_page(page_id, page_name, source_text, when_ts=0, style="real",
                 ratio_key="facebook_post", rank=None, slot_k=0,
                 gap_page_min=15, gap_post_min=300, anchor=0, mode="now"):
    """Tao 1 BAI DANG ANH cho page roi XEP KHO CHO (dang bang Chrome theo lich).

    Gio dang tinh y het duong video (fb_slots): anchor + rank*gap_page + k*gap_bai
    -> bai anh va bai video dung CHUNG mot quy tac lich, khong lech nhau.
    """
    import fb_chrome_queue
    import fb_slots
    r = build(source_text, style=style, ratio_key=ratio_key)
    if not when_ts:
        rk = fb_slots.rank_of(page_id) if rank is None else int(rank)
        a = fb_slots.run_t0() if mode == "now" else int(anchor or 0)
        when_ts = fb_slots.slot_for(a, rk, slot_k, gap_page_min, gap_post_min, min_lead=0)
    it = fb_chrome_queue.add(page_id, page_name, r["image"], int(when_ts),
                             caption=r["caption"], title="", tags=r["tags"], kind="photo")
    return {**r, "queue_id": it["id"], "when_ts": int(when_ts)}


if __name__ == "__main__":
    import argparse
    import io
    import sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    ap = argparse.ArgumentParser(description="Tao bai dang ANH tu chu de (Gemini + 79AI + PIL).")
    ap.add_argument("--source", required=True, help="chu de / noi dung nguon")
    ap.add_argument("--style", default="real")
    ap.add_argument("--ratio", default="facebook_post")
    ap.add_argument("--pack-only", action="store_true", help="chi sinh noi dung, KHONG ve (0 credit)")
    # Che do CHO PAGE: ve xong xep thang KHO CHO (dang bang Chrome theo lich)
    ap.add_argument("--page-id", default="")
    ap.add_argument("--page-name", default="")
    ap.add_argument("--n", type=int, default=1)             # so bai anh cho page nay
    ap.add_argument("--slot-gap-page", type=int, default=15)
    ap.add_argument("--slot-gap-post", type=int, default=300)
    ap.add_argument("--slot-anchor", type=int, default=0)
    ap.add_argument("--chrome-mode", default="now", choices=["now", "schedule"])
    a = ap.parse_args()
    if a.pack_only:
        print(json.dumps(content_pack(a.source), ensure_ascii=False, indent=1))
    elif a.page_id:
        out = []
        for k in range(max(1, a.n)):
            r = run_for_page(a.page_id, a.page_name, a.source, style=a.style,
                             ratio_key=a.ratio, slot_k=k, gap_page_min=a.slot_gap_page,
                             gap_post_min=a.slot_gap_post, anchor=a.slot_anchor,
                             mode=a.chrome_mode)
            print("→ bài ảnh %d/%d → %s | %s" % (
                k + 1, a.n, time.strftime("%H:%M %d/%m", time.localtime(r["when_ts"])),
                r["text"][:60]), flush=True)
            out.append({"when_ts": r["when_ts"], "text": r["text"]})
        print("KETQUA:", json.dumps({"ok": True, "posts": out}, ensure_ascii=False))
    else:
        print(json.dumps(build(a.source, a.style, a.ratio), ensure_ascii=False, indent=1))
