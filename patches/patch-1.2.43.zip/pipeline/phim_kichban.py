# -*- coding: utf-8 -*-
"""KỊCH BẢN cho Xưởng phim — ba đường vào.

  `nhap()`    người dùng dán/tải kịch bản có sẵn
  `tu_reel()` chép lời thoại reel mẫu → kịch bản (dùng cho "cào rồi dựng lại Y CHANG")
  `tu_sinh()` Gemini tự viết kịch bản mới theo đề tài

⚠️ MODULE RIÊNG. `fb_remake` chỉ GỌI, không sửa.

⚠️ MODEL: `tu_sinh` dùng bậc CAO (`phim.MODEL_PRO`) vì đo được flash-lite viết kịch bản kém
hẳn (cùng một việc khó: flash-lite báo 5 lỗi — 1 đúng, 2 BỊA; pro báo 3 lỗi — 3/3 đúng).
`tu_reel` chỉ CHÉP LỜI nên dùng model mặc định cho rẻ.
⚠️ Đường ĐĂNG HÀNG LOẠT vẫn giữ flash-lite — module này không đụng biến của nó.
"""
import json
import os
import re

GOC = os.environ.get("PHIM_GOC", "phim")
KHO = os.path.join(GOC, "_kichban")

# Trường BẮT BUỘC của một nhịp (khớp cái `phim.lam_tap` cần).
TRUONG = ("loai", "dialogue", "nguoi_noi", "nhan_vat_trong_canh")
LOAI = ("thoai", "cam", "dan")


def _ghi(ma, d):
    os.makedirs(KHO, exist_ok=True)
    p = os.path.join(KHO, "%s.json" % re.sub(r"[^\w\-]", "_", ma))
    tmp = "%s.tmp%d" % (p, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)
    return p


def doc(ma):
    p = os.path.join(KHO, "%s.json" % re.sub(r"[^\w\-]", "_", ma))
    try:
        with open(p, encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return {}


def danh_sach():
    if not os.path.isdir(KHO):
        return []
    ra = []
    for f in sorted(os.listdir(KHO)):
        if not f.endswith(".json"):
            continue
        d = doc(f[:-5])
        ra.append({"ma": f[:-5], "so_tap": len(d),
                   "tap": sorted(d.keys(), key=lambda x: int(x) if str(x).isdigit() else 999)})
    return ra


def kiem(d):
    """CODE chấm kịch bản. Trả danh sách lỗi tiếng Việt — rỗng là đạt.

    Không tin LLM tự báo đạt: đo được nó tự nhận đủ trong khi đếm ra 44%.
    """
    loi = []
    if not isinstance(d, dict) or not d:
        return ["Kịch bản rỗng hoặc sai định dạng (phải là {số tập: {...}})."]
    for tap, t in d.items():
        if not isinstance(t, dict):
            loi.append("Tập %s không phải object." % tap)
            continue
        sc = t.get("scenes")
        if not isinstance(sc, list) or not sc:
            loi.append("Tập %s thiếu `scenes` hoặc rỗng." % tap)
            continue
        for i, s in enumerate(sc):
            if not isinstance(s, dict):
                loi.append("Tập %s nhịp %d không phải object." % (tap, i + 1))
                continue
            lo = s.get("loai") or "thoai"
            if lo not in LOAI:
                loi.append("Tập %s nhịp %d có loai=%r, phải là %s." % (tap, i + 1, lo, LOAI))
            if lo == "thoai" and not (s.get("dialogue") or "").strip():
                loi.append("Tập %s nhịp %d loai='thoai' mà không có lời." % (tap, i + 1))
            if lo == "thoai" and not (s.get("nguoi_noi") or "").strip():
                loi.append("Tập %s nhịp %d thiếu `nguoi_noi`." % (tap, i + 1))
    return loi


def nhap(ma, noi_dung):
    """Nhập kịch bản có sẵn. `noi_dung` = dict, hoặc chuỗi JSON."""
    d = noi_dung
    if isinstance(d, str):
        s = d.strip()
        m = re.search(r"\{.*\}", s, re.S)
        if not m:
            raise RuntimeError("Không tìm thấy JSON trong nội dung dán vào.")
        d = json.loads(m.group(0))
    loi = kiem(d)
    if loi:
        raise RuntimeError("Kịch bản chưa dùng được:\n- " + "\n- ".join(loi[:8]))
    _ghi(ma, d)
    return {"ma": ma, "so_tap": len(d)}


_P_REEL = (
    "Bạn XEM video reel này và CHÉP LẠI thành kịch bản để dựng lại Y HỆT bằng hình vẽ mới.\n"
    "LUẬT:\n"
    "1. Chép ĐÚNG TỪNG CHỮ mọi lời nói. TUYỆT ĐỐI không rút gọn, không diễn đạt lại. "
    "Mất chữ là lỗi nặng nhất.\n"
    "2. Câu dài quá 29 từ thì TÁCH thành nhiều nhịp liên tiếp ở ranh giới mệnh đề, "
    "giữ đủ mọi chữ. KHÔNG có độ dài tối thiểu — câu 3 từ là một nhịp tốt.\n"
    "3. Mỗi nhịp chỉ MỘT người nói. Đoạn không ai nói thì loai='cam'.\n"
    "4. `nhan_vat_trong_canh` liệt kê mọi vai CÓ MẶT trong khung, kể cả người không nói.\n"
    "Trả JSON THUẦN: {\"tieu_de\":\"...\",\"scenes\":[{\"loai\":\"thoai|cam\","
    "\"nguoi_noi\":\"MA_VAI\",\"dialogue\":\"...\",\"nhan_vat_trong_canh\":[\"MA_VAI\"],"
    "\"start\":0.0,\"end\":4.0}]}\n"
    "Mã vai viết HOA không dấu (VD: NGUOI_KE, ME, CON)."
)


def tu_reel(video, model=None):
    """Chép lời thoại một reel → kịch bản 1 tập. Dùng cho 'dựng lại Y CHANG'."""
    import fb_remake as R
    import phim
    mp4 = R._gem_ready_video(video, os.path.dirname(video) or ".")
    if not mp4:
        raise RuntimeError("Không chuẩn bị được video để gửi Gemini (quá lớn?)")
    with open(mp4, "rb") as f:
        import base64
        b = base64.b64encode(f.read()).decode()
    d = phim.gemini_json([{"inline_data": {"mime_type": "video/mp4", "data": b}},
                          {"text": _P_REEL}], timeout=600, model=model)
    if not (d.get("scenes")):
        raise RuntimeError("Gemini không trả về nhịp nào")
    return d


_P_SINH = (
    "Viết kịch bản phim ngắn nhiều tập cho Facebook, tiếng Việt.\n"
    "Đề tài: %s\nSố tập: %d — mỗi tập %d nhịp, mỗi nhịp là MỘT câu thoại (tối đa 29 từ).\n"
    "LUẬT:\n"
    "1. Mỗi nhịp chỉ MỘT người nói. Nhịp không lời thì loai='cam'.\n"
    "2. KHÔNG có độ dài tối thiểu — câu ngắn 3 từ thường là câu đắt nhất.\n"
    "3. Mỗi tập kết ở chỗ khiến người xem phải đợi tập sau.\n"
    "4. Nhân vật giữ NGUYÊN mã vai xuyên suốt mọi tập.\n"
    "Trả JSON THUẦN: {\"1\":{\"tieu_de\":\"...\",\"scenes\":[{\"loai\":\"thoai\","
    "\"nguoi_noi\":\"MA_VAI\",\"dialogue\":\"...\",\"nhan_vat_trong_canh\":[\"MA_VAI\"]}]}}"
)


def tu_sinh(ma, de_tai, so_tap=5, so_nhip=16, model=None, bao=None):
    """Gemini tự viết kịch bản. CODE chấm, chưa đạt thì trả lỗi lại cho nó sửa."""
    import phim
    p = _P_SINH % (de_tai, so_tap, so_nhip)

    def cham(d):
        loi = kiem(d)
        if not loi and len(d) != so_tap:
            loi.append("Phải đủ %d tập, đang có %d." % (so_tap, len(d)))
        return loi

    d, con = phim.gemini_json_gated(p, cham, vong=4, timeout=600,
                                    model=model or phim.MODEL_PRO, ten="Kịch bản")
    if con:
        raise RuntimeError("Kịch bản chưa đạt sau 4 vòng:\n- " + "\n- ".join(con[:6]))
    _ghi(ma, d)
    if bao:
        bao("Đã viết %d tập" % len(d))
    return {"ma": ma, "so_tap": len(d)}
