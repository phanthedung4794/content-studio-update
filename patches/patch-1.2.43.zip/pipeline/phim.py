# -*- coding: utf-8 -*-
"""PHIM NGAN NHIEU TAP tu KICH BAN CO SAN (khac han duong remake video nguon).

Duong `fb_remake.remake_dialogue` lam lai MOT video da co: xem nguon -> tach canh -> ve lai.
Duong nay khong co nguon nao ca — dau vao la KICH BAN do nguoi viet, dau ra la tap phim.

BA THU nay la ly do phai tach thanh module rieng, duong remake khong co:
 1. SO DANG KY KHOA XUYEN SERIES — nhan vat + boi canh sinh MOT LAN o tap dau roi dung chung
    moi tap. Sinh rieng tung tap thi Tap 2 doi dau hieu nhan vat, tham chi HOAN DOI giua cac
    vai (da mac that) -> khan gia khong nhan ra ai voi ai, ma nhan dien nhan vat chinh la thu
    giu chan nguoi theo doi mot series.
 2. BA LOAI NHIP — 'thoai' (Veo tu sinh tieng noi), 'cam' (clip khong loi), 'dan' (clip cam +
    giong nam tram doc de len). Duong remake chi co mot loai.
 3. CHU HIEN tren man hinh (vd ket qua xet nghiem) — khac `chu_man_hinh` cua remake (cai kia
    la chep lai chu cua video goc).

Cac con so trong file nay DEU do tu page mau dang viral, khong phai uoc chung:
 - can mat 50-59% so canh          - 3-5 boi canh moi tap
 - caption khong hashtag, co "( Tap N )"   - chu bia dat THANG len anh, khong dai nen
"""
import json
import os
import re
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import fb_remake as R
import openai_image
from gommo_client import GommoClient

# ---------------------------------------------------------------- tham so do duoc
TAIL = float(os.environ.get("PHIM_TAIL", "0.7"))      # chua sau khi noi xong
MINLEN = float(os.environ.get("PHIM_MINLEN", "2.5"))  # san do dai mot nhip
XFADE = float(os.environ.get("PHIM_XFADE", "0.35"))
CAM_LEN = float(os.environ.get("PHIM_CAM_LEN", "3.2"))   # do dai nhip khong loi
LANES = int(os.environ.get("PHIM_LANES", "4"))
STYLE = os.environ.get("PHIM_STYLE", "pixar_3d")

GOC_MAY = {
    "can-mat": ("CLOSE-UP SHOT: the subject described below FILLS the entire frame. "
                "Shallow depth of field, background strongly blurred. If it is a person, "
                "show head and shoulders only, large enough that the emotion is clearly "
                "readable. Do NOT show full bodies, do NOT show the whole room."),
    "trung": "MEDIUM SHOT: the characters framed from the waist up, some background visible.",
    "toan": "WIDE SHOT: full bodies visible together with the surrounding location.",
}

# Bo loc an toan cua OpenAI chan tu manh. Thay bang tu trung tinh TRUOC khi gui — re hon
# nhieu so voi de no tu choi roi phai nho Gemini viet lai ca cau.
_MEM = [(r"pure hatred and disdain", "clear disapproval"), (r"\bhatred\b", "disapproval"),
        (r"\bcruel\b", "stern"), (r"\bharsh\b", "firm"), (r"\bdisdain\b", "disapproval"),
        (r"point(?:s|ing)?(?: her| his)?(?: finger)? at", "gesturing toward"),
        (r"\btriumphant\b", "calm"), (r"\bviolent\b", "tense"),
        (r"\bmocking\b", "unimpressed"), (r"\bblood\b", "red mark"),
        (r"\bbleeding\b", "unwell")]


def lam_mem(t):
    for a, b in _MEM:
        t = re.sub(a, b, t, flags=re.I)
    return re.sub(r"\s+", " ", t).strip()


def _log(m):
    R._prog(m)


# ------------------------------------------------- tro giup RIENG cua module nay
# ⚠️ Ba ham duoi day CO Y dat o day chu KHONG them vao fb_remake.py: fb_remake nam tren
# duong DANG HANG LOAT (thu dang ra tien), sua vao do la rui ro cho viec dang chay. Module
# phim tu mang do nghe cua minh.
def gemini_json(parts, gen_config=None, timeout=180, model=None):
    """Goi Gemini roi boc JSON. Gemini hay kem loi dan hoac rao ```json quanh ket qua."""
    t = R.gemini_generate(parts, gen_config=gen_config, timeout=timeout).strip() \
        if model is None else _goi_model(parts, gen_config, timeout, model)
    m = re.search(r"\{.*\}", t, re.S)
    if not m:
        raise RuntimeError("Gemini khong tra JSON: " + t[:200])
    return json.loads(m.group(0))


# Bac CAO, chi dung cho viec doi NGHE KE CHUYEN (viet kich ban, lap so dang ky).
# ⚠️ Duong DANG HANG LOAT giu flash-lite (nguoi dung chot ro) — module nay khong dung
# chung bien voi fb_remake.GEMINI_MODEL nen khong the lam anh huong ben do.
# Ghim ban CU THE, khong dung alias "-latest": alias tu troi sang ban moi/dat hon ma khong
# bao (da mac 29/07: "gemini-flash-latest" am tham thanh model dat gap 10 lan).
MODEL_PRO = os.environ.get("PHIM_GEMINI_PRO", "gemini-3.1-pro-preview")


def _goi_model(parts, gen_config, timeout, model):
    """Goi Gemini voi model CHI DINH (fb_remake.gemini_generate ghim mot model duy nhat).

    Doc LY DO nha cung cap tra ve thay vi nem loi cut (luat cung #7). Da mat thoi gian that
    02/08: HTTP 429 bi doan la "goi qua nhanh" nen di cat bot prompt, trong khi error.message
    ghi ro "Your prepayment credits are depleted" = HET TIEN.
    """
    import requests
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Thieu GEMINI_API_KEY")
    url = ("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s"
           % (model, key))
    body = {"contents": [{"parts": parts}], "generationConfig": gen_config or {}}
    last = None
    for att in range(4):
        try:
            r = requests.post(url, json=body, timeout=timeout)
            try:
                msg = (r.json().get("error") or {}).get("message") or ""
            except Exception:
                msg = (r.text or "")[:200]
            if r.status_code in (429, 500, 502, 503, 504):
                last = "HTTP %d%s" % (r.status_code, (" - " + msg[:200]) if msg else "")
                # ⚠️ Dieu kien bo cuoc phai HEP. 429 CHAN TOC DO thong thuong cua Gemini ghi
                # "Resource has been exhausted (e.g. check quota)" — bat chu "quota" la bo
                # cuoc oan tren mot loi CHO MOT LAT LA QUA.
                if re.search(r"prepayment credits|credits are depleted|"
                             r"billing (?:account )?(?:is )?(?:disabled|not active)|"
                             r"account (?:is )?suspended|API key not valid", msg, re.I):
                    raise RuntimeError("Gemini tu choi: %s" % last)
                time.sleep(min(20, 4 * (att + 1)))
                continue
            if r.status_code >= 400:
                raise RuntimeError("Gemini HTTP %d: %s" % (r.status_code, (msg or "")[:300]))
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]
        except requests.exceptions.RequestException as e:
            last = str(e)[:80]
            time.sleep(min(20, 4 * (att + 1)))
    raise RuntimeError("Gemini that bai sau 4 lan: %s" % last)


def gemini_json_gated(prompt, cham, vong=4, gen_config=None, timeout=600, model=None,
                      ten="ket qua"):
    """Goi Gemini, CODE CHAM, chua dat thi tra loi lai kem danh sach loi. Tra (data, loi).

    Vi sao can: LLM KHONG DEM DUOC. Bat no tu kiem "cho du 50% canh can mat" thi no tu bao
    da dat trong khi dem ra 44%. Chi co code dem moi tin duoc — do that 04/08 tren so dang
    ky Tap 2: Gemini tra 7/16 = 44%, code bat, vong sau ra 9/16 = 56%.

    ⚠️ `cham` phai la phep dem THAT tren du lieu tra ve, KHONG duoc chi doc lai chinh con so
    minh vua yeu cau (xem memory/test-mock-khong-tu-nghiem-thu-duoc.md).
    """
    def _parts(extra=""):
        if isinstance(prompt, str):
            return [{"text": prompt + extra}]
        return list(prompt) + ([{"text": extra}] if extra else [])

    d = gemini_json(_parts(), gen_config=gen_config, timeout=timeout, model=model)
    for v in range(vong):
        loi = cham(d) or []
        if not loi:
            _log("%s DAT o vong %d" % (ten, v))
            return d, []
        _log("%s vong %d chua dat: %s" % (ten, v, "; ".join(loi)[:160]))
        d = gemini_json(_parts("\n\nBAN VUA TRA VE BAN NAY, CON LOI. Sua roi tra JSON DAY DU:\n"
                               + json.dumps(d, ensure_ascii=False)[:12000]
                               + "\n\nLOI PHAI SUA:\n- " + "\n- ".join(loi)),
                        gen_config=gen_config, timeout=timeout, model=model)
    con = cham(d) or []
    if con:
        _log("%s SAU %d VONG VAN CHUA DAT: %s" % (ten, vong, "; ".join(con)[:200]))
    return d, con


def _speech_end(clip_path, n_words=None):
    """Giay thu may thi nhan vat noi xong trong clip. None neu khong do duoc.

    ⚠️ CAT THEO SO CHU cua cau goc, KHONG theo moc het tieng. Do that Tap 2: Veo doc xong
    cau roi BIA THEM cho day 8 giay ("...Mua dinh... Nghinh anh gam.") — lay moc het tieng
    la giu nguyen phan bia do. Lay dung n chu dau thi bo duoc.
    """
    try:
        from faster_whisper import WhisperModel
    except Exception:
        return None
    global _W
    try:
        _W
    except NameError:
        _W = None
    if _W is None:
        _W = WhisperModel("small", device="cpu", compute_type="int8")
    try:
        segs, _ = _W.transcribe(clip_path, language="vi", word_timestamps=bool(n_words))
        if n_words:
            ws = [w for s in segs for w in (s.words or [])]
            return ws[min(n_words, len(ws)) - 1].end if ws else None
        return max((s.end for s in segs), default=None)
    except Exception:
        return None


# ---------------------------------------------------------------- B1: so dang ky
_P_SODANGKY = """Bạn là đạo diễn hình ảnh cho một SERIES phim ngắn AI. Đây là TẬP __TAP__.

__KHOA__

Kịch bản Tập __TAP__:
__KICHBAN__

TRẢ JSON THUẦN:
{
 __PHAN_MOI__
 "dao_cu": {"MA_DAO_CU": {"mo_ta":"English: exact fixed description with colour and material",
                          "canh_xuat_hien":[số cảnh]}},
 "canh": [{"so":1,"noi_chon":"khớp key bối cảnh","goc_may":"can-mat|trung|toan",
           "dao_cu":["MA_DAO_CU"],
           "khung_hinh":"English: ONE sentence - who, doing what, where in frame. For can-mat write a real close-up: head and shoulders filling the frame, background blurred."}]
}

LUẬT BẮT BUỘC:
- "canh" đủ __N__ phần tử, đúng thứ tự.
- Cận mặt chiếm 50-69% số cảnh (đo từ page mẫu viral: 50-59%). Cảnh chỉ có MỘT người nói
  thì gần như luôn là "can-mat". Cảnh mở đầu một nơi mới, hoặc cảnh đông người -> "trung"/"toan".
- Ít nhất 3 bối cảnh khác nhau trong tập.
- "khung_hinh" chỉ tả hành động và bố cục, KHÔNG tả lại ngoại hình nhân vật.
- Tránh mọi từ bạo lực/thù ghét (hatred, cruel, violent, point at) vì bộ lọc ảnh sẽ chặn.
"""

_MOI = """"nhan_vat": {
   "MA_VAI": {"dau_hieu":"dấu hiệu nhận dạng bằng tiếng Việt, ngắn",
              "mo_ta":"English: age, face, hair, EXACT clothing with colors, one strong distinctive visual marker"}
 },
 "boi_canh": {
   "ma_noi": {"mo_ta":"English: what this place looks like",
              "anh_sang":"English: lighting and colour palette"}
 },"""

_KHOA_MOI = """TÔI ĐÃ ĐO page mẫu đang viral, phải bám ĐÚNG các con số này:
- Cận mặt chiếm 50-59% số cảnh (đây là thứ tạo cảm xúc, KHÔNG được ít hơn).
- Có 3-5 bối cảnh KHÁC NHAU rõ rệt trong 1 tập.
- Mỗi nhân vật có DẤU HIỆU NHẬN DẠNG cực mạnh, nhìn 0,5 giây là biết ai.
  ⚠️ TUYỆT ĐỐI KHÔNG dùng lại dấu hiệu của page mẫu (lô tóc hồng, váy xanh lá, áo ba lỗ
  trắng) — đó là nhân vật của họ. Phải nghĩ dấu hiệu RIÊNG, khác hẳn.
- Ánh sáng ĐỔI theo mạch cảm xúc.
Đây là TẬP ĐẦU nên bạn lập luôn "nhan_vat" và "boi_canh" — chúng sẽ được KHOÁ cho cả series."""

# Dau hieu cua page mau — cam sao chep.
_CAM = ["lô tóc hồng", "lo toc hong", "váy xanh lá", "áo ba lỗ", "ao ba lo", "hair curler"]


def so_dang_ky(scenes, tap, goc=None, model=None):
    """Lap so dang ky cho mot tap. `goc` = so dang ky cua TAP DAU (khoa nhan vat + boi canh).

    Tra dict {nhan_vat, boi_canh, dao_cu, canh}. Tap dau truyen goc=None.
    """
    tt = "\n".join(
        "Canh %d <%s> | noi goi y: %s | ai: %s | %s"
        % (i + 1, c.get("loai") or "thoai", c.get("noi_chon"),
           ",".join(c.get("nhan_vat_trong_canh") or []),
           ((c.get("nguoi_noi") or "") + ": " + c["dialogue"]) if c.get("dialogue")
           else ("KHONG LOI - " + str(c.get("hanh_dong") or "")))
        for i, c in enumerate(scenes))

    if goc:
        NV, BC = goc["nhan_vat"], goc["boi_canh"]
        khoa = ("⚠️ NHÂN VẬT ĐÃ KHOÁ TỪ TẬP ĐẦU. TUYỆT ĐỐI KHÔNG ĐỔI, KHÔNG NGHĨ MỚI, KHÔNG "
                "HOÁN ĐỔI dấu hiệu giữa các vai. Khán giả phải nhận ra đúng người ở mọi tập.\n\n"
                "NHÂN VẬT (khoá):\n"
                + "\n".join("  %s: %s | %s" % (k, v["dau_hieu"], v["mo_ta"])
                            for k, v in NV.items())
                + "\n\nBỐI CẢNH đã có (ưu tiên dùng lại, KHÔNG sửa mô tả):\n"
                + "\n".join("  %s: %s | ánh sáng: %s" % (k, v["mo_ta"], v["anh_sang"])
                            for k, v in BC.items())
                + '\n\nNếu tập này có nơi chốn THẬT SỰ mới thì thêm vào "boi_canh_them", '
                  "không có thì trả {}.")
        phan_moi = '"boi_canh_them": {"ma_noi_moi": {"mo_ta":"English","anh_sang":"English"}},'
    else:
        NV = BC = None
        khoa, phan_moi = _KHOA_MOI, _MOI

    P = (_P_SODANGKY.replace("__TAP__", str(tap)).replace("__KICHBAN__", tt)
         .replace("__N__", str(len(scenes))).replace("__KHOA__", khoa)
         .replace("__PHAN_MOI__", phan_moi))

    def cham(d):
        """CODE DEM. LLM khong dem duoc: do that 04/08 no tra 44% roi tu bao la dat."""
        loi = []
        cn = d.get("canh") or []
        if len(cn) != len(scenes):
            return ['Truong "canh" co %d phan tu, PHAI dung %d.' % (len(cn), len(scenes))]
        hople = set((NV and BC and BC) or (d.get("boi_canh") or {}))
        hople |= set(d.get("boi_canh_them") or {})
        cm = sum(1 for c in cn if c.get("goc_may") == "can-mat")
        if not (50 <= cm * 100.0 / len(cn) <= 69):
            loi.append("Can mat %d/%d = %.0f%%, phai trong khoang 50-69%%. Doi bot canh sang "
                       '"can-mat" (uu tien canh chi co MOT nguoi noi).'
                       % (cm, len(cn), cm * 100.0 / len(cn)))
        la = [c.get("noi_chon") for c in cn if c.get("noi_chon") not in hople]
        if la:
            loi.append("noi_chon khong co trong boi canh: %s. Chi duoc dung: %s"
                       % (sorted(set(la)), sorted(hople)))
        if len({c.get("noi_chon") for c in cn}) < 3:
            loi.append("Phai co it nhat 3 boi canh khac nhau.")
        thieu = [c.get("so") for c in cn if not (c.get("khung_hinh") or "").strip()]
        if thieu:
            loi.append('Canh %s thieu "khung_hinh".' % thieu)
        xau = [k for k, v in (d.get("nhan_vat") or {}).items()
               if any(x in (v.get("dau_hieu", "") + v.get("mo_ta", "")).lower() for x in _CAM)]
        if xau:
            loi.append("Cac vai %s dung dau hieu SAO CHEP tu page mau. Nghi dau hieu KHAC HAN."
                       % xau)
        return loi

    d, con = gemini_json_gated(P, cham, vong=4, gen_config={"temperature": 0.4},
                                 model=model, ten="So dang ky Tap %s" % tap)
    if con:
        raise RuntimeError("So dang ky Tap %s khong dat: %s" % (tap, "; ".join(con)))

    if goc:
        bc = dict(BC)
        for k, v in (d.get("boi_canh_them") or {}).items():
            bc.setdefault(k, v)                       # KHONG ghi de noi da khoa
        out = {"nhan_vat": NV, "boi_canh": bc, "dao_cu": d["dao_cu"], "canh": d["canh"]}
    else:
        out = {"nhan_vat": d["nhan_vat"], "boi_canh": d["boi_canh"],
               "dao_cu": d["dao_cu"], "canh": d["canh"]}
    cn = out["canh"]
    cm = sum(1 for c in cn if c["goc_may"] == "can-mat")
    _log("So dang ky Tap %s: %d canh, can mat %d (%.0f%%), %d boi canh"
         % (tap, len(cn), cm, cm * 100.0 / len(cn), len({c["noi_chon"] for c in cn})))
    return out


# ---------------------------------------------------------------- B2: ve anh + ba loai nhip
def _prompt_anh(so, scenes, sdk):
    c, sc = sdk["canh"][so], scenes[so]
    b = sdk["boi_canh"].get(c["noi_chon"], {})
    NV, DC = sdk["nhan_vat"], sdk["dao_cu"]
    ai = sc.get("nhan_vat_trong_canh") or []
    nguoi = "; ".join("%s = %s" % (v, NV[v]["mo_ta"].rstrip(".")) for v in ai if v in NV)
    do = "; ".join("%s = %s" % (k, DC[k]["mo_ta"].rstrip(".")) for k in c.get("dao_cu", [])
                   if k in DC)
    p = [R._style_prefix(STYLE), GOC_MAY.get(c["goc_may"], GOC_MAY["trung"]), c["khung_hinh"],
         "LOCATION: " + b.get("mo_ta", ""), "LIGHTING: " + b.get("anh_sang", "")]
    if nguoi:
        p.append("CHARACTERS - keep each person's face, hair and outfit IDENTICAL every time: "
                 + nguoi + ". Only these people are in the shot; do NOT add anyone else.")
    if do:
        p.append("PROPS - separate objects present in the scene, drawn exactly as described "
                 "and identical in every scene: " + do + ". A prop is an OBJECT, never "
                 "clothing worn by anyone.")
    p += [R._MOUTH_SHUT, R.STYLES.get(STYLE, R.STYLES[R.DEFAULT_STYLE]), R.BLEED,
          R._anti_photo(STYLE)]
    return lam_mem(" ".join(x for x in p if x))


def _viet_trung_tinh(khung, model=None):
    """Bo loc an toan chan -> nho Gemini viet lai hoan toan trung tinh.
    Thay tu don le KHONG du (do that: doi 3 lan van bi chan, phai viet lai ca cau)."""
    P = ("Câu mô tả khung hình sau bị bộ lọc an toàn của OpenAI từ chối. Viết lại bằng "
         "TIẾNG ANH, giữ hành động và bố cục, dùng từ hoàn toàn trung tính; không dùng "
         "point/accuse/cold/angry/blood. Chỉ trả về ĐÚNG một câu tiếng Anh.\n\n" + khung)
    return R.gemini_generate([{"text": P}], timeout=120, model=model).strip().strip('"')


def anh_mau(work, sdk, work_tap_dau=None):
    """Anh mau = CHAN DUNG nen tron, DUNG CHUNG ca series.

    Vi sao chan dung nen tron chu khong phai canh dau: cac canh sau se 'copy tu anh mau' —
    lay canh dau lam mau thi moi canh deu bi keo ve dung boi canh do.
    """
    ref = os.path.join(work, "ref.png")
    if os.path.isfile(ref) and os.path.getsize(ref) > 1000:
        return ref
    if work_tap_dau:
        goc = os.path.join(work_tap_dau, "ref.png")
        if os.path.isfile(goc):
            import shutil
            shutil.copy(goc, ref)
            _log("Dung lai anh mau CHUNG cua series")
            return ref
    NV = sdk["nhan_vat"]
    vai = next(iter(NV))
    p = lam_mem(R._style_prefix(STYLE) + " " + GOC_MAY["can-mat"] + " A character portrait of "
                + NV[vai]["mo_ta"] + ". Looking straight at the camera with a calm expression. "
                "Plain neutral studio background, no location, no props. "
                + R.STYLES.get(STYLE, R.STYLES[R.DEFAULT_STYLE]) + R.BLEED
                + R._anti_photo(STYLE))
    open(ref, "wb").write(openai_image.generate(p, ratio="9:16", quality="low"))
    R._crop_png_to_ratio(ref)
    _log("Da ve anh mau chan dung (%s)" % vai)
    return ref


def _ve(so, work, scenes, sdk, cli, ref, model=None):
    png = os.path.join(work, "src_%02d.png" % so)
    urlf = os.path.join(work, "img_%02d.txt" % so)
    if os.path.isfile(urlf):
        return open(urlf, encoding="utf-8").read().strip()
    p = _prompt_anh(so, scenes, sdk)
    refb = open(ref, "rb").read()
    for a in range(3):
        try:
            data = openai_image.generate_from_ref(
                p + " Copy from the reference image ONLY two things: (a) the art style and "
                    "rendering technique, (b) the characters' facial identity. The LOCATION, "
                    "framing and lighting MUST follow the description above, NOT the reference.",
                refb, ratio="9:16", quality="low")
        except Exception as e:
            if "safety" not in str(e).lower() or a == 2:
                raise
            sdk["canh"][so]["khung_hinh"] = _viet_trung_tinh(sdk["canh"][so]["khung_hinh"], model)
            p = _prompt_anh(so, scenes, sdk)
            _log("Nhip %d bi bo loc chan -> viet lai trung tinh" % (so + 1))
            continue
        open(png, "wb").write(data)
        R._crop_png_to_ratio(png)
        if not R._is_multi_panel(png):
            break
        _log("Nhip %d ra tranh nhieu o -> ve lai" % (so + 1))
    up = cli.upload_image(png)
    url = up.get("url") or up.get("url_preview")
    open(urlf, "w", encoding="utf-8").write(url)
    return url


def dung_nhip(so, work, scenes, sdk, cli, ref, model=None):
    """Mot nhip -> mot clip. BA LOAI: thoai / cam / dan."""
    clip = os.path.join(work, "clip_%02d.mp4" % so)
    if os.path.isfile(clip) and os.path.getsize(clip) > 1000:
        return so, clip
    sc, c = scenes[so], sdk["canh"][so]
    loai = sc.get("loai") or "thoai"
    _log("Nhip %d/%d <%s> [%s @ %s]" % (so + 1, len(scenes), loai, c["goc_may"], c["noi_chon"]))
    url = _ve(so, work, scenes, sdk, cli, ref, model)
    if loai == "thoai":
        R._gen_dialogue_clip(cli, url, sc["dialogue"], c["khung_hinh"], clip,
                             clip_model="veo_3_1", speaker=sc.get("nguoi_noi"),
                             speaker_desc=sdk["nhan_vat"].get(sc.get("nguoi_noi"), {})
                             .get("mo_ta", ""))
    else:
        # 'cam' va 'dan' deu la clip KHONG LOI. Phai di duong _gen_one_clip chu KHONG phai
        # _gen_dialogue_clip — ham kia luon bat nhan vat mo mieng noi.
        R._gen_one_clip(cli, {"mot": R._MOTION}, url, clip, "veo_3_1")
    return so, clip


def dung_moi_nhip(work, scenes, sdk, work_tap_dau=None, lanes=None, model=None):
    """Dung het cac nhip, song song. Nhip loi KHONG giet ca me.

    ⚠️ LOI DA MAC: dung ThreadPoolExecutor.map tho -> mot nhip nem loi la ca me dung, cac
    nhip phia sau KHONG HE duoc thu. Nay moi nhip tu bat loi, cuoi cung liet ke nhip thieu;
    chay lai se lam tiep vi clip cu duoc giu.
    """
    os.makedirs(work, exist_ok=True)
    cli = GommoClient()
    ref = anh_mau(work, sdk, work_tap_dau)
    n = len(scenes)
    got, lock = {}, threading.Lock()

    def one(i):
        try:
            return dung_nhip(i, work, scenes, sdk, cli, ref, model)
        except Exception as e:
            with lock:
                _log("Nhip %d/%d LOI: %s" % (i + 1, n, str(e)[:150]))
            return i, None

    with ThreadPoolExecutor(max_workers=max(1, lanes or LANES)) as ex:
        for i, p in ex.map(one, range(n)):
            if p:
                got[i] = p
    thieu = [i + 1 for i in range(n) if i not in got]
    if thieu:
        raise RuntimeError("Thieu nhip %s — chay lai se lam tiep, nhip cu giu nguyen" % thieu)
    return got


# ---------------------------------------------------------------- ghep
def _chu_png(txt, w, h, out, font=None):
    """Chu hien giua khung (vd ket qua xet nghiem), nen trong suot."""
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    ft, b = _vua_khung(dr, txt, max(14, int(w * 0.105)), w, font)
    x, y = (w - (b[2] - b[0])) // 2 - b[0], (h - (b[3] - b[1])) // 2 - b[1]
    v = max(2, int(w * 0.005))
    for dx in range(-v, v + 1):
        for dy in range(-v, v + 1):
            if dx * dx + dy * dy <= v * v:
                dr.text((x + dx, y + dy), txt, font=ft, fill=(0, 0, 0, 255))
    dr.text((x, y), txt, font=ft, fill=(255, 255, 255, 255))
    im.save(out)


def ghep(got, scenes, out_path, work, doc_loi_dan=None):
    """Cat khoang chet + long tieng doc cho nhip 'dan' + chu hien + xfade.

    `doc_loi_dan(text, mp3)` = ham doc loi dan (vd ElevenLabs giong nam tram). None -> nhip
    'dan' bi coi nhu 'cam'.
    """
    parts = []
    for i in sorted(got):
        f, sc = got[i], scenes[i]
        p = os.path.join(work, "gon_%02d.mp4" % i)
        loai = sc.get("loai") or "thoai"
        if loai == "dan" and doc_loi_dan:
            mp3 = os.path.join(work, "dan_%02d.mp3" % i)
            if not os.path.isfile(mp3):
                doc_loi_dan(sc["dialogue"], mp3)
            d = min(8.0, (R._dur(mp3) or 4.0) + 0.5)
            R._ff(["ffmpeg", "-v", "error", "-y", "-i", f, "-i", mp3,
                   "-t", "%.2f" % d, "-map", "0:v", "-map", "1:a",
                   "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-r", "30",
                   "-c:a", "aac", "-ar", "48000", "-ac", "2", "-shortest", p])
            _log("Nhip %02d LOI DAN: giong doc %.1fs" % (i + 1, d))
        elif loai in ("cam", "dan"):
            d = CAM_LEN
            # ⚠️ '-t' phai dat SAU het cac '-i' (tuc la tuy chon DAU RA). Dat truoc thi no
            # thanh tuy chon cho DAU VAO ke tiep -> VIDEO KHONG HE bi cat (hinh 8.00s ma
            # tieng 3.20s). Da mac that.
            R._ff(["ffmpeg", "-v", "error", "-y", "-i", f,
                   "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo",
                   "-map", "0:v", "-map", "1:a", "-t", "%.2f" % d,
                   "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-r", "30",
                   "-c:a", "aac", p])
            _log("Nhip %02d CAM: %.1fs" % (i + 1, d))
        else:
            nw = len((sc.get("dialogue") or "").split()) or None
            e = _speech_end(f, nw)
            d = max(MINLEN, min(8.0, (e or 7.3) + TAIL))
            R._ff(["ffmpeg", "-v", "error", "-y", "-i", f, "-t", "%.2f" % d,
                   "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-r", "30",
                   "-c:a", "aac", "-ar", "48000", "-ac", "2", p])
            _log("Nhip %02d: het loi %.1fs -> cat con %.1fs" % (i + 1, e or -1, d))
        if sc.get("chu_hien"):
            o = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v",
                                "-show_entries", "stream=width,height", "-of", "csv=p=0", p],
                               capture_output=True, text=True).stdout.strip()
            w, h = [int(x) for x in o.split(",")[:2]]
            cp = os.path.join(work, "chu_%02d.png" % i)
            p2 = os.path.join(work, "chu_%02d.mp4" % i)
            _chu_png(sc["chu_hien"], w, h, cp)
            R._ff(["ffmpeg", "-v", "error", "-y", "-i", p, "-loop", "1", "-i", cp,
                   "-filter_complex",
                   "[1:v]format=rgba,fade=t=in:st=0.2:d=0.4:alpha=1[t];[0:v][t]overlay=0:0[v]",
                   "-map", "[v]", "-map", "0:a", "-c:v", "libx264", "-crf", "18",
                   "-preset", "veryfast", "-c:a", "copy", "-shortest", p2])
            os.replace(p2, p)
            _log("Nhip %02d chu hien: %s" % (i + 1, sc["chu_hien"]))
        # ⚠️ DO LAI do dai THAT. Bug da mac: tin so du doan trong khi '-shortest' cat ngan hon
        # -> moc xfade TROI DAN -> cac manh chong len nhau -> mat gan het loi thoai.
        that = R._dur(p) or d
        if abs(that - d) > 0.1:
            _log("Nhip %02d: du doan %.2fs nhung THAT %.2fs -> dung so THAT" % (i + 1, d, that))
        parts.append((p, that))
    _log("Tong sau khi cat: %.1f giay" % sum(d for _, d in parts))

    inputs, filt = [], ""
    for p, _ in parts:
        inputs += ["-i", p]
    vlab, alab, off = "[0:v]", "[0:a]", 0.0
    for i in range(1, len(parts)):
        off += parts[i - 1][1] - XFADE
        nv, na = "[v%d]" % i, "[a%d]" % i
        filt += ("%s[%d:v]xfade=transition=fade:duration=%.2f:offset=%.2f%s;"
                 % (vlab, i, XFADE, off, nv))
        filt += "%s[%d:a]acrossfade=d=%.2f%s;" % (alab, i, XFADE, na)
        vlab, alab = nv, na
    filt += "%sloudnorm=I=-16:TP=-1.5:LRA=11[outa]" % alab
    R._ff(["ffmpeg", "-v", "error", "-y"] + inputs
          + ["-filter_complex", filt, "-map", vlab, "-map", "[outa]",
             "-c:v", "libx264", "-crf", "20", "-preset", "veryfast",
             "-c:a", "aac", "-b:a", "192k", out_path])
    return out_path


# ---------------------------------------------------------------- B3: bia + hook
FONT = os.environ.get("PHIM_FONT", "C:/Windows/Fonts/palab.ttf")
LE = 0.92                                    # chu chiem toi da 92% be ngang


def kiem_font(path=None):
    """Cong chan: font thieu glyph tieng Viet -> DUNG NGAY.

    ⚠️ Do bang CHIEU RONG chuoi la THUOC HONG — glyph thieu VAN co chieu rong nen phep do
    bao 'OK' het. Da mac that: Georgia Bold thieu 46/49 ky tu ma van qua. Phai doc bang cmap.
    """
    from fontTools.ttLib import TTFont
    path = path or FONT
    chu = "ĐƯỢỜỬỮỰỹỵặẳẵấầẩẫậắằẻẽếềểễệỉĩịỏốồổỗộớờởỡợủứừửữựỳỷỹ"
    cm = set()
    for tb in TTFont(path, fontNumber=0)["cmap"].tables:
        cm |= set(tb.cmap)
    thieu = [c for c in chu if ord(c) not in cm]
    if thieu:
        raise RuntimeError("Font %s thieu %d/%d ky tu tieng Viet: %s"
                           % (path, len(thieu), len(chu), "".join(thieu[:10])))
    return True


def _vua_khung(dr, txt, co0, w, font=None):
    """TU CO cho vua khung.

    ⚠️ Gan cung co chu la sai: co lay tu dong ngan ("ĐƯA VỢ TÔI VỀ" 13 ky tu) dung cho dong
    dai hon ("BỊ ĐUỔI KHỎI NHÀ" 16 ky tu) -> chu TRAN ra ngoai, mat chu dau va chu cuoi.
    """
    from PIL import ImageFont
    co = int(co0)
    while co > 12:
        ft = ImageFont.truetype(font or FONT, co)
        b = dr.textbbox((0, 0), txt, font=ft)
        if (b[2] - b[0]) <= w * LE:
            return ft, b
        co -= 2
    ft = ImageFont.truetype(font or FONT, 12)
    return ft, dr.textbbox((0, 0), txt, font=ft)


def co_video(f):
    """DO kich thuoc video, KHONG doan. Da mac that: doan 1080x1920 trong khi video la
    720x1280 -> lop chu ve theo 1080 dan vao goc 0:0 -> CUT HET ben phai."""
    o = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v", "-show_entries",
                        "stream=width,height", "-of", "csv=p=0", f],
                       capture_output=True, text=True).stdout.strip()
    w, h = [int(x) for x in o.split(",")[:2]]
    return w, h


def lop_chu(dong, w, h, out, top_ti=0.07, font=None):
    """Lop chu dat THANG len hinh, KHONG dai nen.

    Khuon lay tu anh THAT cua page mau: ho khong dung dai nen blur. `hook_overlay.py` cua
    tool ve dai blur chiem 29% phia tren -> KHONG dung cho phim series.
    `dong` = [(chu, co_theo_be_ngang_1080, (r,g,b))].
    """
    from PIL import Image, ImageDraw
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    k = w / 1080.0
    y = int(h * top_ti)
    vien = max(2, int(5 * k))
    for txt, co, mau in dong:
        ft, b = _vua_khung(dr, txt, max(12, int(co * k)), w, font)
        x = (w - (b[2] - b[0])) // 2 - b[0]
        for dx in range(-vien, vien + 1):
            for dy in range(-vien, vien + 1):
                if dx * dx + dy * dy <= vien * vien:
                    dr.text((x + dx, y + dy), txt, font=ft, fill=(0, 0, 0, 255))
        dr.text((x, y), txt, font=ft, fill=tuple(mau) + (255,))
        y += (b[3] - b[1]) + int(34 * k)
    im.save(out)
    return out


def gan_hook(vid, dong, out, work, page="", hien=5.0, mo=0.8, font=None):
    """Gan chu hook len video + che dau chim "Veo" goc duoi phai bang watermark ten page."""
    from PIL import Image, ImageDraw
    kiem_font(font)
    W, H = co_video(vid)                              # DO, khong doan
    png = os.path.join(work, "hook.png")
    lop_chu(dong, W, H, png, font=font)

    wm_w, wm_h = int(W * 0.20), int(H * 0.045)
    wm_x, wm_y = W - wm_w - int(W * 0.012), H - wm_h - int(H * 0.018)
    cmd = ["ffmpeg", "-v", "error", "-y", "-i", vid, "-loop", "1", "-i", png]
    filt = ("[0:v]crop=%d:%d:%d:%d,boxblur=14:2[wm];[0:v][wm]overlay=%d:%d[base];"
            % (wm_w, wm_h, wm_x, wm_y, wm_x, wm_y))
    base = "[base]"
    if page:
        wmf = os.path.join(work, "wm.png")
        im = Image.new("RGBA", (wm_w, wm_h), (0, 0, 0, 0))
        d2 = ImageDraw.Draw(im)
        ft, b = _vua_khung(d2, page, max(12, int(wm_h * 0.60)), wm_w, font)
        xw = (wm_w - (b[2] - b[0])) // 2 - b[0]
        yw = (wm_h - (b[3] - b[1])) // 2 - b[1]
        v = max(1, int(wm_h * 0.06))
        for dx in range(-v, v + 1):
            for dy in range(-v, v + 1):
                if dx * dx + dy * dy <= v * v:
                    d2.text((xw + dx, yw + dy), page, font=ft, fill=(0, 0, 0, 200))
        d2.text((xw, yw), page, font=ft, fill=(255, 255, 255, 225))
        im.save(wmf)
        cmd += ["-loop", "1", "-i", wmf]
        filt += "[base][2:v]overlay=%d:%d[bw];" % (wm_x, wm_y)
        base = "[bw]"
    filt += ("[1:v]format=rgba,fade=t=out:st=%.2f:d=%.2f:alpha=1[hk];"
             "%s[hk]overlay=0:0:enable='lte(t,%.2f)'[v]" % (hien, mo, base, hien + mo + 0.1))
    R._ff(cmd + ["-filter_complex", filt, "-map", "[v]", "-map", "0:a",
                 "-c:v", "libx264", "-crf", "20", "-preset", "veryfast",
                 "-c:a", "copy", "-shortest", out])
    return out


def bia(nen, dong, out, tap=None, font=None, w=1080, h=1920):
    """Anh bia. CA SERIES DUNG CHUNG MOT ANH NEN, chi doi so tap.

    Do that tren page mau: "Xay nha tren dat nha chong" tap 1/2/5 dung y het mot khung hinh
    -> nguoi luot nhan ra ngay day la tap tiep cua bo dang theo doi. Chu dat THANG len anh,
    KHONG dai nen. Anh nen la canh CANG THANG co 2-4 nguoi, trung/toan canh - khong can mat.
    """
    import tempfile
    from PIL import Image
    kiem_font(font)
    im = Image.open(nen).convert("RGBA").resize((w, h), Image.LANCZOS)
    d = list(dong) + ([("Tập %s" % tap, 70, (255, 205, 70))] if tap else [])
    lp = os.path.join(tempfile.gettempdir(), "phim_bia_%d.png" % os.getpid())
    lop_chu(d, w, h, lp, font=font)
    Image.alpha_composite(im, Image.open(lp).convert("RGBA")).convert("RGB").save(out)
    return out


# ---------------------------------------------------------------- loi dan + nhac nen
GIONG_DAN = os.environ.get("PHIM_GIONG_DAN", "PFBSNl3TjKkPz6LaOfWE")   # Thuc Dovin, 113 Hz
# ⚠️ eleven_multilingual_v2 KHONG ho tro tieng Viet (do that: HTTP 400). Phai eleven_v3.
MODEL_TTS = os.environ.get("PHIM_TTS_MODEL", "eleven_v3")
NHAC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "assets", "music", "nhac_nen_sach.wav")


def doc_loi_dan(text, out_mp3, giong=None, speed=0.88):
    """Giong nam tram ke chuyen. speed 0.88 = doc cham, hop giong dan."""
    import eleven_tts
    eleven_tts.synth(text, giong or GIONG_DAN, out_mp3, model=MODEL_TTS,
                     stability=0.45, similarity=0.8, style=0.35, speed=speed)
    return out_mp3


def long_nhac(vid, out, bed=None):
    """Long nhac nen. Muc tinh BANG PHEP DO chu khong dat tay.

    ⚠️ normalize=0 BAT BUOC: amix mac dinh CHIA BIEN DO theo so input -> nhac bi ha them
    ~6 dB -> doan im lang van nghe trong. Da mac that.
    """
    bed = bed or NHAC
    if not (os.path.isfile(bed) and os.path.getsize(bed) > 2000):
        _log("CANH BAO: khong co file nhac nen %s -> video se trong tieng o doan im lang" % bed)
        return vid
    g = R._clip_gain_db(bed, target=-26.0, lo=-24.0, hi=24.0)
    R._ff(["ffmpeg", "-v", "error", "-y", "-i", vid, "-stream_loop", "-1", "-i", bed,
           "-filter_complex",
           "[1:a]volume=%.1fdB[bed];[0:a][bed]amix=inputs=2:duration=first:"
           "normalize=0:dropout_transition=0,loudnorm=I=-16:TP=-1.5:LRA=11[a]" % g,
           "-map", "0:v", "-map", "[a]", "-c:v", "copy",
           "-c:a", "aac", "-b:a", "192k", "-shortest", out])
    _log("Da long nhac nen (chinh %+.1f dB)" % g)
    return out


# ---------------------------------------------------------------- lam tron mot tap
def lam_tap(scenes, work, out, tap, sdk=None, sdk_goc=None, work_tap_dau=None,
            hook=None, page="", nen_bia=None, out_bia=None, lanes=None, model=None,
            co_loi_dan=True):
    """MOT LENH ra mot tap hoan chinh: so dang ky -> clip -> ghep -> nhac -> hook (-> bia).

    `sdk` co san thi dung lai (khong goi Gemini). `sdk_goc` = so dang ky TAP DAU de khoa
    series. `hook` = [(chu, co, mau)] cho chu hook tren video va anh bia.
    IDEMPOTENT: chay lai chi lam tiep phan thieu.
    """
    t0 = time.time()
    os.makedirs(work, exist_ok=True)
    # ⚠️ XONG ROI THI DUNG LAI. Khong co chot nay thi bam nham "Dung tap" tren tap DA XONG
    # se chay lai ca luot: `anh_mau` thay thieu ref.png -> VE ANH MOI = tien OpenAI that,
    # roi ghep de len ban da duyet. Da suyt mac 04/08.
    if os.path.isfile(out) and os.path.getsize(out) > 1000:
        _log("Tap %s da co video hoan chinh -> bo qua (xoa %s neu muon lam lai)"
             % (tap, os.path.basename(out)))
        return {"ok": True, "out": out, "bo_qua": True, "so_dang_ky": sdk,
                "giay": R._dur(out) or 0}
    if sdk is None:
        sdk = so_dang_ky(scenes, tap, goc=sdk_goc, model=model)
        json.dump(sdk, open(os.path.join(work, "so_dang_ky.json"), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
    if len(sdk["canh"]) != len(scenes):
        raise RuntimeError("So dang ky %d canh, kich ban %d canh"
                           % (len(sdk["canh"]), len(scenes)))

    got = dung_moi_nhip(work, scenes, sdk, work_tap_dau, lanes, model)
    tho = os.path.join(work, "tho.mp4")
    ghep(got, scenes, tho, work, doc_loi_dan if co_loi_dan else None)

    co_nhac = os.path.join(work, "nhac.mp4")
    cuoi = long_nhac(tho, co_nhac)

    if hook:
        gan_hook(cuoi, hook, out, work, page=page)
    else:
        import shutil
        shutil.copy(cuoi, out)

    if nen_bia and out_bia and hook:
        bia(nen_bia, hook, out_bia, tap=tap)

    _log("Tap %s XONG -> %s (%.1f giay, %.1f phut)"
         % (tap, out, R._dur(out) or 0, (time.time() - t0) / 60))
    return {"ok": True, "out": out, "bia": out_bia, "so_dang_ky": sdk,
            "giay": R._dur(out) or 0}
