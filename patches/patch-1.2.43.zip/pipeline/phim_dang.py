# -*- coding: utf-8 -*-
"""ĐĂNG tập phim — hai chế độ giống đăng hàng loạt: ĐĂNG LUÔN / LÊN LỊCH.

⚠️ ĐÂY LÀ CHỖ DUY NHẤT của Xưởng phim chạm kho CHUNG. Người dùng đã chốt cho dùng chung
(2026-08-05). Không thể làm kho chờ riêng: **mutex 1-Chrome nằm trong `fb_chrome_queue`** —
hai kho chờ = hai watchdog cùng lái một Chrome = hỏng cả hai đường.

CÁCH LY: dùng `slot_run_id` RIÊNG (`phim_<ts>`) để bảng rank của phim không đụng bảng rank
của đăng hàng loạt. Thiếu cách ly này thì hai luồng cùng nhận rank 0 → ra cùng một giây
(lỗi đã mắc thật 28/07, xem CLAUDE.md).

⚠️ `fb_chrome_queue` / `fb_slots` chỉ được GỌI, không sửa.
"""
import os
import time

GOC = os.environ.get("PHIM_GOC", "phim")


def gio_dang(che_do, page_id, khi=None, gap_phut=None, run_id=None):
    """Tính giờ đăng. `che_do`: 'ngay' | 'lich'.

    ngay -> đăng ngay khi dựng xong (vẫn giãn cách nếu nhiều tập cùng lúc)
    lich -> neo vào mốc `khi` (unix giây) người dùng chọn
    """
    import fb_slots
    rid = run_id or ("phim_%d" % int(time.time()))
    rank = fb_slots.rank_of(page_id, run_id=rid)
    gap = int(gap_phut or 15)
    if che_do == "lich" and khi:
        return int(fb_slots.slot_for(int(khi), rank, 0, gap, gap, run_id=rid)), rid
    # 'ngay': neo vào BÂY GIỜ. +90 giây để watchdog kịp bắt (nhịp 15 giây).
    return int(fb_slots.slot_for(int(time.time()) + 90, rank, 0, gap, gap, run_id=rid)), rid


def dang(video, page_id, page_name, caption, che_do="ngay", khi=None,
         gap_phut=None, run_id=None, bia=None):
    """Đẩy một tập phim vào kho chờ Chrome. Trả dict kết quả.

    KHÔNG đăng ngay tại đây — chỉ xếp hàng; watchdog của `fb_chrome_queue` lo phần đăng,
    đúng như đường đăng hàng loạt. Nhờ vậy mutex 1-Chrome vẫn giữ.
    """
    import fb_chrome_queue
    if not os.path.isfile(video):
        raise RuntimeError("Không thấy video: %s" % video)
    if not page_id:
        raise RuntimeError("Chưa chọn page để đăng")
    khi_ts, rid = gio_dang(che_do, page_id, khi, gap_phut, run_id)
    # ⚠️ Chữ ký THẬT là `caption=`, không phải `desc=` — đã truyền sai một lần, bắt được
    # nhờ đọc `fb_chrome_queue.add` [pipeline/fb_chrome_queue.py:116] chứ không đoán.
    it = fb_chrome_queue.add(page_id=page_id, page_name=page_name or "",
                             video=os.path.abspath(video), when_ts=khi_ts,
                             caption=caption or "", kind="reel",
                             gap_page_min=int(gap_phut or 15))
    return {"ok": True, "when_ts": khi_ts, "run_id": rid,
            "gio": time.strftime("%d/%m %H:%M", time.localtime(khi_ts)),
            "item": it if isinstance(it, dict) else None}


def xem_lich(page_id=None):
    """Các bài phim đang chờ trong kho chờ Chrome (chỉ đọc)."""
    import fb_chrome_queue
    try:
        it = fb_chrome_queue.all_items() or []      # `load()` là hàm nội bộ `_load()`
    except Exception:
        return []
    ra = []
    for x in it:
        if page_id and str(x.get("page_id")) != str(page_id):
            continue
        ra.append({"page_name": x.get("page_name"), "status": x.get("status"),
                   "when_ts": x.get("when_ts"), "video": x.get("video")})
    return ra
