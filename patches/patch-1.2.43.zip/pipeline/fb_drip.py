# -*- coding: utf-8 -*-
"""
DRIP — tu rai gio dang: tao N moc gio tuong lai trai deu qua cac KHUNG GIO/ngay,
+ jitter, TRANH trung moc da len lich. Dung cho "len lich nhieu bai".

Config: facebook/_drip.json {slots:["08:00",...], jitter_min, days}
"""
import json
import os
import random
import time
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.path.join(ROOT, "facebook")
CFG = os.path.join(FB_ROOT, "_drip.json")
SCHED = os.path.join(FB_ROOT, "_scheduled.json")

DEFAULT = {"slots": ["08:00", "12:30", "19:30"], "jitter_min": 25, "days": 14,
           # CÁCH ĐĂNG (chọn ở hộp ▶ Star). Cả 2 mode đều có: số bài + giãn cách phút.
           #   post_mode="now"      -> bài ĐẦU đăng ngay khi làm xong; bài sau cách gap_min phút.
           #   post_mode="schedule" -> bài đầu hẹn post_hhmm ngày (+post_day_offset); bài sau +gap_min.
           #   run_target           -> số bài cần làm rồi DỪNG (mỗi page). 0 = liên tục.
           #   gap_min              -> giãn cách giữa các bài (phút).
           #   threads              -> số LUỒNG chạy song song (1-10; = số job auto đồng thời).
           #   run_clip/run_style/run_img_model -> ép model/kiểu ảnh cho cả lượt ('' = theo gán từng page).
           "post_mode": "now", "post_hhmm": "08:00", "post_day_offset": 1,
           "run_target": 1, "gap_min": 60,
           #   gap_page_min -> gian cach GIUA CAC PAGE o vong 1 (dung fb_slots.slot_for, giong
           #   duong Chrome). Vong 2 tro di: MOI page tu tinh theo BAI TRUOC cua CHINH no
           #   (= gap_min), KHONG phu thuoc page khac (dam bao boi cong thuc slot_for).
           "gap_page_min": 15,
           #   slot_run_id -> 1 luot bam Star = 1 id (fb_slots.reset khi Star bat dau) de
           #   rank (thu tu page lam xong) khong lan sang luot truoc.
           "slot_run_id": "",
           #   img_run_id -> luot rank RIENG cua nhanh ANH (fb_slots giu moi luot 1 bang) de
           #   chay anh song song voi video ma khong tranh nhau bang rank.
           "img_run_id": "",
           "threads": 0, "run_clip": "", "run_style": "", "run_img_model": "",
           #   run_dialogue -> NHAN VAT NOI THAT (Veo tu sinh audio khop moi) cho CA LUOT.
           #   PHAI co o DEFAULT, khong thi save_config() BO QUA -> tich o hop Star luu duoc
           #   ma doc ra luon False (dung bay da lap lai 3 lan: source_sheet_url, run_img_model,
           #   nhanh lam anh). Xem SKILL.md remake-nhan-vat-noi-that.
           "run_dialogue": False,
           #   run_min_views -> CHI lam reel dat nguong luot xem (0 = lam het, nhu cu).
           #   Do that 05/08 tren 1053 reel da cao: nguong 50.000 giu lai 413 reel (39%).
           #   Tu khi goi 79AI can luot, moi clip tru 1.200 credit that -> lam bua reel
           #   1.000 view la dot tien. PHAI co o DEFAULT (xem chu thich run_dialogue tren).
           "run_min_views": 0,
           #   ── Nhanh LAM ANH cua hop Star. THIEU o DEFAULT thi save_config() BO QUA ->
           #   luu duoc ma doc ra luon rong (dung bay da lap lai: source_sheet_url 07-25,
           #   run_img_model 1.2.18). Hau qua: mo lai hop Star luon nhay ve "Lam video",
           #   so bai anh ve 1, chu de da go mat sach.
           #   make      -> 'video' | 'image' (che do dang chon o hop Star)
           #   img_n     -> so bai anh moi page · img_source -> chu de · img_style -> kieu anh
           #   img_ratio -> kho anh (facebook_post...). THIEU o day thi cron (autopilot anh)
           #   khong biet nguoi dung chon kho nao -> bai cron lam ra khac bai bam tay.
           "make": "video", "img_n": 1, "img_source": "", "img_style": "",
           "img_ratio": "facebook_post",
           #   run_order -> chon reel nguon: 'oldest' (cu nhat, mac dinh) | 'random' (ngau nhien).
           "run_order": "oldest",
           #   transport -> DANG BANG GI: 'token' (Graph API, mac dinh) | 'chrome' (mo Chrome
           #   dang nhu nguoi that). Chon o hop Star (2 tab). Xem docs/hook-chu-va-dang-bang-chrome.md
           "transport": "token",
           #   hook -> CHU HOOK tren dau video (Gemini viet, PIL ve): 'on' | 'off'.
           #   hook_fit -> 'cover' (video lap day be ngang, cat bot tren/duoi — giong anh mau)
           #             | 'contain' (thu nho vua khit, khong cat, co le hai ben).
           "hook": "on", "hook_fit": "cover",
           #   chrome -> LICH RIENG cho duong Chrome (KHONG dung chung voi token, theo yeu cau
           #   nguoi dung). Cung cau truc gio+bai+gian cach, THEM `gap_page_min` = gian cach giua
           #   cac PAGE. Gio dang tinh bang fb_slots.slot_for (rank page theo thu tu lam xong).
           #   run_id (trong chrome) -> server GHI that moi lan bam Star; phai khai bao o day
           #   khong thi save_config() bo qua khi UI gui lai ca cum "chrome".
           "chrome": {"post_mode": "schedule", "post_hhmm": "06:00", "post_day_offset": 0,
                      "run_target": 3, "gap_min": 300, "gap_page_min": 15, "run_id": ""}}


def load_config() -> dict:
    if os.path.isfile(CFG):
        try:
            return {**DEFAULT, **json.load(open(CFG, encoding="utf-8"))}
        except Exception:
            pass
    return dict(DEFAULT)


def save_config(cfg: dict) -> dict:
    cur = load_config()
    for k in DEFAULT:
        if k not in cfg:
            continue
        # Key long nhau (vd "chrome"): MERGE thay vi de len -> gui thieu 1 truong khong xoa
        # cac truong con lai (UI co the chi gui phan da sua).
        if isinstance(DEFAULT[k], dict) and isinstance(cfg[k], dict):
            cur[k] = {**DEFAULT[k], **(cur.get(k) or {}), **cfg[k]}
        else:
            cur[k] = cfg[k]
    # Chi ghi khoa CO TRONG DEFAULT -> khoa mo coi (delay_min/delay_days cua ban cu) tu bien
    # mat o lan luu ke tiep, khong con lam nguoi doc file tuong la cau hinh dang co hieu luc.
    cur = {k: cur[k] for k in DEFAULT if k in cur}
    os.makedirs(FB_ROOT, exist_ok=True)
    json.dump(cur, open(CFG, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return cur


def _used_ts() -> list:
    if os.path.isfile(SCHED):
        try:
            return [s.get("when_ts", 0) for s in json.load(open(SCHED, encoding="utf-8"))
                    if s.get("when_ts")]
        except Exception:
            return []
    return []


def plan(n: int, min_lead_min: int = 20) -> list:
    """Tra N moc unix (giay) tuong lai, trai qua cac khung gio/ngay, tranh trung."""
    cfg = load_config()
    used = _used_ts()
    now = time.time()
    out = []
    day = 0
    base = datetime.now()
    while len(out) < n and day < 60:
        d = base + timedelta(days=day)
        for s in cfg["slots"]:
            hh, mm = [int(x) for x in s.split(":")]
            t = d.replace(hour=hh, minute=mm, second=0, microsecond=0)
            jit = random.randint(-cfg["jitter_min"], cfg["jitter_min"])
            ts = int(t.timestamp()) + jit * 60
            if ts < now + min_lead_min * 60:
                continue
            if any(abs(ts - u) < 300 for u in used + out):   # tranh sat moc da co
                continue
            out.append(ts)
            if len(out) >= n:
                break
        day += 1
    return out[:n]


def _sched_all() -> list:
    if os.path.isfile(SCHED):
        try:
            return json.load(open(SCHED, encoding="utf-8"))
        except Exception:
            return []
    return []


def _day_slots(per_day: int, cfg: dict) -> list:
    """per_day moc 'HH:MM' trong ngay. Du slot config thi dung; thieu -> trai deu 08:00-21:00."""
    slots = cfg.get("slots") or DEFAULT["slots"]
    if per_day <= len(slots):
        return slots[:per_day]
    start, end = 8 * 60, 21 * 60
    step = (end - start) // max(1, per_day - 1)
    return ["%02d:%02d" % ((start + step * i) // 60, (start + step * i) % 60)
            for i in range(per_day)]


def plan_for_page(page_id: str, n: int, per_day: int = 2,
                  min_lead_min: int = 20, horizon_days: int = 30) -> list:
    """N moc gio tuong lai cho RIENG page nay: toi da per_day/ngay, trai deu, tranh trung.

    Chi dem bai da lich CUA page do de dem hang ngay (page khac khong an vao slot).
    Ton trong FB: >= now+min_lead, <= 30 ngay.
    """
    from collections import defaultdict
    cfg = load_config()
    now = time.time()
    day_count = defaultdict(int)
    used = []
    for s in _sched_all():
        ts = s.get("when_ts") or 0
        if not ts:
            continue
        used.append(ts)
        if s.get("page_id") == page_id:
            day_count[time.strftime("%Y-%m-%d", time.localtime(ts))] += 1
    slots = _day_slots(per_day, cfg)
    out = []
    base = datetime.now()
    day = 0
    while len(out) < n and day < horizon_days:
        d = base + timedelta(days=day)
        dkey = d.strftime("%Y-%m-%d")
        avail = per_day - day_count[dkey]
        for s in slots:
            if avail <= 0 or len(out) >= n:
                break
            hh, mm = [int(x) for x in s.split(":")]
            t = d.replace(hour=hh, minute=mm, second=0, microsecond=0)
            jit = random.randint(-cfg["jitter_min"], cfg["jitter_min"])
            ts = int(t.timestamp()) + jit * 60
            if ts < now + min_lead_min * 60:
                continue
            if any(abs(ts - u) < 300 for u in used + out):
                continue
            out.append(ts); used.append(ts); avail -= 1
            day_count[dkey] += 1
        day += 1
    return out[:n]


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "page":
        pid = sys.argv[2] if len(sys.argv) > 2 else "123"
        for ts in plan_for_page(pid, int(sys.argv[3]) if len(sys.argv) > 3 else 6):
            print(time.strftime("%H:%M %d/%m", time.localtime(ts)))
    else:
        n = int(sys.argv[1]) if len(sys.argv) > 1 else 5
        for ts in plan(n):
            print(time.strftime("%H:%M %d/%m", time.localtime(ts)))
