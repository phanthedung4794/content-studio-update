# -*- coding: utf-8 -*-
"""CÀO PAGE MẪU cho Xưởng phim — kho RIÊNG, tải ảnh bìa NGAY.

⚠️ MODULE RIÊNG. `fb_lister` chỉ được GỌI, không sửa (memory/khong-dung-duong-dang-hang-loat).

HAI SỐ ĐO ĐỊNH ĐOẠT THIẾT KẾ FILE NÀY (scout-01):

1. **Cào KHÔNG lấy được caption** — đo trên 1.053 reel đã cào: `caption` là `"None"` ở
   0/1053. Caption chỉ có sau khi TẢI VIDEO. Nên gom bộ theo caption là bất khả nếu chưa tải.

2. **URL ảnh bìa HẾT HẠN** — thumb của lần cào cũ trả HTTP 403 cả 3/3 (Facebook ký URL kèm
   hạn dùng). Nên **phải tải ảnh bìa về đĩa NGAY trong lượt cào**, không được lưu URL rồi
   hôm sau mới xử lý. Đó là lý do `cao()` gọi thẳng `tai_thumb()` chứ không tách hai bước.

KHO RIÊNG `phim/_mau/<slug>/` — KHÔNG đụng `facebook/<slug>/index.json` của đăng hàng loạt.
Cào bằng `fb_lister` thì nó tự ghi kho chung; ta CHÉP ra kho riêng rồi làm việc trên bản chép,
để Xưởng phim sửa gì cũng không ảnh hưởng kho đang chạy.
"""
import json
import os
import time

GOC = os.environ.get("PHIM_GOC", "phim")
MAU = os.path.join(GOC, "_mau")
# Ảnh bìa nhỏ, tải nhanh. Trần để một page lỗi không kéo dài vô tận.
TAI_TIMEOUT = int(os.environ.get("PHIM_THUMB_TIMEOUT", "20"))


def thu_muc(slug):
    return os.path.join(MAU, slug)


def _ghi(p, d):
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    tmp = "%s.tmp%d" % (p, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def _doc(p, md):
    try:
        with open(p, encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return md


def doc(slug):
    """Bản cào của Xưởng phim (kho riêng)."""
    return _doc(os.path.join(thu_muc(slug), "index.json"), {})


def tai_thumb(slug, reels, bao=None):
    """Tải ảnh bìa về đĩa. Trả (số tải được, số hỏng).

    ⚠️ Phải chạy NGAY sau khi cào. URL Facebook ký có hạn — để lâu là 403 hết.
    """
    import requests
    d = os.path.join(thu_muc(slug), "thumb")
    os.makedirs(d, exist_ok=True)
    ok = loi = 0
    for i, (rid, r) in enumerate(reels.items()):
        p = os.path.join(d, "%s.jpg" % rid)
        if os.path.isfile(p) and os.path.getsize(p) > 800:
            ok += 1
            continue
        u = (r or {}).get("thumb") or ""
        if not u:
            loi += 1
            continue
        try:
            x = requests.get(u, timeout=TAI_TIMEOUT)
            if x.status_code == 200 and len(x.content) > 800:
                open(p, "wb").write(x.content)
                ok += 1
            else:
                loi += 1
        except Exception:
            loi += 1
        if bao and i % 10 == 0:
            bao("Tải ảnh bìa %d/%d" % (i + 1, len(reels)))
    return ok, loi


def cao(page_url, bao=None, max_pages=500):
    """Cào page mẫu → kho RIÊNG + tải ảnh bìa ngay. Trả dict tóm tắt.

    Cần Chrome quản lý đã đăng nhập Facebook (giống đường cào của đăng hàng loạt).
    """
    import fb_lister
    slug = fb_lister.page_slug(page_url)
    if bao:
        bao("Đang cào %s…" % slug)
    # GỌI đường cào có sẵn (nó ghi vào kho CHUNG facebook/<slug>/index.json).
    fb_lister.list_reels(page_url, max_scroll=max_pages,
                         progress=(lambda m: bao(m)) if bao else None)
    chung = fb_lister.load_index(slug) or {}
    reels = chung.get("reels") or {}

    # CHÉP sang kho riêng — từ đây Xưởng phim chỉ làm việc trên bản chép.
    ta = {"page": chung.get("page") or slug, "page_url": page_url,
          "cao_luc": int(time.time()), "count": len(reels), "reels": reels}
    _ghi(os.path.join(thu_muc(slug), "index.json"), ta)

    if bao:
        bao("Cào được %d reel — đang tải ảnh bìa (URL có hạn, phải tải ngay)" % len(reels))
    ok, loi = tai_thumb(slug, reels, bao)
    ta["thumb_ok"], ta["thumb_loi"] = ok, loi
    _ghi(os.path.join(thu_muc(slug), "index.json"), ta)
    if bao:
        bao("Xong: %d reel, %d ảnh bìa tải được, %d hỏng" % (len(reels), ok, loi))
    return {"slug": slug, "so_reel": len(reels), "thumb_ok": ok, "thumb_loi": loi}


def danh_sach():
    """Các page mẫu đã cào."""
    if not os.path.isdir(MAU):
        return []
    ra = []
    for s in sorted(os.listdir(MAU)):
        d = doc(s)
        if not d:
            continue
        ra.append({"slug": s, "page": d.get("page") or s, "page_url": d.get("page_url") or "",
                   "so_reel": d.get("count") or len(d.get("reels") or {}),
                   "thumb_ok": d.get("thumb_ok") or 0,
                   "cao_luc": d.get("cao_luc") or 0})
    return ra


def thumb_path(slug, rid):
    p = os.path.join(thu_muc(slug), "thumb", "%s.jpg" % rid)
    return p if os.path.isfile(p) else None
