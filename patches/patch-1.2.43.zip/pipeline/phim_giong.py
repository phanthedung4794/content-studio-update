# -*- coding: utf-8 -*-
"""BA CHẾ ĐỘ GIỌNG cho Xưởng phim — và TỰ chọn giọng theo giới tính người nói.

Người dùng chốt 2026-08-04/05:
  A `goc`    — giữ nguyên tiếng của reel gốc. Rẻ nhất (0đ), khớp nhất với "làm Y CHANG".
  B `eleven` — clip CÂM + ElevenLabs đọc đè. **TỰ phân tích rồi TỰ chọn giọng**, không bắt
               người dùng ngồi gán từng vai.
  C `veo`    — Veo tự sinh tiếng nói (chế độ "nhân vật nói thật" đã có).

⚠️ MODULE RIÊNG. Không sửa `fb_*.py` — chỉ GỌI (xem memory/khong-dung-duong-dang-hang-loat.md).

⚠️ NGUYÊN TẮC ĐO GIỚI TÍNH — luật cứng của dự án: *"Tên giọng nói dối, chỉ tin cao độ đo
bằng librosa.pyin"*. Nên nhận nam/nữ trong reel gốc cũng phải ĐO CAO ĐỘ, tuyệt đối không
hỏi LLM. LLM chỉ dùng để biết câu nào của ai.

⚠️ NGƯỠNG nam/nữ: dùng chung thang của `voice_lab.pitch_label` (nam <165 Hz, nữ ≥165 Hz).
Đây là thang đã dùng cho GIỌNG ĐỌC. Với người nói trong reel (có tiếng nền, ghi âm tạp) thang
này CHƯA ĐƯỢC NGHIỆM THU — `do_gioi_tinh` trả kèm `tin_cay` để nơi gọi biết mà ngờ.
"""
import json
import os
import subprocess

import fb_remake as R

# Ngưỡng lấy từ voice_lab.pitch_label (nam trung <165, nữ trầm 165-200).
NGUONG_NU = float(os.environ.get("PHIM_NGUONG_NU", "165"))
# Đoạn ngắn quá thì pyin ra rác — bỏ.
MIN_DOAN = float(os.environ.get("PHIM_MIN_DOAN_GIONG", "0.8"))

CHE_DO = ("goc", "eleven", "veo")


def _wav(video, ss, t, ra):
    """Cắt một đoạn audio ra wav mono 16k để đo cao độ."""
    R._ff(["ffmpeg", "-v", "error", "-y", "-ss", "%.2f" % ss, "-t", "%.2f" % t,
           "-i", video, "-vn", "-ac", "1", "-ar", "16000", ra])
    return ra


def cao_do(path):
    """Cao độ trung vị (Hz). Dùng CHÍNH hàm của dự án để nhất quán với kho giọng."""
    import voice_lab
    return float(voice_lab.measure_pitch(path))


def do_gioi_tinh(video, scenes, work):
    """Đo cao độ từng VAI trong reel gốc → {vai: {hz, gioi, so_doan, tin_cay}}.

    `scenes` cần có `start`/`end`/`nguoi_noi` (bản phân tích của Gemini đã cho sẵn).
    Gom mọi đoạn của cùng một vai lại rồi đo — đo từng câu lẻ thì đoạn ngắn cho số rác.

    `tin_cay`: 'cao' khi có ≥3 giây tiếng của vai đó, 'thap' khi ít hơn. Nơi gọi nên
    cho người dùng sửa tay khi thấp, đừng im lặng gán bừa.
    """
    import collections
    doan = collections.defaultdict(list)
    for s in scenes or []:
        vai = str(s.get("nguoi_noi") or "").strip()
        try:
            a, b = float(s.get("start") or 0), float(s.get("end") or 0)
        except (TypeError, ValueError):
            continue
        if vai and b - a >= MIN_DOAN:
            doan[vai].append((a, b))
    if not doan:
        return {}

    os.makedirs(work, exist_ok=True)
    ra = {}
    for vai, ds in doan.items():
        # Nối mọi đoạn của vai này thành MỘT file rồi đo một lần.
        parts = []
        for i, (a, b) in enumerate(ds[:12]):          # trần 12 đoạn là quá đủ
            p = os.path.join(work, "gt_%s_%02d.wav" % (_an_toan(vai), i))
            try:
                _wav(video, a, min(6.0, b - a), p)
                parts.append(p)
            except Exception:
                continue
        if not parts:
            continue
        gop = os.path.join(work, "gt_%s.wav" % _an_toan(vai))
        try:
            if len(parts) == 1:
                gop = parts[0]
            else:
                lst = os.path.join(work, "gt_%s.txt" % _an_toan(vai))
                with open(lst, "w", encoding="utf-8") as f:
                    for p in parts:
                        f.write("file '%s'\n" % os.path.abspath(p).replace("\\", "/"))
                R._ff(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0",
                       "-i", lst, "-c", "copy", gop])
            hz = cao_do(gop)
        except Exception:
            hz = 0.0
        tong = sum(min(6.0, b - a) for a, b in ds[:12])
        ra[vai] = {"hz": round(hz, 1),
                   "gioi": "nu" if hz >= NGUONG_NU else ("nam" if hz > 0 else "?"),
                   "so_doan": len(ds), "giay": round(tong, 1),
                   "tin_cay": "cao" if (hz > 0 and tong >= 3.0) else "thap"}
    return ra


def _an_toan(s):
    return "".join(c if c.isalnum() else "_" for c in str(s))[:24] or "vai"


# ---------------------------------------------------------------- chọn giọng TỰ ĐỘNG
def kho_giong():
    """Giọng đã ĐO cao độ, tách sẵn nam/nữ. Chỉ đọc, không gọi API tốn tiền."""
    import voice_catalog
    try:
        p = voice_catalog.load_pitches()
    except Exception:
        return {"nam": [], "nu": []}
    nam, nu = [], []
    for vid, v in (p or {}).items():
        try:
            hz = float(v.get("pitch_hz") if isinstance(v, dict) else v)
        except (TypeError, ValueError):
            continue
        if hz <= 0:
            continue
        (nu if hz >= NGUONG_NU else nam).append({"voice_id": vid, "hz": hz})
    nam.sort(key=lambda x: x["hz"])          # trầm trước — hợp kể chuyện
    nu.sort(key=lambda x: x["hz"])
    return {"nam": nam, "nu": nu}


def chon_giong(gioi_tinh, kho=None):
    """TỰ gán giọng cho từng vai theo giới tính đo được. Trả {vai: {voice_id, hz, gioi}}.

    Mỗi vai một giọng KHÁC nhau (hai nhân vật cùng giọng thì khán giả không phân biệt nổi
    ai đang nói). Hết giọng riêng thì mới dùng lại, và báo ra ở `thieu`.
    """
    kho = kho or kho_giong()
    ra, thieu, trung = {}, [], []
    dung = {"nam": 0, "nu": 0}
    # Vai nào nói nhiều nhất gán trước — nhân vật chính nên được giọng trầm/hay nhất.
    thu_tu = sorted(gioi_tinh.items(), key=lambda kv: -(kv[1].get("giay") or 0))
    for vai, g in thu_tu:
        gi = g.get("gioi")
        gi = gi if gi in ("nam", "nu") else "nam"       # không đo được -> coi như nam
        ds = kho.get(gi) or []
        if not ds:
            thieu.append((vai, gi))
            continue
        # ⚠️ HẾT giọng riêng thì PHẢI BÁO. Bản đầu cứ `%` để quay vòng im lặng — kho chỉ có
        # 1 giọng nữ nên LAN và BÀ THU nhận CÙNG một giọng, người xem không phân biệt nổi
        # ai đang nói mà không có dấu hiệu nào cảnh báo. Đúng kiểu "hỏng mà trông như chạy".
        lap = dung[gi] >= len(ds)
        v = ds[dung[gi] % len(ds)]
        dung[gi] += 1
        if lap:
            trung.append({"vai": vai, "gioi": gi, "voice_id": v["voice_id"]})
        ra[vai] = {"voice_id": v["voice_id"], "hz": v["hz"], "gioi": gi,
                   "hz_goc": g.get("hz"), "tin_cay": g.get("tin_cay"), "dung_lai": lap}

    can = {"nam": sum(1 for g in gioi_tinh.values()
                      if (g.get("gioi") if g.get("gioi") in ("nam", "nu") else "nam") == "nam"),
           "nu": sum(1 for g in gioi_tinh.values() if g.get("gioi") == "nu")}
    co = {"nam": len(kho.get("nam") or []), "nu": len(kho.get("nu") or [])}
    canh_bao = ""
    if thieu:
        canh_bao = "Không có giọng %s nào trong kho — %d vai chưa gán được." % (
            "/".join(sorted({g for _, g in thieu})), len(thieu))
    elif trung:
        canh_bao = ("Kho chỉ có %d giọng nữ / %d giọng nam, mà phim cần %d nữ / %d nam → "
                    "%d vai phải DÙNG LẠI giọng của vai khác (%s). Người xem sẽ không phân "
                    "biệt được ai đang nói. Nên đo thêm giọng trước khi dựng."
                    % (co["nu"], co["nam"], can["nu"], can["nam"], len(trung),
                       ", ".join(x["vai"] for x in trung)))
    return {"gan": ra, "thieu": thieu, "trung": trung,
            "du_giong": not thieu and not trung,
            "canh_bao": canh_bao, "can": can, "kho": co}


# ---------------------------------------------------------------- ba chế độ ghép
def ghep(che_do, clips, out, work, video_goc=None, scenes=None, gan=None):
    """Ghép clip + tiếng theo chế độ. Trả đường dẫn video.

    goc    -> R.assemble_src_audio()  (chính là chế độ audio B của đăng hàng loạt)
    eleven -> clip câm + ElevenLabs đọc từng câu, ghép đè
    veo    -> clip ĐÃ có tiếng sẵn, chỉ nối lại
    """
    if che_do not in CHE_DO:
        raise ValueError("che_do phải là một trong %s" % (CHE_DO,))
    if che_do == "goc":
        if not (video_goc and scenes):
            raise RuntimeError("Chế độ 'giữ giọng gốc' cần video nguồn + mốc cảnh")
        # GỌI hàm của đường cũ, không chép lại: nó đã xử lý xong việc khớp mốc.
        ok = R.assemble_src_audio(clips, out, work, video_path=video_goc, scenes=scenes)
        if not ok:
            raise RuntimeError("Không khớp được tiếng gốc (thiếu transcript/mốc cảnh)")
        return out
    if che_do == "veo":
        return R.assemble_dialogue(clips, out, work, video_path=video_goc, scenes=scenes)
    return _ghep_eleven(clips, out, work, scenes or [], gan or {})


def _ghep_eleven(clips, out, work, scenes, gan):
    """Clip CÂM + ElevenLabs đọc đè, mỗi vai một giọng đã gán."""
    import eleven_tts
    import phim
    parts = []
    for i, cp in enumerate(clips):
        sc = scenes[i] if i < len(scenes) else {}
        loi = (sc.get("dialogue") or "").strip()
        p = os.path.join(work, "eg_%02d.mp4" % i)
        if not loi:
            d = phim.CAM_LEN
            R._ff(["ffmpeg", "-v", "error", "-y", "-i", cp,
                   "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo",
                   "-map", "0:v", "-map", "1:a", "-t", "%.2f" % d,
                   "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-r", "30",
                   "-c:a", "aac", p])
        else:
            vai = str(sc.get("nguoi_noi") or "").strip()
            vid = (gan.get(vai) or {}).get("voice_id")
            if not vid:
                raise RuntimeError("Chưa gán giọng cho vai %r" % vai)
            mp3 = os.path.join(work, "eg_%02d.mp3" % i)
            if not os.path.isfile(mp3):
                eleven_tts.synth(loi, vid, mp3, model=phim.MODEL_TTS,
                                 stability=0.45, similarity=0.8, style=0.35, speed=0.94)
            d = min(8.0, (R._dur(mp3) or 4.0) + 0.4)
            R._ff(["ffmpeg", "-v", "error", "-y", "-i", cp, "-i", mp3,
                   "-t", "%.2f" % d, "-map", "0:v", "-map", "1:a",
                   "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-r", "30",
                   "-c:a", "aac", "-ar", "48000", "-ac", "2", "-shortest", p])
        # ⚠️ ĐO LẠI độ dài thật — '-shortest' cắt ngắn hơn số dự đoán, mốc xfade sẽ trôi.
        parts.append((p, R._dur(p) or 0.0))

    inputs, filt = [], ""
    for p, _ in parts:
        inputs += ["-i", p]
    vlab, alab, off = "[0:v]", "[0:a]", 0.0
    for i in range(1, len(parts)):
        off += parts[i - 1][1] - phim.XFADE
        nv, na = "[v%d]" % i, "[a%d]" % i
        filt += ("%s[%d:v]xfade=transition=fade:duration=%.2f:offset=%.2f%s;"
                 % (vlab, i, phim.XFADE, off, nv))
        filt += "%s[%d:a]acrossfade=d=%.2f%s;" % (alab, i, phim.XFADE, na)
        vlab, alab = nv, na
    filt += "%sloudnorm=I=-16:TP=-1.5:LRA=11[outa]" % alab
    R._ff(["ffmpeg", "-v", "error", "-y"] + inputs
          + ["-filter_complex", filt, "-map", vlab, "-map", "[outa]",
             "-c:v", "libx264", "-crf", "20", "-preset", "veryfast",
             "-c:a", "aac", "-b:a", "192k", out])
    return out


def can_veo(che_do):
    """Chế độ này có BẮT BUỘC dùng Veo không.

    Chỉ 'veo' mới cần. 'goc' và 'eleven' chỉ cần clip CÂM ⇒ dùng được Kling/Hailuo ⇒
    gói Unlimited-Flex (không giới hạn video/tháng) trở nên khả dụng.
    """
    return che_do == "veo"


def luu(work, d):
    p = os.path.join(work, "giong.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    return p
