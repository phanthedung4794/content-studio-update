# -*- coding: utf-8 -*-
"""XUONG PHIM — tang quan ly nam TREN `phim.py`.

`phim.py` biet lam MOT tap. File nay biet co nhung BO nao, moi bo may tap, tap nao dang
o buoc nao, tap nao thieu gi — de giao dien co cai ma ve.

⚠️ MODULE RIENG, KHONG DUNG VAO DUONG DANG HANG LOAT (xem
memory/khong-dung-duong-dang-hang-loat.md). Khong file nao cua duong do import file nay.

NGUYEN TAC: TRANG THAI SUY TU DIA, khong tu ghi mot cuon so song song roi tin no.
Lam vay thi xoa file bang tay / chay lai nua chung / dung giua chung deu tu khop; con cuon
so song song se lech that voi ghi ma khong ai biet. Chi `_bo.json` (danh sach bo + cau hinh
do nguoi dung dat) la ghi that, vi khong suy tu dia ra duoc.
"""
import json
import os
import re
import time

import phim

GOC = os.environ.get("PHIM_GOC", "phim")
SO_BO = os.path.join(GOC, "_bo.json")

# Cac buoc cua mot tap, dung thu tu. Giao dien ve day thanh day cham tien do.
BUOC = [("kich_ban", "Kịch bản"), ("so_dang_ky", "Sổ đăng ký"), ("anh", "Ảnh"),
        ("clip", "Clip"), ("ghep", "Ghép"), ("nhac", "Nhạc"),
        ("hook", "Gắn hook"), ("bia", "Ảnh bìa")]

# Gia do THAT (2026-08-04, doc tu API 79AI + openai_image._PRICE_USD):
#  · anh gpt-image-2 quality low = $0.011 x 26.000 = 286d (tien OpenAI, NGOAI 79AI)
#  · clip veo_3_1 fast/720p     = 1.200 credit; credit mua ~0,91d (muc ULTRA) -> ~1.091d
#  · 1 luot Gemini lap so dang ky ~40d
# ⚠️ CLIP CHI 0 DONG KHI CON QUOTA GOI. Het quota thi 79AI AM THAM chuyen sang tru credit —
# do that 04/08: dung 09:26:00, sau moc do 6 clip cuoi bi tru 1.200 credit/clip = 7.200d ma
# khong he co canh bao nao. Nen `uoc_tinh` PHAI hoi quota truoc chu khong duoc gia dinh 0d.
GIA_ANH = int(os.environ.get("PHIM_GIA_ANH", "286"))
GIA_CLIP_CREDIT = int(os.environ.get("PHIM_GIA_CLIP_CREDIT", "1200"))   # veo fast/720p
DONG_MOI_CREDIT = float(os.environ.get("PHIM_DONG_MOI_CREDIT", "0.91"))  # muc ULTRA
GIA_GEMINI = int(os.environ.get("PHIM_GIA_GEMINI", "40"))
# He so PHI PHAM — do that tren luot dung Tap 2: 26 ban THANH CONG bi tinh tien nhung chi
# dung 16. Nguyen nhan KHONG phai loi (loi khong bi tinh, da doi chieu voi bo dem quota cua
# 79AI: 30 thanh cong - 6 tra credit = 24 = dung videoDayUsage). Nguyen nhan la CHO HET GIO
# roi gui lai, trong khi ban cu VAN chay tiep va VAN xong -> "video mo coi", 79AI van tinh
# tien vi no lam xong that.
HE_SO_PHI = float(os.environ.get("PHIM_HE_SO_PHI", "1.62"))


# ---------------------------------------------------------------- kho bo
def _doc(p, mac_dinh):
    try:
        with open(p, encoding="utf-8-sig") as f:      # utf-8-sig: file co BOM van doc duoc
            return json.load(f)
    except Exception:
        return mac_dinh


def _ghi(p, d):
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    tmp = "%s.tmp%d" % (p, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def danh_sach_bo():
    return _doc(SO_BO, {})


def them_bo(ma, ten, kich_ban, hook=None, page="", style=None, nen_bia=None):
    """Dang ky mot bo phim. `kich_ban` = duong dan JSON {tap: {tieu_de, scenes:[...]}}."""
    d = danh_sach_bo()
    d[ma] = {"ten": ten, "kich_ban": kich_ban, "hook": hook or [], "page": page,
             "style": style or phim.STYLE, "nen_bia": nen_bia,
             "tao_luc": d.get(ma, {}).get("tao_luc") or int(time.time())}
    _ghi(SO_BO, d)
    return d[ma]


def xoa_bo(ma):
    """CHI go khoi danh sach. KHONG dong vao file phim da dung — xoa nham thi mat ca buoi
    dung lai, ma nguoi dung khong he yeu cau xoa video."""
    d = danh_sach_bo()
    if ma in d:
        del d[ma]
        _ghi(SO_BO, d)
        return True
    return False


# ---------------------------------------------------------------- duong dan
def work_cua(ma, tap):
    return os.path.join(GOC, "%s_tap%s.work" % (ma, tap))


def video_cua(ma, tap):
    return os.path.join(GOC, "%s_tap%s_FINAL.mp4" % (ma, tap))


def bia_cua(ma, tap):
    return os.path.join(GOC, "%s_bia_tap%s.png" % (ma, tap))


def _co(p):
    return bool(p) and os.path.isfile(p) and os.path.getsize(p) > 1000


# ---------------------------------------------------------------- trang thai
def trang_thai_tap(ma, tap, q=None):
    """SUY TU DIA: tap nay dang o buoc nao, thieu gi.

    Tra dict co `buoc` = {ma_buoc: 'xong'|'dang'|'chua'} de giao dien ve day cham.
    """
    bo = danh_sach_bo().get(ma) or {}
    kb = _doc(bo.get("kich_ban") or "", {})
    t = kb.get(str(tap)) or {}
    scenes = t.get("scenes") or []
    w = work_cua(ma, tap)

    n = len(scenes)
    anh = len([f for f in os.listdir(w) if re.match(r"img_\d+\.txt$", f)]) if os.path.isdir(w) else 0
    clip = len([f for f in os.listdir(w) if re.match(r"clip_\d+\.mp4$", f)]) if os.path.isdir(w) else 0
    sdk = _co(os.path.join(w, "so_dang_ky.json")) or os.path.isfile(os.path.join(w, "so_dang_ky.json"))
    tho = _co(os.path.join(w, "tho.mp4"))
    nhac = _co(os.path.join(w, "nhac.mp4"))
    vid = video_cua(ma, tap)
    bia = bia_cua(ma, tap)

    def _tt(xong, dang=False):
        return "xong" if xong else ("dang" if dang else "chua")

    # ⚠️ THANH PHAM la BANG CHUNG MANH NHAT. Da mac that 04/08: ban dau suy "ghep/nhac" theo
    # file trung gian tho.mp4/nhac.mp4 trong work dir — Tap 1 va 2 dung bang script cu (dat
    # file o cho khac) nen module bao "dang lam" trong khi video HOAN CHINH nam so so ra day.
    # Trang thai suy ra KHONG DUOC mau thuan voi thu nhin thay duoc: co video cuoi thi moi
    # buoc truoc no tat nhien da xong.
    co_vid = _co(vid)
    b = {
        "kich_ban":   _tt(n > 0),
        "so_dang_ky": _tt(sdk),
        "anh":        _tt(co_vid or (n and anh >= n), 0 < anh < n),
        "clip":       _tt(co_vid or (n and clip >= n), 0 < clip < n),
        "ghep":       _tt(co_vid or tho),
        "nhac":       _tt(co_vid or nhac),
        "hook":       _tt(co_vid),
        "bia":        _tt(_co(bia)),
    }
    xong = all(v == "xong" for v in b.values())
    # `kich_ban` la DIEU KIEN DAU VAO, khong phai tien do. Tinh no vao thi tap chua lam gi
    # ca cung hien "dang lam" — nguoi dung nhin lich se tuong dang chay, khong bam dung.
    dang = any(v in ("dang", "xong") for k, v in b.items() if k != "kich_ban")
    return {
        "bo": ma, "tap": tap, "tieu_de": t.get("tieu_de") or "",
        "so_nhip": n, "anh": anh, "clip": clip,
        "buoc": b,
        "trang_thai": "xong" if xong else ("dang" if dang else "chua"),
        "video": vid if _co(vid) else None,
        "bia": bia if _co(bia) else None,
        "giay": phim.R._dur(vid) if _co(vid) else 0,
        "can_lam": _can_lam(b),
        "uoc_tinh": uoc_tinh(ma, tap, q),
    }


def _can_lam(b):
    """Buoc DAU TIEN chua xong — thu giao dien hien o nut hanh dong."""
    for k, ten in BUOC:
        if b.get(k) != "xong":
            return ten
    return ""


_QUOTA = {"t": 0.0, "d": None}


def quota(lam_moi=False):
    """Gói 79AI còn bao nhiêu lượt video + còn bao nhiêu credit. Cache 60 giây.

    ⚠️ ĐÂY LÀ CHỐT CHẶN QUAN TRỌNG NHẤT của module. Sáng 04/08 quota cạn giữa lượt dựng,
    79AI im lặng chuyển sang trừ credit, mất 7.200đ mà không ai hay. Phải hỏi trước khi báo
    giá, không được đoán "Veo miễn phí".

    Lỗi mạng -> trả `biet=False` chứ KHÔNG mặc định "còn quota" (đoán sai hướng đó = lại mất
    tiền im lặng như cũ).
    """
    now = time.time()
    if not lam_moi and _QUOTA["d"] and now - _QUOTA["t"] < 60:
        return _QUOTA["d"]
    d = {"biet": False, "con": 0, "credit": 0, "het_han": 0, "plan": ""}
    try:
        from gommo_client import GommoClient
        c = GommoClient()
        s = c.subscription()
        o = s.get("options") or {}
        if s.get("status") == "ACTIVE":
            cap = int(o.get("videoMonth") or 0)
            used = int(o.get("videoMonthUsage") or 0)
            d["con"] = max(0, cap - used) if cap > 0 else 10 ** 9
            d["plan"] = s.get("plan_name") or ""
            d["het_han"] = int(s.get("expired_time") or 0)
        d["credit"] = int(c.credits())
        d["biet"] = True
    except Exception:
        pass
    _QUOTA.update(t=now, d=d)
    return d


def uoc_tinh(ma, tap, q=None):
    """Ước tính tiền CÒN PHẢI TRẢ (đã làm rồi thì không tính nữa).

    Trả thêm `canh_bao` khi số clip cần vượt quá quota còn lại — lúc đó phần vượt sẽ bị
    TRỪ CREDIT chứ không miễn phí.
    """
    bo = danh_sach_bo().get(ma) or {}
    kb = _doc(bo.get("kich_ban") or "", {})
    scenes = (kb.get(str(tap)) or {}).get("scenes") or []
    w = work_cua(ma, tap)
    if _co(video_cua(ma, tap)):
        return {"anh": 0, "clip": 0, "dong": 0, "trong_goi": 0, "tra_credit": 0,
                "credit": 0, "canh_bao": ""}
    da_anh = len([f for f in os.listdir(w) if re.match(r"img_\d+\.txt$", f)]) if os.path.isdir(w) else 0
    da_clip = len([f for f in os.listdir(w) if re.match(r"clip_\d+\.mp4$", f)]) if os.path.isdir(w) else 0
    con_anh = max(0, len(scenes) - da_anh)
    con_clip = max(0, len(scenes) - da_clip)
    gem = 0 if os.path.isfile(os.path.join(w, "so_dang_ky.json")) else GIA_GEMINI

    q = q or quota()
    # Số LƯỢT thật sự phải trả, không phải số clip: đo được 1,62 lượt cho mỗi clip dùng được.
    luot = int(round(con_clip * HE_SO_PHI))
    trong_goi = min(luot, q["con"]) if q["biet"] else 0
    tra_credit = max(0, luot - trong_goi)
    credit = tra_credit * GIA_CLIP_CREDIT
    dong = int(con_anh * GIA_ANH + credit * DONG_MOI_CREDIT + gem)

    cb = ""
    if not q["biet"]:
        cb = "Không hỏi được 79AI còn bao nhiêu lượt — số tiền dưới đây có thể sai."
    elif tra_credit and q["credit"] < credit:
        cb = ("HẾT quota VÀ không đủ credit: cần %s credit nhưng chỉ còn %s. Dựng sẽ hỏng dở."
              % (format(credit, ","), format(q["credit"], ",")))
    elif tra_credit:
        cb = ("Gói chỉ còn %d lượt, tập này cần ~%d → %d lượt vượt sẽ TRỪ CREDIT (%s credit)."
              % (q["con"], luot, tra_credit, format(credit, ",")))
    return {"anh": con_anh, "clip": con_clip, "luot": luot,
            "trong_goi": trong_goi, "tra_credit": tra_credit, "credit": credit,
            "dong": dong, "canh_bao": cb}


def trang_thai_bo(ma):
    bo = danh_sach_bo().get(ma)
    if not bo:
        return None
    kb = _doc(bo.get("kich_ban") or "", {})
    taps = sorted(kb.keys(), key=lambda x: int(x) if str(x).isdigit() else 999)
    q = quota()          # hoi MOT lan cho ca bo, khong goi API moi tap
    ds = [trang_thai_tap(ma, t, q) for t in taps]
    return {
        "ma": ma, "ten": bo.get("ten") or ma, "page": bo.get("page") or "",
        "style": bo.get("style"), "kich_ban": bo.get("kich_ban"),
        "so_tap": len(ds),
        "xong": sum(1 for x in ds if x["trang_thai"] == "xong"),
        "dang": sum(1 for x in ds if x["trang_thai"] == "dang"),
        "tong_giay": sum(x["giay"] or 0 for x in ds),
        "con_phai_tra": sum(x["uoc_tinh"]["dong"] for x in ds),
        "quota": q,
        "taps": ds,
    }


def tong_quan():
    return [trang_thai_bo(m) for m in danh_sach_bo()]


# ---------------------------------------------------------------- lam viec
def _sdk_goc(ma):
    """So dang ky cua TAP DAU = ban khoa ca series."""
    for t in ("1", 1):
        p = os.path.join(work_cua(ma, t), "so_dang_ky.json")
        if os.path.isfile(p):
            return _doc(p, None), work_cua(ma, t)
    return None, None


def dung_tap(ma, tap, lanes=None, model=None):
    """Dung mot tap. Idempotent — chay lai chi lam tiep phan thieu.

    Tap != 1 tu lay so dang ky Tap 1 lam ban KHOA (nhan vat + boi canh giu nguyen ca series).
    """
    bo = danh_sach_bo().get(ma)
    if not bo:
        raise RuntimeError("Chua dang ky bo '%s'" % ma)
    kb = _doc(bo.get("kich_ban") or "", {})
    t = kb.get(str(tap))
    if not t or not t.get("scenes"):
        raise RuntimeError("Kich ban khong co Tap %s" % tap)

    w = work_cua(ma, tap)
    sdk = _doc(os.path.join(w, "so_dang_ky.json"), None)
    goc, w1 = (None, None) if str(tap) == "1" else _sdk_goc(ma)
    if str(tap) != "1" and not goc:
        raise RuntimeError("Chua co so dang ky Tap 1 — phai dung Tap 1 truoc de KHOA nhan vat "
                           "cho ca series (khong thi Tap %s ra nhan vat khac han)" % tap)

    hook = [tuple(x) for x in (bo.get("hook") or [])]
    hook = hook + [("Tập %s" % tap, 70, (255, 205, 70))] if hook else None
    return phim.lam_tap(t["scenes"], w, video_cua(ma, tap), tap,
                        sdk=sdk, sdk_goc=goc, work_tap_dau=w1,
                        hook=hook, page=bo.get("page") or "",
                        nen_bia=bo.get("nen_bia"), out_bia=bia_cua(ma, tap),
                        lanes=lanes, model=model)


def lam_lai_nhip(ma, tap, so):
    """Xoa clip + anh cua MOT nhip de lan dung sau lam lai rieng nhip do.

    Vi sao can: mot nhip ra xau (Veo bia loi, nhan vat sai) thi khong co ly do dung lai
    ca tap. Xoa dung hai file cua nhip do, chay `dung_tap` la no lam bu.
    """
    w = work_cua(ma, tap)
    xoa = []
    for f in ("clip_%02d.mp4" % so, "img_%02d.txt" % so, "src_%02d.png" % so,
              "gon_%02d.mp4" % so, "clip_%02d.mp4.task" % so):
        p = os.path.join(w, f)
        if os.path.isfile(p):
            os.remove(p)
            xoa.append(f)
    # ban da ghep khong con dung nua
    for f in ("tho.mp4", "nhac.mp4"):
        p = os.path.join(w, f)
        if os.path.isfile(p):
            os.remove(p)
            xoa.append(f)
    v = video_cua(ma, tap)
    if os.path.isfile(v):
        os.remove(v)
        xoa.append(os.path.basename(v))
    return xoa


def caption(ma, tap):
    """Caption dang bai theo khuon page mau: mot cau ngan + "( Tap N )", KHONG hashtag.

    Do tu 30 caption an khach nhat cua page mau: 0/30 co hashtag, TB 9,7 tu, 29/30 co
    "( Tap N )". Voi phim nhieu tap, thu giu chan nguoi la SO TAP chu khong phai hashtag.
    """
    bo = danh_sach_bo().get(ma) or {}
    kb = _doc(bo.get("kich_ban") or "", {})
    td = (kb.get(str(tap)) or {}).get("tieu_de") or bo.get("ten") or ""
    # bo tien to "TAP n:" — chu A dau nang la U+1EAC, KHONG nam trong [AaAa]
    td = re.sub(r"^\s*T[AaÂâẬậẤấẦầ]P\s*\d+\s*[:.\-]\s*", "", td.strip(), flags=re.I)
    return "%s ( Tập %s )" % (td.rstrip("."), tap)


# ---------------------------------------------------------------- cua dong lenh
def _main():
    """CLI de HANG DOI goi duoc: `python pipeline/phim_xuong.py dung <ma> <tap> [lanes]`.

    ⚠️ Phai la DUONG DAN SCRIPT chu khong phai `python -c`: jobs.py TU THEM
    sys.executable vao dau cmd (dong 302: `PY, *_resolve_pipeline(job.cmd)`), nen truyen
    them python.exe nua thi no chay `python python.exe -c ...` = coi python.exe la file
    .py -> SyntaxError doc byte MZ. Da mac that 04/08.
    """
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("viec", choices=["dung", "trangthai", "cao", "gom", "sinh"])
    ap.add_argument("ma")
    ap.add_argument("tap")
    ap.add_argument("--lanes", type=int, default=0)
    ap.add_argument("--so-tap", type=int, default=5)
    ap.add_argument("--so-nhip", type=int, default=16)
    a = ap.parse_args()

    def bao(m):
        print(m, flush=True)

    if a.viec == "trangthai":
        print(json.dumps(trang_thai_tap(a.ma, a.tap), ensure_ascii=False, indent=1))
        return
    if a.viec == "cao":                      # ma = link page mau
        import phim_mau
        r = phim_mau.cao(a.ma, bao=bao)
        print("XONG: %d reel, %d anh bia" % (r["so_reel"], r["thumb_ok"]))
        return
    if a.viec == "gom":                      # ma = slug
        import phim_gom
        r = phim_gom.gom(a.ma, bao=bao)
        print("XONG: %d bo, %d reel le, %d chua ro"
              % (len(r["bo"]), len(r["le"]), len(r["chua_ro"])))
        return
    if a.viec == "sinh":                     # ma = ma bo, tap = de tai
        import phim_kichban
        r = phim_kichban.tu_sinh(a.ma, a.tap, so_tap=a.so_tap, so_nhip=a.so_nhip, bao=bao)
        print("XONG: kich ban %s, %d tap" % (r["ma"], r["so_tap"]))
        return
    r = dung_tap(a.ma, a.tap, lanes=a.lanes or None)
    print("XONG -> %s (%.1f giay)" % (r.get("out"), r.get("giay") or 0))


if __name__ == "__main__":
    import sys as _s
    _s.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    _main()
