# -*- coding: utf-8 -*-
"""GOM BỘ — reel nào thuộc cùng MỘT BỘ nhiều tập, reel nào để lẻ.

Người dùng chốt: *"reel kia là 1 bộ 5 tập thì cho vô 1 nhóm. cái nào lẻ thì để lẻ. gom lại
để lúc làm lại sẽ hiện thị tiến trình của bộ đó tập nào xong tập nào chưa."*

## Vì sao KHÔNG gom theo caption
Đo thật: **0/1053 reel có caption sau khi cào**. Caption chỉ có sau khi TẢI VIDEO — gom theo
caption nghĩa là phải tải cả 77 reel của một page trước khi biết reel nào thuộc bộ nào.

## Hai tầng, tầng RẺ chạy trước
```
tầng 1  cụm ảnh bìa bằng dHash            0đ   ← cả series dùng CHUNG một ảnh nền
tầng 2  vision đọc "Tập N" trong TỪNG CỤM  ~   ← chỉ gọi cho cụm ≥2 ảnh
```
Tầng 1 giải được việc mà đọc số tập KHÔNG giải nổi: **hai bộ khác nhau trên cùng page, cả hai
đều có "Tập 1"**. Số tập không phân biệt được; ảnh nền thì có.

Căn cứ tầng 1 (đo phiên trước trên page mẫu): *"cả series DÙNG CHUNG MỘT ẢNH NỀN, chỉ đổi số
tập"* — nên bìa cùng bộ giống nhau tới mức dHash bắt được.

⚠️ **CHƯA NGHIỆM THU trên page `danhngoncuocsong2017`.** Số đo cũ là của page phim gia đình
"Chuyện Nhà Mình", thể loại khác. Page danh ngôn có thể KHÔNG dùng chung ảnh nền, và có thể
KHÔNG in "Tập N" lên bìa — lúc đó cả hai tầng đều trượt, phải gán tay.

⚠️ MODULE RIÊNG. `fb_remake._dhash/_ham` chỉ GỌI, không sửa.
"""
import json
import os
import re

import phim_mau

# Ngưỡng khoảng cách Hamming để coi 2 bìa là "cùng một nền".
# ⚠️ Số này phải RÚT TỪ KHOẢNG TRỐNG THẬT trong dữ liệu (như `STILL_P99` của dự án đã làm),
# KHÔNG chọn số tròn cho đẹp. 12 chỉ là mốc khởi đầu để đo — Phase 01 phải chốt lại.
NGUONG = int(os.environ.get("PHIM_GOM_NGUONG", "12"))
LO = int(os.environ.get("PHIM_GOM_LO", "8"))        # số ảnh mỗi lượt gọi vision

_PROMPT = (
    "Mỗi ảnh dưới đây là ẢNH BÌA của một reel trên Facebook. Với TỪNG ảnh theo đúng thứ tự, "
    "đọc chữ IN TRÊN ảnh:\n"
    " - `tap`: số tập nếu thấy \"Tập 3\" / \"( Tập 3 )\" / \"Phần 3\" / \"P3\". "
    "KHÔNG thấy thì để null. TUYỆT ĐỐI không đoán, không suy từ thứ tự ảnh.\n"
    " - `tieu_de`: dòng chữ LỚN NHẤT trên ảnh (tên bộ). Không có thì để \"\".\n"
    "Trả JSON THUẦN {\"anh\":[{\"stt\":1,\"tap\":3,\"tieu_de\":\"...\"}]} đủ đúng %d phần tử."
)


def _hash_bia(slug, reels):
    """{rid: hash} cho mọi reel có ảnh bìa trên đĩa. 0đ."""
    import fb_remake as R
    ra = {}
    for rid in reels:
        p = phim_mau.thumb_path(slug, rid)
        if not p:
            continue
        try:
            ra[rid] = R._dhash(p)
        except Exception:
            continue
    return ra


def cum_theo_bia(slug, reels, nguong=None):
    """Tầng 1 — gom reel có ảnh bìa GIỐNG NHAU thành cụm. 0đ, không gọi API nào.

    Trả list các list rid. Reel không có bìa → mỗi cái một cụm riêng.
    """
    import fb_remake as R
    n = NGUONG if nguong is None else nguong
    h = _hash_bia(slug, reels)
    cum, da = [], set()
    for rid, hx in h.items():
        if rid in da:
            continue
        nhom = [rid]
        da.add(rid)
        for r2, h2 in h.items():
            if r2 in da:
                continue
            if R._ham(hx, h2) <= n:
                nhom.append(r2)
                da.add(r2)
        cum.append(nhom)
    for rid in reels:
        if rid not in h:
            cum.append([rid])
    return cum


def doc_so_tap(slug, rids, model=None):
    """Tầng 2 — vision đọc số tập từ ảnh bìa. Trả {rid: {tap, tieu_de}}.

    Chỉ gọi cho cụm ≥2 ảnh: cụm 1 ảnh chắc chắn là reel lẻ, đọc số tập cũng không đổi gì.
    """
    import base64

    import phim
    ra = {}
    for i in range(0, len(rids), LO):
        lo = rids[i:i + LO]
        parts = []
        dung = []
        for rid in lo:
            p = phim_mau.thumb_path(slug, rid)
            if not p:
                continue
            parts.append({"inline_data": {"mime_type": "image/jpeg",
                                          "data": base64.b64encode(open(p, "rb").read()).decode()}})
            dung.append(rid)
        if not dung:
            continue
        parts.append({"text": _PROMPT % len(dung)})
        try:
            d = phim.gemini_json(parts, timeout=180, model=model)
        except Exception:
            continue
        for k, rid in enumerate(dung):
            v = ((d.get("anh") or [])[k] if k < len(d.get("anh") or []) else {}) or {}
            t = v.get("tap")
            try:
                t = int(t) if t is not None else None
            except (TypeError, ValueError):
                t = None
            ra[rid] = {"tap": t, "tieu_de": str(v.get("tieu_de") or "").strip()}
    return ra


def gom(slug, model=None, bao=None):
    """Chạy cả hai tầng → cấu trúc bộ/lẻ. Lưu `gom.json`, trả kết quả.

    {"bo":[{"ma","ten","reels":[{"rid","tap"}]}], "le":[rid], "chua_ro":[rid]}
    """
    d = phim_mau.doc(slug)
    reels = d.get("reels") or {}
    if not reels:
        raise RuntimeError("Chưa cào page %s (hoặc cào ra 0 reel)" % slug)

    if bao:
        bao("Tầng 1: cụm ảnh bìa (0đ)…")
    cum = cum_theo_bia(slug, reels)
    lon = [c for c in cum if len(c) >= 2]
    le = [c[0] for c in cum if len(c) == 1]
    if bao:
        bao("Tầng 1 xong: %d cụm ≥2 reel, %d reel lẻ" % (len(lon), len(le)))

    # Tầng 2 CHỈ chạy cho cụm ≥2 — cụm 1 ảnh đọc số tập cũng không đổi kết luận.
    can = [r for c in lon for r in c]
    tap = doc_so_tap(slug, can, model) if can else {}
    if bao:
        bao("Tầng 2 xong: đọc số tập %d ảnh" % len(tap))

    bo, chua_ro = [], []
    for k, c in enumerate(lon):
        co = [(r, (tap.get(r) or {}).get("tap")) for r in c]
        cot = [x for x in co if x[1]]
        if len(cot) < 2:
            # Cùng nền nhưng không đọc được số tập ở ≥2 cái → chưa dám gọi là bộ.
            chua_ro.extend(c)
            continue
        ten = next((( tap.get(r) or {}).get("tieu_de") for r, t in cot
                    if (tap.get(r) or {}).get("tieu_de")), "") or ("Bộ %d" % (k + 1))
        bo.append({"ma": "%s_b%d" % (slug, k + 1), "ten": ten,
                   "reels": [{"rid": r, "tap": t} for r, t in sorted(cot, key=lambda x: x[1])],
                   "thieu_tap": [r for r, t in co if not t]})
    ra = {"slug": slug, "bo": bo, "le": le, "chua_ro": chua_ro,
          "nguong": NGUONG, "so_reel": len(reels)}
    p = os.path.join(phim_mau.thu_muc(slug), "gom.json")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(ra, f, ensure_ascii=False, indent=1)
    return ra


def doc_gom(slug):
    p = os.path.join(phim_mau.thu_muc(slug), "gom.json")
    try:
        with open(p, encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return {}


def gan_tay(slug, rid, ma_bo, tap):
    """Người dùng sửa tay khi máy gom sai. Máy đoán sai là chuyện thường — phải có đường sửa,
    không thì gom sai một lần là kẹt luôn."""
    g = doc_gom(slug) or {"slug": slug, "bo": [], "le": [], "chua_ro": []}
    for m in ("le", "chua_ro"):
        g[m] = [x for x in (g.get(m) or []) if x != rid]
    for b in g.get("bo") or []:
        b["reels"] = [x for x in b["reels"] if x.get("rid") != rid]
    if ma_bo:
        b = next((x for x in g["bo"] if x["ma"] == ma_bo), None)
        if not b:
            b = {"ma": ma_bo, "ten": ma_bo, "reels": [], "thieu_tap": []}
            g["bo"].append(b)
        b["reels"].append({"rid": rid, "tap": int(tap) if tap else None})
        b["reels"].sort(key=lambda x: x.get("tap") or 999)
    else:
        g.setdefault("le", []).append(rid)
    p = os.path.join(phim_mau.thu_muc(slug), "gom.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(g, f, ensure_ascii=False, indent=1)
    return g
