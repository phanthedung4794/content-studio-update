# -*- coding: utf-8 -*-
"""
DRIP — tu rai gio dang: tao N moc gio tuong lai trai deu qua cac KHUNG GIO/ngay,
+ jitter, TRANH trung moc da len lich. Dung cho "len lich nhieu bai".

Config: facebook/_drip.json {slots:["08:00",...], jitter_min, days}
"""
import json
import os
import random
import time
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.path.join(ROOT, "facebook")
CFG = os.path.join(FB_ROOT, "_drip.json")
SCHED = os.path.join(FB_ROOT, "_scheduled.json")

DEFAULT = {"slots": ["08:00", "12:30", "19:30"], "jitter_min": 25, "days": 14,
           # CÁCH ĐĂNG (chọn ở hộp ▶ Star). Cả 2 mode đều có: số bài + giãn cách phút.
           #   post_mode="now"      -> bài ĐẦU đăng ngay khi làm xong; bài sau cách gap_min phút.
           #   post_mode="schedule" -> bài đầu hẹn post_hhmm ngày (+post_day_offset); bài sau +gap_min.
           #   run_target           -> số bài cần làm rồi DỪNG (mỗi page). 0 = liên tục.
           #   gap_min              -> giãn cách giữa các bài (phút).
           #   threads              -> số LUỒNG chạy song song (1-10; = số job auto đồng thời).
           #   run_clip/run_style   -> ép model/kiểu ảnh cho cả lượt ('' = theo gán từng page).
           "post_mode": "now", "post_hhmm": "08:00", "post_day_offset": 1,
           "run_target": 1, "gap_min": 60,
           "threads": 5, "run_clip": "", "run_style": "",
           #   run_order -> chon reel nguon: 'oldest' (cu nhat, mac dinh) | 'random' (ngau nhien).
           "run_order": "oldest"}


def load_config() -> dict:
    if os.path.isfile(CFG):
        try:
            return {**DEFAULT, **json.load(open(CFG, encoding="utf-8"))}
        except Exception:
            pass
    return dict(DEFAULT)


def save_config(cfg: dict) -> dict:
    cur = load_config()
    for k in DEFAULT:
        if k in cfg:
            cur[k] = cfg[k]
    os.makedirs(FB_ROOT, exist_ok=True)
    json.dump(cur, open(CFG, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return cur


def _used_ts() -> list:
    if os.path.isfile(SCHED):
        try:
            return [s.get("when_ts", 0) for s in json.load(open(SCHED, encoding="utf-8"))
                    if s.get("when_ts")]
        except Exception:
            return []
    return []


def plan(n: int, min_lead_min: int = 20) -> list:
    """Tra N moc unix (giay) tuong lai, trai qua cac khung gio/ngay, tranh trung."""
    cfg = load_config()
    used = _used_ts()
    now = time.time()
    out = []
    day = 0
    base = datetime.now()
    while len(out) < n and day < 60:
        d = base + timedelta(days=day)
        for s in cfg["slots"]:
            hh, mm = [int(x) for x in s.split(":")]
            t = d.replace(hour=hh, minute=mm, second=0, microsecond=0)
            jit = random.randint(-cfg["jitter_min"], cfg["jitter_min"])
            ts = int(t.timestamp()) + jit * 60
            if ts < now + min_lead_min * 60:
                continue
            if any(abs(ts - u) < 300 for u in used + out):   # tranh sat moc da co
                continue
            out.append(ts)
            if len(out) >= n:
                break
        day += 1
    return out[:n]


def _sched_all() -> list:
    if os.path.isfile(SCHED):
        try:
            return json.load(open(SCHED, encoding="utf-8"))
        except Exception:
            return []
    return []


def _day_slots(per_day: int, cfg: dict) -> list:
    """per_day moc 'HH:MM' trong ngay. Du slot config thi dung; thieu -> trai deu 08:00-21:00."""
    slots = cfg.get("slots") or DEFAULT["slots"]
    if per_day <= len(slots):
        return slots[:per_day]
    start, end = 8 * 60, 21 * 60
    step = (end - start) // max(1, per_day - 1)
    return ["%02d:%02d" % ((start + step * i) // 60, (start + step * i) % 60)
            for i in range(per_day)]


def plan_for_page(page_id: str, n: int, per_day: int = 2,
                  min_lead_min: int = 20, horizon_days: int = 30) -> list:
    """N moc gio tuong lai cho RIENG page nay: toi da per_day/ngay, trai deu, tranh trung.

    Chi dem bai da lich CUA page do de dem hang ngay (page khac khong an vao slot).
    Ton trong FB: >= now+min_lead, <= 30 ngay.
    """
    from collections import defaultdict
    cfg = load_config()
    now = time.time()
    day_count = defaultdict(int)
    used = []
    for s in _sched_all():
        ts = s.get("when_ts") or 0
        if not ts:
            continue
        used.append(ts)
        if s.get("page_id") == page_id:
            day_count[time.strftime("%Y-%m-%d", time.localtime(ts))] += 1
    slots = _day_slots(per_day, cfg)
    out = []
    base = datetime.now()
    day = 0
    while len(out) < n and day < horizon_days:
        d = base + timedelta(days=day)
        dkey = d.strftime("%Y-%m-%d")
        avail = per_day - day_count[dkey]
        for s in slots:
            if avail <= 0 or len(out) >= n:
                break
            hh, mm = [int(x) for x in s.split(":")]
            t = d.replace(hour=hh, minute=mm, second=0, microsecond=0)
            jit = random.randint(-cfg["jitter_min"], cfg["jitter_min"])
            ts = int(t.timestamp()) + jit * 60
            if ts < now + min_lead_min * 60:
                continue
            if any(abs(ts - u) < 300 for u in used + out):
                continue
            out.append(ts); used.append(ts); avail -= 1
            day_count[dkey] += 1
        day += 1
    return out[:n]


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "page":
        pid = sys.argv[2] if len(sys.argv) > 2 else "123"
        for ts in plan_for_page(pid, int(sys.argv[3]) if len(sys.argv) > 3 else 6):
            print(time.strftime("%H:%M %d/%m", time.localtime(ts)))
    else:
        n = int(sys.argv[1]) if len(sys.argv) > 1 else 5
        for ts in plan(n):
            print(time.strftime("%H:%M %d/%m", time.localtime(ts)))
