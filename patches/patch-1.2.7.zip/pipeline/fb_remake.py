# -*- coding: utf-8 -*-
"""
Lam lai video TONG QUAT cho reel BAT KY (khong hardcode prompt).
Quy trinh (dua tren scratchpad da nghiem thu 1 video):
  1. chep loi (faster-whisper) -> cot truyen + moc cau
  2. video goc -> chia canh (dedup/gop) + LUU 1 frame dai dien/canh (goc_XX.jpg)
  3. VISION (GPT-4o nhin tung frame dai dien) -> prompt anh BAM KHUNG GOC (mac dinh).
     Fallback 'story': LLM doc cot truyen -> N canh (lech khung, chi khi thieu OPENAI/frame)
  4. gommo_client -> anh (banana_2 vip 1k) + clip i2v (veo fast / kling / Ken Burns)
  5. ghep: crossfade + lam cham cho day cua so (bam nhip video goc) + long AUDIO GOC (che do B)
Che do A (giong+nhac moi) CHUA lam o day -> tam dung che do B.

Ket qua: out_path (mp4 doc). IDEMPOTENT theo thu muc work (co roi thi bo qua).
CHUA CHAY THAT qua orchestration (ton credit) -> can nghiem thu lan dau cung nguoi dung.
"""
import base64
import glob
import json
import os
import re
import shutil
import subprocess
import time

import requests

from gommo_client import GommoClient, download
import script_gen

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MUSIC_DIR = os.path.join(ROOT, "assets", "music")

# STYLE trung tinh (KHONG khoa noi dung/boi canh) -> ap cho MOI nguon. Noi dung/boi canh
# do VISION mo ta tu chinh video goc (thanh pho/que/dem... deu dung). Chi ap phong cach ve.
# CHON qua tham so `style`: 'real' (giong that = MAC DINH, hop page anh nguoi that) |
# 'cartoon' (mau nuoc hoat hinh, hop page hoai niem). Truoc day HARDCODE 'cartoon' ->
# moi page deu ra hoat hinh; gio chon duoc theo nguon.
# DANH SACH KIEU ANH (khop 79AI, dong bo voi image_post.py). Value = duoi prompt them vao.
_TAIL = " Vertical 9:16 composition, full bleed edge to edge. No text, no words, no letters."
STYLES = {
    "real": (" Photorealistic, realistic natural lighting, true-to-life skin and textures, "
             "candid documentary photography look, sharp focus, high detail, cinematic color." + _TAIL),
    "cartoon": (" Hand-painted watercolor illustration, soft warm cinematic lighting, fine "
                "painterly texture, gentle nostalgic tone." + _TAIL),
    "hoat_hinh": (" cute simple hand-drawn cartoon illustration, thin clean black ink outlines, "
                  "adorable characters, gentle expressions, soft warm color accents, cozy tender mood." + _TAIL),
    "chan_dung_dien_anh": (" cinematic portrait, dramatic moody lighting, shallow depth of field, "
                           "film still, ultra detailed, atmospheric." + _TAIL),
    "anime": (" Japanese anime style, clean crisp line art, cel shading, expressive eyes, "
              "vibrant colors, studio anime key visual." + _TAIL),
    "mau_nuoc": (" soft watercolor painting, delicate translucent washes, textured watercolor "
                 "paper, gentle bleeding colors, hand painted." + _TAIL),
    "pixar_3d": (" 3D animated character render, Pixar Disney style, soft global illumination, "
                 "cute rounded shapes, subsurface scattering, high quality render." + _TAIL),
    "son_dau": (" classical oil painting, visible textured brush strokes, rich warm tones, "
                "canvas texture, painterly." + _TAIL),
    "ngam_doi": (" minimalist 2D cartoon illustration, STRICTLY grayscale black white and gray "
                 "only, no color, simple rounded egg-shaped heads with minimal facial features, "
                 "a dramatic warm glowing spotlight halo behind the characters, long dark shadows "
                 "on the floor, dark vignette background, emotional cinematic mood, clean thin "
                 "black ink line art." + _TAIL),
    "theo_mo_ta": (_TAIL),
}
# Nhan tieng Viet cho o chon "Kieu anh" (UI doc qua endpoint /fb-post/styles).
STYLE_LABELS = {
    "real": "Thật (giống ảnh thật)", "cartoon": "Màu nước hoài niệm",
    "hoat_hinh": "Hoạt hình dễ thương", "chan_dung_dien_anh": "Chân dung điện ảnh",
    "anime": "Anime Nhật Bản", "mau_nuoc": "Tranh màu nước",
    "pixar_3d": "Hoạt hình 3D (Pixar)", "son_dau": "Tranh sơn dầu",
    "ngam_doi": "Đen trắng xúc động (Ngẫm Đời)",
    "theo_mo_ta": "Theo mô tả (không thêm)",
}
DEFAULT_STYLE = "real"
STYLE = STYLES["cartoon"]   # tuong thich nguoc (code cu con tham chieu STYLE)
BLEED = (" Full bleed, fills the entire vertical 9:16 frame edge to edge, no black bars, "
         "no border, no vignette, no letterbox, no matte.")

# So luong 79AI xu SONG SONG (concurrency/account). Do that account credit ~2 lane;
# mua subscription (12 lane) thi dat REMAKE_LANES=12. Dung cho ca ve anh lan i2v.
# MAC DINH 1: song song o cap PAGE (10 page = 10 luong), moi page 1 i2v/luc -> tong <=10 task
# 79 (<12 concurrent cua goi) -> KHONG BAO GIO flood, khong can khoa lien-tien-trinh. Muon nhanh
# hon cho 1 video le (Xuong tay) thi REMAKE_LANES=2. Xem docs/song-song-nhieu-luong.md.
LANES = max(1, int(os.environ.get("REMAKE_LANES", "1")))

# Tham so BAT BUOC tung model i2v (do that tu 79AI: kling can duration, seedance can
# resolution, hailuo khong nhan 9:16). Dung cho FALLBACK khi model chinh het tai nguyen.
VIDEO_PARAMS = {
    # GROK Heavy (server grokai RIENG -> khong nghen nhu veo; do that: 97s, giu nhan vat, motion
    # tro chuyen tot, 1000cr/720p6s). Mode 'normal' (tranh extremely-crazy/spicy). i2v (startImage).
    "grok_video_heavy": {"mode": "normal", "resolution": "720p", "duration": "6"},
    # veo FAST (khong Lite): cung model/chat luong, uu tien CAO -> nhanh + do treo (+~50% gia).
    # DO THAT 2026-07: veo 1080p -> LOI backend #453422 (that bai that). 720p CHAY ngon
    # (SUCCESSFUL 165s, 0 credit). Grok cung 720p OK. -> giu 720p cho ca 2 (on dinh + free).
    "veo_3_1":         {"mode": "fast", "resolution": "720p", "duration": "8"},
    "hailuo_2_3":      {"mode": "fast", "resolution": "720p", "duration": "6"},
    "kling_video_2_6": {"mode": "standard", "duration": "8"},
    "kling_video_2_5": {"mode": "standard", "duration": "8"},
}
# [KHONG CON DUNG] Truoc day _gen_one_clip nhay model khi treo/loi. Da BO: model do NGUOI DUNG
# chon (veo/grok/kenburns), i2v KHONG tu chuyen model, KHONG tu rot Ken Burns (tranh nhoi hang
# doi 79 -> treo). Giu bien de tuong thich; khong tham chieu o dau. Xem docs/song-song-nhieu-luong.md.
FALLBACK_CHAIN = ["veo_3_1", "grok_video_heavy"]
# CHO LAU (goi co HANG DOI UU TIEN 12+30 slot) — KHONG timeout-giet, KHONG tu chuyen model,
# KHONG tu rot Ken Burns. Mac dinh 3600s (1h) = "cho gan nhu vo han" nhung van co tran chong treo.
# Het 1h -> submit LAI CUNG model (bounded REMAKE_I2V_RESUBMIT). Xem docs/song-song-nhieu-luong.md.
I2V_WAIT = int(os.environ.get("REMAKE_I2V_WAIT", "3600"))
# So lan submit LAI CUNG model khi 79 bao FAIL/tu choi (task CHET). KHONG doi model, KHONG Ken Burns.
I2V_RESUBMIT = max(1, int(os.environ.get("REMAKE_I2V_RESUBMIT", "3")))
# So VONG cho toi da khi het I2V_WAIT ma task VAN dang chay (task con song -> KHONG submit lai
# de tranh mo coi/flood). Tong cho ~ I2V_MAX_WAITS x I2V_WAIT. Het -> GIU .task, raise resumable.
I2V_MAX_WAITS = max(1, int(os.environ.get("REMAKE_I2V_MAX_WAITS", "3")))


_PROGRESS = None          # callback(step_msg) -> cap nhat tien trinh len UI (fb_pipeline)


def set_progress(cb):
    """Dang ky callback nhan MOC tien trinh nguoi-doc (vd cap nhat step cua item pipeline).
    None de tat. fb_auto dat = ham cap nhat step cua item dang lam -> UI hien 'Dang tao
    anh 3/7', 'Dang ghep video'... thay vi step co dinh 'download'."""
    global _PROGRESS
    _PROGRESS = cb


def _log(m):
    print(m, flush=True)


def _prog(m):
    """MOC tien trinh NGUOI-DOC (tieng Viet co dau): in stdout (nhat ky job) + day len UI qua
    callback. Chi dung cho cac CHANG quan trong nguoi dung theo doi, khong phai moi dong debug."""
    print(m, flush=True)
    cb = _PROGRESS
    if cb:
        try:
            cb(m)
        except Exception:
            pass


def _dur(path):
    """Do dai (giay) 1 file media qua ffprobe."""
    return float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", path]).decode().strip())


def _ff(args, **kw):
    """Chay ffmpeg BAT stderr -> loi DOC DUOC. Thay cho subprocess.run(..., check=True):
    str(CalledProcessError) chi ra 'Command ... returned non-zero exit status' (VO DUNG,
    giau ly do). Ham nay raise kem 3 dong stderr cuoi cua ffmpeg -> khach/dev thay ly do that
    (vd 'Stream map matches no streams' = nguon cam, 'moov atom not found' = file tai cut)."""
    r = subprocess.run(args, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", **kw)
    if r.returncode != 0:
        err = (r.stderr or r.stdout or "").strip()
        tail = " | ".join([l for l in err.splitlines() if l.strip()][-3:])[:300]
        raise RuntimeError("ffmpeg loi: " + (tail or "khong ro (rc=%d)" % r.returncode))
    return r


def _has_audio(path):
    """Video co luong AUDIO khong (reel tai bang DASH co the mat fragment audio -> mp4 cam)."""
    try:
        out = subprocess.check_output([
            "ffprobe", "-v", "error", "-select_streams", "a", "-show_entries",
            "stream=index", "-of", "csv=p=0", path]).decode().strip()
        return bool(out)
    except Exception:
        return True    # khong chac -> gia dinh co (dau '?' o map van lo an toan)


def transcribe(video_path, work):
    """Chep loi -> [{start,end,text}] + story."""
    tj = os.path.join(work, "transcript.json")
    if os.path.isfile(tj):
        segs = json.load(open(tj, encoding="utf-8"))
    else:
        from faster_whisper import WhisperModel
        wav = os.path.join(work, "audio.wav")
        _ff(["ffmpeg", "-v", "error", "-y", "-i", video_path,
             "-ac", "1", "-ar", "16000", wav])
        m = WhisperModel("small", device="cpu", compute_type="int8")
        segs = [{"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()}
                for s in m.transcribe(wav, language="vi", vad_filter=True)[0]]
        json.dump(segs, open(tj, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    story = " ".join(s["text"] for s in segs)
    return segs, story


def gen_scene_prompts(story, n_scenes, work, scene_texts=None, context=None):
    """LLM DOC CA TRUYEN -> N canh {img, mot} (nhat quan nhan vat, KHAC nhau tung canh).

    scene_texts (hybrid): N doan LOI THOAI theo thu tu thoi gian -> moi canh minh hoa DUNG
    doan cua no (khop loi + nhip video). None -> chia deu tu cot truyen.
    context: 1 cau boi canh TONG rut tu video goc (era/vung/khong khi) -> grounding, tranh
    westernize; ghim vao moi canh. Cache ra work/scenes.json.
    """
    pf = os.path.join(work, "scenes.json")
    if os.path.isfile(pf):
        return json.load(open(pf, encoding="utf-8"))
    ctx = (context or "").strip()
    system = (
        "Ban la dao dien hinh anh cho video ke chuyen hoai niem Viet Nam. Doc HET cot truyen "
        "roi dung hinh cho tung canh. QUY TAC BAT BUOC: (1) Khoa DANH TINH nhan vat — moi nhan "
        "vat co mo ta ngoai hinh CO DINH (tuoi, toc, trang phuc, dac diem) lap lai Y HET o moi "
        "canh co nhan vat do (tranh moi canh ve mot kieu). (2) Moi canh KHAC NHAU ro rang "
        "(khoanh khac/goc nhin/hanh dong khac) — TUYET DOI khong lap lai cung mot canh. "
        "(3) Giu dung boi canh van hoa, khong doi sang phuong Tay. Tra ve JSON thuan tuy."
        + (" Boi canh tong the video: %s." % ctx if ctx else ""))
    if scene_texts:
        blocks = "\n".join('%d. "%s"' % (i + 1, (t or "").strip()) for i, t in enumerate(scene_texts))
        want = len(scene_texts)
        user = (f"COT TRUYEN DAY DU (loi ke/thoai ca video):\n\"{story}\"\n\n"
                f"Video co {want} canh LIEN TIEP theo thoi gian, moi canh ung 1 doan loi:\n{blocks}\n\n"
                f"Voi MOI canh tao 1 hinh minh hoa DUNG noi dung/khong khi doan loi do, nhat "
                f"quan trong ca mach truyen:\n"
                f"- img: mo ta ANH tieng Anh (nhan vat + hanh dong + boi canh khop doan loi; "
                f"lap lai mo ta nhan vat de khop cac canh khac)\n"
                f"- mot: mo ta CHUYEN DONG nhe tieng Anh cho i2v (cham, khong rung lac)\n"
                f'Tra ve JSON: {{"scenes":[{{"img":"...","mot":"..."}}, ...]}} — DUNG {want} canh, '
                f"dung thu tu tren, khong giai thich.")
    else:
        want = n_scenes
        user = (f"Cot truyen (loi thoai/ke): \"{story}\"\n\n"
                f"Chia thanh {n_scenes} canh KE TIEP theo dien bien, MOI canh KHAC nhau. Moi canh cho:\n"
                f"- img: mo ta ANH tieng Anh (nhan vat + boi canh + hanh dong; lap lai mo ta nhan vat)\n"
                f"- mot: mo ta CHUYEN DONG nhe tieng Anh cho i2v (cham, khong rung lac)\n"
                f'Tra ve JSON: {{"scenes":[{{"img":"...","mot":"..."}}, ...]}} — dung {n_scenes} canh, '
                f"khong giai thich.")
    txt = script_gen._chat_text(system, user, max_tokens=2200)
    m = re.search(r"\{.*\}", txt, re.S)
    data = json.loads(m.group(0)) if m else {"scenes": []}
    scenes = data.get("scenes", [])[:want]
    if len(scenes) < want:
        raise RuntimeError("LLM tra it canh hon yeu cau (%d/%d)" % (len(scenes), want))
    if ctx:                              # ghim boi canh tong vao moi canh (grounding chac)
        for sc in scenes:
            sc["img"] = "%s. %s" % (ctx, sc.get("img", ""))
    json.dump(scenes, open(pf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return scenes


# ── PHAN TICH VIDEO GOC (video-driven, TONG QUAT moi noi dung) ──────────────
def _dhash(path, size=8):
    """Hash tri giac 1 anh -> so 64 bit (so sanh 2 frame co khac 'slide' khong)."""
    from PIL import Image
    img = Image.open(path).convert("L").resize((size + 1, size))
    px = list(img.getdata())
    bits = 0
    for r in range(size):
        for c in range(size):
            bits = (bits << 1) | (1 if px[r * (size + 1) + c] < px[r * (size + 1) + c + 1] else 0)
    return bits


def _ham(a, b):
    return bin(a ^ b).count("1")


# Prompt MEM (khong hoi tuoi/gioi/sac toc tung nguoi -> tranh bo loc tu choi). Boi canh
# van GIU (khong westernize) + BOI CANH TONG rut rieng tu video ghep vao -> giu chat Viet.
_CONTEXT_PROMPT = ("In ONE short English phrase, state the overall SETTING, ERA, region/culture and "
                   "mood of this video for consistent art direction (e.g. '1990s rural Vietnamese "
                   "countryside, warm nostalgic'). Output only the phrase.")


def _openai_vision(text, img_b64_list, max_tokens=400, timeout=90):
    """1 loi goi GPT-4o vision (1+ anh + text). Tra text tra loi."""
    ok = os.environ.get("OPENAI_API_KEY", "").strip()
    if not ok:
        raise RuntimeError("Thieu OPENAI_API_KEY de phan tich video (vision).")
    content = [{"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,%s" % b}}
               for b in img_b64_list]
    content.append({"type": "text", "text": text})
    base = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/") + "/chat/completions"
    r = requests.post(base, json={"model": os.environ.get("OPENAI_MODEL") or "gpt-4o",
                                  "max_tokens": max_tokens, "messages": [{"role": "user", "content": content}]},
                      timeout=timeout, headers={"Authorization": "Bearer %s" % ok, "Content-Type": "application/json"})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def _b64(p):
    return base64.b64encode(open(p, "rb").read()).decode()


def _video_context(frame_paths):
    """Boi canh TONG cua video (video-derived, 1 cau) -> grounding cho moi canh."""
    try:
        return _openai_vision(_CONTEXT_PROMPT, [_b64(p) for p in frame_paths[:3]], max_tokens=60)
    except Exception:
        return ""


# ── VISION per-frame + SO DANG KY LUY TIEN: bam KHUNG GOC + nhat quan nhan vat/do vat/con vat ──
# VISION bam khung (do that: 2 dua dap xe -> ve 2 dua dap xe). Van de: ta MOI frame COO LAP ->
# cung 1 nguoi moi canh ve 1 kieu. GIAI: SO DANG KY LUY TIEN — duyet canh THEO THU TU; canh nao
# sinh them nhan vat/con vat/do vat MOI thi KHOA vao so; canh sau xuat hien lai thi tai dung DUNG
# mo ta da khoa. Moi canh chi ve dung thuc the co mat. Boi canh khoa MEM (chong drift Tay, doi
# khi chuyen cho). Vd: canh1 2 dua -> khoa; canh2 them 2 dua moi -> khoa them; canh3 them nguoi
# cha -> khoa cha; canh4 chi 4 dua canh1+2 -> hien dung 4 dua do.

# CHI lam diu vai tu goi cam (banana KHONG chan boy/girl). KHONG xoa boy/girl nua vi lam MAT
# gioi tinh -> anh ra sai gioi (anh ra nu). Giu boy/girl de model ve dung gioi.
_SOFTEN = [("cheekily", "gently"), ("grins", "smiles")]

# Chuyen dong nhe cho i2v: CHONG morph mat/drift (i2v hay ve lai mat -> anime "Naruto").
_MOTION = ("Gentle subtle motion: slight natural movement of the subject and a slow gentle "
           "camera push-in, cinematic and smooth. Keep faces, identities and composition "
           "stable; no morphing, no distortion, no shaking.")

# Canh CO thoai VA CO NGUOI: nhan vat MAP MAY MIENG nhu dang noi chuyen (khong phai lip-sync tung
# chu, chi "trong nhu dang noi"). Van chong morph. Gan theo _dialogue_per_window (canh nao co loi).
_MOTION_TALK = ("The characters are talking to each other, their mouths moving as if speaking and "
                "smiling, with small natural head and hand gestures, as if having a real "
                "conversation; a slow gentle camera push-in, cinematic and smooth. Keep faces, "
                "identities and composition stable; no morphing, no distortion, no shaking. "
                "Do NOT add any new people beyond those already in the image.")

# Canh KHONG CO NGUOI (phong canh/vat the) — dU audio co voiceover, i2v TUYET DOI khong duoc
# bia them nguoi (bug: canh cai loa bi gan 'characters talking' -> veo de ra 2 nguoi + drift style).
_MOTION_SCENERY = ("Gentle subtle motion of the scenery only: soft moving light, drifting clouds or "
                   "smoke, a slow gentle camera push-in, cinematic and smooth. Do NOT add any people "
                   "or characters; keep it an empty scenery shot. Keep the composition and art style "
                   "stable; no morphing, no distortion, no shaking.")

# Tu khoa NGUOI trong prompt anh -> quyet dinh canh co nguoi hay khong (chong bia nguoi vao phong canh).
_PEOPLE_RE = re.compile(
    r"\b(man|men|woman|women|boy|boys|girl|girls|child|children|kid|kids|person|people|villager|"
    r"villagers|family|grandmother|grandfather|grandma|grandpa|mother|father|parents|lady|ladies|"
    r"human|figure|figures|crowd|elderly|couple|baby|infant|teenager|worker|farmer|monk|soldier)\b",
    re.I)


# Bo cum PHU DINH truoc khi kiem (hau to "do not add unrelated people" dinh chu 'people' -> duong tinh gia).
_NEG_PEOPLE_RE = re.compile(r"(do not add[^.]*?\bpeople\b|no people\b|any people\b|unrelated people\b|"
                            r"people or characters)", re.I)


def _scene_has_people(sc):
    """Canh co nguoi khong? Doc prompt anh (img) SAU khi bo cum phu dinh. Chong gan 'talking'
    cho canh phong canh/vat the (bug: canh loa bi veo bia 2 nguoi vao)."""
    txt = _NEG_PEOPLE_RE.sub("", sc.get("img", ""))
    return bool(_PEOPLE_RE.search(txt))


def apply_talk_motion(scenes, segs, bounds, adur):
    """Gan motion theo canh (sua scenes tai cho):
    - CO thoai VA CO NGUOI -> map may mieng (nhu dang noi).
    - CO NGUOI, khong thoai -> nhe (giu identity).
    - KHONG CO NGUOI -> scenery (CAM bia nguoi) — du audio co voiceover.
    Bug cu: canh khong nguoi (loa/phong canh) + audio co tieng -> 'characters talking' -> veo de nguoi."""
    texts = _dialogue_per_window(segs, bounds, adur)
    for i, sc in enumerate(scenes):
        has_speech = bool(i < len(texts) and (texts[i] or "").strip())
        has_people = _scene_has_people(sc)
        if not has_people:
            sc["mot"] = _MOTION_SCENERY
        elif has_speech:
            sc["mot"] = _MOTION_TALK
        else:
            sc["mot"] = _MOTION
    return scenes

# Prompt duyet TUNG frame theo thu tu (co so dang ky hien tai) -> nhan dien thuc the co mat +
# khoa thuc the MOI + ta canh (bam khung). Gioi tinh ro (khong "anh ra nu"); khong nhan A/B/C.
_REG_PROMPT = (
    "This is frame %d of %d from ONE nostalgic 1990s rural Vietnamese video whose recurring "
    "characters, animals and objects must stay consistent across scenes.\n"
    "ALREADY REGISTERED entities (reuse each EXACTLY, do NOT change or re-describe its look):\n%s\n\n"
    "Look ONLY at THIS frame and return JSON with three keys:\n"
    '"present": array of the ID NUMBERS of already-registered entities that actually appear here.\n'
    '"new": array of entities that appear but are NOT yet registered; for each give '
    '{"kind":"person|animal|object","desc":"fixed canonical description"}. For a person state '
    "GENDER (a boy / a girl / a man / a woman), age, hair, face, build, and clothing WITH colors. "
    "For an animal/object give type, colors, shape, pattern.\n"
    '"scene": ONE paragraph to RECREATE this frame (poses, actions, setting/background, camera '
    "framing, colors, lighting, art style); refer to entities by what they are, do NOT restate their "
    "fixed appearance. 1990s rural Vietnamese, NOT European; do not mention any letters as visible text.\n"
    "Output ONLY the JSON, no preface.")


def _reg_lines(registry):
    return "\n".join("%d. [%s] %s" % (e["id"], e["kind"], e["desc"]) for e in registry) or "(none yet)"


def _soften(p):
    for a, b in _SOFTEN:
        p = re.sub(a, b, p, flags=re.I)
    return p


def _build_registry(frame_paths):
    """Duyet frame THEO THU TU -> SO DANG KY LUY TIEN. Tra (registry, per_scene).

    registry=[{id,kind,desc}] (khoa dan khi thuc the xuat hien LAN DAU); per_scene[i]=
    {present:[id...], scene:str}. Tuan tu (buoc i doc so sau i-1) nen KHONG song song.
    """
    registry, per_scene = [], []
    for i, fp in enumerate(frame_paths):
        prompt = _REG_PROMPT % (i + 1, len(frame_paths), _reg_lines(registry))
        try:
            txt = _openai_vision(prompt, [_b64(fp)], max_tokens=700)
            m = re.search(r"\{.*\}", txt, re.S)
            d = json.loads(m.group(0)) if m else {}
        except Exception as e:
            _log("  canh %d so-dang-ky loi: %s" % (i, str(e)[:60])); d = {}
        present = []
        for pid in (d.get("present") or []):
            try:
                pid = int(pid)
                if 1 <= pid <= len(registry):
                    present.append(pid)
            except Exception:
                pass
        nnew = 0
        for ne in (d.get("new") or []):                 # thuc the MOI -> khoa vao so
            if isinstance(ne, dict) and ne.get("desc"):
                nid = len(registry) + 1
                registry.append({"id": nid, "kind": (ne.get("kind") or "person"),
                                 "desc": _soften(ne["desc"]).strip()})
                present.append(nid); nnew += 1
        per_scene.append({"present": sorted(set(present)), "scene": (d.get("scene") or "").strip()})
        _log("  canh %d: co mat=%s, +%d moi (so dang ky=%d)"
             % (i, sorted(set(present)), nnew, len(registry)))
    return registry, per_scene


def vision_scene_prompts(work, n):
    """VISION + SO DANG KY LUY TIEN: moi canh ve DUNG thuc the co mat (khoa dan khi xuat hien moi),
    tai dung DUNG mo ta cho thuc the cu -> nhan vat/do vat/con vat nhat quan xuyen suot 8 canh.
    Moi canh {img: khoa thuc the co mat + mo ta canh, mot: chuyen dong nhe}. Cache scenes+registry.json.
    """
    pf = os.path.join(work, "scenes.json")
    if os.path.isfile(pf):
        return json.load(open(pf, encoding="utf-8"))
    frames = [os.path.join(work, "goc_%02d.jpg" % i) for i in range(n)]
    missing = [i for i, f in enumerate(frames) if not os.path.isfile(f)]
    if missing:
        raise RuntimeError("thieu frame dai dien goc_XX.jpg: %s" % missing)
    registry, per_scene = _build_registry(frames)
    json.dump({"registry": registry, "per_scene": per_scene},
              open(os.path.join(work, "registry.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    by_id = {e["id"]: e for e in registry}
    scenes = []
    for i in range(n):
        ps = per_scene[i] if i < len(per_scene) else {"present": [], "scene": ""}
        ents = [by_id[pid] for pid in ps.get("present", []) if pid in by_id]
        lock = ""
        if ents:                                        # khoa DUNG thuc the co mat trong canh nay
            lock = ("Keep each of these entities IDENTICAL to its established look across scenes: "
                    + " ".join(e["desc"].rstrip(".") + "." for e in ents) + " ")
        img = (lock + "Scene: " + ps.get("scene", "")).strip()
        img += (" 1990s rural Vietnamese setting, not European. Draw only the entities described; "
                "do not add unrelated people; do not render any letters, labels or captions.")
        scenes.append({"img": img, "mot": _MOTION})
    json.dump(scenes, open(pf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return scenes


GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-flash-latest")


def gemini_generate(parts, gen_config=None, tries=4, timeout=180):
    """1 call Gemini generateContent (parts = list [{inline_data}|{text}]). Retry 503/429/timeout
    (backoff 4->20s) vi Gemini hay 503 tam thoi. Tra text tra loi hoac raise sau khi het luot."""
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Thieu GEMINI_API_KEY")
    url = ("https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s"
           % (GEMINI_MODEL, key))
    body = {"contents": [{"parts": parts}], "generationConfig": gen_config or {}}
    last = None
    for att in range(tries):
        try:
            r = requests.post(url, json=body, timeout=timeout)
            if r.status_code in (429, 500, 502, 503, 504):
                last = "HTTP %d" % r.status_code
                time.sleep(min(20, 4 * (att + 1)))
                continue
            r.raise_for_status()
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]
        except requests.exceptions.RequestException as e:
            last = str(e)[:80]
            time.sleep(min(20, 4 * (att + 1)))
    raise RuntimeError("Gemini that bai sau %d lan: %s" % (tries, last))

_GEM_SCENE = (
    "Ban XEM VIDEO ngan nay de VE LAI thanh video moi (giu cot truyen + giong goc, chi thay HINH).\n"
    "Video co %d CANH, moc thoi gian (giay) tung canh:\n%s\n"
    'LOI THOAI (transcript): "%s"\n\n'
    "Voi MOI canh theo DUNG THU TU, viet 1 PROMPT tieng ANH de tao ANH tai hien khoanh khac chinh "
    "cua canh do. Mo ta: nguoi (neu ro GIOI TINH: a boy / a girl / a man / a woman; tuoi, toc, khuon "
    "mat, dang nguoi, QUAN AO kem MAU), con vat, do vat, tu the, hanh dong, boi canh/hau canh, goc "
    "may, anh sang, mau sac.\n"
    "CUC KY QUAN TRONG: moi nhan vat / con vat / do vat lap lai phai GIU NGUYEN DIEN MAO Y HET qua "
    "TAT CA cac canh (cung nguoi = cung khuon mat, toc, quan ao). Boi canh nong thon Viet Nam thap "
    "nien 1990, KHONG chau Au. Chi ve dung thuc the thuc su xuat hien; KHONG them nguoi la. KHONG ve "
    "bat ky chu/text/caption nao.\n"
    'Tra JSON THUAN (khong markdown): {"scenes":[{"img":"..."}, ...] } dung %d phan tu, theo thu tu canh.')


def _gem_ready_video(video_path, work):
    """Tra duong dan video <19MB de gui inline Gemini. Video goc qua lon -> transcode PROXY nhe
    (chi de PHAN TICH, khong dung lam output). Tra None neu that bai."""
    try:
        if os.path.getsize(video_path) <= 19 * 1024 * 1024:
            return video_path
    except OSError:
        return None
    proxy = os.path.join(work, "gem_proxy.mp4")
    if os.path.isfile(proxy) and os.path.getsize(proxy) > 1000:
        return proxy
    try:                                                  # nen ve ~480p, crf cao -> nhe cho analyze
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", video_path, "-vf", "scale=-2:480",
                        "-c:v", "libx264", "-crf", "32", "-preset", "veryfast",
                        "-c:a", "aac", "-b:a", "64k", proxy], check=True)
        if os.path.getsize(proxy) <= 19 * 1024 * 1024:
            return proxy
    except Exception:
        pass
    return None


_VIRAL_CAP = (
    "Ban la chuyen gia viet caption VIRAL cho video reel Facebook (hoai niem / tam su tuoi tho / "
    "doi song que). Duoi la caption GOC cua 1 video. Hay VIET LAI (TUYET DOI khong copy nguyen van) "
    "thanh caption tieng Viet CO DAU:\n"
    "- Dong DAU la cau HOOK khien nguoi dang luot phai DUNG LAI xem (khoi to mo / cham cam xuc / cau "
    "hoi gan). Ngan, manh.\n"
    "- 2-4 dong, giu DUNG chu de va cam xuc goc, gan gui that long, khong sao rong khong noi qua.\n"
    "- TUYET DOI khong nhac ten kenh / link / keu goi subscribe-follow / nguon. Toi da 2-3 emoji.\n"
    "- Ket bang 3-5 hashtag xu huong hop chu de (vi du #hoainiem #tuoitho #kyuc #xuhuong #quenha).\n"
    "Chi TRA VE dung caption cuoi cung, khong giai thich, khong tieu de.\n\nCAPTION GOC:\n\"\"\"%s\"\"\"")


def viral_caption(original, timeout=60):
    """Gemini VIET LAI caption cho VIRAL (hook giu nguoi xem, bo quang ba kenh). KHONG copy nguyen van.
    Fallback: tra `original` neu thieu key / loi (da retry trong gemini_generate)."""
    base = (original or "").strip()
    if not base:
        return base
    try:
        txt = gemini_generate([{"text": _VIRAL_CAP % base[:1500]}],
                              gen_config={"temperature": 0.85}, timeout=timeout)
        out = (txt or "").strip().strip('"').strip()
        return out or base
    except Exception:
        return base


def gemini_scene_prompts(video_path, work, n, bounds=None, windows=None, story=""):
    """Gemini XEM NGUYEN video (hinh dong + tieng) -> viet prompt anh cho N canh trong 1 call.
    Uu the vs vision per-frame: thay ca luong + nhat quan nhan vat tu nhien (khong can so dang ky
    tuan tu N call). Cache scenes.json. Tra [{img, mot}] hoac RuntimeError (caller fallback)."""
    pf = os.path.join(work, "scenes.json")
    if os.path.isfile(pf):
        return json.load(open(pf, encoding="utf-8"))
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("Thieu GEMINI_API_KEY")
    mp4 = _gem_ready_video(video_path, work)
    if not mp4:
        raise RuntimeError("Khong chuan bi duoc video <19MB cho Gemini")
    # moc thoi gian tung canh (de Gemini can canh dung khoanh khac)
    if bounds:
        rng = []
        for i in range(n):
            s = bounds[i] if i < len(bounds) else 0
            e = (bounds[i] + windows[i]) if (windows and i < len(windows)) else (
                bounds[i + 1] if i + 1 < len(bounds) else s + 3)
            rng.append("canh %d: %.1f-%.1fs" % (i + 1, s, e))
        moc = "\n".join(rng)
    else:
        moc = "%d canh chia deu" % n
    prompt = _GEM_SCENE % (n, moc, (story or "").strip()[:900], n)
    b64 = base64.b64encode(open(mp4, "rb").read()).decode()
    txt = gemini_generate(
        [{"inline_data": {"mime_type": "video/mp4", "data": b64}}, {"text": prompt}],
        gen_config={"responseMimeType": "application/json", "temperature": 0.15})
    data = json.loads(txt)
    arr = data.get("scenes") if isinstance(data, dict) else data
    if not isinstance(arr, list) or not arr:
        raise RuntimeError("Gemini tra scenes rong")
    scenes = []
    for i in range(n):
        img = ""
        if i < len(arr) and isinstance(arr[i], dict):
            img = (arr[i].get("img") or "").strip()
        if not img:                                       # thieu canh -> tai dung canh truoc/mo ta chung
            img = scenes[-1]["img"] if scenes else "1990s rural Vietnamese scene."
        img = _soften(img)
        img += (" 1990s rural Vietnamese setting, not European. Draw only the entities described; "
                "do not add unrelated people; do not render any letters, labels or captions.")
        scenes.append({"img": img, "mot": _MOTION})
    json.dump(scenes, open(pf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return scenes


def video_scene_bounds(video_path, work, max_scenes=24, segs=None, fps_sample=1, dhash_thresh=14):
    """Phan tich NHIP video goc -> ranh gioi canh (theo slide THAT) + do dai + boi canh TONG.

    So canh TU BAM theo so slide that (gop thong minh bam moc cau) -> khop nhip loi/gio.
    KHONG mo ta tung frame (2 slide giong nhau -> 2 prompt trung -> ve trung). Chi lay 1 boi
    canh TONG (era/vung/khong khi) de LLM grounding. Cache vbounds.json (idempotent).
    Tra ve (bounds, windows, context): bounds = moc bat dau moi canh; windows = do dai canh.
    """
    vb_f = os.path.join(work, "vbounds.json")
    if os.path.isfile(vb_f):
        d = json.load(open(vb_f, encoding="utf-8"))
        return d["bounds"], d["windows"], d.get("context", "")
    adur = _dur(video_path)
    kf = os.path.join(work, "_kf")
    os.makedirs(kf, exist_ok=True)
    _ff(["ffmpeg", "-v", "error", "-y", "-i", video_path, "-vf", "fps=%d" % fps_sample,
         "-q:v", "3", os.path.join(kf, "f_%04d.jpg")])
    frames = sorted(glob.glob(os.path.join(kf, "f_*.jpg")))
    if not frames:
        raise RuntimeError("Khong tach duoc frame tu video goc.")
    # loc slide RIENG (frame khac han frame giu truoc) + DEDUP slide LAP LAI o xa (slideshow
    # lap 1 canh 2 lan -> so voi MOI slide da giu, nguong chat rep_thresh -> bo slide lap).
    rep_thresh = max(6, dhash_thresh - 6)
    kept, kept_h, last = [], [], None
    for i, f in enumerate(frames):
        h = _dhash(f)
        if last is not None and _ham(h, last) <= dhash_thresh:
            continue                                   # con trong cung 1 slide
        if any(_ham(h, kh) <= rep_thresh for kh in kept_h):
            last = h; continue                         # slide LAP lai o xa -> bo
        kept.append((i / float(fps_sample), f)); kept_h.append(h); last = h
    if not kept:
        kept = [(0.0, frames[0])]
    # GOP THONG MINH: giu cat o CANH CHINH (trung moc doi cau/giong) hoac canh LON (>=2.5s);
    # gop canh vun/phu vao canh truoc. Tua nhip goc, khong truot qua nhu ep 6 canh.
    if segs and len(kept) > 4:
        starts = sorted(float(s.get("start", 0)) for s in segs
                        if s.get("start") is not None and float(s.get("start", 0)) > 0)
        kt = [t for t, _ in kept] + [adur]
        merged = [kept[0]]
        cur_start = kept[0][0]
        for i in range(1, len(kept)):
            dur = kt[i + 1] - kt[i]
            near_narr = any(abs(kept[i][0] - st) < 1.2 for st in starts)   # giong chuyen canh
            too_long = (kt[i] - cur_start) >= 7.0    # canh gop qua dai -> ep cat
            if near_narr or dur >= 2.5 or too_long:
                merged.append(kept[i]); cur_start = kept[i][0]             # else: gop (bo qua)
        kept = merged
    if len(kept) > max_scenes and max_scenes > 0:
        pick = sorted(set(round(k * (len(kept) - 1) / (max_scenes - 1)) for k in range(max_scenes))) \
            if max_scenes > 1 else [0]
        kept = [kept[j] for j in pick]
    bounds = [t for t, _ in kept]
    times = bounds + [adur]
    windows = [max(1.0, times[i + 1] - times[i]) for i in range(len(kept))]
    _log("phan tich NHIP video goc: %d slide -> %d canh" % (len(frames), len(kept)))
    # LUU 1 frame DAI DIEN moi canh (goc_%02d.jpg, ben trong work) -> VISION ta lai de VE
    # bam KHUNG GOC (thay story-driven lech khung). Frame giu la slide dau canh (da dedup).
    for i, (_, fp) in enumerate(kept):
        try:
            shutil.copy(fp, os.path.join(work, "goc_%02d.jpg" % i))
        except OSError:
            pass
    # Bo OpenAI: context chi dung cho 'story' mode (thu cong). Gemini (mac dinh) KHONG can.
    # Chi goi _video_context (OpenAI) khi THAT SU chay story mode -> tinh lazy o nhanh do.
    context = ""

    json.dump({"bounds": bounds, "windows": windows, "context": context},
              open(vb_f, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    shutil.rmtree(kf, ignore_errors=True)
    return bounds, windows, context


def _dialogue_per_window(segs, bounds, adur):
    """Gan loi thoai vao tung cua so canh [bounds[i], bounds[i+1]) theo moc cau whisper.

    Cua so rong (khong cau nao roi vao) -> lay cau gan giua nhat. Tra list text dung thu tu canh.
    """
    edges = list(bounds) + [adur]
    out = []
    for i in range(len(bounds)):
        lo, hi = edges[i], edges[i + 1]
        txt = " ".join(s.get("text", "").strip() for s in (segs or [])
                       if lo - 0.01 <= float(s.get("start", 0)) < hi).strip()
        if not txt and segs:
            near = min(segs, key=lambda s: abs(float(s.get("start", 0)) - (lo + hi) / 2))
            txt = near.get("text", "").strip()
        out.append(txt)
    return out


def _wait_image(c, iid, timeout=900):
    w = 0
    while w < timeout:
        info = c.check_image(iid)
        if info.get("status") == "SUCCESS" and info.get("url"):
            return info["url"]
        if info.get("status") == "ERROR":
            raise RuntimeError("anh loi")
        time.sleep(12); w += 12
    raise TimeoutError("anh qua gio")


def _wait_video(c, vid, timeout=1500):
    w = 0
    while w < timeout:
        info = c.check_video(vid)
        st = str(info.get("status") or "").upper()
        msg = str(info.get("message") or "").lower()
        # het tai nguyen model -> BAO NGAY de fallback (dung cho timeout 25')
        if "NOT_RESOURCE" in st or "không khả dụng" in msg or "khong kha dung" in msg:
            raise _NotResources(info.get("message") or "NOT_RESOURCES")
        url = GommoClient._video_url(info)
        if "FAIL" in st or "ERROR" in st:
            raise RuntimeError("clip loi: " + str(info.get("message") or "")[:150])
        if url and "PENDING" not in st and "PROCESS" not in st and "QUEUE" not in st:
            return url
        time.sleep(12); w += 12
    raise TimeoutError("clip qua gio")


# Tu khoa 79/veo (Google) BAO BI TU CHOI NOI DUNG (khac treo/het tai nguyen). Refusal la loi
# VINH VIEN cho prompt do tren model do -> co the NHAY model khac (grok loc khac). Treo/resource
# thi GIU model (tranh flood). Xem _gen_one_clip.
_REFUSAL_KW = ("nguy hiem", "nguy hiểm", "tu khoa", "từ kh\xf3a", "dangerous",
               "generation failed", "unsafe", "sensitive", "policy", "violat", "flagged",
               "khong an toan", "kh\xf4ng an to\xe0n", "tu choi", "từ chối")


def _is_refusal(msg):
    m = (msg or "").lower()
    return any(k in m for k in _REFUSAL_KW)


class _NotResources(RuntimeError):
    """Model i2v het tai nguyen -> chuyen model khac."""


def _gen_one_image(c, sc, urlf, tries=4, style=DEFAULT_STYLE):
    """Ve 1 anh khung dau (idempotent qua urlf). Tra ve url.

    BEN: 79AI hay ket 1 anh >10' khi nghen -> GUI LAI (anh moi, slot moi) thay vi
    de TimeoutError giet CA tien trinh (bug cu: 1 anh cham -> mat sach tien do).
    Moi lan cho toi da 8' roi thu anh khac.
    """
    if os.path.isfile(urlf):
        return open(urlf).read().strip()
    # Model/mode ve anh CHON DUOC qua env (do that: banana_2 vip 400cr HAY KET khi 79AI nghen;
    # banana_pro vip 600cr CHEN duoc hang -> xong ~4'). Mac dinh giu banana_2 (khoi doi cost auto).
    # MAC DINH banana_pro vip 1k (600cr): CHEN duoc hang doi khi 79AI nghen (do that 8/8 xong).
    # banana_2 400cr re hon nhung HAY KET khi nghen -> bo lam mac dinh. Van doi duoc qua env.
    img_model = os.environ.get("REMAKE_IMG_MODEL", "google_image_gen_banana_pro")
    img_mode = os.environ.get("REMAKE_IMG_MODE", "vip")
    # DO THAT (2026-07-24): banana_pro vip 1k = 81s ON DINH; 2k = 90s -> 235s BIEN DONG
    # manh khi 79AI nghen (nguon "anh ve lau lam"). 1k = 1024px thua net cho video doc 1080px
    # (frame con qua i2v/Ken Burns). -> mac dinh 1k cho NHANH + het treo 4'. Doi 2k qua env.
    img_res = os.environ.get("REMAKE_IMG_RES", "1k")
    last = None
    for t in range(tries):
        try:
            r = c.create_image(model=img_model,
                               prompt=sc["img"] + STYLES.get(style, STYLES[DEFAULT_STYLE]) + BLEED,
                               ratio="9:16", mode=img_mode, resolution=img_res)
            info = r.get("imageInfo") or r.get("data") or r
            iid = info.get("id_base") or r.get("id_base")
            if not iid:
                last = "submit loi: %s" % str(r)[:100]
                time.sleep(6); continue
            # cho ANH lau hon khi 79AI nghen (banana cao diem >8'/anh -> tranh churn gui lai).
            # env REMAKE_IMG_WAIT (giay), mac dinh 900 = 15'. Ket that (>15') moi gui lai.
            img_wait = int(os.environ.get("REMAKE_IMG_WAIT", "900"))
            url = _wait_image(c, iid, timeout=img_wait)
            open(urlf, "w").write(url)
            return url
        except (TimeoutError, RuntimeError) as e:
            last = str(e)[:100]
            _log("  anh ket/loi (%s) -> gui lai (lan %d/%d)" % (last, t + 2, tries))
            time.sleep(4)
    raise RuntimeError("anh that bai sau %d lan: %s" % (tries, last))


MAX_STRETCH = float(os.environ.get("REMAKE_MAX_STRETCH", "1.5"))   # keo clip toi da 1.5x (het GIAT)


def _fit_scene(clip, target, seg_path, resample):
    """Tao 1 doan video DUNG `target` giay tu clip i2v -> KHONG bi giat vi keo qua cham.
    - target <= clip*MAX_STRETCH: keo cham nhe (<=1.5x) cho day (motion muot, blend it).
    - target >  clip*MAX_STRETCH: clip keo toi 1.5x + NOI Ken-Burns zoom KHUNG CUOI cho phan du.
      (Truoc: keo thang 2-3x = motion bo + blend = GIAT. Freeze = do. Ken-Burns = muot, lien mach.)"""
    base = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1"
    enc = ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium", "-crf", "20", "-r", "30"]
    cl = _dur(clip)
    if target <= cl * MAX_STRETCH + 0.05:
        stretch = max(1.0, target / cl)
        vf = "%s,setpts=%.4f*PTS,%s,trim=0:%.3f,setpts=PTS-STARTPTS,format=yuv420p" % (
            base, stretch, resample, target)
        _ff(["ffmpeg", "-v", "error", "-y", "-i", clip, "-vf", vf, "-an"] + enc + [seg_path])
        return seg_path
    # Phan CLIP: keo toi 1.5x. Phan DU: Ken-Burns khung cuoi.
    clip_dur = cl * MAX_STRETCH
    tail = max(0.4, target - clip_dur)
    pc, pk, lf, lst = seg_path + ".c.mp4", seg_path + ".k.mp4", seg_path + ".last.jpg", seg_path + ".txt"
    vf = "%s,setpts=%.4f*PTS,%s,trim=0:%.3f,setpts=PTS-STARTPTS,format=yuv420p" % (
        base, MAX_STRETCH, resample, clip_dur)
    _ff(["ffmpeg", "-v", "error", "-y", "-i", clip, "-vf", vf, "-an"] + enc + [pc])
    _ff(["ffmpeg", "-v", "error", "-y", "-sseof", "-0.2", "-i", clip, "-frames:v", "1",
         "-vf", base, lf])
    _ken_burns_clip(lf, pk, dur=tail)                 # zoom cham khung cuoi -> noi tiep muot
    with open(lst, "w", encoding="utf-8") as f:
        f.write("file '%s'\nfile '%s'\n" % (os.path.abspath(pc), os.path.abspath(pk)))
    _ff(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-an"]
        + enc + [seg_path])
    for p in (pc, pk, lf, lst):
        try:
            os.remove(p)
        except OSError:
            pass
    return seg_path


def _ken_burns_clip(img_src, clip_path, dur=8.0):
    """LUOI AN TOAN (khong i2v): zoom/pan cham tren ANH TINH -> clip 1080x1920. LUON chay,
    0 hang, 0 credit video. Dung khi moi model i2v treo/fail. Motion la camera (khong canh dong).
    """
    tmp = clip_path + ".src.jpg"
    if str(img_src).startswith("http"):
        download(img_src, tmp)
    else:
        shutil.copy(img_src, tmp)
    fps = 30
    frames = max(1, int(dur * fps))
    # scale len 2x roi zoompan xuong 1080x1920 -> zoom min muot, khong vo hat.
    vf = ("scale=2160:3840:force_original_aspect_ratio=increase,crop=2160:3840,"
          "zoompan=z='min(zoom+0.0012,1.12)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
          "d=%d:s=1080x1920:fps=%d,setsar=1,format=yuv420p" % (frames, fps))
    _ff(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-i", tmp, "-t", "%.3f" % dur,
         "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium",
         "-crf", "20", clip_path])
    try:
        os.remove(tmp)
    except OSError:
        pass
    return clip_path


def _gen_one_clip(c, sc, img_url, clip_path, clip_model, kb_dur=8.0):
    """i2v 1 canh — CHI dung model NGUOI DUNG chon. KHONG tu chuyen model, KHONG tu rot Ken Burns.

    - clip_model == 'kenburns': nguoi dung CHON Ken Burns -> ve tu anh (KHONG goi 79).
    - veo/grok: submit 1 lan -> LUU id_base ra `<clip>.task` NGAY (process chet van cuu duoc) ->
      cho LAU (I2V_WAIT ~1h, hang doi uu tien cua goi). RESUME: co `.task` san -> cho+tai, KHONG
      submit lai. 79 het tai nguyen / loi / cho qua lau -> submit LAI CUNG model (bounded
      I2V_RESUBMIT), KHONG nhay model (tranh nhoi hang cho -> treo), KHONG Ken Burns ngam. Het
      luot -> raise (canh loi -> reel loi RO -> nguoi dung tu chon lam lai / doi 'kenburns').
    DUNG hay CHO la QUYET DINH cua nguoi dung (nut Dung) — khong tu dong."""
    # Nguoi dung chon Ken Burns -> ve thang tu anh, khong dung 79 (0 cho, 0 quota).
    if clip_model == "kenburns":
        _ken_burns_clip(img_url, clip_path, dur=kb_dur)
        return "kenburns"
    taskf = clip_path + ".task"
    params = VIDEO_PARAMS.get(clip_model, {"mode": "fast", "resolution": "720p"})
    # RESUME: process truoc da submit + luu id (chet giua chung) -> DUNG lai id do, KHONG submit lai.
    vid = open(taskf).read().strip() or None if os.path.isfile(taskf) else None
    tries = 0        # so lan SUBMIT LAI (chi khi task CHET) — bounded I2V_RESUBMIT
    waits = 0        # so vong CHO them khi task VAN song (khong submit lai) — bounded I2V_MAX_WAITS
    refusals = 0     # so lan bi TU CHOI NOI DUNG -> du I2V_RESUBMIT thi NHAY grok (1 lan)
    switched = False # da nhay sang grok chua (chi nhay 1 lan)
    while True:
        if not vid:
            rv = c.create_video(model=clip_model, prompt=sc["mot"], ratio="9:16",
                                ref_image_urls=[img_url], **params)
            info = rv.get("videoInfo") or rv.get("data") or rv
            vid = (info or {}).get("id_base") or (rv.get("id_base") if isinstance(rv, dict) else None)
            if not vid:                    # 79 tu choi submit (thuong do het tai nguyen tam thoi)
                reason = (rv.get("error") or rv.get("message") or str(rv)[:90]) if isinstance(rv, dict) else str(rv)[:90]
                tries += 1
                if tries >= I2V_RESUBMIT:
                    raise RuntimeError("79AI tu choi i2v %s sau %d lan (%s)" % (clip_model, tries, reason))
                _prog("79AI bận (%s) → chờ rồi thử LẠI CÙNG model (%d/%d), KHÔNG đổi model" % (clip_model, tries, I2V_RESUBMIT))
                time.sleep(min(60, 15 * tries)); continue
            open(taskf, "w").write(vid)    # LUU id NGAY sau khi 79 nhan -> cuu duoc neu process chet
        try:
            url = _wait_video(c, vid, timeout=I2V_WAIT)   # cho LAU trong hang doi uu tien
            download(url, clip_path)
            try:
                os.remove(taskf)
            except OSError:
                pass
            return clip_model
        except TimeoutError:
            # HET GIO CHO nhung task CO THE VAN dang chay tren 79 -> TUYET DOI KHONG xoa .task /
            # submit lai (se de task MO COI + nhoi hang doi = FLOOD). Giu NGUYEN task, cho TIEP
            # (cung id). Het kien nhan -> GIU .task de lan chay sau RESUME (tai ve khi 79 xong).
            waits += 1
            if waits >= I2V_MAX_WAITS:
                raise RuntimeError("i2v %s cho qua lau (%d x %ds) — GIU task de chay lai resume, KHONG Ken Burns"
                                   % (clip_model, waits, I2V_WAIT))
            _prog("Clip %s vẫn đang xử lý trên 79 (chờ tiếp, GIỮ nguyên task) — KHÔNG đổi model, KHÔNG Ken Burns" % clip_model)
            continue                        # vid GIU NGUYEN -> _wait_video lai CUNG task, KHONG submit moi
        except (_NotResources, RuntimeError) as e:
            # task DA CHET -> an toan clear + submit LAI.
            vid = None
            try:
                os.remove(taskf)
            except OSError:
                pass
            emsg = str(e)
            # (1) BI TU CHOI NOI DUNG (veo loc gat "prompt nguy hiem"): la loi VINH VIEN cho prompt do
            # tren model do. Sau I2V_RESUBMIT lan tu choi -> NHAY grok (loc khac, thuong qua). CHI
            # refusal moi nhay model; treo/het-tai-nguyen thi GIU model (nhanh (2) tranh flood).
            if _is_refusal(emsg):
                refusals += 1
                if refusals < I2V_RESUBMIT:
                    _prog("Bị từ chối nội dung (%d/%d) → làm mềm prompt, thử LẠI cùng model %s"
                          % (refusals, I2V_RESUBMIT, clip_model))
                    sc = dict(sc, mot=_soften(sc.get("mot", "")))   # lam mem prompt truoc khi thu lai
                    time.sleep(3); continue
                if clip_model != "grok_video_heavy" and not switched:
                    _prog("veo từ chối nội dung %d lần → CHUYỂN sang grok (chỉ khi bị từ chối, không phải treo)"
                          % refusals)
                    clip_model = "grok_video_heavy"
                    params = VIDEO_PARAMS.get(clip_model, {"mode": "fast", "resolution": "720p"})
                    switched, tries, refusals = True, 0, 0
                    time.sleep(3); continue
                raise RuntimeError("i2v bị từ chối nội dung %d lần (cả veo lẫn grok) — cảnh lỗi, đổi prompt/kiểu ảnh"
                                   % (refusals + I2V_RESUBMIT))
            # (2) KHONG phai refusal (treo/het tai nguyen/loi khac) -> GIU model, resubmit bounded (cu).
            tries += 1
            if tries >= I2V_RESUBMIT:
                raise RuntimeError("i2v %s that bai sau %d lan (%s) — canh loi, khong tu Ken Burns"
                                   % (clip_model, tries, emsg[:60]))
            _prog("Clip %s lỗi trên 79 (%s) → submit LẠI CÙNG model (%d/%d), KHÔNG Ken Burns"
                  % (clip_model, emsg[:40], tries, I2V_RESUBMIT))
            time.sleep(min(90, 20 * tries)); continue


def gen_media(scenes, work, clip_model="veo_3_1", style=DEFAULT_STYLE, lanes=None):
    """Ve anh + i2v SONG SONG (`lanes` lane, mac dinh LANES=1). IDEMPOTENT (resume qua .task/.txt).
    KHONG fallback model — model do NGUOI DUNG chon (veo/grok/kenburns), i2v cho lau + submit
    lai cung model (xem _gen_one_clip). style: 'real' (MAC DINH) | 'cartoon' ..."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    lanes = max(1, int(lanes or LANES))
    c = GommoClient()          # _post dung requests.post truc tiep -> thread-safe
    n = len(scenes)
    clip_of = lambda i: os.path.join(work, "clip_%02d.mp4" % i)
    urlf_of = lambda i: os.path.join(work, "img_%02d.txt" % i)
    done = lambda i: os.path.isfile(clip_of(i)) and os.path.getsize(clip_of(i)) > 1000
    have = sum(1 for i in range(n) if done(i))
    if have:                                   # RESUME: bao ro da co bao nhieu canh -> chi lam tiep phan thieu
        _prog("Đã có %d/%d cảnh làm sẵn → chỉ làm tiếp %d cảnh còn thiếu (giữ clip cũ)" % (have, n, n - have))
    # Bo dem tien trinh chay TRONG lock: cac lane song song bao xong -> dem/day len UI
    # tuan tu (fb_pipeline ghi CUNG 1 file, phai serialize de khoi hong).
    plock = threading.Lock()

    # Pha 1: ve anh (bo qua canh da co clip). Song song toi da LANES.
    todo_img = [i for i in range(n) if not done(i)]
    imgs = {}
    img_cnt = [n - len(todo_img)]          # tinh ca canh da co san (resume) -> "3/7" dung
    def _img(i):
        u = _gen_one_image(c, scenes[i], urlf_of(i), style=style)
        with plock:
            img_cnt[0] += 1
            _prog("Đang tạo ảnh %d/%d" % (img_cnt[0], n))
        _log("scene%d anh xong (con %d cr)" % (i, c.credits())); return i, u
    if todo_img:
        _prog("Đang tạo ảnh 0/%d (chuẩn bị)" % n)
        with ThreadPoolExecutor(max_workers=lanes) as ex:
            for f in [ex.submit(_img, i) for i in todo_img]:
                i, u = f.result(); imgs[i] = u

    # Pha 2: i2v (bo qua canh da co clip). Song song toi da LANES.
    todo_clip = [i for i in range(n) if not done(i)]
    clip_cnt = [n - len(todo_clip)]
    def _clip(i):
        img_url = imgs.get(i) or open(urlf_of(i)).read().strip()
        used = _gen_one_clip(c, scenes[i], img_url, clip_of(i), clip_model)
        with plock:
            clip_cnt[0] += 1
            _prog("Đang tạo video từ ảnh %d/%d" % (clip_cnt[0], n))
        _log("scene%d clip xong (model %s, con %d cr)" % (i, used, c.credits()))
    if todo_clip:
        _prog("Đang chờ tạo video từ ảnh 0/%d" % n)
        with ThreadPoolExecutor(max_workers=lanes) as ex:
            for f in [ex.submit(_clip, i) for i in todo_clip]:
                f.result()          # propagate loi (neu co)
    return [clip_of(i) for i in range(n)]


def _group_scenes(segs, n, adur, min_win=1.2):
    """Chia transcript thanh n NHOM cau lien tiep (bam moc cau) -> [{text,start,end,dur}].

    Canh i phu nhom cau i -> vua khop TIMING (bien = moc cau) vua khop NOI DUNG (text
    nhom do dung de sinh prompt anh). Nguon duy nhat cho ca gen_scene_prompts lan assemble.
    """
    if not segs or n <= 1:
        return [{"text": "", "start": i * adur / n, "end": (i + 1) * adur / n,
                 "dur": adur / n} for i in range(n)]
    starts = sorted(set(float(s.get("start", 0)) for s in segs
                        if s.get("start") is not None and 0 < float(s.get("start", 0)) < adur))
    bnds = [0.0]
    for i in range(1, n):
        target = i * adur / n
        cand = [st for st in starts if st > bnds[-1] + min_win and st < adur - min_win]
        b = min(cand, key=lambda st: abs(st - target)) if cand else min(bnds[-1] + min_win, adur)
        bnds.append(b)
    bnds.append(adur)
    groups = []
    for i in range(n):
        lo, hi = bnds[i], bnds[i + 1]
        txt = " ".join(s.get("text", "").strip() for s in segs
                       if lo - 0.01 <= float(s.get("start", 0)) < hi).strip()
        if not txt and segs:                         # nhom rong -> cau gan giua nhat
            near = min(segs, key=lambda s: abs(float(s.get("start", 0)) - (lo + hi) / 2))
            txt = near.get("text", "").strip()
        groups.append({"text": txt, "start": lo, "end": hi, "dur": max(min_win, hi - lo)})
    return groups


def _scene_windows(segs, n, adur):
    """Do dai tung canh (giay) — dung chung nhom voi gen prompt (nhat quan timing)."""
    return [g["dur"] for g in _group_scenes(segs, n, adur)]


def assemble(clips, orig_video, out_path, work, segs=None, wins=None, xfade=0.6):
    """Ghep muot (crossfade + lam cham cho day) + long AUDIO GOC (che do B).

    wins (uu tien) = do dai moi canh theo TIMING video goc (video-driven). Neu None ->
    tinh tu segs (bam moc cau). Neu ca hai None -> chia deu.
    """
    adur = float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", orig_video]).decode().strip())
    n = len(clips)
    if wins and len(wins) == n:
        segw = list(wins)                            # do dai canh theo video goc
    else:
        segw = _scene_windows(segs, n, adur)         # fallback: bam moc cau / chia deu
    wins = [s + xfade for s in segw]                 # them xfade de crossfade sang canh sau
    def cdur(p):
        return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries",
            "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", p]).decode().strip())
    # DO THAT (2026-07-23): clip Grok la 24fps, ep fps=30 -> ffmpeg NHAN DOI 1/4 khung
    # (240 khung/8s nhung chi 192 khac nhau) => CHUYEN CANH GIAT/LAC. Giai phap: minterpolate
    # BLEND hoa khung chen -> 238/238 khung khac nhau (het trung), chi cham hon ~2s/clip.
    # (mci muot nhat nhung >90s/clip @1080x1920 -> khong dung cho may khach.)
    # Env REMAKE_SMOOTH: blend (mac dinh) | dup (cu, nhanh nhat, con giat) | mci (muot nhat, RAT cham).
    _sm = os.environ.get("REMAKE_SMOOTH", "blend").lower()
    if _sm == "dup":
        _resample = "fps=30"
    elif _sm == "mci":
        _resample = "minterpolate=fps=30:mi_mode=mci:mc_mode=obmc:me_mode=bidir"
    else:
        _resample = "minterpolate=fps=30:mi_mode=blend"
    # Build TUNG doan canh dung do dai (fit): keo <=1.5x, du thi Ken-Burns khung cuoi (het GIAT).
    inputs, filt = [], []
    for i, cp in enumerate(clips):
        seg = os.path.join(work, "seg_%02d.mp4" % i)
        _fit_scene(cp, wins[i], seg, _resample)
        inputs += ["-i", seg]
        filt.append("[%d:v]setpts=PTS-STARTPTS[v%d]" % (i, i))
    prev = "v0"; acc = wins[0]
    for k in range(1, n):
        filt.append("[%s][v%d]xfade=transition=fade:duration=%.2f:offset=%.3f[x%d]"
                    % (prev, k, xfade, max(0.0, acc - xfade), k))
        prev = "x%d" % k; acc = acc + wins[k] - xfade
    # NGUON CAM (DASH mat fragment audio -> mp4 khong co tieng): dau '?' o map audio =
    # tuy chon -> ffmpeg BO QUA thay vi CHET "Stream map matches no streams" (loi khach hay gap
    # o khau ghep cuoi SAU khi da ve het clip). Nguon cam -> video ra IM (van xong, khong mat clip).
    if not _has_audio(orig_video):
        _prog("⚠ Video nguồn KHÔNG có tiếng (tải thiếu audio) → video sẽ im (không mất clip đã vẽ)")
    cmd = ["ffmpeg", "-v", "error", "-y"] + inputs + ["-i", orig_video,
        "-filter_complex", ";".join(filt), "-map", "[%s]" % prev, "-map", "%d:a?" % n,
        "-t", "%.3f" % adur, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium",
        "-crf", "20", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out_path]
    _ff(cmd)
    for i in range(len(clips)):                       # don seg tam
        try:
            os.remove(os.path.join(work, "seg_%02d.mp4" % i))
        except OSError:
            pass
    return out_path


def _assemble_simple(clips, orig_video, out_path, work, wins=None):
    """LUOI AN TOAN cho GHEP: KHONG xfade, KHONG minterpolate. Chuan hoa moi clip -> 1080x1920
    30fps yuv420p (dup frame) roi CONCAT (cat thang) + long audio (map '?' -> nguon cam khong crash),
    encode `-threads 1` (chong libx264 loi -22 'Terminating thread'). Dung khi ghep muot (xfade+
    minterpolate) sap tren may khach -> video VAN xong tu clip DA VE (chi mat hieu ung chuyen canh muot).
    """
    n = len(clips)
    adur = _dur(orig_video)
    segw = list(wins) if (wins and len(wins) == n) else [adur / max(1, n)] * n
    base = ("scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,"
            "fps=30,format=yuv420p")
    enc = ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium", "-crf", "20", "-threads", "1"]
    parts, lst = [], os.path.join(work, "s_concat.txt")
    for i, cp in enumerate(clips):
        seg = os.path.join(work, "ssg_%02d.mp4" % i)
        cl = _dur(cp)
        stretch = max(1.0, segw[i] / cl) if cl > 0 else 1.0
        vf = "%s,setpts=%.4f*PTS,trim=0:%.3f,setpts=PTS-STARTPTS" % (base, stretch, segw[i])
        _ff(["ffmpeg", "-v", "error", "-y", "-i", cp, "-vf", vf, "-an"] + enc + [seg])
        parts.append(seg)
    with open(lst, "w", encoding="utf-8") as f:
        for p in parts:
            f.write("file '%s'\n" % os.path.abspath(p))
    concat = os.path.join(work, "s_concat.mp4")
    _ff(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c:v", "copy", concat])
    _ff(["ffmpeg", "-v", "error", "-y", "-i", concat, "-i", orig_video, "-map", "0:v", "-map", "1:a?",
         "-t", "%.3f" % adur, "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
         "-movflags", "+faststart", out_path])
    for p in parts + [concat, lst]:
        try:
            os.remove(p)
        except OSError:
            pass
    return out_path


def _default_voice_id():
    """Voice ElevenLabs de doc: uu tien roster (giong dang dung), roi giong dau."""
    try:
        import voice_roster
        for v in voice_roster.roster():
            if v.get("engine") == "eleven":
                return v.get("id")
    except Exception:
        pass
    try:
        import eleven_tts
        vs = eleven_tts.list_voices()
        return vs[0]["voice_id"] if vs else None
    except Exception:
        return None


def _pick_music():
    if os.path.isdir(MUSIC_DIR):
        pref = os.path.join(MUSIC_DIR, "nhac_nen_mau.m4a")
        if os.path.isfile(pref):
            return pref
        for fn in sorted(os.listdir(MUSIC_DIR)):
            if fn.lower().endswith((".mp3", ".m4a", ".ogg", ".wav")):
                return os.path.join(MUSIC_DIR, fn)
    return None


def make_voice_audio(story, work, voice_id=None):
    """Mode A: TTS giong MOI doc cot truyen + nhac nen ducked -> audio.m4a. Tra (path)."""
    import eleven_tts
    out = os.path.join(work, "voicemix.m4a")
    if os.path.isfile(out) and os.path.getsize(out) > 1000:
        return out
    vid = voice_id or _default_voice_id()
    if not vid:
        raise RuntimeError("Khong co voice ElevenLabs de doc (mode A).")
    voice_mp3 = os.path.join(work, "voice.mp3")
    if not (os.path.isfile(voice_mp3) and os.path.getsize(voice_mp3) > 1000):
        _log("TTS giong moi (ElevenLabs)...")
        eleven_tts.synth(story, vid, voice_mp3)
    music = _pick_music()
    if music:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", voice_mp3,
                        "-stream_loop", "-1", "-i", music, "-filter_complex",
                        "[1:a]volume=0.18[m];[0:a][m]amix=inputs=2:duration=first:normalize=0[a]",
                        "-map", "[a]", "-c:a", "aac", "-b:a", "192k", out], check=True)
    else:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", voice_mp3,
                        "-c:a", "aac", "-b:a", "192k", out], check=True)
    return out


def remake(video_path, out_path, n_scenes=6, clip_model="veo_3_1",
           audio_mode="B", voice_id=None, prompt_mode="gemini",
           style=DEFAULT_STYLE, lanes=None) -> dict:
    """Lam lai 1 video. audio_mode: 'B' giu audio goc | 'A' giong+nhac MOI.

    prompt_mode: 'gemini' (MAC DINH — Gemini xem NGUYEN video, mach truyen bam luong+loi thoai,
    1 call) | 'vision' (OpenAI nhin 1 frame dai dien/canh) | 'story' (LLM doc cot truyen).
    Fallback tu dong: gemini -> vision -> story (thieu GEMINI/OPENAI van chay). {ok,out}.
    """
    work = out_path + ".work"
    os.makedirs(work, exist_ok=True)
    if os.path.isfile(out_path) and os.path.getsize(out_path) > 1000:
        _prog("Video đã dựng xong từ trước → bỏ qua dựng, chỉ lên lịch")
        return {"ok": True, "out": out_path, "skipped": True}
    # (1) chep loi (cho audio/timing). (2) video goc -> moc slide THAT = ranh gioi/nhip canh
    # + LUU 1 frame dai dien/canh (goc_XX.jpg). (3) VISION nhin tung frame -> prompt bam KHUNG
    # GOC (thay story-driven lech khung). Canh da RIENG (dedup) nen khong trung anh.
    _prog("Đang chép lời thoại")
    segs, story = transcribe(video_path, work)
    _prog("Đang phân tích cảnh video gốc")
    # SO CANH theo ĐỘ DÀI video (~8s/canh = do dai clip veo) -> cua so canh khop clip, KHONG
    # keo cham. GOC BUG GIAT: cap cung =7 GOP NGUOC ~15 canh ngan thanh 7 cua so 18-22s ->
    # clip 8s bi setpts cham 2.2-2.75x -> motion bo + blend = giat. Nay cap = do_dai/8 (7..24).
    target_scenes = max(n_scenes, min(24, round(_dur(video_path) / 8.0)))
    bounds, windows, context = video_scene_bounds(video_path, work, max_scenes=target_scenes, segs=segs)
    n = len(bounds)
    _prog("Đang viết mô tả %d cảnh" % n)
    if prompt_mode == "gemini":
        # CHI Gemini (da retry 4 lan backoff trong gemini_generate). Gemini SAP -> RAISE ->
        # __main__ ghi item ERROR tren tool. KHONG rot OpenAI (da bo theo yeu cau user).
        _log("GEMINI: xem NGUYEN video -> prompt %d canh (KHONG fallback OpenAI)..." % n)
        scenes = gemini_scene_prompts(video_path, work, n, bounds=bounds, windows=windows, story=story)
    elif prompt_mode == "vision":             # tuy chon THU CONG (khong tu dong) — OpenAI per-frame
        scenes = vision_scene_prompts(work, n)
    else:                                     # 'story' — tuy chon THU CONG (OpenAI, tinh context lazy)
        frames = sorted(glob.glob(os.path.join(work, "goc_*.jpg")))
        context = _video_context(frames) if frames else ""
        scene_texts = _dialogue_per_window(segs, bounds, _dur(video_path))
        scenes = gen_scene_prompts(story, len(scene_texts), work, scene_texts=scene_texts, context=context)
    # canh co thoai -> nhan vat map may mieng nhu dang noi (khong lip-sync tung chu)
    apply_talk_motion(scenes, segs, bounds, _dur(video_path))
    clips = gen_media(scenes, work, clip_model, style=style, lanes=lanes)
    if audio_mode == "A":
        _prog("Đang tạo giọng đọc mới")
        audio_src = make_voice_audio(story, work, voice_id)   # story da co tu tren
    else:
        audio_src = video_path
    _prog("Đang ghép video + âm thanh")
    try:
        assemble(clips, audio_src, out_path, work, wins=windows)
    except Exception as e:
        # Ghep muot (xfade+minterpolate) sap tren may khach (vd libx264 loi -22) -> GHEP AN TOAN
        # (cat thang, threads 1) -> video VAN xong tu clip DA VE, khong mat credit.
        _prog("Ghép mượt lỗi (%s) → ghép AN TOÀN cắt thẳng (giữ clip đã vẽ)" % str(e)[:70])
        _assemble_simple(clips, audio_src, out_path, work, wins=windows)
    return {"ok": True, "out": out_path, "mode": audio_mode}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--scenes", type=int, default=6)
    ap.add_argument("--clip", default="veo_3_1")
    ap.add_argument("--audio", default="B")           # B giu tieng goc | A giong+nhac moi
    ap.add_argument("--prompt-mode", default="gemini") # gemini (xem nguyen video, MAC DINH) | vision (frame goc) | story
    ap.add_argument("--style", default=DEFAULT_STYLE)  # real (giong that) | cartoon (hoat hinh)
    ap.add_argument("--item-id", default="")           # ghi tien trinh vao fb_pipeline
    a = ap.parse_args()

    item = a.item_id

    def _st(status, **kw):
        if not item:
            return
        try:
            import fb_pipeline
            fb_pipeline.update(item, status=status, **kw)
        except Exception:
            pass

    _st("remaking", step="chép lời + sinh cảnh + vẽ ảnh")
    try:
        res = remake(a.video, a.out, a.scenes, a.clip, a.audio,
                     prompt_mode=a.prompt_mode, style=a.style)
    except Exception as exc:
        _st("error", step="", error=str(exc)[:200])
        print("KETQUA:", json.dumps({"ok": False, "error": str(exc)[:200]},
                                    ensure_ascii=False), flush=True)
        raise
    if res.get("ok"):
        _st("done", step="", out=res.get("out", ""))
    else:
        _st("error", step="", error=str(res)[:200])
    print("KETQUA:", json.dumps(res, ensure_ascii=False), flush=True)
