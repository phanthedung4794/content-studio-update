"""
Dang REEL len Facebook Page qua Graph API chinh thuc (video_reels 3 pha).
Ho tro DANG NGAY (PUBLISHED) hoac LEN LICH (SCHEDULED + scheduled_publish_time).

DA NGHIEM THU THAT (canary): upload 71MB -> post_id 122111192541387639,
hen gio 14:00 19/07 tren page "Goc Nho Binh Yen". Can quyen pages_manage_posts.

Reel yeu cau: MP4, 9:16, 3-90s, >=720p. Lich: 10 phut -> 30 ngay.

Token: PAGE access token (lay tu /me/accounts). System User token cho ben.
KHONG log token ra ngoai.
"""
import json
import os
import re
import time
import urllib.parse
import urllib.request

GRAPH = "https://graph.facebook.com/v19.0"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120 Safari/537.36"

# ── Don CAPTION goc truoc khi dang lai (khong mang link/quang ba kenh nguon sang page minh) ──
_URL_RE = re.compile(r"(?i)(?:https?://|www\.)\S+")
# Link rut gon / shop / affiliate viet KHONG co http:// (vd s.shopee.vn/xxxx)
_BARELINK_RE = re.compile(
    r"(?i)\b(?:s\.shopee\.vn|shopee\.vn|shp\.ee|s\.lazada\.vn|lazada\.vn|"
    r"t\.co|bit\.ly|vt\.tiktok\.com|tiktok\.com/t|taobao|1688\.com)\S*")
# Hashtag TU-QUANG-BA / thuong mai cua kenh nguon -> bo; giu tag chu de.
_TAG_BLOCK = {"xaykenh", "kiemtiennoidung", "kiemtientunoidung", "kiemtien",
              "kiemtientn", "reels", "reel", "review", "affiliate", "shopee",
              "tiktokshop", "capcut"}
# Chan CA HO tag theo tien to (vd viral -> viralvideo). (xuhuong KHONG chan — la tag ta MUON.)
_TAG_BLOCK_PREFIX = ("viral", "fyp", "foryou")
# Tag TU THEM vao moi tut dang lai (cau xu huong). Them 1 lan, khong nhan doi.
_APPEND_TAGS = ["#xuhuong", "#viral"]
# Thay cum mo dau "tuoi tho 8x 9x" (dau dong) bang "Ngay ay" — theo yeu cau nguoi dung.
_OPENER_RE = re.compile(r"(?im)^([ \t]*)tuổi\s+thơ\s+8x\s*9x", re.UNICODE)
# DONG QUANG BA KENH NGUON (ten kenh / keu goi theo doi) -> BO ca dong; giu loi ke chuyen.
_CHANNEL_LINE_RE = re.compile(
    r"(?im)^.*\b(?:k[eê]nh\s+youtube|k[eê]nh\s+tiktok|đăng\s*k[ýy]\s*k[eê]nh|"
    r"theo\s*d[õo]i\s*(?:k[eê]nh|ủng\s*hộ)|like\s*(?:&|và|va)?\s*share|subscribe|"
    r"follow\s|fanpage|nguồn\s*:|credit\s*:|st\s*:|sưu\s*tầm).*$")
_HANDLE_RE = re.compile(r"@[\w.]+")


def clean_caption(text: str, add_tags: bool = True) -> str:
    """Loai LINK (Shopee/rut gon/shop) + hashtag/dong QUANG BA kenh nguon; giu loi + tag chu de.
    add_tags=True -> tu them tag cau xu huong (_APPEND_TAGS). Dat False khi con viet lai viral (viral_caption)."""
    t = text or ""
    t = _URL_RE.sub("", t)
    t = _BARELINK_RE.sub("", t)
    t = _CHANNEL_LINE_RE.sub("", t)        # bo dong quang ba kenh (Kenh Youtube, dang ky...)
    t = _HANDLE_RE.sub("", t)              # bo @handle kenh nguon

    def _tag(m):
        w = m.group(1).lower()
        if w in _TAG_BLOCK or any(w.startswith(p) for p in _TAG_BLOCK_PREFIX):
            return ""
        return m.group(0)
    t = re.sub(r"#(\w+)", _tag, t, flags=re.UNICODE)
    # don khoang trang / dong trong thua sau khi cat
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r" *\n *", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    t = t.strip()
    # "Tuổi thơ 8x 9x ..." (dau dong) -> "Ngày ấy ..."
    t = _OPENER_RE.sub(r"\1Ngày ấy", t)
    # them tag cau xu huong (bo qua tag da co san, khong phan biet hoa thuong)
    if add_tags:
        low = t.lower()
        extra = [tag for tag in _APPEND_TAGS if tag.lower() not in low]
        if extra:
            t = (t + "\n" + " ".join(extra)).strip()
    return t


def ensure_trend_tags(text: str) -> str:
    """Bao dam caption LUON co #xuhuong + #viral (dedup, khong phan biet hoa thuong).
    Dung SAU viral_caption (Gemini viet lai) — Gemini co the KHONG kem 2 tag ta muon."""
    t = (text or "").strip()
    low = t.lower()
    extra = [tag for tag in _APPEND_TAGS if tag.lower() not in low]
    if not extra:
        return t
    return (t + "\n" + " ".join(extra)).strip() if t else " ".join(extra)


def _post(url, data=None, headers=None, raw=None, timeout=300):
    body = raw if raw is not None else (
        urllib.parse.urlencode(data).encode() if data else None)
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"User-Agent": UA, **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": True, "http": e.code, "body": e.read().decode()[:400]}
    except Exception as e:
        return {"error": True, "exc": str(e)[:200]}


def _get(url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": True, "http": e.code, "body": e.read().decode()[:400]}
    except Exception as e:
        return {"error": True, "exc": str(e)[:200]}


def publish_reel(page_id: str, page_token: str, video_path: str,
                 description: str = "", scheduled_ts: int = None) -> dict:
    """Dang 1 reel. scheduled_ts=None -> dang ngay; co -> len lich (unix seconds).

    Tra ve {ok, post_id/video_id, ...} hoac {ok:False, error}.
    """
    if not os.path.isfile(video_path):
        return {"ok": False, "error": "khong thay file video: %s" % video_path}
    size = os.path.getsize(video_path)

    # PHA 1: start
    r1 = _post("%s/%s/video_reels" % (GRAPH, page_id),
               {"upload_phase": "start", "access_token": page_token})
    if r1.get("error") or not r1.get("upload_url"):
        return {"ok": False, "phase": "start", "error": r1}
    video_id = r1["video_id"]
    upload_url = r1["upload_url"]

    # PHA 2: upload binary (rupload.facebook.com)
    with open(video_path, "rb") as f:
        blob = f.read()
    r2 = _post(upload_url, raw=blob, headers={
        "Authorization": "OAuth " + page_token,
        "offset": "0",
        "file_size": str(size),
        "Content-Type": "application/octet-stream",
    }, timeout=900)
    if r2.get("error") or not r2.get("success"):
        return {"ok": False, "phase": "upload", "video_id": video_id, "error": r2}

    # PHA 3: finish (publish ngay hoac len lich)
    data = {"upload_phase": "finish", "video_id": video_id,
            "access_token": page_token, "description": description or ""}
    if scheduled_ts:
        data["video_state"] = "SCHEDULED"
        data["scheduled_publish_time"] = str(int(scheduled_ts))
    else:
        data["video_state"] = "PUBLISHED"
    r3 = _post("%s/%s/video_reels" % (GRAPH, page_id), data)
    if r3.get("error") or not r3.get("success"):
        return {"ok": False, "phase": "finish", "video_id": video_id, "error": r3}

    return {"ok": True, "video_id": video_id,
            "post_id": r3.get("post_id"),
            "scheduled_ts": int(scheduled_ts) if scheduled_ts else None}


def reel_status(video_id: str, page_token: str) -> dict:
    """Kiem trang thai xu ly/len lich cua reel."""
    url = "%s/%s?fields=status&access_token=%s" % (
        GRAPH, video_id, urllib.parse.quote(page_token))
    return _get(url)


def delete_reel(video_id: str, page_token: str) -> dict:
    """Huy/xoa reel (da lich hoac da dang) qua Graph API."""
    url = "%s/%s?access_token=%s" % (GRAPH, video_id, urllib.parse.quote(page_token))
    req = urllib.request.Request(url, method="DELETE", headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return {"ok": True, "resp": json.loads(r.read().decode())}
    except urllib.error.HTTPError as e:
        return {"ok": False, "http": e.code, "body": e.read().decode()[:300]}
    except Exception as e:
        return {"ok": False, "exc": str(e)[:200]}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--page-id", help="id page (lay token tu cache fb_graph)")
    ap.add_argument("--page", help="ten page trong pages.json (che do test)")
    ap.add_argument("--video", required=True)
    ap.add_argument("--desc", default="")
    ap.add_argument("--desc-file", help="doc mo ta tu file (uu tien)")
    ap.add_argument("--when-ts", type=int, default=0, help="unix giay; 0 = dang ngay")
    ap.add_argument("--in", dest="mins", type=int, default=0, help="dang sau N phut")
    ap.add_argument("--pages-json", default="pages.json")
    a = ap.parse_args()

    desc = a.desc
    if a.desc_file and os.path.isfile(a.desc_file):
        desc = open(a.desc_file, encoding="utf-8").read().strip()

    ts = None
    if a.when_ts:
        ts = a.when_ts
    elif a.mins > 0:
        ts = int(time.time()) + a.mins * 60

    if a.page_id:
        import fb_graph
        tok = fb_graph.page_token(a.page_id)
        if not tok:
            print(json.dumps({"ok": False, "error": "khong co token cho page_id (refresh cache truoc)"}))
            raise SystemExit(1)
        res = publish_reel(a.page_id, tok, a.video, desc, ts)
    else:
        pages = json.load(open(a.pages_json, encoding="utf-8"))
        pg = next(p for p in pages if p["name"] == a.page)
        res = publish_reel(pg["id"], pg["access_token"], a.video, desc, ts)
    print(json.dumps(res, ensure_ascii=False))
