# -*- coding: utf-8 -*-
"""
STATE — kho bền theo dõi tiến trình auto (Tầng 5).
Mỗi item auto: {id, page, link, reel, step, status, ts, post_id, error}.
status: queued | downloading | remaking | scheduling | done | error
Dùng bởi server (tạo entry) + fb_auto (cập nhật từng bước). Đọc bởi UI.
"""
import json
import os
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STORE = os.path.join(ROOT, "facebook", "_pipeline.json")
LOCK = STORE + ".lock"


def _with_lock(fn):
    """Serialize ĐỌC-SỬA-GHI qua NHIỀU tiến trình (N remake song song cùng ghi 1 file).

    GOC BUG (2026-07-24): update() = _load() (đọc cả list) -> sửa 1 item -> _save() (ghi cả
    list). 5 tiến trình cùng làm -> tiến trình sau đọc TRƯỚC khi tiến trình trước ghi ->
    ghi đè MẤT cập nhật -> item chạy dở nhìn như 'kẹt/đang xếp hàng'. Càng nhiều job song
    song càng lộ. Khoá bằng lock-file atomic (O_CREAT|O_EXCL) -> chỉ 1 tiến trình sửa 1 lúc.
    Lock cũ >20s (tiến trình chết khi đang giữ) -> cướp để không kẹt vĩnh viễn."""
    fd = None
    for _ in range(400):                         # ~ tối đa 12s chờ khoá
        try:
            fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_RDWR)
            break
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(LOCK) > 20:   # khoá mồ côi -> cướp
                    os.remove(LOCK)
                    continue
            except OSError:
                pass
            time.sleep(0.03)
    try:
        return fn()
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
            try:
                os.remove(LOCK)
            except OSError:
                pass


def _load() -> list:
    if os.path.isfile(STORE):
        try:
            with open(STORE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []


def _save(items: list):
    """Ghi bền trên Windows: tmp RIÊNG mỗi tiến trình + thử lại os.replace nhiều lần.

    server (tiến trình chính) và fb_auto (tiến trình con) cùng ghi _pipeline.json.
    Windows chặn đổi tên (WinError 5) nếu file đích đang bị tiến trình khác MỞ ĐỌC
    (server đọc /pipeline, antivirus, indexer). Thử lại vài lần -> gần như luôn qua;
    cùng lắm ghi thẳng (không nguyên tử nhưng KHÔNG làm sập cả lần chạy auto).
    """
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    data = json.dumps(items[-500:], ensure_ascii=False, indent=1)   # giữ 500 gần nhất
    tmp = "%s.%d.tmp" % (STORE, os.getpid())        # tmp riêng -> 2 tiến trình không đụng
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(data)
    for i in range(12):                              # ~ tổng < 1.2s
        try:
            os.replace(tmp, STORE)
            return
        except OSError:                              # WinError 5/32: đích đang bị mở
            time.sleep(0.05 * (i + 1))
    # vẫn kẹt -> ghi thẳng (bỏ atomic), dọn tmp
    try:
        with open(STORE, "w", encoding="utf-8") as f:
            f.write(data)
    except OSError:
        pass
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def add(item_id: str, page: str, link: str, **extra) -> str:
    """extra: page_id, audio, clip, when_ts... (để RETRY dựng lại được).
    `cts` = giờ TẠO (bất biến, KHÁC `ts` bị update() ghi đè mỗi lần đổi trạng thái) —
    dùng để đếm 'số bài đã làm từ lúc bắt đầu lượt' cho đúng."""
    now = int(time.time())

    def _do():
        items = _load()
        items.append({"id": item_id, "page": page, "link": link, "reel": "",
                      "step": "queued", "status": "queued", "ts": now, "cts": now,
                      "post_id": "", "error": "", **extra})
        _save(items)
    _with_lock(_do)
    return item_id


def get(item_id: str) -> dict:
    for it in _load():
        if it.get("id") == item_id:
            return it
    return {}


def update(item_id: str, **fields):
    def _do():
        items = _load()
        for it in items:
            if it.get("id") == item_id:
                it.update(fields)
                it["ts"] = int(time.time())
                break
        _save(items)
    _with_lock(_do)


def recent(n: int = 60) -> list:
    return list(reversed(_load()))[:n]


def summary() -> dict:
    items = _load()
    c = {}
    for it in items:
        c[it.get("status", "?")] = c.get(it.get("status", "?"), 0) + 1
    return {"total": len(items), "by_status": c}


if __name__ == "__main__":
    print(json.dumps({"summary": summary(), "recent": recent(5)}, ensure_ascii=False, indent=1))
