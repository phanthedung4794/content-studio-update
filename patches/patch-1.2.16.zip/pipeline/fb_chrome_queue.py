# -*- coding: utf-8 -*-
"""
KHO CHO + WATCHDOG cho duong dang bang CHROME.

Video lam xong KHONG dang ngay: xep vao kho cho kem GIO HEN (tinh bang fb_slots).
Watchdog tick moi 60s, den gio thi mo Chrome dang.

VI SAO CAN MUTEX: chi co 1 Chrome. N page chay song song, xong cung luc -> neu bang
nao cung mo composer thi tranh nhau 1 trinh duyet. Watchdog xu ly TUAN TU trong 1
luong duy nhat -> khong bao gio 2 bai dang cung luc.

CHINH SACH TRE (may tat qua gio hen):
  tre <= LATE_OK (mac dinh 2h)  -> DANG BU NGAY khi may bat lai
  tre >  LATE_OK               -> DOI sang gio hen ke tiep + ghi ro ly do (khong im lang bo)

Kho: facebook/_chrome_queue.json  (co lock-file, nhieu tien trinh ghi khong mat update
     — bai hoc pipeline-clobber 2026-07-24)
"""
import json
import os
import re
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.environ.get("CS_FB_ROOT") or os.path.join(ROOT, "facebook")
STORE = os.path.join(FB_ROOT, "_chrome_queue.json")
LOCK = STORE + ".lock"
SHOTS = os.path.join(FB_ROOT, "_chrome_shots")

LATE_OK = int(os.environ.get("CS_CHROME_LATE_OK", str(2 * 3600)))    # tre <=2h thi dang bu
TICK = int(os.environ.get("CS_CHROME_TICK", "60"))                   # nhip watchdog (giay)

_run_lock = threading.Lock()        # MUTEX: chi 1 bai dang bang Chrome tai 1 thoi diem
_thread = None
_stop = threading.Event()


# ─────────────────────────── kho (lock-file) ───────────────────────────
def _with_lock(fn, tries: int = 60):
    """Chay fn() khi giu lock-file (chong 2 tien trinh doc-sua-ghi de len nhau)."""
    os.makedirs(FB_ROOT, exist_ok=True)
    for _ in range(tries):
        try:
            fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_RDWR)
            try:
                return fn()
            finally:
                os.close(fd)
                try:
                    os.remove(LOCK)
                except OSError:
                    pass
        except FileExistsError:
            time.sleep(0.1)
    return fn()                      # ket lock qua lau -> cu chay (tha sai con hon treo)


def _load() -> list:
    try:
        with open(STORE, encoding="utf-8-sig") as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except Exception:
        return []


def _save(items: list) -> None:
    os.makedirs(FB_ROOT, exist_ok=True)
    tmp = STORE + ".%d.tmp" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=1)
    for _ in range(12):
        try:
            os.replace(tmp, STORE)
            return
        except OSError:
            time.sleep(0.15)
    with open(STORE, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=1)


def add(page_id: str, page_name: str, video: str, when_ts: int, caption: str = "",
        title: str = "", tags=None, item_id: str = "", audio_mode: str = "original_only",
        kind: str = "reel") -> dict:
    """Xep 1 bai vao kho cho dang bang Chrome. Tra ve item.

    kind='reel'  -> `video` la file mp4 (composer Reels)
    kind='photo' -> `video` la file anh (composer bai viet anh)
    """
    it = {"id": "cq_%d_%s" % (int(time.time() * 1000), page_id[-6:]),
          "page_id": page_id, "page_name": page_name or page_id,
          "kind": kind, "video": video, "when_ts": int(when_ts),
          "caption": caption, "title": title, "tags": list(tags or []),
          "audio_mode": audio_mode,
          "pipeline_id": item_id,              # de cap nhat nguoc ve tab San xuat
          "status": "waiting",                 # waiting | posting | done | error
          "step": "chờ tới giờ đăng", "error": "", "cts": int(time.time())}

    def _do():
        items = _load()
        items.append(it)
        _save(items)
        return it
    return _with_lock(_do)


def update(item_id: str, **kw) -> None:
    def _do():
        items = _load()
        for x in items:
            if x.get("id") == item_id:
                x.update(kw)
                break
        _save(items)
    _with_lock(_do)


def delete(ids) -> int:
    ids = set(ids or [])

    def _do():
        items = _load()
        keep = [x for x in items if x.get("id") not in ids]
        n = len(items) - len(keep)
        _save(keep)
        return n
    return _with_lock(_do)


def all_items() -> list:
    return _load()


def due(now: int = 0) -> list:
    """Cac item DEN GIO can dang (cu nhat truoc)."""
    now = int(now or time.time())
    return sorted([x for x in _load()
                   if x.get("status") == "waiting" and int(x.get("when_ts") or 0) <= now],
                  key=lambda x: int(x.get("when_ts") or 0))


def _caption_with_tags(caption: str, tags) -> str:
    """Ghep hashtag vao cuoi tus (cho BAI ANH — khong co o 'The' rieng nhu Reels).

    Luon co #xuhuong #viral (giong duong video, xem fb_publish.ensure_trend_tags),
    khong nhan doi the da co san trong tus.
    """
    cap = (caption or "").rstrip()
    have = {t.lower().lstrip("#") for t in re.findall(r"#(\w+)", cap)}
    out = []
    for t in list(tags or []) + ["xuhuong", "viral"]:
        t = str(t).lstrip("#").strip()
        if t and t.lower() not in have:
            have.add(t.lower())
            out.append("#" + t)
    return (cap + "\n\n" + " ".join(out)).strip() if out else cap


# ─────────────────────────── dang 1 item ───────────────────────────
def post_one(it: dict, on_done=None) -> dict:
    """Dang 1 item bang Chrome. GIU MUTEX -> khong bao gio 2 bai cung luc."""
    import fb_chrome_post
    with _run_lock:
        update(it["id"], status="posting", step="đang mở Chrome đăng", error="")
        try:
            if (it.get("kind") or "reel") == "photo":
                # BAI VIET ANH khong co o "The" rieng nhu Reels -> hashtag phai nam
                # TRONG noi dung, neu khong bai anh se KHONG co hashtag nao (khac video).
                r = fb_chrome_post.post_photo(
                    it["page_id"], it["video"],
                    caption=_caption_with_tags(it.get("caption") or "", it.get("tags") or []),
                    shot_dir=SHOTS)
            else:
                r = fb_chrome_post.post_reel(
                    it["page_id"], it["video"], caption=it.get("caption") or "",
                    title=it.get("title") or "", tags=it.get("tags") or [],
                    audio_mode=it.get("audio_mode") or "original_only", shot_dir=SHOTS)
            update(it["id"], status="done", step="đã đăng bằng Chrome", error="")
            if on_done:
                try:
                    on_done(it, None)
                except Exception:
                    pass
            return {"ok": True, "id": it["id"], **r}
        except Exception as exc:
            msg = "%s: %s" % (type(exc).__name__, exc)
            update(it["id"], status="error", step="lỗi đăng bằng Chrome", error=msg[:400])
            if on_done:
                try:
                    on_done(it, msg)
                except Exception:
                    pass
            return {"ok": False, "id": it["id"], "error": msg}


def _handle_late(it: dict, now: int) -> bool:
    """Xu ly item TRE. True = cu dang bu ngay; False = da doi lich, bo qua luot nay."""
    late = now - int(it.get("when_ts") or 0)
    if late <= LATE_OK:
        return True
    # Tre qua lau (may tat) -> DOI sang mai cung gio, ghi ro (khong im lang bo bai)
    new_ts = int(it["when_ts"]) + 86400 * max(1, (late // 86400) + 1)
    update(it["id"], when_ts=new_ts,
           step="trễ %.1f giờ (máy tắt) → dời sang %s"
                % (late / 3600.0, time.strftime("%H:%M %d/%m", time.localtime(new_ts))))
    return False


def tick(now: int = 0, on_done=None) -> dict:
    """1 nhip watchdog: dang MOI item den gio, TUAN TU. Tra thong ke."""
    now = int(now or time.time())
    posted, failed, moved = 0, 0, 0
    for it in due(now):
        if _stop.is_set():
            break
        if not _handle_late(it, now):
            moved += 1
            continue
        r = post_one(it, on_done=on_done)
        if r.get("ok"):
            posted += 1
        else:
            failed += 1
    return {"posted": posted, "failed": failed, "moved": moved}


# ─────────────────────────── watchdog ───────────────────────────
def start(on_done=None) -> bool:
    """Bat vong nen. Goi 1 lan luc server khoi dong."""
    global _thread
    if _thread and _thread.is_alive():
        return False
    _stop.clear()

    def _loop():
        while not _stop.is_set():
            try:
                st = tick(on_done=on_done)
                if st["posted"] or st["failed"] or st["moved"]:
                    print("[chrome-queue] %s" % st, flush=True)
            except Exception as exc:
                print("[chrome-queue] loi vong nen: %s" % exc, flush=True)
            _stop.wait(TICK)

    _thread = threading.Thread(target=_loop, name="chrome-queue", daemon=True)
    _thread.start()
    return True


def stop() -> None:
    _stop.set()


def alive() -> bool:
    return bool(_thread and _thread.is_alive())


if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"
    if cmd == "list":
        for x in all_items():
            print("%-22s %-16s %-9s %s | %s" % (
                x["id"], x.get("page_name", "")[:16], x.get("status"),
                time.strftime("%H:%M %d/%m", time.localtime(x.get("when_ts") or 0)),
                (x.get("error") or x.get("step") or "")[:50]))
    elif cmd == "tick":
        print(json.dumps(tick(), ensure_ascii=False))
