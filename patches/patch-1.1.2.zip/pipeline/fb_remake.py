# -*- coding: utf-8 -*-
"""
Lam lai video TONG QUAT cho reel BAT KY (khong hardcode prompt).
Quy trinh (dua tren scratchpad da nghiem thu 1 video):
  1. chep loi (faster-whisper) -> cot truyen + moc cau
  2. video goc -> chia canh (dedup/gop) + LUU 1 frame dai dien/canh (goc_XX.jpg)
  3. VISION (GPT-4o nhin tung frame dai dien) -> prompt anh BAM KHUNG GOC (mac dinh).
     Fallback 'story': LLM doc cot truyen -> N canh (lech khung, chi khi thieu OPENAI/frame)
  4. gommo_client -> anh (banana_2 vip 1k) + clip i2v (veo fast / kling / Ken Burns)
  5. ghep: crossfade + lam cham cho day cua so (bam nhip video goc) + long AUDIO GOC (che do B)
Che do A (giong+nhac moi) CHUA lam o day -> tam dung che do B.

Ket qua: out_path (mp4 doc). IDEMPOTENT theo thu muc work (co roi thi bo qua).
CHUA CHAY THAT qua orchestration (ton credit) -> can nghiem thu lan dau cung nguoi dung.
"""
import base64
import glob
import json
import os
import re
import shutil
import subprocess
import time

import requests

from gommo_client import GommoClient, download
import script_gen

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MUSIC_DIR = os.path.join(ROOT, "assets", "music")

# STYLE trung tinh (KHONG khoa noi dung/boi canh) -> ap cho MOI nguon. Noi dung/boi canh
# do VISION mo ta tu chinh video goc (thanh pho/que/dem... deu dung). Chi ap phong cach ve.
# CHON qua tham so `style`: 'real' (giong that = MAC DINH, hop page anh nguoi that) |
# 'cartoon' (mau nuoc hoat hinh, hop page hoai niem). Truoc day HARDCODE 'cartoon' ->
# moi page deu ra hoat hinh; gio chon duoc theo nguon.
# DANH SACH KIEU ANH (khop 79AI, dong bo voi image_post.py). Value = duoi prompt them vao.
_TAIL = " Vertical 9:16 composition, full bleed edge to edge. No text, no words, no letters."
STYLES = {
    "real": (" Photorealistic, realistic natural lighting, true-to-life skin and textures, "
             "candid documentary photography look, sharp focus, high detail, cinematic color." + _TAIL),
    "cartoon": (" Hand-painted watercolor illustration, soft warm cinematic lighting, fine "
                "painterly texture, gentle nostalgic tone." + _TAIL),
    "hoat_hinh": (" cute simple hand-drawn cartoon illustration, thin clean black ink outlines, "
                  "adorable characters, gentle expressions, soft warm color accents, cozy tender mood." + _TAIL),
    "chan_dung_dien_anh": (" cinematic portrait, dramatic moody lighting, shallow depth of field, "
                           "film still, ultra detailed, atmospheric." + _TAIL),
    "anime": (" Japanese anime style, clean crisp line art, cel shading, expressive eyes, "
              "vibrant colors, studio anime key visual." + _TAIL),
    "mau_nuoc": (" soft watercolor painting, delicate translucent washes, textured watercolor "
                 "paper, gentle bleeding colors, hand painted." + _TAIL),
    "pixar_3d": (" 3D animated character render, Pixar Disney style, soft global illumination, "
                 "cute rounded shapes, subsurface scattering, high quality render." + _TAIL),
    "son_dau": (" classical oil painting, visible textured brush strokes, rich warm tones, "
                "canvas texture, painterly." + _TAIL),
    "ngam_doi": (" minimalist 2D cartoon illustration, STRICTLY grayscale black white and gray "
                 "only, no color, simple rounded egg-shaped heads with minimal facial features, "
                 "a dramatic warm glowing spotlight halo behind the characters, long dark shadows "
                 "on the floor, dark vignette background, emotional cinematic mood, clean thin "
                 "black ink line art." + _TAIL),
    "theo_mo_ta": (_TAIL),
}
# Nhan tieng Viet cho o chon "Kieu anh" (UI doc qua endpoint /fb-post/styles).
STYLE_LABELS = {
    "real": "Thật (giống ảnh thật)", "cartoon": "Màu nước hoài niệm",
    "hoat_hinh": "Hoạt hình dễ thương", "chan_dung_dien_anh": "Chân dung điện ảnh",
    "anime": "Anime Nhật Bản", "mau_nuoc": "Tranh màu nước",
    "pixar_3d": "Hoạt hình 3D (Pixar)", "son_dau": "Tranh sơn dầu",
    "ngam_doi": "Đen trắng xúc động (Ngẫm Đời)",
    "theo_mo_ta": "Theo mô tả (không thêm)",
}
DEFAULT_STYLE = "real"
STYLE = STYLES["cartoon"]   # tuong thich nguoc (code cu con tham chieu STYLE)
BLEED = (" Full bleed, fills the entire vertical 9:16 frame edge to edge, no black bars, "
         "no border, no vignette, no letterbox, no matte.")

# So luong 79AI xu SONG SONG (concurrency/account). Do that account credit ~2 lane;
# mua subscription (12 lane) thi dat REMAKE_LANES=12. Dung cho ca ve anh lan i2v.
LANES = max(1, int(os.environ.get("REMAKE_LANES", "2")))

# Tham so BAT BUOC tung model i2v (do that tu 79AI: kling can duration, seedance can
# resolution, hailuo khong nhan 9:16). Dung cho FALLBACK khi model chinh het tai nguyen.
VIDEO_PARAMS = {
    # GROK Heavy (server grokai RIENG -> khong nghen nhu veo; do that: 97s, giu nhan vat, motion
    # tro chuyen tot, 1000cr/720p6s). Mode 'normal' (tranh extremely-crazy/spicy). i2v (startImage).
    "grok_video_heavy": {"mode": "normal", "resolution": "720p", "duration": "6"},
    # veo FAST (khong Lite): cung model/chat luong, uu tien CAO -> nhanh + do treo (+~50% gia).
    # DO THAT 2026-07: veo 1080p -> LOI backend #453422 (that bai that). 720p CHAY ngon
    # (SUCCESSFUL 165s, 0 credit). Grok cung 720p OK. -> giu 720p cho ca 2 (on dinh + free).
    "veo_3_1":         {"mode": "fast", "resolution": "720p", "duration": "8"},
    "hailuo_2_3":      {"mode": "fast", "resolution": "720p", "duration": "6"},
    "kling_video_2_6": {"mode": "standard", "duration": "8"},
    "kling_video_2_5": {"mode": "standard", "duration": "8"},
}
# Chuoi fallback i2v khi model chinh treo/loi/NOT_RESOURCES. GROK dau (server rieng, khong nghen)
# -> veo(fast) -> hailuo -> kling. BO wan_2_2 (KHONG i2v). Het chuoi van treo/fail -> Ken Burns.
# CHI 2 model GOI Starter(Video) bao FREE theo quota: veo_3_1 (xin nhat, 720p) truoc,
# grok_video_heavy (720p) du phong. Ca 2 het/ket -> Ken Burns (local, 0 quota).
# KHONG dua hailuo/kling vao day: NGOAI goi -> se tru CREDIT that (khong free).
FALLBACK_CHAIN = ["veo_3_1", "grok_video_heavy"]
# Moi model i2v cho toi da bao lau (giay) truoc khi bo -> model sau -> Ken Burns. Render lite
# khoe ~7' nen de 10' (>7' la treo that). Truoc 25' -> "treo" lau moi chiu roi.
I2V_WAIT = int(os.environ.get("REMAKE_I2V_WAIT", "600"))


def _log(m):
    print(m, flush=True)


def _dur(path):
    """Do dai (giay) 1 file media qua ffprobe."""
    return float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", path]).decode().strip())


def transcribe(video_path, work):
    """Chep loi -> [{start,end,text}] + story."""
    tj = os.path.join(work, "transcript.json")
    if os.path.isfile(tj):
        segs = json.load(open(tj, encoding="utf-8"))
    else:
        from faster_whisper import WhisperModel
        wav = os.path.join(work, "audio.wav")
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", video_path,
                        "-ac", "1", "-ar", "16000", wav], check=True)
        m = WhisperModel("small", device="cpu", compute_type="int8")
        segs = [{"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()}
                for s in m.transcribe(wav, language="vi", vad_filter=True)[0]]
        json.dump(segs, open(tj, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    story = " ".join(s["text"] for s in segs)
    return segs, story


def gen_scene_prompts(story, n_scenes, work, scene_texts=None, context=None):
    """LLM DOC CA TRUYEN -> N canh {img, mot} (nhat quan nhan vat, KHAC nhau tung canh).

    scene_texts (hybrid): N doan LOI THOAI theo thu tu thoi gian -> moi canh minh hoa DUNG
    doan cua no (khop loi + nhip video). None -> chia deu tu cot truyen.
    context: 1 cau boi canh TONG rut tu video goc (era/vung/khong khi) -> grounding, tranh
    westernize; ghim vao moi canh. Cache ra work/scenes.json.
    """
    pf = os.path.join(work, "scenes.json")
    if os.path.isfile(pf):
        return json.load(open(pf, encoding="utf-8"))
    ctx = (context or "").strip()
    system = (
        "Ban la dao dien hinh anh cho video ke chuyen hoai niem Viet Nam. Doc HET cot truyen "
        "roi dung hinh cho tung canh. QUY TAC BAT BUOC: (1) Khoa DANH TINH nhan vat — moi nhan "
        "vat co mo ta ngoai hinh CO DINH (tuoi, toc, trang phuc, dac diem) lap lai Y HET o moi "
        "canh co nhan vat do (tranh moi canh ve mot kieu). (2) Moi canh KHAC NHAU ro rang "
        "(khoanh khac/goc nhin/hanh dong khac) — TUYET DOI khong lap lai cung mot canh. "
        "(3) Giu dung boi canh van hoa, khong doi sang phuong Tay. Tra ve JSON thuan tuy."
        + (" Boi canh tong the video: %s." % ctx if ctx else ""))
    if scene_texts:
        blocks = "\n".join('%d. "%s"' % (i + 1, (t or "").strip()) for i, t in enumerate(scene_texts))
        want = len(scene_texts)
        user = (f"COT TRUYEN DAY DU (loi ke/thoai ca video):\n\"{story}\"\n\n"
                f"Video co {want} canh LIEN TIEP theo thoi gian, moi canh ung 1 doan loi:\n{blocks}\n\n"
                f"Voi MOI canh tao 1 hinh minh hoa DUNG noi dung/khong khi doan loi do, nhat "
                f"quan trong ca mach truyen:\n"
                f"- img: mo ta ANH tieng Anh (nhan vat + hanh dong + boi canh khop doan loi; "
                f"lap lai mo ta nhan vat de khop cac canh khac)\n"
                f"- mot: mo ta CHUYEN DONG nhe tieng Anh cho i2v (cham, khong rung lac)\n"
                f'Tra ve JSON: {{"scenes":[{{"img":"...","mot":"..."}}, ...]}} — DUNG {want} canh, '
                f"dung thu tu tren, khong giai thich.")
    else:
        want = n_scenes
        user = (f"Cot truyen (loi thoai/ke): \"{story}\"\n\n"
                f"Chia thanh {n_scenes} canh KE TIEP theo dien bien, MOI canh KHAC nhau. Moi canh cho:\n"
                f"- img: mo ta ANH tieng Anh (nhan vat + boi canh + hanh dong; lap lai mo ta nhan vat)\n"
                f"- mot: mo ta CHUYEN DONG nhe tieng Anh cho i2v (cham, khong rung lac)\n"
                f'Tra ve JSON: {{"scenes":[{{"img":"...","mot":"..."}}, ...]}} — dung {n_scenes} canh, '
                f"khong giai thich.")
    txt = script_gen._chat_text(system, user, max_tokens=2200)
    m = re.search(r"\{.*\}", txt, re.S)
    data = json.loads(m.group(0)) if m else {"scenes": []}
    scenes = data.get("scenes", [])[:want]
    if len(scenes) < want:
        raise RuntimeError("LLM tra it canh hon yeu cau (%d/%d)" % (len(scenes), want))
    if ctx:                              # ghim boi canh tong vao moi canh (grounding chac)
        for sc in scenes:
            sc["img"] = "%s. %s" % (ctx, sc.get("img", ""))
    json.dump(scenes, open(pf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return scenes


# ── PHAN TICH VIDEO GOC (video-driven, TONG QUAT moi noi dung) ──────────────
def _dhash(path, size=8):
    """Hash tri giac 1 anh -> so 64 bit (so sanh 2 frame co khac 'slide' khong)."""
    from PIL import Image
    img = Image.open(path).convert("L").resize((size + 1, size))
    px = list(img.getdata())
    bits = 0
    for r in range(size):
        for c in range(size):
            bits = (bits << 1) | (1 if px[r * (size + 1) + c] < px[r * (size + 1) + c + 1] else 0)
    return bits


def _ham(a, b):
    return bin(a ^ b).count("1")


# Prompt MEM (khong hoi tuoi/gioi/sac toc tung nguoi -> tranh bo loc tu choi). Boi canh
# van GIU (khong westernize) + BOI CANH TONG rut rieng tu video ghep vao -> giu chat Viet.
_CONTEXT_PROMPT = ("In ONE short English phrase, state the overall SETTING, ERA, region/culture and "
                   "mood of this video for consistent art direction (e.g. '1990s rural Vietnamese "
                   "countryside, warm nostalgic'). Output only the phrase.")


def _openai_vision(text, img_b64_list, max_tokens=400, timeout=90):
    """1 loi goi GPT-4o vision (1+ anh + text). Tra text tra loi."""
    ok = os.environ.get("OPENAI_API_KEY", "").strip()
    if not ok:
        raise RuntimeError("Thieu OPENAI_API_KEY de phan tich video (vision).")
    content = [{"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,%s" % b}}
               for b in img_b64_list]
    content.append({"type": "text", "text": text})
    base = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/") + "/chat/completions"
    r = requests.post(base, json={"model": os.environ.get("OPENAI_MODEL") or "gpt-4o",
                                  "max_tokens": max_tokens, "messages": [{"role": "user", "content": content}]},
                      timeout=timeout, headers={"Authorization": "Bearer %s" % ok, "Content-Type": "application/json"})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()


def _b64(p):
    return base64.b64encode(open(p, "rb").read()).decode()


def _video_context(frame_paths):
    """Boi canh TONG cua video (video-derived, 1 cau) -> grounding cho moi canh."""
    try:
        return _openai_vision(_CONTEXT_PROMPT, [_b64(p) for p in frame_paths[:3]], max_tokens=60)
    except Exception:
        return ""


# ── VISION per-frame + SO DANG KY LUY TIEN: bam KHUNG GOC + nhat quan nhan vat/do vat/con vat ──
# VISION bam khung (do that: 2 dua dap xe -> ve 2 dua dap xe). Van de: ta MOI frame COO LAP ->
# cung 1 nguoi moi canh ve 1 kieu. GIAI: SO DANG KY LUY TIEN — duyet canh THEO THU TU; canh nao
# sinh them nhan vat/con vat/do vat MOI thi KHOA vao so; canh sau xuat hien lai thi tai dung DUNG
# mo ta da khoa. Moi canh chi ve dung thuc the co mat. Boi canh khoa MEM (chong drift Tay, doi
# khi chuyen cho). Vd: canh1 2 dua -> khoa; canh2 them 2 dua moi -> khoa them; canh3 them nguoi
# cha -> khoa cha; canh4 chi 4 dua canh1+2 -> hien dung 4 dua do.

# CHI lam diu vai tu goi cam (banana KHONG chan boy/girl). KHONG xoa boy/girl nua vi lam MAT
# gioi tinh -> anh ra sai gioi (anh ra nu). Giu boy/girl de model ve dung gioi.
_SOFTEN = [("cheekily", "gently"), ("grins", "smiles")]

# Chuyen dong nhe cho i2v: CHONG morph mat/drift (i2v hay ve lai mat -> anime "Naruto").
_MOTION = ("Gentle subtle motion: slight natural movement of the subject and a slow gentle "
           "camera push-in, cinematic and smooth. Keep faces, identities and composition "
           "stable; no morphing, no distortion, no shaking.")

# Canh CO thoai: nhan vat MAP MAY MIENG nhu dang noi chuyen (khong phai lip-sync tung chu, chi
# "trong nhu dang noi"). Van chong morph. Gan theo _dialogue_per_window (canh nao co loi).
_MOTION_TALK = ("The characters are talking to each other, their mouths moving as if speaking and "
                "smiling, with small natural head and hand gestures, as if having a real "
                "conversation; a slow gentle camera push-in, cinematic and smooth. Keep faces, "
                "identities and composition stable; no morphing, no distortion, no shaking.")


def apply_talk_motion(scenes, segs, bounds, adur):
    """Canh CO thoai -> mot MAP MAY MIENG (nhu dang noi); canh khong thoai -> mot nhe. Sua scenes tai cho."""
    texts = _dialogue_per_window(segs, bounds, adur)
    for i, sc in enumerate(scenes):
        has = bool(i < len(texts) and (texts[i] or "").strip())
        sc["mot"] = _MOTION_TALK if has else _MOTION
    return scenes

# Prompt duyet TUNG frame theo thu tu (co so dang ky hien tai) -> nhan dien thuc the co mat +
# khoa thuc the MOI + ta canh (bam khung). Gioi tinh ro (khong "anh ra nu"); khong nhan A/B/C.
_REG_PROMPT = (
    "This is frame %d of %d from ONE nostalgic 1990s rural Vietnamese video whose recurring "
    "characters, animals and objects must stay consistent across scenes.\n"
    "ALREADY REGISTERED entities (reuse each EXACTLY, do NOT change or re-describe its look):\n%s\n\n"
    "Look ONLY at THIS frame and return JSON with three keys:\n"
    '"present": array of the ID NUMBERS of already-registered entities that actually appear here.\n'
    '"new": array of entities that appear but are NOT yet registered; for each give '
    '{"kind":"person|animal|object","desc":"fixed canonical description"}. For a person state '
    "GENDER (a boy / a girl / a man / a woman), age, hair, face, build, and clothing WITH colors. "
    "For an animal/object give type, colors, shape, pattern.\n"
    '"scene": ONE paragraph to RECREATE this frame (poses, actions, setting/background, camera '
    "framing, colors, lighting, art style); refer to entities by what they are, do NOT restate their "
    "fixed appearance. 1990s rural Vietnamese, NOT European; do not mention any letters as visible text.\n"
    "Output ONLY the JSON, no preface.")


def _reg_lines(registry):
    return "\n".join("%d. [%s] %s" % (e["id"], e["kind"], e["desc"]) for e in registry) or "(none yet)"


def _soften(p):
    for a, b in _SOFTEN:
        p = re.sub(a, b, p, flags=re.I)
    return p


def _build_registry(frame_paths):
    """Duyet frame THEO THU TU -> SO DANG KY LUY TIEN. Tra (registry, per_scene).

    registry=[{id,kind,desc}] (khoa dan khi thuc the xuat hien LAN DAU); per_scene[i]=
    {present:[id...], scene:str}. Tuan tu (buoc i doc so sau i-1) nen KHONG song song.
    """
    registry, per_scene = [], []
    for i, fp in enumerate(frame_paths):
        prompt = _REG_PROMPT % (i + 1, len(frame_paths), _reg_lines(registry))
        try:
            txt = _openai_vision(prompt, [_b64(fp)], max_tokens=700)
            m = re.search(r"\{.*\}", txt, re.S)
            d = json.loads(m.group(0)) if m else {}
        except Exception as e:
            _log("  canh %d so-dang-ky loi: %s" % (i, str(e)[:60])); d = {}
        present = []
        for pid in (d.get("present") or []):
            try:
                pid = int(pid)
                if 1 <= pid <= len(registry):
                    present.append(pid)
            except Exception:
                pass
        nnew = 0
        for ne in (d.get("new") or []):                 # thuc the MOI -> khoa vao so
            if isinstance(ne, dict) and ne.get("desc"):
                nid = len(registry) + 1
                registry.append({"id": nid, "kind": (ne.get("kind") or "person"),
                                 "desc": _soften(ne["desc"]).strip()})
                present.append(nid); nnew += 1
        per_scene.append({"present": sorted(set(present)), "scene": (d.get("scene") or "").strip()})
        _log("  canh %d: co mat=%s, +%d moi (so dang ky=%d)"
             % (i, sorted(set(present)), nnew, len(registry)))
    return registry, per_scene


def vision_scene_prompts(work, n):
    """VISION + SO DANG KY LUY TIEN: moi canh ve DUNG thuc the co mat (khoa dan khi xuat hien moi),
    tai dung DUNG mo ta cho thuc the cu -> nhan vat/do vat/con vat nhat quan xuyen suot 8 canh.
    Moi canh {img: khoa thuc the co mat + mo ta canh, mot: chuyen dong nhe}. Cache scenes+registry.json.
    """
    pf = os.path.join(work, "scenes.json")
    if os.path.isfile(pf):
        return json.load(open(pf, encoding="utf-8"))
    frames = [os.path.join(work, "goc_%02d.jpg" % i) for i in range(n)]
    missing = [i for i, f in enumerate(frames) if not os.path.isfile(f)]
    if missing:
        raise RuntimeError("thieu frame dai dien goc_XX.jpg: %s" % missing)
    registry, per_scene = _build_registry(frames)
    json.dump({"registry": registry, "per_scene": per_scene},
              open(os.path.join(work, "registry.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    by_id = {e["id"]: e for e in registry}
    scenes = []
    for i in range(n):
        ps = per_scene[i] if i < len(per_scene) else {"present": [], "scene": ""}
        ents = [by_id[pid] for pid in ps.get("present", []) if pid in by_id]
        lock = ""
        if ents:                                        # khoa DUNG thuc the co mat trong canh nay
            lock = ("Keep each of these entities IDENTICAL to its established look across scenes: "
                    + " ".join(e["desc"].rstrip(".") + "." for e in ents) + " ")
        img = (lock + "Scene: " + ps.get("scene", "")).strip()
        img += (" 1990s rural Vietnamese setting, not European. Draw only the entities described; "
                "do not add unrelated people; do not render any letters, labels or captions.")
        scenes.append({"img": img, "mot": _MOTION})
    json.dump(scenes, open(pf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return scenes


def video_scene_bounds(video_path, work, max_scenes=24, segs=None, fps_sample=1, dhash_thresh=14):
    """Phan tich NHIP video goc -> ranh gioi canh (theo slide THAT) + do dai + boi canh TONG.

    So canh TU BAM theo so slide that (gop thong minh bam moc cau) -> khop nhip loi/gio.
    KHONG mo ta tung frame (2 slide giong nhau -> 2 prompt trung -> ve trung). Chi lay 1 boi
    canh TONG (era/vung/khong khi) de LLM grounding. Cache vbounds.json (idempotent).
    Tra ve (bounds, windows, context): bounds = moc bat dau moi canh; windows = do dai canh.
    """
    vb_f = os.path.join(work, "vbounds.json")
    if os.path.isfile(vb_f):
        d = json.load(open(vb_f, encoding="utf-8"))
        return d["bounds"], d["windows"], d.get("context", "")
    adur = _dur(video_path)
    kf = os.path.join(work, "_kf")
    os.makedirs(kf, exist_ok=True)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", video_path, "-vf", "fps=%d" % fps_sample,
                    "-q:v", "3", os.path.join(kf, "f_%04d.jpg")], check=True)
    frames = sorted(glob.glob(os.path.join(kf, "f_*.jpg")))
    if not frames:
        raise RuntimeError("Khong tach duoc frame tu video goc.")
    # loc slide RIENG (frame khac han frame giu truoc) + DEDUP slide LAP LAI o xa (slideshow
    # lap 1 canh 2 lan -> so voi MOI slide da giu, nguong chat rep_thresh -> bo slide lap).
    rep_thresh = max(6, dhash_thresh - 6)
    kept, kept_h, last = [], [], None
    for i, f in enumerate(frames):
        h = _dhash(f)
        if last is not None and _ham(h, last) <= dhash_thresh:
            continue                                   # con trong cung 1 slide
        if any(_ham(h, kh) <= rep_thresh for kh in kept_h):
            last = h; continue                         # slide LAP lai o xa -> bo
        kept.append((i / float(fps_sample), f)); kept_h.append(h); last = h
    if not kept:
        kept = [(0.0, frames[0])]
    # GOP THONG MINH: giu cat o CANH CHINH (trung moc doi cau/giong) hoac canh LON (>=2.5s);
    # gop canh vun/phu vao canh truoc. Tua nhip goc, khong truot qua nhu ep 6 canh.
    if segs and len(kept) > 4:
        starts = sorted(float(s.get("start", 0)) for s in segs
                        if s.get("start") is not None and float(s.get("start", 0)) > 0)
        kt = [t for t, _ in kept] + [adur]
        merged = [kept[0]]
        cur_start = kept[0][0]
        for i in range(1, len(kept)):
            dur = kt[i + 1] - kt[i]
            near_narr = any(abs(kept[i][0] - st) < 1.2 for st in starts)   # giong chuyen canh
            too_long = (kt[i] - cur_start) >= 7.0    # canh gop qua dai -> ep cat
            if near_narr or dur >= 2.5 or too_long:
                merged.append(kept[i]); cur_start = kept[i][0]             # else: gop (bo qua)
        kept = merged
    if len(kept) > max_scenes and max_scenes > 0:
        pick = sorted(set(round(k * (len(kept) - 1) / (max_scenes - 1)) for k in range(max_scenes))) \
            if max_scenes > 1 else [0]
        kept = [kept[j] for j in pick]
    bounds = [t for t, _ in kept]
    times = bounds + [adur]
    windows = [max(1.0, times[i + 1] - times[i]) for i in range(len(kept))]
    _log("phan tich NHIP video goc: %d slide -> %d canh" % (len(frames), len(kept)))
    # LUU 1 frame DAI DIEN moi canh (goc_%02d.jpg, ben trong work) -> VISION ta lai de VE
    # bam KHUNG GOC (thay story-driven lech khung). Frame giu la slide dau canh (da dedup).
    for i, (_, fp) in enumerate(kept):
        try:
            shutil.copy(fp, os.path.join(work, "goc_%02d.jpg" % i))
        except OSError:
            pass
    context = _video_context([f for _, f in kept])   # boi canh TONG (video-derived)
    _log("  boi canh tong: %s" % (context or "(khong ro)")[:70])
    json.dump({"bounds": bounds, "windows": windows, "context": context},
              open(vb_f, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    shutil.rmtree(kf, ignore_errors=True)
    return bounds, windows, context


def _dialogue_per_window(segs, bounds, adur):
    """Gan loi thoai vao tung cua so canh [bounds[i], bounds[i+1]) theo moc cau whisper.

    Cua so rong (khong cau nao roi vao) -> lay cau gan giua nhat. Tra list text dung thu tu canh.
    """
    edges = list(bounds) + [adur]
    out = []
    for i in range(len(bounds)):
        lo, hi = edges[i], edges[i + 1]
        txt = " ".join(s.get("text", "").strip() for s in (segs or [])
                       if lo - 0.01 <= float(s.get("start", 0)) < hi).strip()
        if not txt and segs:
            near = min(segs, key=lambda s: abs(float(s.get("start", 0)) - (lo + hi) / 2))
            txt = near.get("text", "").strip()
        out.append(txt)
    return out


def _wait_image(c, iid, timeout=900):
    w = 0
    while w < timeout:
        info = c.check_image(iid)
        if info.get("status") == "SUCCESS" and info.get("url"):
            return info["url"]
        if info.get("status") == "ERROR":
            raise RuntimeError("anh loi")
        time.sleep(12); w += 12
    raise TimeoutError("anh qua gio")


def _wait_video(c, vid, timeout=1500):
    w = 0
    while w < timeout:
        info = c.check_video(vid)
        st = str(info.get("status") or "").upper()
        msg = str(info.get("message") or "").lower()
        # het tai nguyen model -> BAO NGAY de fallback (dung cho timeout 25')
        if "NOT_RESOURCE" in st or "không khả dụng" in msg or "khong kha dung" in msg:
            raise _NotResources(info.get("message") or "NOT_RESOURCES")
        url = GommoClient._video_url(info)
        if "FAIL" in st or "ERROR" in st:
            raise RuntimeError("clip loi")
        if url and "PENDING" not in st and "PROCESS" not in st and "QUEUE" not in st:
            return url
        time.sleep(12); w += 12
    raise TimeoutError("clip qua gio")


class _NotResources(RuntimeError):
    """Model i2v het tai nguyen -> chuyen model khac."""


def _gen_one_image(c, sc, urlf, tries=4, style=DEFAULT_STYLE):
    """Ve 1 anh khung dau (idempotent qua urlf). Tra ve url.

    BEN: 79AI hay ket 1 anh >10' khi nghen -> GUI LAI (anh moi, slot moi) thay vi
    de TimeoutError giet CA tien trinh (bug cu: 1 anh cham -> mat sach tien do).
    Moi lan cho toi da 8' roi thu anh khac.
    """
    if os.path.isfile(urlf):
        return open(urlf).read().strip()
    # Model/mode ve anh CHON DUOC qua env (do that: banana_2 vip 400cr HAY KET khi 79AI nghen;
    # banana_pro vip 600cr CHEN duoc hang -> xong ~4'). Mac dinh giu banana_2 (khoi doi cost auto).
    # MAC DINH banana_pro vip 1k (600cr): CHEN duoc hang doi khi 79AI nghen (do that 8/8 xong).
    # banana_2 400cr re hon nhung HAY KET khi nghen -> bo lam mac dinh. Van doi duoc qua env.
    img_model = os.environ.get("REMAKE_IMG_MODEL", "google_image_gen_banana_pro")
    img_mode = os.environ.get("REMAKE_IMG_MODE", "vip")
    img_res = os.environ.get("REMAKE_IMG_RES", "2k")   # goi Starter bao 2k banana_pro (free) -> net hon 1k
    last = None
    for t in range(tries):
        try:
            r = c.create_image(model=img_model,
                               prompt=sc["img"] + STYLES.get(style, STYLES[DEFAULT_STYLE]) + BLEED,
                               ratio="9:16", mode=img_mode, resolution=img_res)
            info = r.get("imageInfo") or r.get("data") or r
            iid = info.get("id_base") or r.get("id_base")
            if not iid:
                last = "submit loi: %s" % str(r)[:100]
                time.sleep(6); continue
            # cho ANH lau hon khi 79AI nghen (banana cao diem >8'/anh -> tranh churn gui lai).
            # env REMAKE_IMG_WAIT (giay), mac dinh 900 = 15'. Ket that (>15') moi gui lai.
            img_wait = int(os.environ.get("REMAKE_IMG_WAIT", "900"))
            url = _wait_image(c, iid, timeout=img_wait)
            open(urlf, "w").write(url)
            return url
        except (TimeoutError, RuntimeError) as e:
            last = str(e)[:100]
            _log("  anh ket/loi (%s) -> gui lai (lan %d/%d)" % (last, t + 2, tries))
            time.sleep(4)
    raise RuntimeError("anh that bai sau %d lan: %s" % (tries, last))


def _ken_burns_clip(img_src, clip_path, dur=8.0):
    """LUOI AN TOAN (khong i2v): zoom/pan cham tren ANH TINH -> clip 1080x1920. LUON chay,
    0 hang, 0 credit video. Dung khi moi model i2v treo/fail. Motion la camera (khong canh dong).
    """
    tmp = clip_path + ".src.jpg"
    if str(img_src).startswith("http"):
        download(img_src, tmp)
    else:
        shutil.copy(img_src, tmp)
    fps = 30
    frames = max(1, int(dur * fps))
    # scale len 2x roi zoompan xuong 1080x1920 -> zoom min muot, khong vo hat.
    vf = ("scale=2160:3840:force_original_aspect_ratio=increase,crop=2160:3840,"
          "zoompan=z='min(zoom+0.0012,1.12)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
          "d=%d:s=1080x1920:fps=%d,setsar=1,format=yuv420p" % (frames, fps))
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-loop", "1", "-i", tmp, "-t", "%.3f" % dur,
                    "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium",
                    "-crf", "20", clip_path], check=True)
    try:
        os.remove(tmp)
    except OSError:
        pass
    return clip_path


def _gen_one_clip(c, sc, img_url, clip_path, clip_model, kb_dur=8.0):
    """i2v 1 canh, FALLBACK model (veo -> kling). Moi model cho toi da I2V_WAIT roi bo.
    Het chuoi ma van treo/fail -> Ken Burns (khong hang) -> video LUON xong. Tra model da dung.
    """
    chain = [clip_model] + [m for m in FALLBACK_CHAIN if m != clip_model]
    last = None
    for model in chain:
        try:
            params = VIDEO_PARAMS.get(model, {"mode": "lite", "resolution": "720p"})
            rv = c.create_video(model=model, prompt=sc["mot"], ratio="9:16",
                                ref_image_urls=[img_url], **params)
            info = rv.get("videoInfo") or rv.get("data") or rv
            vid = info.get("id_base") or rv.get("id_base")
            if not vid:                        # submit KHONG co id -> LOG (truoc nhay ngam)
                last = "submit khong co id (%s)" % str(rv)[:100]
                _log("  i2v %s submit KHONG co id -> thu model sau (%s)" % (model, str(rv)[:80]))
                continue
            url = _wait_video(c, vid, timeout=I2V_WAIT)   # bo som neu treo -> roi model/Ken Burns
            download(url, clip_path)
            return model
        except _NotResources as e:
            last = "%s het tai nguyen" % model
            _log("  i2v %s NOT_RESOURCES -> thu model khac" % model); continue
        except Exception as e:
            last = "%s loi/treo: %s" % (model, str(e)[:80])
            _log("  i2v %s loi/treo (%s) -> thu model khac" % (model, str(e)[:60])); continue
    # MOI model i2v treo/fail -> luoi an toan Ken Burns (video khong bao gio treo mai)
    _log("  MOI model i2v that bai (%s) -> Ken Burns (zoom/pan anh tinh)" % last)
    _ken_burns_clip(img_url, clip_path, dur=kb_dur)
    return "kenburns"


def gen_media(scenes, work, clip_model="veo_3_1", style=DEFAULT_STYLE):
    """Ve anh + i2v SONG SONG (LANES lane) + FALLBACK model. IDEMPOTENT. Tra list clip.

    style: 'real' (giong that, MAC DINH) | 'cartoon' (mau nuoc hoat hinh)."""
    from concurrent.futures import ThreadPoolExecutor
    c = GommoClient()          # _post dung requests.post truc tiep -> thread-safe
    n = len(scenes)
    clip_of = lambda i: os.path.join(work, "clip_%02d.mp4" % i)
    urlf_of = lambda i: os.path.join(work, "img_%02d.txt" % i)
    done = lambda i: os.path.isfile(clip_of(i)) and os.path.getsize(clip_of(i)) > 1000

    # Pha 1: ve anh (bo qua canh da co clip). Song song toi da LANES.
    todo_img = [i for i in range(n) if not done(i)]
    imgs = {}
    def _img(i):
        u = _gen_one_image(c, scenes[i], urlf_of(i), style=style)
        _log("scene%d anh xong (con %d cr)" % (i, c.credits())); return i, u
    if todo_img:
        _log("ve %d anh (song song %d lane)..." % (len(todo_img), LANES))
        with ThreadPoolExecutor(max_workers=LANES) as ex:
            for f in [ex.submit(_img, i) for i in todo_img]:
                i, u = f.result(); imgs[i] = u

    # Pha 2: i2v (bo qua canh da co clip). Song song toi da LANES.
    todo_clip = [i for i in range(n) if not done(i)]
    def _clip(i):
        img_url = imgs.get(i) or open(urlf_of(i)).read().strip()
        used = _gen_one_clip(c, scenes[i], img_url, clip_of(i), clip_model)
        _log("scene%d clip xong (model %s, con %d cr)" % (i, used, c.credits()))
    if todo_clip:
        _log("i2v %d clip (song song %d lane)..." % (len(todo_clip), LANES))
        with ThreadPoolExecutor(max_workers=LANES) as ex:
            for f in [ex.submit(_clip, i) for i in todo_clip]:
                f.result()          # propagate loi (neu co)
    return [clip_of(i) for i in range(n)]


def _group_scenes(segs, n, adur, min_win=1.2):
    """Chia transcript thanh n NHOM cau lien tiep (bam moc cau) -> [{text,start,end,dur}].

    Canh i phu nhom cau i -> vua khop TIMING (bien = moc cau) vua khop NOI DUNG (text
    nhom do dung de sinh prompt anh). Nguon duy nhat cho ca gen_scene_prompts lan assemble.
    """
    if not segs or n <= 1:
        return [{"text": "", "start": i * adur / n, "end": (i + 1) * adur / n,
                 "dur": adur / n} for i in range(n)]
    starts = sorted(set(float(s.get("start", 0)) for s in segs
                        if s.get("start") is not None and 0 < float(s.get("start", 0)) < adur))
    bnds = [0.0]
    for i in range(1, n):
        target = i * adur / n
        cand = [st for st in starts if st > bnds[-1] + min_win and st < adur - min_win]
        b = min(cand, key=lambda st: abs(st - target)) if cand else min(bnds[-1] + min_win, adur)
        bnds.append(b)
    bnds.append(adur)
    groups = []
    for i in range(n):
        lo, hi = bnds[i], bnds[i + 1]
        txt = " ".join(s.get("text", "").strip() for s in segs
                       if lo - 0.01 <= float(s.get("start", 0)) < hi).strip()
        if not txt and segs:                         # nhom rong -> cau gan giua nhat
            near = min(segs, key=lambda s: abs(float(s.get("start", 0)) - (lo + hi) / 2))
            txt = near.get("text", "").strip()
        groups.append({"text": txt, "start": lo, "end": hi, "dur": max(min_win, hi - lo)})
    return groups


def _scene_windows(segs, n, adur):
    """Do dai tung canh (giay) — dung chung nhom voi gen prompt (nhat quan timing)."""
    return [g["dur"] for g in _group_scenes(segs, n, adur)]


def assemble(clips, orig_video, out_path, work, segs=None, wins=None, xfade=0.6):
    """Ghep muot (crossfade + lam cham cho day) + long AUDIO GOC (che do B).

    wins (uu tien) = do dai moi canh theo TIMING video goc (video-driven). Neu None ->
    tinh tu segs (bam moc cau). Neu ca hai None -> chia deu.
    """
    adur = float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", orig_video]).decode().strip())
    n = len(clips)
    if wins and len(wins) == n:
        segw = list(wins)                            # do dai canh theo video goc
    else:
        segw = _scene_windows(segs, n, adur)         # fallback: bam moc cau / chia deu
    wins = [s + xfade for s in segw]                 # them xfade de crossfade sang canh sau
    def cdur(p):
        return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries",
            "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", p]).decode().strip())
    # DO THAT (2026-07-23): clip Grok la 24fps, ep fps=30 -> ffmpeg NHAN DOI 1/4 khung
    # (240 khung/8s nhung chi 192 khac nhau) => CHUYEN CANH GIAT/LAC. Giai phap: minterpolate
    # BLEND hoa khung chen -> 238/238 khung khac nhau (het trung), chi cham hon ~2s/clip.
    # (mci muot nhat nhung >90s/clip @1080x1920 -> khong dung cho may khach.)
    # Env REMAKE_SMOOTH: blend (mac dinh) | dup (cu, nhanh nhat, con giat) | mci (muot nhat, RAT cham).
    _sm = os.environ.get("REMAKE_SMOOTH", "blend").lower()
    if _sm == "dup":
        _resample = "fps=30"
    elif _sm == "mci":
        _resample = "minterpolate=fps=30:mi_mode=mci:mc_mode=obmc:me_mode=bidir"
    else:
        _resample = "minterpolate=fps=30:mi_mode=blend"
    inputs, filt = [], []
    for i, cp in enumerate(clips):
        inputs += ["-i", cp]
        cl = cdur(cp)
        stretch = max(1.0, wins[i] / cl)             # lam cham clip cho day cua so canh do
        filt.append("[%d:v]scale=1080:1920:force_original_aspect_ratio=increase,"
                    "crop=1080:1920,setsar=1,setpts=%.4f*PTS,%s,trim=0:%.3f,"
                    "setpts=PTS-STARTPTS,format=yuv420p[v%d]" % (i, stretch, _resample, wins[i], i))
    prev = "v0"; acc = wins[0]
    for k in range(1, n):
        filt.append("[%s][v%d]xfade=transition=fade:duration=%.2f:offset=%.3f[x%d]"
                    % (prev, k, xfade, max(0.0, acc - xfade), k))
        prev = "x%d" % k; acc = acc + wins[k] - xfade
    cmd = ["ffmpeg", "-v", "error", "-y"] + inputs + ["-i", orig_video,
        "-filter_complex", ";".join(filt), "-map", "[%s]" % prev, "-map", "%d:a" % n,
        "-t", "%.3f" % adur, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium",
        "-crf", "20", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out_path]
    subprocess.run(cmd, check=True)
    return out_path


def _default_voice_id():
    """Voice ElevenLabs de doc: uu tien roster (giong dang dung), roi giong dau."""
    try:
        import voice_roster
        for v in voice_roster.roster():
            if v.get("engine") == "eleven":
                return v.get("id")
    except Exception:
        pass
    try:
        import eleven_tts
        vs = eleven_tts.list_voices()
        return vs[0]["voice_id"] if vs else None
    except Exception:
        return None


def _pick_music():
    if os.path.isdir(MUSIC_DIR):
        pref = os.path.join(MUSIC_DIR, "nhac_nen_mau.m4a")
        if os.path.isfile(pref):
            return pref
        for fn in sorted(os.listdir(MUSIC_DIR)):
            if fn.lower().endswith((".mp3", ".m4a", ".ogg", ".wav")):
                return os.path.join(MUSIC_DIR, fn)
    return None


def make_voice_audio(story, work, voice_id=None):
    """Mode A: TTS giong MOI doc cot truyen + nhac nen ducked -> audio.m4a. Tra (path)."""
    import eleven_tts
    out = os.path.join(work, "voicemix.m4a")
    if os.path.isfile(out) and os.path.getsize(out) > 1000:
        return out
    vid = voice_id or _default_voice_id()
    if not vid:
        raise RuntimeError("Khong co voice ElevenLabs de doc (mode A).")
    voice_mp3 = os.path.join(work, "voice.mp3")
    if not (os.path.isfile(voice_mp3) and os.path.getsize(voice_mp3) > 1000):
        _log("TTS giong moi (ElevenLabs)...")
        eleven_tts.synth(story, vid, voice_mp3)
    music = _pick_music()
    if music:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", voice_mp3,
                        "-stream_loop", "-1", "-i", music, "-filter_complex",
                        "[1:a]volume=0.18[m];[0:a][m]amix=inputs=2:duration=first:normalize=0[a]",
                        "-map", "[a]", "-c:a", "aac", "-b:a", "192k", out], check=True)
    else:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", voice_mp3,
                        "-c:a", "aac", "-b:a", "192k", out], check=True)
    return out


def remake(video_path, out_path, n_scenes=6, clip_model="veo_3_1",
           audio_mode="B", voice_id=None, prompt_mode="vision",
           style=DEFAULT_STYLE) -> dict:
    """Lam lai 1 video. audio_mode: 'B' giu audio goc | 'A' giong+nhac MOI.

    prompt_mode: 'vision' (MAC DINH, do that bam KHUNG GOC — nhin 1 frame dai dien/canh
    roi ta lai) | 'story' (LLM doc cot truyen -> lech khung, chi de fallback). {ok,out}.
    """
    work = out_path + ".work"
    os.makedirs(work, exist_ok=True)
    if os.path.isfile(out_path) and os.path.getsize(out_path) > 1000:
        return {"ok": True, "out": out_path, "skipped": True}
    # (1) chep loi (cho audio/timing). (2) video goc -> moc slide THAT = ranh gioi/nhip canh
    # + LUU 1 frame dai dien/canh (goc_XX.jpg). (3) VISION nhin tung frame -> prompt bam KHUNG
    # GOC (thay story-driven lech khung). Canh da RIENG (dedup) nen khong trung anh.
    _log("chep loi (moc cau)...")
    segs, story = transcribe(video_path, work)
    _log("phan tich NHIP video goc (moc slide + luu frame dai dien)...")
    # CAP so canh = max(n_scenes, 7) — giu MUOT nhu video dau, khong phinh (truoc 24 = vo han).
    bounds, windows, context = video_scene_bounds(video_path, work, max_scenes=max(n_scenes, 7), segs=segs)
    n = len(bounds)
    scenes = None
    if prompt_mode == "vision":
        try:
            _log("VISION: nhin frame dai dien/canh -> prompt bam KHUNG GOC (%d canh)..." % n)
            scenes = vision_scene_prompts(work, n)
        except Exception as e:
            _log("  VISION loi (%s) -> fallback story-driven" % str(e)[:100])
    if scenes is None:                        # fallback (khong OPENAI / thieu frame): story-driven
        scene_texts = _dialogue_per_window(segs, bounds, _dur(video_path))
        _log("LLM doc ca truyen -> sinh %d canh khop loi (khoa nhan vat)..." % len(scene_texts))
        scenes = gen_scene_prompts(story, len(scene_texts), work, scene_texts=scene_texts, context=context)
    # canh co thoai -> nhan vat map may mieng nhu dang noi (khong lip-sync tung chu)
    apply_talk_motion(scenes, segs, bounds, _dur(video_path))
    _log("ve anh + i2v (style=%s)..." % style)
    clips = gen_media(scenes, work, clip_model, style=style)
    if audio_mode == "A":
        _log("mode A: tao giong+nhac moi + ghep...")
        audio_src = make_voice_audio(story, work, voice_id)   # story da co tu tren
    else:
        _log("mode B: giu audio goc + ghep (timing goc)...")
        audio_src = video_path
    assemble(clips, audio_src, out_path, work, wins=windows)
    return {"ok": True, "out": out_path, "mode": audio_mode}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--scenes", type=int, default=6)
    ap.add_argument("--clip", default="veo_3_1")
    ap.add_argument("--audio", default="B")           # B giu tieng goc | A giong+nhac moi
    ap.add_argument("--prompt-mode", default="vision") # vision (bam khung goc) | story (fallback)
    ap.add_argument("--style", default=DEFAULT_STYLE)  # real (giong that) | cartoon (hoat hinh)
    ap.add_argument("--item-id", default="")           # ghi tien trinh vao fb_pipeline
    a = ap.parse_args()

    item = a.item_id

    def _st(status, **kw):
        if not item:
            return
        try:
            import fb_pipeline
            fb_pipeline.update(item, status=status, **kw)
        except Exception:
            pass

    _st("remaking", step="chép lời + sinh cảnh + vẽ ảnh")
    try:
        res = remake(a.video, a.out, a.scenes, a.clip, a.audio,
                     prompt_mode=a.prompt_mode, style=a.style)
    except Exception as exc:
        _st("error", step="", error=str(exc)[:200])
        print("KETQUA:", json.dumps({"ok": False, "error": str(exc)[:200]},
                                    ensure_ascii=False), flush=True)
        raise
    if res.get("ok"):
        _st("done", step="", out=res.get("out", ""))
    else:
        _st("error", step="", error=str(res)[:200])
    print("KETQUA:", json.dumps(res, ensure_ascii=False), flush=True)
