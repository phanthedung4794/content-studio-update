# -*- coding: utf-8 -*-
"""
Orchestration 1 dong mapping: LINK nguon -> tai -> lam lai -> len lich dang len PAGE.
Dung boi tab "Tu dong theo page". Moi dong chay 1 job (qua hang doi).

CHUA NGHIEM THU THAT (ton credit + chan dang) -> debug lan dau cung nguoi dung.
"""
import argparse
import json
import os
import re
import time

import fb_download
import fb_governor
import fb_graph
import fb_pipeline
import fb_publish
import fb_remake
import fb_watch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.path.join(ROOT, "facebook")


def _reel_id(link: str) -> str:
    m = re.search(r"/reel/(\d+)", link) or re.search(r"/videos/(\d+)", link) \
        or re.search(r"[?&]v=(\d+)", link)
    return m.group(1) if m else ""


def _slug(link: str) -> str:
    m = re.search(r"facebook\.com/([^/?#]+)", link)
    s = m.group(1) if m else "auto"
    return "auto" if s in ("reel", "watch", "profile.php") else s


def run_row(page_id, link, audio_mode="B", clip_model="veo_3_1",
            when_ts=0, desc="", n_scenes=6, item_id=None, style="real",
            post_mode="schedule"):
    def _st(step, status, **kw):
        if item_id:
            fb_pipeline.update(item_id, step=step, status=status, **kw)

    def _fail(res):
        _st(res.get("step", "?"), "error",
            error=str(res.get("reason") or res.get("error"))[:200])
        return res

    # Link NGUON (page) -> tu lay reel MOI ke tiep; link co dinh -> lay dung reel do
    is_src = fb_watch.is_source(link)
    if is_src:
        rid = fb_watch.next_oldest(link)      # CŨ NHẤT trước (backlog cách A)
        if not rid:
            return _fail({"ok": False, "step": "watch", "reason": "Hết video chưa làm ở nguồn."})
    else:
        rid = _reel_id(link)
        if not rid:
            return _fail({"ok": False, "step": "watch", "error": "Link không có reel id."})
    slug = _slug(link)
    _st("download", "downloading", reel=rid)

    # 1) TAI
    print("→ tải reel %s ..." % rid, flush=True)
    dl = fb_download.download_reel(slug, rid, quality="best")
    if not dl.get("ok"):
        return _fail({"ok": False, "step": "download", "error": dl})
    src = os.path.join(dl["dir"], "video.mp4")

    # 2) LAM LAI — qua GOVERNOR truoc (chan chay credit)
    out = os.path.join(FB_ROOT, slug, "remake", "%s-lamlai.mp4" % rid)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    already = os.path.isfile(out) and os.path.getsize(out) > 1000
    if not already:
        # uoc luong credit: grok ~1000cr/clip + banana ~600cr/anh (~7 canh) ~= 11k; wan re hon
        est = 3600 if clip_model == "wan_2_2" else (11000 if clip_model == "grok_video_heavy" else 7200)
        # model TRONG goi thue bao (veo_3_1/grok) + con quota -> 0 credit (tru quota) -> bo qua san credit
        plan_free = clip_model in ("veo_3_1", "grok_video_heavy") and fb_governor.sub_active()
        g = fb_governor.can_produce(est, plan_free=plan_free)
        if not g["ok"]:
            return _fail({"ok": False, "step": "governor", "reason": g["reason"]})
    _st("remake", "remaking")
    print("→ làm lại (mode %s, %s) ..." % (audio_mode, clip_model), flush=True)
    rm = fb_remake.remake(src, out, n_scenes=n_scenes, clip_model=clip_model,
                          audio_mode=audio_mode, style=style)
    if not rm.get("ok"):
        return _fail({"ok": False, "step": "remake", "error": rm})
    if not (already or rm.get("skipped")):
        fb_governor.record_produced()

    # 3) LEN LICH DANG
    tok = fb_graph.page_token(page_id)
    if not tok:
        return _fail({"ok": False, "step": "publish", "error": "không có page token (refresh)"})
    if not desc:
        cap = os.path.join(dl["dir"], "caption.txt")
        # Loc link Shopee + hashtag quang ba kenh nguon truoc khi dang lai
        desc = fb_publish.clean_caption(open(cap, encoding="utf-8").read()) \
            if os.path.isfile(cap) else ""
    # GIỜ ĐĂNG: server tính sẵn (đăng luôn = when_ts 0/None; hẹn = mốc tuyệt đối).
    #   post_mode="now"  -> đăng LUÔN.
    #   khác            -> hẹn FB tại when_ts (nếu đã lỡ giờ vì remake lâu → đăng luôn).
    if post_mode == "now" or not when_ts:
        pub_when = None
        print("→ đăng luôn ...", flush=True)
    elif int(when_ts) > int(time.time()) + 540:
        pub_when = int(when_ts)
        print("→ lên lịch %s ..." % time.strftime("%H:%M %d/%m", time.localtime(pub_when)), flush=True)
    else:
        pub_when = None
        print("→ (lịch đã qua) đăng luôn ...", flush=True)
    _st("schedule", "scheduling")
    pub = fb_publish.publish_reel(page_id, tok, out, desc, pub_when)
    if not pub.get("ok"):
        return _fail({"ok": False, "step": "publish", "error": pub})
    if is_src:
        fb_watch.mark(slug, rid)          # ghi so da xu ly -> lan sau khong lam lai
    _st("done", "done", post_id=str(pub.get("post_id") or ""),
        video_id=str(pub.get("video_id") or ""), page_id=page_id, when_ts=int(pub_when or 0))
    return {"ok": True, "reel": rid, "out": out,
            "post_id": pub.get("post_id"), "when_ts": int(pub_when or 0)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--page-id", required=True)
    ap.add_argument("--link", required=True)
    ap.add_argument("--audio", default="B")
    ap.add_argument("--clip", default="veo_3_1")
    ap.add_argument("--when-ts", type=int, default=0)
    ap.add_argument("--desc-file", default="")
    ap.add_argument("--scenes", type=int, default=6)
    ap.add_argument("--style", default="real")   # real (giong that) | cartoon (hoat hinh)
    ap.add_argument("--post-mode", default="schedule")   # now | schedule
    ap.add_argument("--item-id", default=None)
    a = ap.parse_args()
    desc = ""
    if a.desc_file and os.path.isfile(a.desc_file):
        desc = open(a.desc_file, encoding="utf-8").read().strip()
    res = run_row(a.page_id, a.link, a.audio, a.clip, a.when_ts, desc, a.scenes,
                  item_id=a.item_id, style=a.style, post_mode=a.post_mode)
    print("KETQUA:", json.dumps(res, ensure_ascii=False), flush=True)
