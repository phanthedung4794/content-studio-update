"""
Client goi 79ai / Gommo API. CHI DUNG DE VE TRANH.

TTS cua 79ai da bo: endpoint /ai/audio tra ve "xi-api-key: " rong
-> ho chua nap key ElevenLabs phia server. Giong doc dung eleven_tts.py.

Token doc tu bien moi truong GOMMO_API_TOKEN
(nap bang D:\\ChungAllDuAn\\api-keys\\load-env.ps1).
"""
import json
import os
import time

import requests
import yaml

BASE_API = "https://api.gommo.net/ai"
BASE_APPS = "https://api.gommo.net/api/apps/go-mmo"

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.yaml")


def load_config(config_path: str = CONFIG_PATH) -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def download(url: str, out_path: str) -> None:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=180)
    resp.raise_for_status()
    with open(out_path, "wb") as f:
        f.write(resp.content)


def _opts(raw, key: str) -> list:
    """Chuan hoa [{name, type}] -> [{label, value}], khu trung, chiu duoc rong.

    value = truong gui di (name hoac type tuy o chon); label = ten hien thi.
    Du lieu API hoi ban: co model khai trung (GPT Image 2: Low/Medium/High x2)
    -> khu theo value. Model khai rong (Seedream 4.0 modes=None) -> tra [].
    """
    out, seen = [], set()
    for e in raw or []:
        if isinstance(e, dict):
            value = e.get(key) or e.get("type") or e.get("name")
            label = e.get("name") or value
        else:
            value = label = str(e)
        if value is None or value in seen:
            continue
        seen.add(value)
        out.append({"label": str(label), "value": str(value)})
    return out


class GommoClient:
    def __init__(self, config_path: str = CONFIG_PATH):
        self.cfg = load_config(config_path)
        self.access_token = os.environ.get("GOMMO_API_TOKEN")
        if not self.access_token:
            raise SystemExit(
                "Thieu GOMMO_API_TOKEN.\n"
                "Chay: cd D:\\ChungAllDuAn\\api-keys; .\\load-env.ps1 -Action Load\n"
                "Roi mo terminal moi."
            )
        self.domain = self.cfg["gommo"]["domain"]

    def _post(self, url: str, extra: dict = None, timeout: int = 90,
              retries: int = 2) -> dict:
        data = {"access_token": self.access_token, "domain": self.domain}
        if extra:
            data.update(extra)

        last = None
        for attempt in range(retries + 1):
            try:
                resp = requests.post(url, data=data, timeout=timeout)
                resp.raise_for_status()
                return resp.json()
            except (requests.Timeout, requests.ConnectionError) as exc:
                last = exc
                if attempt < retries:
                    wait = 5 * (attempt + 1)
                    print(f"   (mang cham, thu lai sau {wait}s...)")
                    time.sleep(wait)
        raise last

    def credits(self) -> int:
        info = self._post(f"{BASE_APPS}/ai/me")
        return int((info.get("balancesInfo") or {}).get("credits_ai", 0))

    def subscription(self) -> dict:
        """Goi thue bao (Starter Video...) dang ACTIVE. {} neu khong co.

        BAT BUOC gui subscribe_type='MEMBER_PLAN_AI' — thieu thi API tra null.
        options.videoMonth/videoMonthUsage = quota + da dung; trong quota = 0 credit.
        """
        r = self._post(f"{BASE_APPS}/users/subscriptions",
                       {"subscribe_type": "MEMBER_PLAN_AI"})
        return r.get("subscriptionInfo") or {}

    def create_image(self, model: str, prompt: str, ratio: str = None,
                     mode: str = None, resolution: str = None,
                     subjects: list = None) -> dict:
        data = {"action_type": "create", "model": model, "prompt": prompt}
        if subjects:
            data["subjects"] = json.dumps(subjects)
        if ratio:
            data["ratio"] = ratio
        if mode:
            data["mode"] = mode
        if resolution:
            data["resolution"] = resolution
        return self._post(f"{BASE_API}/generateImage", data)

    def upload_image(self, path: str) -> dict:
        """Tai 1 anh len domain 79ai -> tra ve URL server dung lai duoc + id_base.

        Endpoint that: POST /ai/image-upload, multipart field 'file' (do tu JS
        frontend 79ai.net). Anh host tren CDN 'bunny' -> cloud 79ai FETCH duoc,
        dung lam anh tham chieu (subjects[i][url]) khi ve. KHONG ton credit AI.
        """
        with open(path, "rb") as f:
            blob = f.read()
        files = {"file": (os.path.basename(path) or "ref.png", blob, "image/png")}
        data = {"access_token": self.access_token, "domain": self.domain}
        resp = requests.post(f"{BASE_API}/image-upload", data=data, files=files, timeout=120)
        resp.raise_for_status()
        j = resp.json()
        info = j.get("imageInfo") or j
        return dict(info) if isinstance(info, dict) else j

    def create_image_ref(self, model: str, prompt: str, ratio: str = None,
                         mode: str = None, resolution: str = None,
                         ref_b64: list = None, ref_urls: list = None) -> dict:
        """Ve anh CO ANH THAM CHIEU (subjects), gui multipart giong frontend 79ai.

        Anh tham chieu gan vao truong mang:
          subjects[i][base64Image] = base64 THO (KHONG prefix 'data:image/...;base64,')
          subjects[i][url]         = URL da host (vd tu upload_image)
        (Do tu bundle JS 79ai.net: no strip prefix bang split(',')[1].)
        """
        fields = [("access_token", self.access_token), ("domain", self.domain),
                  ("action_type", "create"), ("model", model), ("prompt", prompt)]
        if ratio:
            fields.append(("ratio", ratio))
        if mode:
            fields.append(("mode", mode))
        if resolution:
            fields.append(("resolution", resolution))
        i = 0
        for b in (ref_b64 or []):
            if b and ";base64," in b:          # bo prefix data URI neu con
                b = b.split(",", 1)[1]
            if b:
                fields.append((f"subjects[{i}][base64Image]", b)); i += 1
        for u in (ref_urls or []):
            if u:
                fields.append((f"subjects[{i}][url]", u)); i += 1
        # gui multipart/form-data (khong file that -> dung tuple (None, value))
        multi = [(k, (None, v)) for k, v in fields]
        resp = requests.post(f"{BASE_API}/generateImage", files=multi, timeout=120)
        resp.raise_for_status()
        return resp.json()

    def image_models(self) -> list:
        """Danh sach model VE ANH dang bat (status ON).

        79ai bat/tat model lien tuc -> KHONG hardcode, goi API do vao o chon.
        Moi model tu khai ratios/modes/resolutions RIENG, dang [{name, type}]:
          - ratio  gui di dung NAME  ("9:16")  — khop code hien chay (config 3:2).
          - mode   gui di dung TYPE  ("vip3")  — khop config image_mode.
          - resolution: name == type ("2k").
        Gia khong phang: prices[] theo (mode, resolution).
        """
        resp = self._post(f"{BASE_API}/models", {"type": "image"})
        out = []
        for m in resp.get("data") or []:
            if not isinstance(m, dict) or m.get("status") != "ON":
                continue
            out.append({
                "model": m.get("model"),
                "name": m.get("name"),
                "price": m.get("price"),
                "ratios": _opts(m.get("ratios"), key="name"),      # gui NAME
                "modes": _opts(m.get("modes"), key="type"),        # gui TYPE
                "resolutions": _opts(m.get("resolutions"), key="type"),
                "prices": [p for p in (m.get("prices") or [])
                           if isinstance(p, dict) and "price" in p],
            })
        return out

    def check_image(self, id_base: str) -> dict:
        resp = self._post(f"{BASE_API}/image", {"id_base": id_base})
        info = resp.get("imageInfo")
        return dict(info) if isinstance(info, dict) else resp

    def wait_for_image(self, id_base: str, interval: int = 8,
                       timeout: int = 600) -> dict:
        waited = 0
        while waited < timeout:
            info = self.check_image(id_base)
            status = info.get("status")
            if status == "SUCCESS" and info.get("url"):
                return info
            if status == "ERROR":
                raise RuntimeError(f"Tao anh that bai ({id_base}): {info}")
            time.sleep(interval)
            waited += interval
        raise TimeoutError(f"Anh {id_base} chua xong sau {timeout}s")

    # ─────────────────────────── VIDEO ───────────────────────────
    # API that (moc tu frontend 79ai.net):
    #   tao : POST /ai/create-video  body {model, prompt, ratio, resolution,
    #         duration, mode, privacy, references[i][url]}  -> job (id_base)
    #   kiem: POST /ai/video         body {id_base, id}     -> file_url/url khi xong
    # Anh khung dau (image-to-video) truyen qua references[i][url].
    # KHONG dung /ai_spaces/render cua ho — minh ghep clip bang ffmpeg local.
    def video_models(self) -> list:
        """Danh sach model TAO VIDEO dang bat (status ON).

        Cung khuon image_models: KHONG hardcode, goi API do vao o chon.
        Khac anh: co `durations`; gia `prices[]` theo (mode[/resolution], duration).
        `startImage`/`startText` cho biet model nhan anh khung dau / prompt-thang.
        """
        resp = self._post(f"{BASE_API}/models", {"type": "video"})
        out = []
        for m in resp.get("data") or []:
            if not isinstance(m, dict) or m.get("status") != "ON":
                continue
            out.append({
                "model": m.get("model"),
                "name": m.get("name"),
                "price": m.get("price"),
                "ratios": _opts(m.get("ratios"), key="type"),        # gui TYPE ("9:16")
                "modes": _opts(m.get("modes"), key="type"),          # gui TYPE ("relax")
                "resolutions": _opts(m.get("resolutions"), key="type"),
                "durations": _opts(m.get("durations"), key="type"),  # gui TYPE ("5")
                "prices": [p for p in (m.get("prices") or [])
                           if isinstance(p, dict) and "price" in p],
                "start_image": bool(m.get("startImage")),
                "start_text": bool(m.get("startText")),
            })
        return out

    def create_video(self, model: str, prompt: str, ratio: str = None,
                     duration: str = None, mode: str = None,
                     resolution: str = None, ref_image_urls: list = None,
                     privacy: str = "PRIVATE") -> dict:
        data = {"model": model, "prompt": prompt or "", "privacy": privacy}
        if ratio:
            data["ratio"] = ratio
        if duration:
            data["duration"] = str(duration)
        if mode:
            data["mode"] = mode
        if resolution:
            data["resolution"] = resolution
        # Anh khung dau (i2v): field `images` = JSON [{"url": ...}].
        # (Da do that: `references`/`references[i][url]` KHONG duoc nhan;
        #  `images` moi qua kiem "yeu cau toi thieu 1 anh tham chieu".)
        imgs = [u for u in (ref_image_urls or []) if u]
        if imgs:
            data["images"] = json.dumps([{"url": u} for u in imgs])
        return self._post(f"{BASE_API}/create-video", data, timeout=120)

    @staticmethod
    def _video_url(info: dict) -> str:
        for k in ("file_url", "url", "video_url", "download_url"):
            v = info.get(k)
            if v:
                return v
        return ""

    def check_video(self, id_base: str) -> dict:
        resp = self._post(f"{BASE_API}/video", {"id_base": id_base, "id": id_base})
        info = resp.get("videoInfo")
        if isinstance(info, list):
            info = info[0] if info else {}
        return dict(info) if isinstance(info, dict) else resp

    def wait_for_video(self, id_base: str, interval: int = 12,
                       timeout: int = 1200) -> dict:
        """Cho video xong. Video cham hon anh nhieu (poll thua, timeout dai)."""
        # Status THAT cua gommo: MEDIA_GENERATION_STATUS_PENDING / _SUCCESSFUL /
        # _FAILED (do bang API that). Khong so khop chuoi cung — dua vao co URL
        # + khong con PENDING; loi thi bao FAIL/ERROR.
        waited = 0
        while waited < timeout:
            info = self.check_video(id_base)
            status = str(info.get("status") or "").upper()
            url = self._video_url(info)
            if "FAIL" in status or "ERROR" in status:
                raise RuntimeError(f"Tao video that bai ({id_base}): "
                                   f"{info.get('message') or status}")
            if url and "PENDING" not in status and "PROCESS" not in status \
               and "QUEUE" not in status:
                return info
            time.sleep(interval)
            waited += interval
        raise TimeoutError(f"Video {id_base} chua xong sau {timeout}s")
