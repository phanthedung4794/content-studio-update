# -*- coding: utf-8 -*-
"""
DON DU LIEU — xoa sach dau vet cua MOT page, hoac LAM LAI TU DAU ca tool.

Vi sao can: du lieu cua 1 page nam rai o ~12 kho khac nhau (mot so danh so theo
`page_id` cua Facebook, mot so theo `slug` cua trang NGUON, con lai la thu muc media).
Xoa tay thi chac chan sot, ma sot thi lan sau chay lai gap du lieu cu -> hanh vi la.

HAI LUAT AN TOAN, khong duoc bo:

1. LUON SAO LUU TRUOC KHI XOA. Ghi vao `_backup_<viec>_<thoi diem>/`. Da mot lan mat
   kho nhom 535 -> 29 vi xen theo mot lan quet hong (xem fb_groups.set_groups) — do la
   ly do co muc nay.

2. KHONG XOA THU MUC NGUON DANG DUOC PAGE KHAC DUNG. Hai page CO THE tro cung mot
   trang nguon; xoa `facebook/<slug>/` la lay mat kho reel da cao cua page kia.

Reset toan bo van GIU: `_chrome_profile/` (dang nhap Facebook — xoa la phai dang nhap
lai), `keys.env` (khong nam trong thu muc nay), va link Google Sheet (o app_config).
"""
import json
import os
import shutil
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.environ.get("CS_FB_ROOT") or os.path.join(ROOT, "facebook")

# Kho danh so theo PAGE_ID cua Facebook
_BY_PAGE = ("_page_groups.json", "_chrome_access.json", "_image_topics.json",
            "_runstate.json")
# Kho danh so theo SLUG cua trang NGUON
_BY_SLUG = ("_backlog.json", "_watch_ledger.json", "_source_list.json")
# Kho dang DANH SACH, moi phan tu co truong page_id
_LISTS = ("_pipeline.json", "_chrome_queue.json", "_scheduled.json")

# Reset toan bo: GIU nguyen nhung thu nay (mat la nguoi dung phai lam lai tu tay)
_KEEP_ON_RESET = {"_chrome_profile", "_chrome_profiles", "_chrome_profiles.json"}


def _rj(path, default=None):
    try:
        with open(path, encoding="utf-8-sig") as f:      # utf-8-sig: file co BOM van doc duoc
            return json.load(f)
    except Exception:
        return default


def _wj(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = "%s.%d.tmp" % (path, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    for _ in range(12):                                   # Windows hay chan os.replace
        try:
            os.replace(tmp, path)
            return
        except OSError:
            time.sleep(0.12)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def _slug_of(link: str) -> str:
    if not link:
        return ""
    try:
        import fb_lister
        return fb_lister.page_slug(link)
    except Exception:
        return ""


def busy_pages() -> set:
    """Page DANG dang bai ngay luc nay — khong duoc dong vao."""
    items = _rj(os.path.join(FB_ROOT, "_chrome_queue.json"), []) or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return {str(x.get("page_id")) for x in items if x.get("status") == "posting"}


def _backup(paths, tag: str) -> str:
    """Chep cac duong dan con song vao thu muc sao luu. Tra duong dan thu muc."""
    dst = os.path.join(FB_ROOT, "_backup_%s_%s" % (tag, time.strftime("%Y%m%d_%H%M%S")))
    os.makedirs(dst, exist_ok=True)
    for p in paths:
        if not os.path.exists(p):
            continue
        try:
            if os.path.isdir(p):
                shutil.copytree(p, os.path.join(dst, os.path.basename(p)),
                                dirs_exist_ok=True)
            else:
                shutil.copy2(p, os.path.join(dst, os.path.basename(p)))
        except Exception:
            pass                       # sao luu that bai KHONG duoc chan viec chinh
    return dst


def purge_page(page_id: str, link: str = "", rows=None) -> dict:
    """Xoa SACH du lieu cua 1 page trong tool. Tra ban ke da xoa nhung gi.

    `rows` = danh sach automap SAU KHI da bo dong cua page nay (de biet slug nguon con
    page khac dung khong). Khong truyen thi tu doc file.
    """
    page_id = str(page_id or "")
    if not page_id:
        raise ValueError("thieu page_id")
    if page_id in busy_pages():
        raise RuntimeError("Page nay DANG dang bai — doi dang xong roi hay xoa.")

    rep = {"page_id": page_id, "slug": "", "stores": [], "items": 0,
           "files": 0, "dirs": [], "backup": ""}

    # ── 1. dong automap: bo dong cua page nay ──────────────────────────────
    fa = os.path.join(FB_ROOT, "_automap.json")
    all_rows = _rj(fa, []) or []
    if rows is None:
        rows = [r for r in all_rows if str(r.get("page_id")) != page_id]
    mine = [r for r in all_rows if str(r.get("page_id")) == page_id]
    slug = _slug_of(link or (mine[0].get("link") if mine else ""))
    rep["slug"] = slug

    # ── 2. sao luu TRUOC khi dong vao bat cu thu gi ────────────────────────
    tobk = [os.path.join(FB_ROOT, n) for n in
            _BY_PAGE + _BY_SLUG + _LISTS + ("_automap.json",)]
    tobk.append(os.path.join(FB_ROOT, "_insights", "%s.json" % page_id))
    rep["backup"] = _backup(tobk, "xoa_page_%s" % page_id[-6:])

    if mine:
        _wj(fa, rows)
        rep["stores"].append("_automap.json")

    # ── 3. kho danh so theo page_id ────────────────────────────────────────
    for name in _BY_PAGE:
        p = os.path.join(FB_ROOT, name)
        d = _rj(p)
        if isinstance(d, dict) and page_id in d:
            d.pop(page_id, None)
            _wj(p, d)
            rep["stores"].append(name)

    # ── 4. kho dang danh sach (pipeline / kho cho Chrome / lich) ───────────
    for name in _LISTS:
        p = os.path.join(FB_ROOT, name)
        d = _rj(p)
        items = d.get("items") if isinstance(d, dict) else d
        if not isinstance(items, list):
            continue
        keep = [x for x in items if str(x.get("page_id")) != page_id]
        if len(keep) == len(items):
            continue
        # File media rieng cua bai bi xoa (anh bai dang) -> xoa luon cho khoi rac
        for x in items:
            if str(x.get("page_id")) != page_id:
                continue
            f = x.get("video") or ""
            if f and os.path.sep + "_image_posts" + os.path.sep in f and os.path.isfile(f):
                try:
                    os.remove(f)
                    rep["files"] += 1
                except OSError:
                    pass
        rep["items"] += len(items) - len(keep)
        _wj(p, {**d, "items": keep} if isinstance(d, dict) else keep)
        rep["stores"].append(name)

    # ── 5. bang rank gio dang ──────────────────────────────────────────────
    p = os.path.join(FB_ROOT, "_slot_rank.json")
    d = _rj(p)
    if isinstance(d, dict) and isinstance(d.get("runs"), dict):
        hit = False
        for run in d["runs"].values():
            if isinstance(run.get("ranks"), dict) and run["ranks"].pop(page_id, None) is not None:
                hit = True
        if hit:
            _wj(p, d)
            rep["stores"].append("_slot_rank.json")

    # ── 6. so lieu + anh chup luc loi ──────────────────────────────────────
    for p in (os.path.join(FB_ROOT, "_insights", "%s.json" % page_id),):
        if os.path.isfile(p):
            os.remove(p)
            rep["files"] += 1
    shots = os.path.join(FB_ROOT, "_chrome_shots")
    if os.path.isdir(shots):
        for n in os.listdir(shots):
            if n.startswith(page_id + "_"):
                try:
                    os.remove(os.path.join(shots, n))
                    rep["files"] += 1
                except OSError:
                    pass

    # ── 7. du lieu theo SLUG nguon — CHI khi khong page nao khac con dung ──
    if slug:
        con_dung = any(_slug_of(r.get("link") or "") == slug for r in rows)
        if con_dung:
            rep["slug_giu_lai"] = True     # page khac dung chung nguon -> khong dong vao
        else:
            for name in _BY_SLUG:
                p = os.path.join(FB_ROOT, name)
                d = _rj(p)
                if isinstance(d, dict) and slug in d:
                    d.pop(slug, None)
                    _wj(p, d)
                    rep["stores"].append(name)
            sd = os.path.join(FB_ROOT, slug)
            if os.path.isdir(sd):
                shutil.rmtree(sd, ignore_errors=True)
                rep["dirs"].append(slug)
    return rep


def reset_all(keep_pages_cache: bool = True) -> dict:
    """LAM LAI TU DAU: xoa moi du lieu chay cua tool, GIU dang nhap Chrome + key.

    keep_pages_cache=True thi giu `_fb_pages.json` (danh sach page doc tu token) de
    nguoi dung khong phai nap lai page tu Business Manager.
    """
    busy = busy_pages()
    if busy:
        raise RuntimeError("Con %d page dang dang bai — doi xong roi hay lam lai tu dau."
                           % len(busy))
    keep = set(_KEEP_ON_RESET)
    if keep_pages_cache:
        keep.add("_fb_pages.json")

    if not os.path.isdir(FB_ROOT):
        return {"backup": "", "removed": [], "kept": sorted(keep)}

    names = [n for n in os.listdir(FB_ROOT)
             if n not in keep and not n.startswith("_backup_")]
    bk = _backup([os.path.join(FB_ROOT, n) for n in names
                  if not os.path.isdir(os.path.join(FB_ROOT, n))], "lam_lai_tu_dau")

    removed = []
    for n in names:
        p = os.path.join(FB_ROOT, n)
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            else:
                os.remove(p)
            removed.append(n)
        except OSError:
            pass
    return {"backup": bk, "removed": removed, "kept": sorted(keep)}
