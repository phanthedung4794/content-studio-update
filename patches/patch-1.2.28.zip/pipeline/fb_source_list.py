"""
DANH SACH NGUON — khau TRUNG GIAN giua CAO va LAM LAI (Xuong).

Xem docs/danh-sach-nguon-ke-hoach.md. Y tuong:
- Tai dung reel da cao (facebook/<slug>/index.json) — KHONG cao lai.
- AI phan tich cap LO (vai thumbnail dai dien) -> chot "lo nay dang X" -> ap ca lo. RE.
  (Validate THAT 2026-07-24: GPT-4o phan loai dung tu 4 thumbnail, ~1 call/page.)
- Anh xa Dang -> Huong dung + Model de xuat + Credit uoc tinh.
- Tick chon -> day sang Xuong (remake) kem preset.

Ket qua phan tich luu facebook/_source_list.json (gitignore) keyed theo slug.
"""
import base64
import json
import os
import shutil

import requests   # bundled (khong dung httpx -> tranh sap server ban khach thieu httpx)

import fb_lister

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_DIR = os.path.join(ROOT, "facebook")
STORE = os.path.join(FB_DIR, "_source_list.json")

# Anh xa DANG lo -> huong dung + model i2v de xuat + kieu anh mac dinh + co ho tro.
# CHI map sang pipeline remake DA CHAY (rule #1). Motion Control/lipsync CHUA wire -> supported=False.
DANG_MAP = {
    "slideshow_anh": {
        "huong": "Vẽ lại ảnh theo kiểu + i2v (giữ nội dung + giọng gốc)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "video_that_nguoi": {
        "huong": "Vẽ lại giữ nhân vật + i2v (bám khung gốc)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "text_card": {
        "huong": "Ken Burns / ảnh tĩnh + nhạc (chữ do tool vẽ)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "talking_head": {
        "huong": "⚠️ Cần lipsync (chưa hỗ trợ tốt) — tạm vẽ lại giữ nhân vật",
        "clip": "grok_video_heavy", "style": "real", "supported": False},
    "khac": {
        "huong": "⚠️ Chưa rõ dạng — kiểm tay trước khi làm",
        "clip": "grok_video_heavy", "style": "real", "supported": False},
}

# Chi phi uoc tinh 1 CANH (credit ~ dong). banana_pro 1k ~600, grok i2v ~1000. Xem [[co-van-trung-thuc]].
_IMG_CR = 600
_CLIP_CR = {"grok_video_heavy": 1000, "veo_3_1": 800, "wan_2_2": 200,
            "kenburns": 0}      # Ken Burns chay bang ffmpeg tai may -> 0 credit

# Vision nhan NHIEU KHUNG + LOI THOAI (transcript) -> phan loai SAU (cach san xuat + dinh dang
# noi dung). MAU van lay tu do BAO HOA (tin hon vision); KIEU ANH suy tu mau+thuc (khong lay tu
# LLM — POC 2026-07-24: LLM chon kieu_anh khong nhat quan). remakeable canh bao dance/review/gaming.
_VP = """Ban phan tich 1 video ngan de XAY KENH. Duoi la VAI KHUNG HINH + LOI THOAI (transcript).
Phan loai CHINH XAC. Tra JSON THUAN (khong markdown):
{"san_xuat":"talking_head"|"faceless"|"hoat_hinh"|"slideshow_tinh"|"video_ai"|"quay_that",
 "dinh_dang":"<the loai ngan tieng Viet: ke chuyen|hoai niem|review phim|dance nhay|vlog|top list|giao duc|reaction|asmr|nau an|gaming|tin tuc|...>",
 "thuc":"anh_that"|"tranh_ve"|"hoat_hinh","co_chu":true|false,
 "remakeable":true|false,"chu_de":"<ngan tieng Viet>","do_tin_cay":0}
san_xuat: talking_head=nguoi lo mat noi truoc camera; faceless=giong doc + hinh, khong lo mat;
hoat_hinh=nhan vat ve/motion graphic; slideshow_tinh=anh tinh+nhac+giong; video_ai=AI tao toan bo;
quay_that=quay canh that chuyen dong (dance/vlog...).
thuc = HINH ANH TRONG VIDEO TRONG NHU THE NAO (nhin bang mat), KHONG phai video noi ve cai gi:
anh_that=anh/quay that; tranh_ve=tranh ve tay/minh hoa; hoat_hinh=nhan vat ve 2D/3D.
chu_de = video NAY noi ve chuyen gi, CU THE. CAM tra chu chung chung kieu "gia dinh va cuoc song",
"cuoc song thuong ngay"; CAM mac dinh gan moi thu vao "ky uc tuoi tho / hoai niem / lang que"
khi video khong thuc su nhu vay.
remakeable = pipeline lam lai (VE anh + i2v + GIU giong goc) co HOP khong. false neu: dance/nhay,
review/tom tat phim (dung clip phim), gaming, talking_head can lipsync, footage that phuc tap.
CHI JSON."""


def _load():
    if os.path.isfile(STORE):
        try:
            return json.load(open(STORE, encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save(d):
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    tmp = STORE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STORE)


def _measure_video(mp4):
    """Do THAT tu VIDEO (nhieu khung, 0 credit): do BAO HOA (mau/den trang) + so CAT CANH
    (ghep canh vs 1 canh). 1 thumbnail KHONG do duoc may thu nay (do POC 2026-07-24:
    slideshow 8 canh sat=4, 1-canh mau sat=137 -> tach dung; cat-canh tach ghep vs 1 canh)."""
    import glob
    import subprocess
    import tempfile
    import numpy as np
    from PIL import Image
    td = tempfile.mkdtemp()
    try:
        # `setparams=color_primaries=bt709` PHAI dung dau chuoi loc: mot so reel FB co the
        # ghi the mau HONG (prim:reserved) -> swscale tu choi ("Unsupported input, Error
        # number -129") -> ffmpeg ra 0 khung -> ca page bao "khong tai/do duoc video mau".
        # Voi video the mau binh thuong thi day la lenh vo hai (ghi de dung gia tri cu).
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", mp4, "-vf",
                        "setparams=color_primaries=bt709,fps=1,scale=160:-1",
                        "-frames:v", "20", os.path.join(td, "f%03d.jpg")], check=True)
        fs = sorted(glob.glob(os.path.join(td, "f*.jpg")))
        if len(fs) < 2:
            return {"sat": 128.0, "cuts": 0, "scenes": 1}
        hsv = [np.asarray(Image.open(f).convert("HSV"), dtype=np.float32) for f in fs]
        sat = float(np.mean([h[:, :, 1].mean() for h in hsv]))
        gray = [np.asarray(Image.open(f).convert("L"), dtype=np.float32) for f in fs]
        diffs = [float(np.abs(gray[i] - gray[i - 1]).mean()) / 255.0 for i in range(1, len(gray))]
        cuts = sum(1 for d in diffs if d > 0.10)       # nhay lon = cat canh
        return {"sat": round(sat, 1), "cuts": cuts, "scenes": cuts + 1}
    finally:
        shutil.rmtree(td, ignore_errors=True)


GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-flash-latest")

_VP_GEM = """Ban XEM VIDEO ngan nay (ca HINH CHUYEN DONG lan AM THANH) de XAY KENH. Phan loai CHINH XAC.
Tra JSON THUAN (khong markdown):
{"san_xuat":"talking_head"|"faceless"|"hoat_hinh"|"slideshow_tinh"|"video_ai"|"quay_that",
 "dinh_dang":"<the loai ngan tieng Viet: ke chuyen|hoai niem|review phim|dance nhay|vlog|top list|giao duc|reaction|...>",
 "thuc":"anh_that"|"tranh_ve"|"hoat_hinh","co_chu":true|false,
 "remakeable":true|false,"chu_de":"<ngan tieng Viet>","do_tin_cay":0}
san_xuat: talking_head=nguoi lo mat noi truoc camera; faceless=giong doc + hinh, khong lo mat;
hoat_hinh=nhan vat ve/motion graphic; slideshow_tinh=anh tinh+nhac+giong; video_ai=AI tao toan bo;
quay_that=quay canh that CHUYEN DONG (dance/vlog...).
thuc = HINH ANH TRONG VIDEO TRONG NHU THE NAO (nhin bang mat), KHONG phai video noi ve cai gi:
anh_that=anh/quay that; tranh_ve=tranh ve tay/minh hoa; hoat_hinh=nhan vat ve 2D/3D.
chu_de = video NAY noi ve chuyen gi, CU THE. Vi du dung: "hai huoc chuyen sep va nhan vien cong so",
"tinh yeu tuoi hoc tro". CAM tra chu chung chung kieu "gia dinh va cuoc song", "cuoc song thuong ngay",
"tinh cam gia dinh" khi video khong thuc su noi ve cai do. CAM mac dinh gan moi thu vao
"ky uc tuoi tho / hoai niem / lang que" — chi ghi vay khi video THUC SU nhu vay.
remakeable = pipeline lam lai (VE anh + i2v + GIU giong goc) co HOP khong. false neu: dance/nhay,
review/tom tat phim (dung clip phim), gaming, talking_head can lipsync, footage that phuc tap.
do_tin_cay: 0-100. CHI JSON."""


def _gemini_video(mp4):
    """Gui NGUYEN video cho Gemini (XEM ca chuyen dong + am thanh) -> san_xuat/dinh_dang/thuc/
    co_chu/remakeable/chu_de. TIN hon frames-tinh o cho BAT CHUYEN DONG (dance/quay that).
    Video >19MB -> transcode PROXY 480p (fb_remake._gem_ready_video). Tra {} neu thieu key/loi
    (da retry 503/429 trong gemini_generate) -> caller BAO LOI (khong con OpenAI fallback).
    Do THAT 2026-07-24: 9/9 page chay 0 rate-limit; mau khop phep do saturation 9/9."""
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        return {}
    import tempfile
    import fb_remake                                        # dung chung retry + proxy
    send = mp4
    try:
        if os.path.getsize(mp4) > 19 * 1024 * 1024:        # inline Gemini gioi han ~20MB -> proxy nhe
            send = fb_remake._gem_ready_video(mp4, tempfile.mkdtemp()) or mp4
    except OSError:
        pass
    try:
        b64 = base64.b64encode(open(send, "rb").read()).decode()
        txt = fb_remake.gemini_generate(
            [{"inline_data": {"mime_type": "video/mp4", "data": b64}}, {"text": _VP_GEM}],
            gen_config={"responseMimeType": "application/json", "temperature": 0.1})
        return json.loads(txt) or {}
    except Exception:
        return {}


def _vision_frames(mp4, n=8, transcript=""):
    """Vision tren NHIEU khung + LOI THOAI -> san xuat/dinh dang/thuc/chu/remakeable/chu de.
    Transcript la CHIA KHOA phan biet ke chuyen vs dance vs review... (nhin hinh khong ra)."""
    import glob
    import subprocess
    import tempfile
    import fb_remake
    td = tempfile.mkdtemp()
    try:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", mp4, "-vf", "fps=1,scale=380:-1",
                        "-frames:v", str(n), os.path.join(td, "v%02d.jpg")], check=True)
        imgs = [base64.b64encode(open(f, "rb").read()).decode()
                for f in sorted(glob.glob(os.path.join(td, "v*.jpg")))]
        if not imgs:
            return {}
        prompt = _VP + ('\n\nLOI THOAI (transcript):\n"%s"' % transcript.strip()[:800]
                        if (transcript or "").strip() else "\n\n(video khong co loi thoai / khong noi)")
        raw = fb_remake._openai_vision(prompt, imgs, max_tokens=260).strip().strip("`")
        if raw.startswith("json"):
            raw = raw[4:].strip()
        return json.loads(raw)
    finally:
        shutil.rmtree(td, ignore_errors=True)


# Gemini tra text TU DO nen cung MOT the loai ra nhieu ten ('ke chuyen' / 'kể chuyện' /
# 'ke_chuyen' / 'Kể Chuyện') -> loc/nhom theo cot "Dang" deu sai (13 gia tri cho vai khai
# niem). Ep ve MOT tap gia tri co dinh ngay khi nhan ket qua.
_DD_CANON = {
    "ke chuyen": "kể chuyện", "storytelling": "kể chuyện",
    "hoai niem": "hoài niệm", "ky uc": "hoài niệm", "nostalgia": "hoài niệm",
    "review phim": "review phim", "review": "review phim", "tom tat phim": "review phim",
    "dance nhay": "dance/nhảy", "dance": "dance/nhảy", "nhay": "dance/nhảy",
    "vlog": "vlog", "top list": "top list", "toplist": "top list",
    "giao duc": "giáo dục", "kien thuc": "giáo dục", "reaction": "reaction",
    "asmr": "asmr", "nau an": "nấu ăn", "am thuc": "nấu ăn", "gaming": "gaming",
    "tin tuc": "tin tức", "thoi su": "tin tức", "hai": "hài", "comedy": "hài",
    "am nhac": "âm nhạc", "music": "âm nhạc", "the thao": "thể thao",
}


def _strip_dau(s: str) -> str:
    import unicodedata
    s = unicodedata.normalize("NFD", s)
    return "".join(c for c in s if unicodedata.category(c) != "Mn").replace("đ", "d")


def _norm_dinh_dang(v) -> str:
    """'kể chuyện' / 'ke chuyen' / 'ke_chuyen' / 'Kể Chuyện' -> CUNG mot gia tri."""
    s = (v or "").strip().lower().replace("_", " ").replace("-", " ").replace("/", " ")
    s = " ".join(s.split())
    if not s:
        return ""
    key = _strip_dau(s)
    if key in _DD_CANON:
        return _DD_CANON[key]
    # Khop mem NHUNG theo NGUYEN TU ('video ke chuyen cam dong' -> ke chuyen). Khong dung
    # `k in key` thuan: 'truyen cam hung' se dinh 'truyen', 'khai giang' se dinh 'hai'.
    import re as _re
    for k, canon in _DD_CANON.items():
        if _re.search(r"(?:^|\s)%s(?:\s|$)" % _re.escape(k), key):
            return canon
    return s


def _derive(meas, vis, motion=None):
    """Ket hop do-that (mau/canh/CHUYEN DONG) + vision -> phan loai.

    KIEU ANH suy tu MAU (do, tin) + THUC (vision) — KHONG lay tu LLM (POC: LLM chon khong
    nhat quan). TINH/DONG cung suy tu PHEP DO (`motion`, ffmpeg) chu KHONG tu nhan
    `san_xuat` cua Gemini: do that 2026-07-27 tren 33 page cho thay page `chuyencongso69`
    bi Gemini gan 'hoat_hinh' nhung do ra still=0.97 = anh tinh hoan toan.
    """
    # noqa: dinh_dang duoc chuan hoa ngay ben duoi (_norm_dinh_dang)
    den_trang = meas["sat"] < 60           # nguong 60 (do that: 4/33 = den trang, 137 = mau)
    thuc = vis.get("thuc") or "anh_that"
    co_chu = bool(vis.get("co_chu"))
    remakeable = bool(vis.get("remakeable", True))
    san_xuat = (vis.get("san_xuat") or "").strip()
    dinh_dang = _norm_dinh_dang(vis.get("dinh_dang"))
    cuts = meas["cuts"]
    bo_cuc = "ghep_canh" if cuts >= 3 else ("1_canh" if cuts == 0 else "vai_canh")
    # KIEU ANH: den trang -> Ngam Doi; mau+that -> real; ve -> mau nuoc; hoat hinh -> hoat_hinh
    if den_trang:
        style = "ngam_doi"
    elif thuc == "hoat_hinh":
        style = "hoat_hinh"
    elif thuc == "tranh_ve":
        style = "mau_nuoc"
    else:
        style = "real"
    n_scene = 7 if bo_cuc == "ghep_canh" else (1 if bo_cuc == "1_canh" else 3)
    _SX = {"talking_head": "người dẫn (lộ mặt)", "faceless": "faceless (giọng+hình)",
           "hoat_hinh": "hoạt hình", "slideshow_tinh": "slideshow tĩnh",
           "video_ai": "video AI", "quay_that": "quay thật"}
    dd = dinh_dang or _SX.get(san_xuat, "khác")
    # CHUYEN DONG: do bang ffmpeg tren chinh video mau (0 credit). `motion` co the None
    # (do hong / video qua ngan) -> KHONG doan bua, chi ghi 'chua do'.
    tinh = bool(motion and motion.get("static"))
    mo_ta_dong = ("ảnh tĩnh" if tinh else "có chuyển động") if motion else "chưa đo"
    dang = "%s · %s%s%s%s" % (dd, "Đen trắng" if den_trang else "Màu",
                              " · ảnh tĩnh" if tinh else "",
                              " · có chữ" if co_chu else "",
                              "" if remakeable else " · ⚠️ khó làm lại")
    # Nguon TINH -> i2v la tra tien cho chuyen dong ban goc khong he co -> Ken Burns (0 credit).
    clip = "kenburns" if tinh else "grok_video_heavy"
    if remakeable:
        huong = "Vẽ lại %d cảnh kiểu '%s' + %s (giữ giọng gốc)" % (
            n_scene, style, "Ken Burns (0 credit — nguồn là ảnh tĩnh)" if tinh else "i2v")
        if co_chu:
            huong += " — CÓ CHỮ: 79AI không vẽ chữ Việt, tool vẽ chữ bằng font thật"
    else:
        huong = "⚠️ %s — pipeline làm lại (vẽ ảnh+i2v) CHƯA HỢP, giữ nguyên / kiểm tay" % dd
    return {"dang": dang, "san_xuat": san_xuat, "dinh_dang": dinh_dang,
            "mau": "den_trang" if den_trang else "mau", "bo_cuc": bo_cuc,
            "thuc": thuc, "co_chu": co_chu, "remakeable": remakeable,
            "kieu_anh": style, "n_scene": n_scene, "huong": huong,
            "clip": clip, "supported": remakeable,
            "motion": motion or None, "tinh": tinh, "mo_ta_dong": mo_ta_dong,
            "sat": meas["sat"], "cuts": cuts, "scenes": meas["scenes"]}


def analyze_batch(slug, n_sample=2):
    """Phan tich page tu VIDEO THAT (tai 1-2 reel view cao) -> mau/bo cuc/thuc/co chu/chu de.

    KHAC ban cu (chi 1 THUMBNAIL -> khong do duoc chuyen dong/so canh -> gom het 'slideshow',
    khach bao 'sai bet'). Gio do THAT tu video: do bao hoa (mau) + cat canh (bo cuc) + vision
    (anh that/chu/chu de). Video tai ve DUOC TAI DUNG luc remake (khong phi). Xem POC 2026-07-24.
    """
    import tempfile
    import fb_download
    import fb_remake
    idx = fb_lister.load_index(slug)
    reels = sorted((idx.get("reels") or {}).values(),
                   key=lambda x: x.get("views") or 0, reverse=True)
    if not reels:
        raise RuntimeError("Chua cao reel nao cho page nay (cao nguon truoc).")
    meas_all, mot_all, vis, engine = [], [], {}, ""
    why = []      # GIU lai ly do that cua tung reel — truoc day `except: continue` nuot sach
    for r in reels[:max(1, n_sample)]:
        rid = r.get("id")
        if not rid:
            continue
        try:
            dl = fb_download.download_reel(slug, rid, quality="best")
            if not dl.get("ok"):
                why.append("reel %s: tai that bai (%s)" % (rid, str(dl.get("error") or "khong ro")[:120]))
                continue
            mp4 = os.path.join(dl["dir"], "video.mp4")
            meas_all.append(_measure_video(mp4))
            # CHUYEN DONG: video da tai roi nen do them la MIEN PHI (~0.7s, 0 credit).
            # Truoc day buoc phan tich nguon KHONG he do cai nay — nguoi dung nhin bang
            # phan tich khong biet page la slideshow tinh hay quay that, trong khi khau
            # dung lai am tham do va tu doi sang Ken Burns. Cache nam trong thu muc tai ve.
            try:
                _m = fb_remake.motion_stats(mp4, dl["dir"])
                if _m:
                    mot_all.append(_m)
            except Exception as exc:
                why.append("reel %s: do chuyen dong loi (%s)" % (rid, str(exc)[:90]))
            if not vis:
                # CHI Gemini (xem NGUYEN video -> bat chuyen dong dance/quay that). KHONG rot OpenAI.
                vis = _gemini_video(mp4)     # da retry 503/429 ben trong gemini_generate
                engine = "gemini" if vis else ""
        except Exception as e:
            why.append("reel %s: %s: %s" % (rid, type(e).__name__, str(e)[:150]))
            continue
    if not meas_all:
        # Bao ly do THAT thay vi cau chung chung "kiem Chrome dang nhap" — reel co the da bi
        # xoa / gioi han do tuoi / khong co luong tai duoc, chang lien quan gi den cookie.
        raise RuntimeError("Khong tai/do duoc video mau. Chi tiet: "
                           + (" | ".join(why) if why else "khong co reel nao trong index"))
    if not vis:
        # Gemini sap / het retry -> BAO LOI ro tren tool (KHONG len len OpenAI).
        raise RuntimeError("Gemini phan tich that bai (thu lai sau, hoac Gemini dang qua tai).")
    # gop nhieu mau: sat trung binh; cat-canh lay NHIEU nhat (bat 'ghep canh' neu 1 reel co)
    meas = {"sat": round(sum(m["sat"] for m in meas_all) / len(meas_all), 1),
            "cuts": max(m["cuts"] for m in meas_all),
            "scenes": max(m["scenes"] for m in meas_all)}
    # Gop chuyen dong: chi ket luan TINH khi MOI mau deu tinh. Mot mau dong = page co reel
    # dong -> nghieng ve GIU i2v (nhan nham 'tinh' lam video xau di; nhan nham 'dong' chi
    # ton them luot — hai it hon). Day chi la GOI Y muc page: khau dung van do TUNG video.
    motion = None
    if mot_all:
        motion = {
            "still_ratio": round(sum(m["still_ratio"] for m in mot_all) / len(mot_all), 3),
            "median": round(sum(m["median"] for m in mot_all) / len(mot_all), 4),
            "static": all(m.get("static") for m in mot_all),
            "n": len(mot_all),
        }
    d = _derive(meas, vis, motion)
    try:
        tin = int(vis.get("do_tin_cay") or 0)
    except (TypeError, ValueError):
        tin = 0
    result = {**d, "dang_mo_ta": d["huong"], "chu_de": vis.get("chu_de", ""),
              "do_tin_cay": tin if tin >= 40 else 85, "n_sample": len(meas_all),
              "engine": engine or "gemini",
              "analyzed_at": int(__import__("time").time())}
    store = _load()
    store[slug] = result
    _save(store)
    return result


def analyses():
    """Toan bo ket qua phan tich da luu (keyed theo slug) — de xem TAT CA 1 luc.

    Chuan hoa `dinh_dang` NGAY LUC DOC de ket qua phan tich CU (luu truoc khi co _norm_dinh_dang)
    cung ve cung tap gia tri -> loc/nhom theo Dang khong con tach 1 the loai thanh 3 dong.
    """
    d = _load()
    for a in d.values():
        if isinstance(a, dict) and a.get("dinh_dang"):
            a["dinh_dang"] = _norm_dinh_dang(a["dinh_dang"])
    return d


def credit_per_reel(clip="grok_video_heavy", n_scenes=7):
    """Uoc tinh credit lam lai 1 reel = n_scenes x (anh + clip)."""
    return n_scenes * (_IMG_CR + _CLIP_CR.get(clip, 1000))


def _downloaded_ids(slug):
    """Reel ĐÃ CÓ FILE trên đĩa — đọc THẲNG thư mục downloads/.

    Cờ `downloaded` trong index.json chỉ được `fb_download.download_many` ghi; các đường tải
    khác (fb_auto.run_row khi chạy auto, analyze_batch khi phân tích nguồn) tải xong KHÔNG
    cập nhật index ⇒ cột "Trạng thái" của lưới báo "chưa tải" cho 100% reel, kể cả reel đã
    nằm sẵn trên đĩa. Nhìn thẳng vào đĩa là sự thật duy nhất không thể lệch.
    """
    base = os.path.join(FB_DIR, slug, "downloads")
    out = set()
    try:
        for rid in os.listdir(base):
            mp4 = os.path.join(base, rid, "video.mp4")
            if os.path.isfile(mp4) and os.path.getsize(mp4) > 1000:
                out.add(rid)
    except OSError:
        pass
    return out


def grid(slug):
    """Du lieu luoi Danh Sach Nguon cho 1 page: reels + phan tich + uoc tinh."""
    idx = fb_lister.load_index(slug)
    reels = sorted((idx.get("reels") or {}).values(),
                   key=lambda x: x.get("views") or 0, reverse=True)
    analysis = _load().get(slug)
    have = _downloaded_ids(slug)
    try:                                   # reel ĐÃ LÀM (sổ _watch_ledger.json)
        import fb_watch
        done = set(fb_watch.done_ids(slug))
    except Exception:
        done = set()
    rows = [{
        "id": r["id"], "href": r.get("href"), "views": r.get("views"),
        "view_text": r.get("view_text"), "thumb": r.get("thumb"),
        "length": r.get("length"),
        "downloaded": bool(r.get("downloaded")) or (r["id"] in have),
        # made = ĐÃ LÀM LẠI rồi (khỏi tick nhầm reel cũ -> tốn credit đôi + đăng trùng)
        "made": r["id"] in done,
        "status": r.get("status", "listed"),
    } for r in reels]
    return {"slug": slug, "count": len(rows), "analysis": analysis, "reels": rows,
            "n_downloaded": sum(1 for x in rows if x["downloaded"]),
            "n_made": sum(1 for x in rows if x["made"])}


if __name__ == "__main__":
    import sys
    slug = sys.argv[1] if len(sys.argv) > 1 else "tuoitho89x"
    print("Phan tich lo:", slug)
    print(json.dumps(analyze_batch(slug), ensure_ascii=False, indent=1))
