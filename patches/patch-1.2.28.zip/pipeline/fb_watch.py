# -*- coding: utf-8 -*-
"""
WATCHER — canh page NGUON, phat hien reel MOI (chua xu ly).
Dung fb_lister (cao qua Chrome dang dang nhap). So DA XU LY theo (nguon).

Ledger: facebook/_watch_ledger.json = { "<slug>": ["reel_id", ...] }
"""
import json
import os

import fb_lister

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LEDGER = os.path.join(ROOT, "facebook", "_watch_ledger.json")


def _load() -> dict:
    if os.path.isfile(LEDGER):
        with open(LEDGER, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save(d: dict):
    os.makedirs(os.path.dirname(LEDGER), exist_ok=True)
    with open(LEDGER, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)


def is_source(link: str) -> bool:
    """Link la NGUON (page) hay reel co dinh? Nguon = khong co /reel/<so>."""
    import re
    return not bool(re.search(r"/reel/\d+", link or ""))


def scan(link: str, progress=None, max_scroll: int = 8) -> dict:
    """Cao nguon -> tra ve reel MOI (chua trong so). {slug, new:[...], total, done}.

    max_scroll nho (8) = quet nhanh, chi lay reel moi nhat (du de phat hien video moi).
    """
    slug = fb_lister.page_slug(link)
    idx = fb_lister.list_reels(link, max_scroll=max_scroll, progress=progress)
    reels = idx.get("reels", {})            # id -> {views, href, thumb, ...}
    done = set(_load().get(slug, []))
    new = [{"id": rid, **info} for rid, info in reels.items() if rid not in done]
    # moi nhat truoc (reels tab cao tu tren = moi nhat)
    return {"slug": slug, "new": new, "new_count": len(new),
            "total": len(reels), "done": len(done)}


def next_new(link: str) -> str:
    """Reel MOI ke tiep de xu ly (moi nhat chua lam). '' neu het."""
    r = scan(link)
    return r["new"][0]["id"] if r["new"] else ""


# ── BACKLOG xep CU->MOI (cach A): xu tu dau (cu nhat), them bai moi vao DUOI ──
BACKLOG = os.path.join(ROOT, "facebook", "_backlog.json")


def _bl_load() -> dict:
    if os.path.isfile(BACKLOG):
        try:
            with open(BACKLOG, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def _bl_save(d: dict):
    os.makedirs(os.path.dirname(BACKLOG), exist_ok=True)
    tmp = "%s.%d.tmp" % (BACKLOG, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    for _ in range(8):
        try:
            os.replace(tmp, BACKLOG); return
        except OSError:
            import time as _t; _t.sleep(0.05)
    with open(BACKLOG, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    try:
        os.remove(tmp)
    except OSError:
        pass


def _scroll_ids(slug: str) -> list:
    """Id reel theo thu tu CUON (moi->cu) tu index.json da cao."""
    return list((fb_lister.load_index(slug).get("reels") or {}).keys())


def build_backlog(link: str, refresh: bool = False, max_scroll: int = 500,
                  progress=None) -> dict:
    """Dung/ cap nhat backlog CU->MOI cho 1 nguon. Them id MOI vao DUOI.

    refresh=True -> cao lai qua Chrome (fb_lister) truoc; nguoc lai dung index co san.
    Thu tu cuon = moi->cu; DAO lai = cu->moi. Id chua co trong backlog = moi hon
    (nguon chi them bai moi) -> noi vao duoi (dau moi nhat).
    """
    slug = fb_lister.page_slug(link)
    problem = ""
    if refresh:
        _res = fb_lister.list_reels(link, max_scroll=max_scroll, progress=progress) or {}
        problem = _res.get("problem") or ""   # nguon chet/rieng tu -> noi ro, dung im lang
    # Don RAC lot vao index tu cac ban cu (reel cua khung thong bao/quang cao — KHONG
    # phai cua page nay; do that: 1 id dinh o CA 9 page) roi moi dung backlog.
    try:
        n_bad = fb_lister.purge_junk(slug)
        if n_bad:
            print("[backlog] %s: bo %d reel la (khong phai cua page)" % (slug, n_bad), flush=True)
    except Exception:
        n_bad = 0
    scroll = _scroll_ids(slug)                 # moi->cu
    alive = set(scroll)
    d = _bl_load()
    cur = [r for r in d.get(slug, []) if r in alive] if n_bad else d.get(slug, [])
    have = set(cur)
    # id moi (chua trong backlog), dao ve cu->moi, noi vao duoi
    new_ids = [rid for rid in reversed(scroll) if rid not in have]
    if new_ids or n_bad:
        cur = cur + new_ids
        d[slug] = cur
        _bl_save(d)
    return {"slug": slug, "total": len(cur), "added": len(new_ids), "problem": problem}


def _remaining(link: str, auto_build: bool = True) -> list:
    """Danh sach reel CHUA lam (theo backlog cu->moi, bo so da lam)."""
    slug = fb_lister.page_slug(link)
    d = _bl_load()
    if slug not in d and auto_build:
        build_backlog(link, refresh=False)      # dung index co san (khong can Chrome)
        d = _bl_load()
    done = set(_load().get(slug, []))
    return [rid for rid in d.get(slug, []) if rid not in done]


def next_pick(link: str, order: str = "oldest", auto_build: bool = True) -> str:
    """Reel chua xu ly theo THU TU: 'oldest' (cu nhat = dau backlog, MAC DINH) |
    'random' (ngau nhien trong so con lai). '' neu het. Van bo qua reel da lam (s0 mark)."""
    remain = _remaining(link, auto_build)
    if not remain:
        return ""
    if order == "random":
        import random
        return random.choice(remain)
    return remain[0]


def next_oldest(link: str, auto_build: bool = True) -> str:
    """Reel CU NHAT chua xu ly (dau backlog, bo qua so da lam). '' neu het. = next_pick('oldest')."""
    return next_pick(link, "oldest", auto_build)


def backlog_status(link: str) -> dict:
    """Thong ke backlog 1 nguon: tong / da lam / con lai."""
    slug = fb_lister.page_slug(link)
    bl = _bl_load().get(slug, [])
    done = set(_load().get(slug, []))
    remain = [r for r in bl if r not in done]
    return {"slug": slug, "total": len(bl), "done": len(bl) - len(remain),
            "remain": len(remain), "next": remain[0] if remain else ""}


def mark(slug: str, reel_id: str):
    d = _load()
    d.setdefault(slug, [])
    if reel_id not in d[slug]:
        d[slug].append(reel_id)
        _save(d)


def done_ids(slug: str) -> list:
    """Reel DA LAM cua 1 slug (doc so). Dung cho luoi Danh Sach Nguon hien co 'da lam'."""
    return list(_load().get(slug, []))


def fix_orphan_slugs() -> dict:
    """Di tru cac id ghi nham duoi slug rac 'auto' ve DUNG slug page cua chung.

    Di san bug _slug cu (fb_auto tra 'auto' cho link /reel/<id>): reel DA LAM bi ghi so duoi
    key 'auto' -> backlog_status cua page that khong thay -> cot "Kho dem" dem du va luong
    auto se CHON LAI dung reel do lam lan 2 (ton credit doi + dang trung noi dung).
    Tim chu so hu: id nam trong backlog cua slug nao thi tra ve slug do.
    """
    d = _load()
    junk = list(d.get("auto") or [])
    if not junk:
        return {"moved": 0, "left": 0}
    bl = _bl_load()
    moved, left = 0, []
    for rid in junk:
        owner = next((s for s, ids in bl.items() if s != "auto" and rid in ids), "")
        if not owner:
            left.append(rid)
            continue
        d.setdefault(owner, [])
        if rid not in d[owner]:
            d[owner].append(rid)
        moved += 1
    if left:
        d["auto"] = left
    else:
        d.pop("auto", None)
    _save(d)
    return {"moved": moved, "left": len(left)}


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "build":
        # build/refresh backlog cu->moi (cao qua Chrome)
        link = sys.argv[2] if len(sys.argv) > 2 else "https://www.facebook.com/tuoitho89x/reels/"
        r = build_backlog(link, refresh=True,
                          progress=lambda n, s: print("  ...%d reel (buoc %d)" % (n, s), flush=True))
        st = backlog_status(link)
        print("BACKLOG %s: tong %d (them %d) | da lam %d | con %d | ke tiep %s"
              % (r["slug"], st["total"], r["added"], st["done"], st["remain"], st["next"]))
    elif len(sys.argv) > 1 and sys.argv[1] == "build-many-parallel":
        # Cao SONG SONG nhieu nguon (httpx 1 cookie) -> sync backlog -> fallback cuon.
        links = [x for x in sys.argv[2:] if x.strip()]

        def _tidy_tabs():
            # Xong tac vu -> dong bot tab Chrome (chua lai 1 tab de KHONG mat phien).
            try:
                import fb_session
                n = fb_session.close_extra_tabs(keep=1)
                if n:
                    print("  [chrome] da dong %d tab thua" % n, flush=True)
            except Exception:
                pass

        def _crawl_sequential(urls, why=""):
            # Cao TUAN TU tung page (moi page try/except RIENG -> 1 loi khong chan phan con lai).
            if why:
                print("CAO TUAN TU %d nguon (%s)..." % (len(urls), why), flush=True)
            for i, link in enumerate(urls, 1):
                slug = fb_lister.page_slug(link)
                print("\n[%d/%d] %s" % (i, len(urls), slug), flush=True)
                try:
                    _b = build_backlog(link, refresh=True,
                                       progress=lambda n, s: print("  ...%d reel (buoc %d)" % (n, s), flush=True))
                    bs = backlog_status(link)
                    if bs["total"] == 0 and (_b or {}).get("problem"):
                        # Phan biet "nguon da chet" voi "trinh cao hong" — 2 cach xu ly khac han.
                        print("  ⚠ %s: 0 reel — %s" % (slug, _b["problem"]), flush=True)
                    else:
                        print("  XONG %s: tong %d | con %d" % (slug, bs["total"], bs["remain"]), flush=True)
                except Exception as e:
                    print("  LOI %s: %s -> cao tiep" % (slug, e), flush=True)

        # Thu SONG SONG; BAT KY loi nao (thieu httpx / bootstrap / runtime) -> ROT cao tuan tu.
        # (Khach hay bao "loi cao nguon song song" -> phai KHONG BAO GIO vang, luon co duong lui.)
        try:
            import fb_scrape_parallel as sp
            print("CAO SONG SONG %d nguon (concurrency=%d)..." % (len(links), sp.CONCURRENCY), flush=True)
            out = sp.crawl_many_parallel(
                links, progress=lambda slug, n: print("  [%s] %d reel" % (slug, n), flush=True))
        except Exception as e:
            print("Cao song song loi (%s) -> ROT cao TUAN TU (van lay du reel)." % str(e)[:120], flush=True)
            _crawl_sequential(links, why="fallback")
            print("\nTONG: %d nguon (tuan tu)." % len(links), flush=True)
            _tidy_tabs()
            sys.exit(0)
        for r in out["results"]:
            try:
                build_backlog(r["url"], refresh=False)   # dung index vua luu, KHONG cao lai
                bs = backlog_status(r["url"])
                print("  XONG %s: tong %d | con %d" % (r["slug"], bs["total"], bs["remain"]), flush=True)
            except Exception as e:
                print("  backlog loi %s: %s" % (r["slug"], e), flush=True)
        if out["failed_bootstrap"]:                       # page khong bootstrap duoc -> cuon du phong
            _crawl_sequential(out["failed_bootstrap"], why="fallback cuon")
        print("\nTONG: %d page song song, %d fallback." % (len(out["results"]), len(out["failed_bootstrap"])), flush=True)
        _tidy_tabs()
    elif len(sys.argv) > 1 and sys.argv[1] == "build-many":
        # Cao NHIEU nguon TUAN TU trong 1 job (tranh tranh 1 tab Chrome).
        # Moi page try/except RIENG -> 1 page loi KHONG chan cac page con lai.
        links = [x for x in sys.argv[2:] if x.strip()]
        print("CAO %d nguon lan luot..." % len(links), flush=True)
        ok, fail = 0, 0
        for i, link in enumerate(links, 1):
            slug = fb_lister.page_slug(link)
            print("\n[%d/%d] %s" % (i, len(links), slug), flush=True)
            try:
                r = build_backlog(link, refresh=True,
                                  progress=lambda n, s: print("  ...%d reel (buoc %d)" % (n, s), flush=True))
                st = backlog_status(link)
                print("  XONG %s: tong %d (them %d) | con %d"
                      % (r["slug"], st["total"], r["added"], st["remain"]), flush=True)
                ok += 1
            except Exception as e:
                print("  LOI %s: %s -> bo qua, cao tiep" % (slug, e), flush=True)
                fail += 1
        print("\nTONG: %d nguon xong, %d loi." % (ok, fail), flush=True)
    else:
        link = sys.argv[1] if len(sys.argv) > 1 else "https://www.facebook.com/tuoitho89x/reels/"
        r = scan(link, progress=lambda n, s: print("  ...%d reel (buoc %d)" % (n, s), flush=True))
        print("NGUON %s: %d moi / %d tong (da lam %d)" % (r["slug"], r["new_count"], r["total"], r["done"]))
        for x in r["new"][:8]:
            print("  MOI:", x["id"], x.get("view_text"), x.get("href"))
