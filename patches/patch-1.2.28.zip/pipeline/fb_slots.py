# -*- coding: utf-8 -*-
"""
SLOT ALLOCATOR — tinh GIO DANG khi chay NHIEU PAGE SONG SONG.

Cong thuc (nguoi dung chot 2026-07-25):

    gio_dang(page, bai thu k) = anchor + rank(page) * gap_page + k * gap_post

  anchor    = moc bat dau (vd 6h sang hom nay)
  rank(page)= thu tu page DO lam xong BAI DAU (ai xong truoc lay so nho) - first-come-first-serve
  gap_page  = gian cach giua cac PAGE (vd 15')
  gap_post  = gian cach giua cac BAI cua CUNG 1 page (vd 300')

VD 10 page, anchor 6:00, gap_page 15', gap_post 300':
  page xong dau  -> 6:00 (luot 1), 11:00 (luot 2)
  page xong thu 2 -> 6:15 (luot 1), 11:15 (luot 2)
  ...
  page thu 10     -> 8:15 (luot 1), 13:15 (luot 2)

LO TOAN phai chan: neu n_page * gap_page > gap_post thi luot 2 cua page dau CHONG len
luot 1 cua page cuoi -> `check_conflict()` bao ra de UI canh bao.

Rank luu ben file (facebook/_slot_rank.json) de restart khong mat thu tu.
Khac `_compute_slot` cu (server.py): cu tinh theo SO BAI DA LAM cua rieng 1 page,
khong biet cac page khac -> nhieu page xong cung luc thi trung gio.
"""
import json
import os
import time
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.environ.get("CS_FB_ROOT") or os.path.join(ROOT, "facebook")
STORE = os.path.join(FB_ROOT, "_slot_rank.json")

MIN_LEAD = 660          # FB doi gio hen >= 10' tuong lai (dung chung voi fb_publish)
# Moc gio hen da qua bao lau thi coi la "dang bu" (van dang hom nay) thay vi doi hom sau.
# Bang LATE_OK cua fb_chrome_queue de 2 noi xu ly tre GIONG NHAU.
LATE_GRACE = int(os.environ.get("CS_CHROME_LATE_OK", str(2 * 3600)))


# ─────────────────────────── kho rank (ben file) ───────────────────────────
def _load() -> dict:
    try:
        with open(STORE, encoding="utf-8-sig") as f:      # utf-8-sig: file co BOM van doc duoc
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d: dict) -> None:
    os.makedirs(FB_ROOT, exist_ok=True)
    tmp = STORE + ".%d.tmp" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    for _ in range(12):                                    # Windows hay chan os.replace
        try:
            os.replace(tmp, STORE)
            return
        except OSError:
            time.sleep(0.15)
    with open(STORE, "w", encoding="utf-8") as f:          # fallback: ghi thang
        json.dump(d, f, ensure_ascii=False, indent=1)


class _Lock:
    """Khoa lien tien-trinh (lock-file) cho bang rank.

    LOI THAT (do 2026-07-25): N job chay SONG SONG, moi job doc file rank thay RONG roi
    cung ghi rank 0 -> 2 page cung gio dang (13:47 / 13:47) thay vi gian 15 phut.
    Doc-sua-ghi phai nam TRON trong khoa (cung bai hoc voi _pipeline.json).
    """

    def __init__(self, path, wait=8.0):
        self.lock = path + ".lock"
        self.wait = wait
        self.fd = None

    def __enter__(self):
        t0 = time.time()
        while time.time() - t0 < self.wait:
            try:
                self.fd = os.open(self.lock, os.O_CREAT | os.O_EXCL | os.O_RDWR)
                return self
            except FileExistsError:
                try:                       # khoa mo coi (tien trinh chet giua chung)
                    if time.time() - os.path.getmtime(self.lock) > 30:
                        os.unlink(self.lock)
                except OSError:
                    pass
                time.sleep(0.05)
        return self                        # het gio cho -> chay tiep (tha con hon ket)

    def __exit__(self, *a):
        if self.fd is not None:
            os.close(self.fd)
            try:
                os.unlink(self.lock)
            except OSError:
                pass
        return False


# Giu lai bao nhieu LUOT gan nhat. Phai ROI RAI: moi lan bam Star (4 luong x nhieu lan) deu
# mo 1 luot moi, trong khi job cua luot CU van dang render va se con goi rank_of. Cat qua tay
# = bang rank cua luot dang chay bi xoa -> page ke tiep nhan lai rank 0 -> TRUNG GIO, dung
# cai loi ma ban viet lai nay sinh ra de chua.
MAX_RUNS = 24


def _migrate(d: dict) -> dict:
    """File doi cu {run_id, ranks, t0} -> dang moi {runs: {rid: {ranks, t0}}}.

    LOI THAT (do 2026-07-27): kho CHI giu 1 bang rank cho ca he. Chay VIDEO va ANH song song
    (2 luot, 2 run_id khac nhau) thi moi loi goi rank_of thay run_id khac lai XOA bang cua
    luot kia -> lan luot ca hai ben deu nhan rank 0 -> MOI page cung mot gio dang.
    Nay moi luot mot bang RIENG -> 2 luong chay song song khong dam chan nhau.
    """
    if not isinstance(d, dict):
        return {"runs": {}}
    if isinstance(d.get("runs"), dict):
        return d
    out = {"runs": {}}
    rid = str(d.get("run_id") or "")
    if rid:
        out["runs"][rid] = {"ranks": d.get("ranks") or {}, "t0": d.get("t0") or 0}
    return out


def _age_key(run: dict) -> int:
    """Moc 'moi nhat' cua 1 luot = max(t0, cts).

    KHONG duoc xep hang chi theo `t0`: luot VUA MO (reset xong, chua page nao lam xong) co
    t0 = 0 nen se dung CHOT BANG danh sach va bi cat DAU TIEN — dung cai luot dang can dung.
    `cts` (luc mo luot) vi the la moc toi thieu.
    """
    return max(int(run.get("t0") or 0), int(run.get("cts") or 0))


def _trim(d: dict) -> dict:
    runs = d.get("runs") or {}
    if len(runs) > MAX_RUNS:                               # bo luot CU NHAT (theo t0/cts)
        keep = sorted(runs.items(), key=lambda kv: _age_key(kv[1]), reverse=True)[:MAX_RUNS]
        d["runs"] = dict(keep)
    return d


def reset(run_id: str = "") -> None:
    """Mo BANG RANK MOI cho 1 luot (goi khi bam Star). KHONG dung toi luot khac."""
    rid = str(run_id or int(time.time()))
    os.makedirs(FB_ROOT, exist_ok=True)
    with _Lock(STORE):
        d = _migrate(_load())
        # cts = luc MO luot; giu luot moi khoi bi cat nham khi chua page nao lam xong (t0=0).
        d.setdefault("runs", {})[rid] = {"ranks": {}, "t0": 0, "cts": int(time.time())}
        _save(_trim(d))


def rank_of(page_id: str, run_id: str = "") -> int:
    """Cap rank cho page theo THU TU GOI DAU TIEN (first-come-first-serve) TRONG 1 luot.

    Page da co rank -> tra lai rank cu (goi bao nhieu lan cung the).
    Lan cap DAU TIEN cua luot cung ghi `t0` = thoi diem page DAU TIEN lam xong
    (dung lam MOC NEO cho che do "dang luon").
    """
    rid = str(run_id or "_")
    os.makedirs(FB_ROOT, exist_ok=True)
    with _Lock(STORE):                                     # đọc-sửa-ghi TRỌN trong khóa
        d = _migrate(_load())
        run = d.setdefault("runs", {}).setdefault(rid, {"ranks": {}, "t0": 0, "cts": int(time.time())})
        run.setdefault("cts", int(time.time()))
        ranks = run.setdefault("ranks", {})
        if page_id in ranks:
            return int(ranks[page_id])
        if not ranks:                                      # page DAU TIEN cua luot
            run["t0"] = int(time.time())
        ranks[page_id] = len(ranks)                        # 0,1,2... theo thu tu xong
        _save(_trim(d))
        return int(ranks[page_id])


def run_t0(run_id: str = "") -> int:
    """Thoi diem page DAU TIEN cua luot lam xong (moc neo che do 'dang luon').

    Chua co (chua page nao xong) -> tra now.
    """
    run = (_migrate(_load()).get("runs") or {}).get(str(run_id or "_")) or {}
    return int(run.get("t0") or time.time())


# ─────────────────────────── tinh gio ───────────────────────────
def anchor_ts(hhmm: str = "06:00", day_offset: int = 0, now: int = 0) -> int:
    """Moc bat dau: hh:mm cua ngay (hom nay + day_offset).

    LOI THAT (do 2026-07-25): chon "06:00 hom nay" luc 13:15 -> moc nam trong QUA KHU ->
    slot_for keo len 'bay gio' -> watchdog thay den han -> DANG NGAY, trong khi nguoi dung
    bam "Len lich" = mong bai cho toi gio do. Nay moc da qua HON 2h thi tu day sang
    NGAY HOM SAU cung gio (cung nguong LATE_OK cua kho cho: tre <=2h moi dang bu).
    """
    now = int(now or time.time())
    try:
        hh, mm = [int(x) for x in str(hhmm).split(":")[:2]]
    except Exception:
        hh, mm = 6, 0
    base = datetime.fromtimestamp(now) + timedelta(days=max(0, int(day_offset or 0)))
    ts = int(base.replace(hour=hh, minute=mm, second=0, microsecond=0).timestamp())
    if ts < now - LATE_GRACE:
        ts += 86400
    return ts


def late_anchor(run_id: str, now: int = 0, lead: int = 0) -> int:
    """MOC NEO LAI dung CHUNG cho ca luot khi moc goc da troi qua.

    Vi sao phai chung: moi job tinh gio LUC NO LAM XONG. Neu moi job tu neo vao "bay gio"
    cua rieng no roi cong lai rank*gap_page + k*gap_bai thi bai sau bi day ra xa dan —
    do that 2026-07-27 (gap_page 2' + gap_bai 3'): page rank 1 le ra 18:01:49 va 18:04:49
    nhung ra 18:04:49 va 18:08:49, tre dan 3 phut. Ghi moc neo lai MOT LAN vao so cua luot,
    moi job sau dung lai dung moc do -> khoang cach tro ve dung nhu cai da cai.
    """
    now = int(now or time.time())
    rid = str(run_id or "_")
    with _Lock(STORE):
        d = _migrate(_load())
        run = d.setdefault("runs", {}).setdefault(
            rid, {"ranks": {}, "t0": 0, "cts": now})
        got = int(run.get("late_t0") or 0)
        if got and got >= now - LATE_GRACE:     # moc neo lai con han thi dung lai
            return got
        run["late_t0"] = now + int(lead)
        _save(_trim(d))
        return int(run["late_t0"])


def slot_for(anchor: int, rank: int, k: int, gap_page_min: int, gap_post_min: int,
             now: int = 0, min_lead: int = None, run_id: str = "") -> int:
    """Gio dang (unix) cua BAI THU k (0-based) cua page co `rank` (0-based).

    min_lead: khoang cach toi thieu so voi bay gio.
      - None (mac dinh) -> MIN_LEAD (660s): dung khi HEN LICH qua Graph API (FB tu choi
        gio hen qua gan).
      - 0 -> khong day: dung cho CHROME "dang luon" (page dau xong la dang NGAY, khong
        co ly do doi 11 phut vi Chrome bam nut truc tiep chu khong hen lich FB).
    run_id: co thi khi moc goc da qua se dung MOC NEO LAI CHUNG cua luot (xem late_anchor)
      thay vi neo vao "bay gio" cua rieng job dang goi -> khong bi tre dan.
    """
    now = int(now or time.time())
    lead = MIN_LEAD if min_lead is None else max(0, int(min_lead))
    gp = max(0, int(gap_page_min)) * 60
    gb = max(0, int(gap_post_min)) * 60
    ts = int(anchor) + int(rank) * gp + int(k) * gb
    if ts < now + lead:
        # MOC DA QUA (vd t0 con cua luot truoc) -> KHONG duoc keo tat ca ve "bay gio",
        # lam vay moi page ra cung mot gio -> dang lien tuc (do that: 14:05/14:05/14:06).
        # Neo lai NHUNG GIU nguyen khoang cach page/bai.
        base = late_anchor(run_id, now, lead) if run_id else (now + lead)
        ts = base + int(rank) * gp + int(k) * gb
    return ts


def check_conflict(n_pages: int, gap_page_min: int, gap_post_min: int) -> str:
    """'' neu OK. Nguoc lai tra CANH BAO doc duoc (luot 2 chong luot 1 cua page cuoi).

    Dieu kien an toan: (n_pages - 1) * gap_page < gap_post.
    """
    n = max(1, int(n_pages))
    gp, gb = max(0, int(gap_page_min)), max(0, int(gap_post_min))
    need = (n - 1) * gp
    if gb and need >= gb:
        return ("%d page × %d phút = %d phút > giãn cách mỗi bài %d phút → bài lượt 2 của page "
                "đầu sẽ đè lên lượt 1 của page cuối. Tăng giãn cách mỗi bài lên ≥ %d phút "
                "(hoặc giảm giãn cách page)." % (n, gp, need, gb, need + 1))
    return ""


def plan_preview(n_pages: int, n_posts: int, hhmm: str, day_offset: int,
                 gap_page_min: int, gap_post_min: int, now: int = 0,
                 mode: str = "schedule") -> list:
    """Bang gio DU KIEN (de hien cho nguoi dung xem truoc). [{page_i, post_k, ts}]

    mode='now'      -> neo vao BAY GIO (page xong dau tien dang ngay).
    mode='schedule' -> neo vao hh:mm cua ngay (hom nay + day_offset).
    """
    now = int(now or time.time())
    a = now if mode == "now" else anchor_ts(hhmm, day_offset, now)
    out = []
    for i in range(max(1, int(n_pages))):
        for k in range(max(1, int(n_posts))):
            out.append({"page_i": i, "post_k": k,
                        "ts": slot_for(a, i, k, gap_page_min, gap_post_min, now, min_lead=0)})
    out.sort(key=lambda x: x["ts"])
    return out


if __name__ == "__main__":                                 # kiem THAT bang so
    import io
    import sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    now = int(datetime(2026, 7, 25, 5, 0, 0).timestamp())  # 05:00 hom nay
    a = anchor_ts("06:00", 0, now)
    print("anchor:", datetime.fromtimestamp(a).strftime("%d/%m %H:%M"))
    for i in range(3):
        for k in range(2):
            ts = slot_for(a, i, k, 15, 300, now)
            print("  page#%d bai#%d -> %s" % (i, k, datetime.fromtimestamp(ts).strftime("%d/%m %H:%M")))
    print("conflict 10 page:", check_conflict(10, 15, 300) or "OK")
    print("conflict 30 page:", check_conflict(30, 15, 300) or "OK")

    # ── TAI HIEN LOI TROI LICH (do that 2026-07-27) roi chung minh da va ──
    # Boi canh: moi job tinh gio LUC NO LAM XONG. Moc goc da troi qua -> roi vao nhanh
    # "neo lai vao bay gio". Neu moi job tu neo vao "bay gio" cua rieng no thi gio cua
    # cung mot (rank, k) PHU THUOC vao luc job chay -> bai sau tre dan.
    # Thuoc do dung: gio cua (rank, k) KHONG DUOC phu thuoc thoi diem goi.
    STORE = os.path.join(os.environ.get("TEMP", "."), "_test_slot_rank.json")
    for _p in (STORE, STORE + ".lock"):
        if os.path.isfile(_p):
            os.remove(_p)
    fails = 0

    def chk(name, got, want):
        global fails
        ok = got == want
        fails += 0 if ok else 1
        print(("  OK   " if ok else "  FAIL ") + "%s: %s%s"
              % (name, got, "" if ok else " (mong %s)" % want))

    GP, GB = 2, 3                       # dung cau hinh that cua lot chay 18h
    T = int(time.time())
    stale = T - 600                     # moc goc da qua 10 phut

    print("\n-- CHUA VA (moi job tu neo vao 'bay gio' cua no) --")
    a0 = slot_for(stale, 1, 0, GP, GB, now=T, min_lead=0)
    a1 = slot_for(stale, 1, 1, GP, GB, now=T + 180, min_lead=0)   # job sau xong tre 3'
    print("     bai1 %+ds | bai2 %+ds | cach nhau %d phut"
          % (a0 - T, a1 - T, (a1 - a0) // 60))
    chk("khong run_id -> khoang cach SAI (chung to loi co that)",
        (a1 - a0) // 60 != GB, True)

    print("-- DA VA (ca luot dung CHUNG mot moc neo lai) --")
    b0 = slot_for(stale, 1, 0, GP, GB, now=T, min_lead=0, run_id="R1")
    b1 = slot_for(stale, 1, 1, GP, GB, now=T + 180, min_lead=0, run_id="R1")
    b2 = slot_for(stale, 0, 0, GP, GB, now=T + 300, min_lead=0, run_id="R1")
    print("     rank1 bai1 %+ds | rank1 bai2 %+ds | rank0 bai1 %+ds" % (b0 - T, b1 - T, b2 - T))
    chk("2 bai cung page cach dung gap_bai", (b1 - b0) // 60, GB)
    chk("2 page cach dung gap_page", (b0 - b2) // 60, GP)
    chk("goi lai luc khac VAN ra dung gio",
        slot_for(stale, 1, 1, GP, GB, now=T + 900, min_lead=0, run_id="R1"), b1)
    chk("moc neo lai giu nguyen qua nhieu lan goi",
        late_anchor("R1", T + 1200, 0), late_anchor("R1", T, 0))
    chk("luot KHAC thi moc neo rieng",
        late_anchor("R2", T + 60, 0) != late_anchor("R1", T, 0), True)

    print("-- moc goc CON O TUONG LAI thi giu nguyen, khong dung moc neo lai --")
    fut = T + 3600
    chk("giu dung cong thuc", slot_for(fut, 1, 1, GP, GB, now=T, min_lead=0, run_id="R1"),
        fut + 1 * GP * 60 + 1 * GB * 60)

    print("\n%d loi" % fails)
    sys.exit(1 if fails else 0)
