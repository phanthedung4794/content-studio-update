"""Ve anh bang OpenAI gpt-image-2 — goi THANG API OpenAI, KHONG qua 79AI.

Dung o 3 noi (deu di qua generate() ben duoi — sua o day la sua CA 3):
  - tab "Tao anh" (anh don le, dong bo)
  - fb_remake._gen_one_image  -> anh CANH cua video lam lai (Dang hang loat)
  - fb_image_post.make_image   -> anh cua BAI DANG ANH (Dang hang loat)

LUU Y kien truc: 79AI la BAT DONG BO (.task/resume/poll), OpenAI la DONG BO (1 call la xong)
-> nhanh nay khong can .task. Nhung anh ve xong VAN duoc upload nguoc len CDN 79AI
(fb_remake dong 860) de khau i2v dung lam anh tham chieu -> "chon OpenAI" KHONG co nghia
la thoat khoi 79AI hoan toan; khau i2v (anh -> video) van bat buoc qua 79AI.
"""
import base64
import json
import os
import random
import re
import time
import urllib.error
import urllib.request

API_URL = "https://api.openai.com/v1/images/generations"

# Ti le (ten dung chung voi 79AI: "9:16","1:1"...) -> size CO DINH OpenAI ho tro (chi 3
# kich thuoc). "9:16"/"16:9" (video doc/ngang) khong co size rieng -> alias ve 2:3/3:2
# gan nhat (anh se duoc crop lai o buoc dung video/ghep the nao cung khong sao).
SIZES = {"1:1": "1024x1024", "2:3": "1024x1536", "3:2": "1536x1024",
         "9:16": "1024x1536", "16:9": "1536x1024"}

# Gia USD/anh do THAT tu developers.openai.com/api/docs/pricing (2026-07-26, size 1024x1024).
_PRICE_USD = {"low": 0.011, "medium": 0.042, "high": 0.167}
USD_VND = 26000   # ty gia tham khao co dinh — chi de UI hien chi phi uoc tinh (~doi VND)

# BACKOFF khi OpenAI chan toc do (HTTP 429). DO THAT 2026-07-27: OpenAI gop chung 1 nhom
# gioi han ten "gpt-image" cho ca gpt-image-1 lan gpt-image-2, va gioi han theo TIER rat thap:
#   Tier 1 = 5 anh/phut · Tier 2 = 20 · Tier 3 = 50 · Tier 4 = 150 · Tier 5 = 250
# (nguon: developers.openai.com/api/docs/guides/rate-limits, fetch 2026-07-27)
# Moi video ~6-7 canh, hop Star mac dinh threads=0 (chay HET page cung luc) -> Tier 1 cham
# tran ngay lap tuc. Truoc day generate() KHONG he retry -> 429 la giet ca item, phi sach
# nhung anh da ve. Nay: cho roi thu lai, soi chieu mau cua gommo_client._post (79AI).
RATE_TRIES = int(os.environ.get("OPENAI_IMG_RATE_TRIES", "6"))
RATE_MAX_WAIT = int(os.environ.get("OPENAI_IMG_RATE_MAX_WAIT", "60"))
NET_TRIES = 2            # loi mang/timeout (khac rate limit) — thu lai vai lan roi thoi


def price_vnd(quality: str) -> int:
    return round(_PRICE_USD.get(quality, _PRICE_USD["low"]) * USD_VND)


def _key() -> str:
    k = os.environ.get("OPENAI_API_KEY", "")
    if not k:
        raise RuntimeError("Thiếu OPENAI_API_KEY (điền ở Cài đặt → Quản lý key).")
    return k


def _parse_reset(v) -> float | None:
    """Header thoi gian cua OpenAI -> so GIAY. Chiu duoc '6m0s', '1.5s', '500ms', '30'."""
    if not v:
        return None
    s = str(v).strip().lower()
    parts = re.findall(r"([\d.]+)\s*(ms|h|m|s)", s)      # 'ms' phai dung TRUOC 'm'
    if parts:
        unit = {"ms": 0.001, "s": 1.0, "m": 60.0, "h": 3600.0}
        try:
            return sum(float(n) * unit[u] for n, u in parts)
        except (ValueError, KeyError):
            return None
    try:
        return float(s)                                  # 'retry-after: 30' (giay tran)
    except ValueError:
        return None


def _hdr(hdr, name: str):
    """Doc header KHONG phan biet hoa/thuong.

    `HTTPError.headers` that la HTTPMessage (.get da khong phan biet hoa thuong), nhung
    HTTPError co the duoc dung bang dict thuong (test, thu vien khac) — luc do .get('retry-after')
    se TRUOT header 'Retry-After' va ta am tham bo qua so giay OpenAI da bao. Chuan hoa cho chac.
    """
    if not hdr:
        return None
    try:
        v = hdr.get(name)
        if v is not None:
            return v
    except Exception:
        pass
    try:
        items = list(hdr.items())
    except Exception:
        return None
    low = name.lower()
    for k, v in items:
        if str(k).lower() == low:
            return v
    return None


def _err_info(e: urllib.error.HTTPError) -> tuple:
    """Doc than loi HTTPError DUNG 1 LAN (e.read() khong doc lai duoc).

    -> (etype, emsg, wait_giay|None). etype='insufficient_quota' nghia la HET TIEN/QUOTA:
    cho bao lau cung vo ich, phai nap tien -> KHONG duoc retry.
    """
    try:
        raw = e.read().decode("utf-8", "replace")
    except Exception:
        raw = ""
    etype = emsg = ""
    try:
        err = (json.loads(raw) or {}).get("error") or {}
        etype = str(err.get("type") or err.get("code") or "")
        emsg = str(err.get("message") or "")
    except Exception:
        pass
    if not emsg:
        emsg = raw[:400] or "(khong co than loi)"
    wait = None
    for h in ("retry-after", "x-ratelimit-reset-requests", "x-ratelimit-reset-tokens"):
        wait = _parse_reset(_hdr(e.headers, h))
        if wait is not None:
            break
    return etype, emsg, wait


def generate(prompt: str, ratio: str = "1:1", quality: str = "low",
             max_wait_s: float = 120.0) -> bytes:
    """Goi OpenAI images/generations -> tra ve BYTES PNG.

    Gap 429 (chan toc do) thi CHO roi thu lai toi RATE_TRIES lan — uu tien so giay OpenAI
    tu bao trong header (retry-after / x-ratelimit-reset-*), khong co thi backoff luy thua
    + jitter (khuyen nghi chinh thuc cua OpenAI: min 1s, max 60s).
    Het tien/quota (insufficient_quota) thi BAO NGAY, khong cho vo ich.

    max_wait_s = TRAN TONG thoi gian NGU cho rate-limit. Job nen (fb_remake/fb_image_post)
    de mac dinh 120s. Duong DONG BO qua HTTP (tab "Tao anh", server.py) PHAI truyen so nho
    (~25s) — khong thi request treo lau hon timeout cua trinh duyet/uvicorn, nguoi dung
    tuong app dung hinh.
    """
    size = SIZES.get(ratio, "1024x1024")
    q = quality if quality in _PRICE_USD else "low"
    body = json.dumps({"model": "gpt-image-2", "prompt": prompt, "size": size,
                        "quality": q, "n": 1}).encode("utf-8")

    rate_left, net_left, slept = RATE_TRIES, NET_TRIES, 0.0
    while True:
        req = urllib.request.Request(
            API_URL, data=body,
            headers={"Authorization": f"Bearer {_key()}", "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                data = json.loads(r.read().decode())
            break
        except urllib.error.HTTPError as e:
            etype, emsg, wait = _err_info(e)
            if etype == "insufficient_quota":
                raise RuntimeError(
                    "OpenAI hết quota/billing (nạp tiền hoặc kiểm tra gói tại "
                    "platform.openai.com/settings/organization/billing): %s" % emsg[:300])
            if e.code == 429 and rate_left > 0:
                done = RATE_TRIES - rate_left + 1                 # lan thu 1,2,3...
                # `is None` chu KHONG phai `not wait`: header "0s" (server bao thu lai NGAY)
                # la gia tri HOP LE nhung falsy -> truoc day bi coi nhu "khong co header" roi
                # ngu luy thua vo ich.
                if wait is None:
                    wait = min(RATE_MAX_WAIT, 2 ** done)          # 2,4,8,16,32,60
                # CLAMP >= 0: header la du lieu NGOAI, khong tin duoc. Retry-After am ->
                # time.sleep(so am) -> ValueError, ma ValueError KHONG chua chu "OpenAI" nen
                # pha vo chinh co che nhan dien nha cung cap vua xay (fbpShortErr + `terminal`).
                wait = max(0.0, min(RATE_MAX_WAIT, wait)) + random.uniform(0, 3)  # +jitter chong dong pha
                if slept + wait > max_wait_s:                     # het ngan sach cho -> bo cuoc
                    raise RuntimeError(
                        "OpenAI chặn tốc độ (rate limit) — đã chờ %.0fs (trần %.0fs) vẫn chưa qua. "
                        "Giảm 'Số luồng chạy SONG SONG' ở hộp Star, hoặc nâng tier OpenAI "
                        "(Tier 1 chỉ 5 ảnh/phút cho cả nhóm gpt-image): %s"
                        % (slept, max_wait_s, emsg[:300]))
                rate_left -= 1
                slept += wait
                print("   (OpenAI chan toc do -> cho %.0fs roi thu lai %d/%d...)"
                      % (wait, done, RATE_TRIES), flush=True)
                time.sleep(wait)
                continue
            if e.code == 429:
                raise RuntimeError(
                    "OpenAI chặn tốc độ (rate limit) — đã chờ và thử lại %d lần vẫn không qua. "
                    "Giảm 'Số luồng chạy SONG SONG' trong hộp Star, hoặc nâng tier OpenAI "
                    "(Tier 1 chỉ 5 ảnh/phút cho cả nhóm gpt-image): %s" % (RATE_TRIES, emsg[:300]))
            raise RuntimeError("OpenAI từ chối (HTTP %d, %s): %s"
                               % (e.code, etype or "khong ro loai", emsg[:300]))
        except urllib.error.URLError as e:
            if net_left > 0:
                net_left -= 1
                print("   (OpenAI loi mang: %s -> thu lai...)" % str(e.reason)[:80], flush=True)
                time.sleep(5)
                continue
            raise RuntimeError("OpenAI lỗi mạng: %s" % str(e.reason)[:200])

    item = (data.get("data") or [{}])[0]
    b64 = item.get("b64_json")
    if not b64:
        raise RuntimeError(f"OpenAI không trả ảnh: {str(data)[:300]}")
    return base64.b64decode(b64)
