# -*- coding: utf-8 -*-
"""
GOVERNOR — bo ham cho autopilot: chan chay credit + tran video/ngay.
"Full-auto" van phai qua day. Doc credit THAT tu 79AI de quyet dinh.

Config: facebook/_governor.json ; State (dem theo ngay): facebook/_governor_state.json
"""
import json
import os
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.path.join(ROOT, "facebook")
CFG = os.path.join(FB_ROOT, "_governor.json")
STATE = os.path.join(FB_ROOT, "_governor_state.json")

DEFAULT = {
    "enabled": True,
    "floor_credit": 8000,      # duoi nay -> DUNG lam (phanh THAT, bảo vệ credit)
    "video_per_day": 60,       # TRAN AN TOAN tong/ngay (chan runaway). Nhip THAT do
                               # scheduler per-page lo (post_per_page_day + plan_for_page).
                               # 20 page x 2 = 40 -> 60 co margin.
    "post_per_page_day": 2,    # NHIP dang: bai/page/ngay (scheduler + autopilot dung)
    "jitter_min": 25,          # lech gio dang +-phut
    "est_per_video": 7200,     # uoc credit 1 video (de tinh truoc)
    # ── TRAN RIENG cho BAI ANH ─────────────────────────────────────────────────────
    # Anh va video la 2 LUONG khac nhau (rule [[sua-song-song-4-duong]]): dung chung
    # 1 tran thi lam nhieu anh se "an" het suat video cua ngay hom do (va nguoc lai).
    # 1 bai anh ~1 anh 79AI (trong goi = 0 credit) nen tran co the cao hon video.
    "image_per_day": 60,
    "est_per_image": 600,      # uoc credit 1 bai anh (banana_pro vip 1k ~600cr ngoai goi)
}


def _read(path, default):
    if os.path.isfile(path):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return dict(default)
    return dict(default)


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def load_config() -> dict:
    return {**DEFAULT, **_read(CFG, DEFAULT)}


def save_config(cfg: dict) -> dict:
    cur = load_config()
    for k in DEFAULT:
        if k in cfg:
            cur[k] = cfg[k]
    _write(CFG, cur)
    return cur


def _today() -> str:
    return time.strftime("%Y-%m-%d")


def _state() -> dict:
    # produced = so VIDEO da lam hom nay · produced_img = so BAI ANH (dem RIENG, xem DEFAULT).
    s = _read(STATE, {"date": _today(), "produced": 0, "produced_img": 0})
    if s.get("date") != _today():          # sang ngay moi -> reset dem
        s = {"date": _today(), "produced": 0, "produced_img": 0}
        _write(STATE, s)
    s.setdefault("produced_img", 0)        # file cu (truoc khi tach luong anh) khong co khoa nay
    return s


def _credit() -> int:
    """Credit 79AI THAT (None neu khong doc duoc)."""
    try:
        from gommo_client import GommoClient
        return GommoClient().credits()
    except Exception:
        return None


_SUB_CACHE = {"t": 0.0, "active": False}


def sub_active() -> bool:
    """Co goi thue bao (Starter Video...) dang ACTIVE + CON quota video khong?

    Work bang model TRONG goi (veo_3_1/grok/banana_pro) khi con quota = 0 credit
    -> governor KHONG duoc chan theo credit. Cache 10' de khoi goi API moi lan.
    Loi mang -> giu trang thai cache cu (khong chan oan nguoi da mua goi).
    """
    now = time.time()
    if now - _SUB_CACHE["t"] < 600:
        return _SUB_CACHE["active"]
    active = _SUB_CACHE["active"]
    try:
        from gommo_client import GommoClient
        info = GommoClient().subscription()
        if info.get("status") == "ACTIVE":
            opt = info.get("options") or {}
            cap = int(opt.get("videoMonth") or 0)
            used = int(opt.get("videoMonthUsage") or 0)
            active = (cap <= 0) or (used < cap)   # con quota (cap<=0 = khong gioi han)
        else:
            active = False
        _SUB_CACHE.update(t=now, active=active)
    except Exception:
        pass   # giu cache cu
    return active


def _kind_keys(kind: str):
    """(khoa_dem, khoa_tran, khoa_uoc_gia, ten_hien_thi) cho tung LOAI noi dung."""
    if kind == "image":
        return "produced_img", "image_per_day", "est_per_image", "bài ảnh"
    return "produced", "video_per_day", "est_per_video", "video"


def can_produce(est_cost: int = None, plan_free: bool = False, kind: str = "video") -> dict:
    """Co duoc phep LAM them 1 bai (video hoac anh) khong? Tra {ok, reason, credit, produced}.

    plan_free=True (work bang model trong goi thue bao, con quota) -> BO QUA san credit
    (video khong tru credit, tru quota goi) — chi con chan tran/ngay.

    kind='image' -> dung TRAN va BO DEM RIENG cua bai anh (khong an vao suat video).
    """
    cfg = load_config()
    st = _state()
    kcnt, kcap, kest, klabel = _kind_keys(kind)
    made = int(st.get(kcnt) or 0)
    if not cfg["enabled"]:
        return {"ok": False, "reason": "Governor đang TẮT", "produced": made}
    if made >= cfg[kcap]:
        return {"ok": False, "reason": "Đã đủ %d %s hôm nay" % (cfg[kcap], klabel),
                "produced": made}
    cr = _credit()
    if plan_free:                                   # goi thue bao bao -> khong dung credit
        return {"ok": True, "reason": "OK (gói thuê bao — free theo quota)",
                "credit": cr, "produced": made}
    est = est_cost or cfg[kest]
    if cr is None:
        return {"ok": False, "reason": "Không đọc được credit 79AI", "produced": made}
    if cr - est < cfg["floor_credit"]:
        return {"ok": False, "reason": "Credit %d - %d < sàn %d → DỪNG" % (cr, est, cfg["floor_credit"]),
                "credit": cr, "produced": made}
    return {"ok": True, "reason": "OK", "credit": cr, "produced": made}


def record_produced(kind: str = "video"):
    """Ghi so "da lam them 1 bai". PHAI trong khoa: moi job la 1 TIEN TRINH RIENG chay song
    song (N page cung luc) — doc-sua-ghi khong khoa thi 2 job xong cung luc chi dem duoc 1,
    tran/ngay khong con chan dung so bai da lam that. Cung bai hoc voi bang rank fb_slots.
    """
    from fb_slots import _Lock
    k = _kind_keys(kind)[0]
    with _Lock(STATE):
        st = _state()
        st[k] = int(st.get(k) or 0) + 1
        _write(STATE, st)


def status(plan_free: bool = False) -> dict:
    """Trang thai CA HAI luong: can_produce/produced_today la cua VIDEO (giu nguyen nghia cu
    cho moi noi dang doc), them can_produce_img/produced_img_today cho nhanh ANH."""
    cfg = load_config()
    st = _state()
    dec = can_produce(plan_free=plan_free)
    dimg = can_produce(plan_free=plan_free, kind="image")
    return {"config": cfg, "produced_today": st["produced"],
            "credit": dec.get("credit"), "can_produce": dec["ok"], "reason": dec["reason"],
            "produced_img_today": int(st.get("produced_img") or 0),
            "can_produce_img": dimg["ok"], "reason_img": dimg["reason"]}


if __name__ == "__main__":
    print(json.dumps(status(), ensure_ascii=False, indent=1))
