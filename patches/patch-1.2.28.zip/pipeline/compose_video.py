"""
Buoc 3: Ghep tranh + chu tieng Viet + giong doc lien mach.

Kien truc (quan trong):
  - Giong doc la MOT dai lien tuc tu narrate.py (khong cat vun).
  - Video hinh duoc dung theo moc thoi gian tung cau trong timing.json,
    nen phu de va tranh luon khop voi giong.
  - Audio duoc ghep vao SAU CUNG, mot lan duy nhat -> ngu dieu troi chay.

Chu duoc ve bang PIL (sac net, dung dau tieng Viet), KHONG de AI ve chu.

Chay:
    python pipeline/narrate.py --episode ep001      # doc mot mach truoc
    python pipeline/compose_video.py --episode ep001
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageFont

from gommo_client import load_config

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def load_script(episode: str) -> dict:
    path = os.path.join("scripts", f"{episode}.json")
    if not os.path.exists(path):
        raise SystemExit(f"Khong tim thay kich ban: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def hex_to_rgb(value: str) -> tuple:
    value = value.lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))


def wrap_text(draw, text, font, max_width):
    words = text.split()
    lines, current = [], ""
    for word in words:
        trial = f"{current} {word}".strip()
        if draw.textlength(trial, font=font) <= max_width or not current:
            current = trial
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_centered(draw, lines, font, top, width, color, line_gap,
                  stroke=0, stroke_fill=None):
    """Ve cac dong chu can giua. stroke>0 = vien tuong phan (chu noi tren nen loang lo)."""
    y = top
    for line in lines:
        w = draw.textlength(line, font=font)
        draw.text(((width - w) / 2, y), line, font=font, fill=color,
                  stroke_width=stroke, stroke_fill=stroke_fill)
        ascent, descent = font.getmetrics()
        y += ascent + descent + line_gap
    return y


def fit_illustration(img, box_w, box_h):
    src = img.width / img.height
    box = box_w / box_h
    if src > box:
        new_h, new_w = box_h, int(box_h * src)
    else:
        new_w, new_h = box_w, int(box_w / src)
    img = img.resize((new_w, new_h), Image.LANCZOS)
    left = (new_w - box_w) // 2
    top = (new_h - box_h) // 2
    return img.crop((left, top, left + box_w, top + box_h))


def render_frame(cfg, title, caption, scene_path, out_path):
    lay = cfg["layout"]
    W, H = lay["width"], lay["height"]

    canvas = Image.new("RGB", (W, H), hex_to_rgb(lay["bg_color"]))
    draw = ImageDraw.Draw(canvas)

    title_font = ImageFont.truetype(lay["fonts"]["title"], lay["title_font_size"])
    cap_font = ImageFont.truetype(lay["fonts"]["caption"], lay["caption_font_size"])

    title_lines = wrap_text(draw, title, title_font, lay["title_max_width"])
    draw_centered(draw, title_lines, title_font, lay["title_top"], W,
                  hex_to_rgb(lay["title_color"]), 6)

    band_top, band_h = lay["image_top"], lay["image_height"]
    draw.rectangle([0, band_top, W, band_top + band_h],
                   fill=hex_to_rgb(lay["band_color"]))
    if os.path.exists(scene_path):
        illo = Image.open(scene_path).convert("RGB")
        canvas.paste(fit_illustration(illo, W, band_h), (0, band_top))

    if caption:
        cap_lines = wrap_text(draw, caption, cap_font, lay["caption_max_width"])
        draw_centered(draw, cap_lines, cap_font, lay["caption_top"], W,
                      hex_to_rgb(lay["caption_color"]), 10)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    canvas.save(out_path, quality=95)


def probe_duration(path):
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", path],
        capture_output=True, text=True, check=True,
    )
    return float(r.stdout.strip())


def probe_loudness(path):
    r = subprocess.run(
        ["ffmpeg", "-hide_banner", "-i", path, "-af", "volumedetect",
         "-f", "null", os.devnull],
        capture_output=True, text=True,
    )
    mean = peak = 0.0
    for line in r.stderr.splitlines():
        if "mean_volume:" in line:
            mean = float(line.split("mean_volume:")[1].replace("dB", "").strip())
        elif "max_volume:" in line:
            peak = float(line.split("max_volume:")[1].replace("dB", "").strip())
    return mean, peak


def build_visual(cfg, frame_path, duration, out_path):
    """Chi dung HINH, khong co audio - audio se ghep sau, mot lan duy nhat."""
    v = cfg["video"]
    fps = v["fps"]
    frames = max(int(duration * fps), 1)
    zmax = 1.0 + float(v.get("zoom_per_beat", 0) or 0)

    if zmax > 1.001:
        step = (zmax - 1.0) / frames
        vf = (f"scale=2160:3840,"
              f"zoompan=z='min(zoom+{step:.6f},{zmax:.4f})':d={frames}"
              f":x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1080x1920:fps={fps},"
              f"format=yuv420p")
    else:
        vf = f"fps={fps},format=yuv420p"

    subprocess.run(
        ["ffmpeg", "-y", "-v", "error",
         "-loop", "1", "-framerate", str(fps), "-i", frame_path,
         "-t", f"{duration:.3f}", "-vf", vf,
         "-c:v", "libx264", "-preset", "medium", "-crf", "20",
         "-pix_fmt", "yuv420p", "-an", out_path],
        check=True,
    )


def pick_music(cfg: dict, given: str = None) -> str:
    """Chon nhac nen. Uu tien file duoc chi dinh, khong thi lay ngau nhien
    trong assets/music/. Tra ve '' neu khong co nhac."""
    if given:
        if not os.path.exists(given):
            raise SystemExit(f"Khong tim thay nhac: {given}")
        return given

    music_dir = cfg.get("paths", {}).get("music_dir", "assets/music")
    if not os.path.isdir(music_dir):
        return ""

    tracks = [os.path.join(music_dir, f) for f in sorted(os.listdir(music_dir))
              if f.lower().endswith((".mp3", ".m4a", ".wav", ".ogg"))]
    if not tracks:
        return ""

    import random
    return random.choice(tracks)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--episode", required=True)
    parser.add_argument("--variant", default="")
    parser.add_argument("--music", default=None,
                        help="File nhac nen. Bo trong -> lay ngau nhien trong assets/music/")
    parser.add_argument("--no-music", action="store_true",
                        help="Khong ghep nhac (mac dinh se lay trong assets/music/ neu co)")
    parser.add_argument("--music-db", type=float, default=None,
                        help="Am luong nhac, dB. Am = nho hon giong doc. Mac dinh -18")
    args = parser.parse_args()

    cfg = load_config()
    script = load_script(args.episode)
    ep = args.episode
    tag = ep + (f"_{args.variant}" if args.variant else "")
    title = script["title"]

    scenes_dir = os.path.join(cfg["paths"]["scenes_dir"], ep)
    voice_dir = os.path.join(cfg["paths"]["voice_dir"], ep)
    final_dir = cfg["paths"]["final_dir"]
    os.makedirs(final_dir, exist_ok=True)

    timing_path = os.path.join(voice_dir, "timing.json")
    audio_path = os.path.join(voice_dir, "narration.mp3")
    if not os.path.exists(timing_path):
        raise SystemExit(
            f"Thieu {timing_path}.\n"
            f"Chay truoc: python pipeline/narrate.py --episode {ep}"
        )

    with open(timing_path, "r", encoding="utf-8") as f:
        timing = json.load(f)

    workdir = tempfile.mkdtemp(prefix=f"{tag}_")
    segments = []

    n_img = len({b.get("image_idx", b["index"]) for b in timing["beats"]})
    print(f"Dung hinh theo moc giong doc "
          f"({len(timing['beats'])} doan / {n_img} tranh)...")

    # HINH PHAI PHU KIN TIENG, KE CA KHOANG LANG.
    #
    # Truoc day moi doan hinh chi dai bang b["duration"] — tuc la chi phan CO
    # TIENG NOI. Khoang lang GIUA cac doan khong thuoc doan nao -> hinh ngan hon
    # tieng dung bang tong cac khoang lang.
    #
    # Roi co -shortest cat theo luong NGAN hon -> CAU CUOI BI CUT.
    # Da do that: hinh 12.23s / tieng 12.72s -> mat 0.49s cuoi.
    #
    # Sua: doan hinh keo dai den luc doan SAU bat dau. Doan cuoi keo den het tieng.
    total = timing.get("total_duration") or timing["beats"][-1]["end"]
    beats = timing["beats"]

    for n, b in enumerate(beats):
        i = b["index"]
        # Tranh giu nguyen qua nhieu doan; chi CHU chay ben duoi doi.
        img = b.get("image_idx", i)
        scene_path = os.path.join(scenes_dir, f"scene_{img:02d}.png")
        if not os.path.exists(scene_path):
            raise SystemExit(
                f"Thieu {scene_path}.\n"
                f"Chay truoc: python pipeline/generate_scenes.py --episode {ep}"
            )

        frame_path = os.path.join(workdir, f"frame_{i:02d}.png")
        render_frame(cfg, title, b["caption"], scene_path, frame_path)

        # Den luc doan sau bat dau (om ca khoang lang sau doan nay).
        stop = beats[n + 1]["start"] if n + 1 < len(beats) else total
        span = max(stop - b["start"], b["duration"])

        seg = os.path.join(workdir, f"seg_{i:02d}.mp4")
        build_visual(cfg, frame_path, span, seg)
        segments.append(seg)

        gap = span - b["duration"]
        print(f"  doan {i:02d} [tranh {img:02d}]  {b['start']:>6.2f}s -> "
              f"{b['end']:>6.2f}s  ({b['duration']:.2f}s"
              + (f" + {gap:.2f}s lang)" if gap > 0.02 else ")"))

    # Noi phan hinh
    list_path = os.path.join(workdir, "concat.txt")
    with open(list_path, "w", encoding="utf-8") as f:
        for seg in segments:
            f.write(f"file '{seg.replace(os.sep, '/')}'\n")

    visual = os.path.join(workdir, "visual.mp4")
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
         "-i", list_path, "-c", "copy", visual],
        check=True,
    )

    # Ghep giong doc (+ nhac nen neu co) vao hinh
    v = cfg["video"]
    lufs = float(v.get("loudness_lufs", -14))
    gain = float(v.get("audio_gain_db", 0) or 0)
    music_db = args.music_db if args.music_db is not None else float(v.get("music_db", -18))

    music = "" if args.no_music else pick_music(cfg, args.music)
    out_path = os.path.join(final_dir, f"{tag}.mp4")

    cmd = ["ffmpeg", "-y", "-v", "error", "-i", visual, "-i", audio_path]

    if music:
        # Nhac lap lai cho du dai, ha am luong, va TU DONG NE giong doc
        # (sidechaincompress: khi co tieng noi, nhac tu nho lai).
        cmd += ["-stream_loop", "-1", "-i", music]
        filt = (
            f"[1:a]loudnorm=I={lufs}:TP=-1.5:LRA=11,apad[voice];"
            f"[2:a]volume={music_db}dB[m];"
            f"[m][voice]sidechaincompress=threshold=0.02:ratio=6:attack=10:release=350[duck];"
            f"[voice][duck]amix=inputs=2:duration=first:dropout_transition=0[a]"
        )
        cmd += ["-filter_complex", filt, "-map", "0:v", "-map", "[a]"]
    else:
        af = f"loudnorm=I={lufs}:TP=-1.5:LRA=11"
        if gain:
            af += f",volume={gain}dB"
        af += ",apad"
        cmd += ["-af", af]

    cmd += ["-c:v", "libx264", "-preset", "medium", "-crf", "20",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-ac", "2",
            "-shortest", "-movflags", "+faststart", out_path]

    subprocess.run(cmd, check=True)

    total = probe_duration(out_path)
    mean, peak = probe_loudness(out_path)
    print(f"\n===== XONG: {out_path} ({total:.1f}s) =====")
    print(f"Am luong: trung binh {mean:.1f} dB, dinh {peak:.1f} dB")
    if music:
        print(f"Nhac nen : {os.path.basename(music)} ({music_db:.0f} dB, tu ne giong doc)")
    else:
        print("Nhac nen : khong  (bo file .mp3 vao assets/music/ de tu ghep)")
    print("Giong doc lien mach 1 lan - phu de khop theo moc thoi gian that.")


if __name__ == "__main__":
    main()
