"""
Dieu phoi TAO VIDEO AI (montage i2v) — chay nhu 1 job trong hang doi.

Luong (SONG SONG de nhanh):
  Pha 0: che do giong -> doc loi tung canh -> do dai -> chon do dai clip.
  Pha 1: nop TAT CA anh khung dau -> cho tat ca -> tai.
  Pha 2: nop TAT CA clip i2v -> cho tat ca (hien %/message, canh bao ket) -> tai.
  Pha 3: video_montage ghep clip + nhac/giong -> MP4 doc 1080x1920.

BEN VUNG (chong dot credit): moi buoc luu file. Chay lai -> BO QUA clip da co;
clip DANG CHO luu id vao .vid -> RESUME dung clip do, khong tao (tra tien) lai.

Chay:  python pipeline/ai_video.py --spec videos-ai/<id>/spec.json
Cwd = thu muc kenh (hang doi tu dat). Duong dan trong spec tuong doi voi cwd.
"""
import argparse
import json
import os
import re
import sys
import time

from gommo_client import GommoClient, load_config, download
import video_montage

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

POLL_INTERVAL = 10       # giay giua 2 lan hoi
VIDEO_TIMEOUT = 2400     # 40 phut — Kling relax xep hang co the >16 phut/clip
STALL_WARN = 720         # 12 phut percent=0 khong doi -> CANH BAO (khong fail: Kling
                         # ngoi 0% khi xep hang la binh thuong, fail som se giet oan)


def log(msg: str) -> None:
    print(msg, flush=True)


def _save_state(workdir: str, state: dict) -> None:
    with open(os.path.join(workdir, "state.json"), "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=1)


def _pick_duration(durations: list, need: float) -> str:
    vals = sorted(int(d) for d in durations if str(d).isdigit())
    if not vals:
        return None
    for v in vals:
        if v >= need - 0.01:
            return str(v)
    return str(vals[-1])


def _narrate_continuous(voice: dict, scenes: list, out_mp3: str, cfg: dict) -> list:
    """Doc LIEN MACH ca kich ban trong MOT lan goi ElevenLabs (/with-timestamps)
    -> giong troi chay, khong vap. Tra ve targets[i] = do dai (giay) DANH cho canh i
    (tu luc canh i bat dau doc den luc canh SAU bat dau; canh cuoi den het giong).

    Nho vay HINH doi theo GIONG (giong nhu compose_video.py cua ban lam), khong
    con doc roi tung canh roi chen khoang lang (thu gay vap).
    """
    import base64
    import requests
    import eleven_tts

    ev = (cfg.get("voice", {}) or {}).get("eleven", {}) or {}
    model = voice.get("model") or ev.get("model", "eleven_v3")
    # Noi loi cac canh thanh MOT chuoi, nho vi tri ky tu dau moi canh.
    parts, spans, cursor = [], [], 0
    for sc in scenes:
        t = (sc.get("narration") or "").strip()
        if not t:
            spans.append(None)
            continue
        if parts:
            parts.append(" ")
            cursor += 1
        spans.append((cursor, cursor + len(t)))
        parts.append(t)
        cursor += len(t)
    text = "".join(parts)

    payload = {
        "text": text, "model_id": model, "language_code": "vi",
        # Seed CO DINH — khop voi "nghe thu" (probe) de giong nhat quan (xem eleven_tts).
        "seed": eleven_tts.DEFAULT_SEED,
        "voice_settings": {
            "stability": float(voice.get("stability", ev.get("stability", 0.45))),
            "similarity_boost": 0.8,
            "style": float(voice.get("style", ev.get("style", 0.55))),
            "use_speaker_boost": True,
            "speed": float(voice.get("speed", ev.get("speed", 0.88))),
        },
    }
    r = requests.post(
        f"https://api.elevenlabs.io/v1/text-to-speech/{voice['eleven_voice']}/with-timestamps",
        headers={"xi-api-key": eleven_tts.get_key(), "Content-Type": "application/json"},
        json=payload, timeout=300)
    if r.status_code != 200:
        raise SystemExit(f"ElevenLabs loi {r.status_code}: {r.text[:250]}")
    data = r.json()
    with open(out_mp3, "wb") as f:
        f.write(base64.b64decode(data["audio_base64"]))

    align = data.get("alignment") or data.get("normalized_alignment") or {}
    starts = align.get("character_start_times_seconds") or []
    ends = align.get("character_end_times_seconds") or []
    if not starts:
        raise SystemExit("ElevenLabs khong tra ve moc thoi gian. Doi model khac.")
    total = float(ends[-1])

    # Moc bat dau doc cua tung canh (canh rong -> None).
    scene_start = []
    for span in spans:
        if span is None:
            scene_start.append(None)
        else:
            a = min(span[0], len(starts) - 1)
            scene_start.append(float(starts[a]))

    # target[i] = tu luc canh i bat dau den luc canh KE TIEP (co loi) bat dau;
    # canh cuoi -> den het giong. Om ca khoang nghi -> hinh phu kin tieng.
    idx = [i for i, s in enumerate(scene_start) if s is not None]
    targets = [None] * len(scenes)
    for k, i in enumerate(idx):
        nxt = scene_start[idx[k + 1]] if k + 1 < len(idx) else total
        targets[i] = max(round(nxt - scene_start[i], 3), 1.0)
    return targets, round(total, 3)


def _narrate_omni(voice: dict, scenes: list, out_mp3: str, cfg: dict) -> tuple:
    """Doc bang OMNIVOICE — doc CA KICH BAN 1 MACH (khong doc roi tung canh).

    VI SAO 1 mach: OmniVoice zero-shot, moi lan generate() cho tong/nhip HOI KHAC
    -> doc roi 8 canh nghe 'lech' (tong troi giua cac canh). Doc 1 mach -> giong
    DONG NHAT ca video. OmniVoice khong co moc thoi gian nhu Eleven, nen chia thoi
    luong moi canh THEO TI LE SO CHU (hinh doi gan dung cho loi).

    OmniVoice CHAM va giay phep CC-BY-NC (cam thuong mai).
    """
    import omnivoice_tts
    import voice_profiles

    pid = voice.get("profile_id")
    if not pid:
        raise SystemExit("Chế độ giọng OmniVoice: chưa chọn profile.")
    ref = voice_profiles.reference_path(pid, os.getcwd())
    if not os.path.isfile(ref):
        raise SystemExit(f"Không tìm thấy giọng OmniVoice (profile {pid}).")

    import subprocess

    ov = (cfg.get("voice", {}) or {}).get("omnivoice", {}) or {}
    step = int(ov.get("step", 8))
    guid = float(ov.get("guidance", 1.0))
    denoise = bool(ov.get("denoise", False))
    threads = int(ov.get("threads", 0))
    CHUNK_CHARS = 220          # OmniVoice doc text QUA DAI (1 lan >~250 ky tu) hay
                               # cat cut/loi -> gom canh thanh khuc <=220 ky tu.

    idx = [i for i, sc in enumerate(scenes) if (sc.get("narration") or "").strip()]
    if not idx:
        raise SystemExit("Không có lời đọc nào cho OmniVoice.")
    texts = {i: scenes[i]["narration"].strip() for i in idx}

    # Gom cac canh LIEN TIEP thanh khuc <= CHUNK_CHARS (1 canh dai qua van 1 khuc).
    chunks, cur, cur_len = [], [], 0
    for i in idx:
        li = len(texts[i])
        if cur and cur_len + li > CHUNK_CHARS:
            chunks.append(cur); cur, cur_len = [], 0
        cur.append(i); cur_len += li + 1
    if cur:
        chunks.append(cur)

    workdir = os.path.dirname(out_mp3)
    targets = [None] * len(scenes)
    parts = []
    for c, group in enumerate(chunks):
        text = " ".join(texts[i] for i in group)
        seg = os.path.join(workdir, f"omnichunk_{c:02d}.mp3")
        omnivoice_tts.speak(text, seg, ref_audio=ref, step=step, guidance=guid,
                            denoise=denoise, threads=threads)
        dseg = video_montage.probe_duration(seg)
        parts.append(seg)
        # Chia thoi luong khuc cho cac canh trong khuc theo TI LE so ky tu.
        glens = [max(len(texts[i]), 1) for i in group]
        gs = sum(glens)
        acc = 0.0
        for k, i in enumerate(group):
            dur = dseg - acc if k == len(group) - 1 else round(dseg * glens[k] / gs, 3)
            targets[i] = max(dur, 0.5)
            acc += targets[i]

    if len(parts) == 1:
        os.replace(parts[0], out_mp3)
    else:
        lst = os.path.join(workdir, "omni_concat.txt")
        with open(lst, "w", encoding="utf-8") as f:
            for p in parts:
                f.write(f"file '{p.replace(os.sep, '/')}'\n")
        # RE-ENCODE khi noi (khong -c copy) — cac mp3 khuc co the lech DTS gay
        # loi/gap o mep -> re-encode cho lien mach sach.
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
                        "-i", lst, "-c:a", "libmp3lame", "-b:a", "192k",
                        "-ar", "44100", out_mp3], check=True)
    return targets, round(video_montage.probe_duration(out_mp3), 3)


def _create_video_retry(client: GommoClient, seconds: int, **kw) -> tuple:
    """Nop clip; neu 79ai tu choi vi THOI LUONG (vd Kling relax chi 5s du bang gia
    ghi co 10s), boc so giay duoc phep tu thong bao roi NOP LAI. Tra (resp, seconds).
    """
    rv = client.create_video(duration=str(seconds), **kw)
    if rv.get("error"):
        msg = str(rv.get("message") or "")
        m = re.search(r"(\d+)\s*s", msg)
        if m and ("thoi luong" in msg.lower() or "thời lượng" in msg
                  or "duration" in msg.lower() or "support" in msg.lower()):
            alt = int(m.group(1))
            if alt != seconds:
                rv = client.create_video(duration=str(alt), **kw)
                if not rv.get("error"):
                    return rv, alt
    return rv, seconds


def _id_of(resp: dict) -> str:
    for k in ("id_base", "id", "job_id"):
        if resp.get(k):
            return resp[k]
    vi = resp.get("videoInfo") or resp.get("data") or {}
    if isinstance(vi, dict):
        return vi.get("id_base") or vi.get("id") or ""
    return ""


def _set_scene(state: dict, i: int, **kw) -> None:
    for s in state["scenes"]:
        if s["i"] == i:
            s.update(kw)
            return
    state["scenes"].append({"i": i, **kw})


def _poll_many(client: GommoClient, id_map: dict, workdir: str, state: dict,
               kind: str, on_done) -> None:
    """Cho NHIEU job cung luc (song song). id_map: {scene_i: job_id}.

    - Hien %/message that; CANH BAO neu ket (percent=0 khong doi lau) — KHONG fail.
    - Job FAIL/ERROR -> dung ngay. Xong -> goi on_done(i, info) (de tai file).
    """
    remaining = dict(id_map)
    last = {i: (None, None, time.time()) for i in id_map}
    start = time.time()
    while remaining and time.time() - start < VIDEO_TIMEOUT:
        for i, jid in list(remaining.items()):
            info = client.check_video(jid) if kind == "video" else client.check_image(jid)
            status = str(info.get("status") or "").upper()
            url = GommoClient._video_url(info) if kind == "video" else info.get("url")
            pct = info.get("percent") or 0
            msg = (info.get("message") or "").strip()
            if "FAIL" in status or "ERROR" in status:
                _set_scene(state, i, status="loi", percent=pct)
                _save_state(workdir, state)
                raise SystemExit(f"Canh {i + 1} that bai: {msg or status}")
            if url and "PENDING" not in status and "PROCESS" not in status \
               and "QUEUE" not in status:
                remaining.pop(i)
                _set_scene(state, i, status="xong", percent=100)
                _save_state(workdir, state)
                on_done(i, info)
                log(f"  canh {i + 1}: xong")
                continue
            op, om, ots = last[i]
            if pct != op or msg != om:
                log(f"  canh {i + 1}: {pct}% {msg[:44]}")
                last[i] = (pct, msg, time.time())
                _set_scene(state, i, status="dang", percent=pct)
                _save_state(workdir, state)
            elif time.time() - ots > STALL_WARN:
                mins = int((time.time() - ots) / 60)
                log(f"  [!] canh {i + 1} CO THE KET: {mins} phut khong nhuc nhich "
                    f"({pct}% '{msg[:30]}'). Neu la VEO/Google, nen doi model (Kling).")
                last[i] = (pct, msg, time.time())
        if remaining:
            time.sleep(POLL_INTERVAL)
    if remaining:
        raise TimeoutError(
            f"Canh {[i + 1 for i in remaining]} chua xong sau {VIDEO_TIMEOUT // 60} phut "
            f"(79ai qua tai). Chay lai job de RESUME (khong ton them credit).")


def run(spec_path: str) -> None:
    with open(spec_path, "r", encoding="utf-8") as f:
        spec = json.load(f)

    workdir = os.path.dirname(os.path.abspath(spec_path))
    cfg = load_config()
    lay = cfg["layout"]
    W, H, fps = lay["width"], lay["height"], cfg["video"]["fps"]

    ratio = spec.get("ratio", "9:16")
    mode = spec.get("audio_mode", "music")
    img = spec.get("image", {})
    vid = spec.get("video", {})
    voice = spec.get("voice") or {}
    scenes = spec["scenes"]
    durations = vid.get("durations") or []

    client = GommoClient()
    try:
        credit0 = client.credits()
    except Exception:
        credit0 = None
    log(f"Bat dau tao video AI - {len(scenes)} canh, che do am thanh: {mode}"
        + (f" | so du: {credit0} credit" if credit0 is not None else ""))

    state = {"id": spec.get("id"), "status": "running",
             "scenes": [{"i": i, "status": "cho", "percent": 0} for i in range(len(scenes))]}
    _save_state(workdir, state)

    # ── PHA 0: giong doc LIEN MACH (1 lan) + do dai moi canh theo moc giong ──
    voice_track = ""
    targets = [None] * len(scenes)
    voice_total = 0.0
    if mode == "voice" and any((sc.get("narration") or "").strip() for sc in scenes):
        voice_track = os.path.join(workdir, "narration.mp3")
        timing_path = os.path.join(workdir, "timing.json")
        engine = voice.get("engine") or ("omnivoice" if voice.get("profile_id") else "eleven")
        if os.path.isfile(voice_track) and os.path.isfile(timing_path):
            tj = json.load(open(timing_path, encoding="utf-8"))
            targets, voice_total = tj["targets"], tj["total"]
        elif engine == "omnivoice":
            log("Doc loi bang OmniVoice (tung canh, cham)...")
            targets, voice_total = _narrate_omni(voice, scenes, voice_track, cfg)
            json.dump({"targets": targets, "total": voice_total},
                      open(timing_path, "w", encoding="utf-8"))
        else:
            log("Doc loi ElevenLabs LIEN MACH (1 lan, khop moc thoi gian)...")
            targets, voice_total = _narrate_continuous(voice, scenes, voice_track, cfg)
            json.dump({"targets": targets, "total": voice_total},
                      open(timing_path, "w", encoding="utf-8"))
        log(f"Giong doc {voice_total:.1f}s ({engine}).")

    plan = []
    for i, sc in enumerate(scenes):
        if mode == "voice" and targets[i] is not None:
            target = targets[i]
            seconds = int(_pick_duration(durations, target) or sc.get("seconds") or 5)
        else:
            seconds = int(sc.get("seconds") or (durations[0] if durations else 5))
            target = float(seconds)
        plan.append({"i": i, "seconds": seconds, "target": target,
                     "clip": os.path.join(workdir, f"clip_{i:02d}.mp4"),
                     "frame": os.path.join(workdir, f"frame_{i:02d}.png"),
                     "url": os.path.join(workdir, f"frame_{i:02d}.url"),
                     "vidid": os.path.join(workdir, f"clip_{i:02d}.vid")})

    def _need_clip(p):
        return not os.path.isfile(p["clip"])

    # ── PHA 1: anh khung dau (nop het -> cho het) ──
    pend_img = {}
    for p in plan:
        if not _need_clip(p) or os.path.isfile(p["url"]):
            continue
        sc = scenes[p["i"]]
        log(f"[canh {p['i'] + 1}] ve anh khung dau...")
        # Chong matte/vien toi banana hay them (da gap that: anh loi vien tren-duoi).
        prompt_img = sc["prompt_img"].rstrip(". ") + \
            ". Full bleed, fills the entire vertical 9:16 frame edge to edge, " \
            "no black bars, no border, no vignette, no letterbox, no matte."
        if img["model"] == "gpt-image-2":
            # OpenAI ve THANG (dong bo, ngoai 79AI) — khong co ma job de poll nhu 79AI.
            # Khau i2v sau do chi nhan URL nen ve xong phai UPLOAD NGUOC len CDN 79AI
            # (upload_image, KHONG ton credit AI); tu do moi buoc sau coi nhu anh 79AI
            # binh thuong. Giong het nhanh da chay o fb_remake/fb_image_post — truoc ban
            # nay tab "Tao video AI" la noi DUY NHAT khong dung duoc model nay.
            import openai_image
            png = openai_image.generate(prompt_img, ratio=ratio,
                                        quality=img.get("mode") or "low")
            with open(p["frame"], "wb") as f:
                f.write(png)
            up = client.upload_image(p["frame"])
            url = up.get("url") or up.get("image") or up.get("src")
            if not url:
                raise SystemExit(f"Canh {p['i'] + 1} upload anh len 79AI khong tra URL: {str(up)[:150]}")
            with open(p["url"], "w", encoding="utf-8") as f:
                f.write(url)
            continue
        r = client.create_image(model=img["model"], prompt=prompt_img, ratio=ratio,
                                mode=img.get("mode") or None,
                                resolution=img.get("resolution") or None)
        if r.get("error"):
            raise SystemExit(f"Canh {p['i'] + 1} 79AI tu choi ve anh: {r.get('message') or r}")
        info = r.get("imageInfo") or r.get("data") or r
        iid = info.get("id_base") or r.get("id_base")
        if not iid:
            raise SystemExit(f"Canh {p['i'] + 1} khong lay duoc ma anh: {r}")
        pend_img[p["i"]] = iid

    if pend_img:
        log(f"Cho {len(pend_img)} anh khung dau...")
        by_i = {p["i"]: p for p in plan}

        def _img_done(i, info):
            p = by_i[i]
            download(info["url"], p["frame"])
            with open(p["url"], "w", encoding="utf-8") as f:
                f.write(info["url"])
        _poll_many(client, pend_img, workdir, state, "image", _img_done)

    # ── PHA 2: clip i2v (nop het -> cho het) ──
    pend_vid = {}
    for p in plan:
        if not _need_clip(p):
            continue
        vjid = ""
        if os.path.isfile(p["vidid"]):
            vjid = open(p["vidid"], encoding="utf-8").read().strip()
        if vjid:
            # Clip da dat truoc do THAT BAI (79ai fail) -> bo ma cu, nop lai clip moi
            # (khong ke lai clip dang xu ly). Nho vay resume TU LANH sau khi het tien.
            try:
                st = str(client.check_video(vjid).get("status") or "").upper()
                if "FAIL" in st or "ERROR" in st:
                    log(f"[canh {p['i'] + 1}] clip cu that bai -> nop lai")
                    os.remove(p["vidid"])
                    vjid = ""
            except Exception:
                pass
        if not vjid:
            img_url = open(p["url"], encoding="utf-8").read().strip()
            sc = scenes[p["i"]]
            log(f"[canh {p['i'] + 1}] tao chuyen dong (i2v, {p['seconds']}s)...")
            rv, used = _create_video_retry(
                client, p["seconds"],
                model=vid["model"], prompt=sc.get("prompt_action") or sc.get("prompt_img"),
                ratio=ratio, mode=vid.get("mode") or None,
                resolution=vid.get("resolution") or None, ref_image_urls=[img_url])
            if rv.get("error"):
                raise SystemExit(f"Canh {p['i'] + 1} 79AI tu choi tao video: {rv.get('message') or rv}")
            if used != p["seconds"]:
                log(f"[canh {p['i'] + 1}] model chi cho {used}s -> dung {used}s (montage giu khung cuoi cho khop giong)")
                p["seconds"] = used
            vjid = _id_of(rv)
            if not vjid:
                raise SystemExit(f"Canh {p['i'] + 1} khong lay duoc ma video: {rv}")
            with open(p["vidid"], "w", encoding="utf-8") as f:
                f.write(vjid)
        else:
            log(f"[canh {p['i'] + 1}] tiep tuc cho clip da dat...")
        pend_vid[p["i"]] = vjid

    if pend_vid:
        log(f"Cho {len(pend_vid)} clip (chay song song, co the vai phut/clip)...")
        by_i = {p["i"]: p for p in plan}

        def _vid_done(i, info):
            download(GommoClient._video_url(info), by_i[i]["clip"])
        _poll_many(client, pend_vid, workdir, state, "video", _vid_done)

    # ── PHA 3: ghep montage (hinh khop theo GIONG LIEN MACH) ──
    log("Ghep clip + am thanh...")
    montage_scenes = [{"clip": p["clip"], "seconds": p["target"]} for p in plan]
    music = spec.get("music") or ""
    if music and not os.path.isabs(music):
        music = os.path.join(os.getcwd(), music)
    out_path = os.path.join(os.path.dirname(workdir), f"{spec['id']}.mp4")
    result = video_montage.build_montage(
        montage_scenes, out_path, mode=mode, music=music, voice_track=voice_track,
        voice_speed=float(spec.get("voice_speed", 1.0)),
        music_db=float(spec.get("music_db", cfg["video"].get("music_db", -18))),
        lufs=float(cfg["video"].get("loudness_lufs", -14)),
        width=W, height=H, fps=fps)

    state["status"] = "done"
    state["output"] = os.path.basename(out_path)
    state.update(result)
    _save_state(workdir, state)

    if credit0 is not None:
        try:
            log(f"Da tieu ~{credit0 - client.credits()} credit.")
        except Exception:
            pass
    log(f"===== XONG: {out_path} ({result['duration']}s, {result['n_scenes']} canh) =====")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True, help="Duong dan spec.json")
    args = ap.parse_args()
    run(args.spec)


if __name__ == "__main__":
    main()
