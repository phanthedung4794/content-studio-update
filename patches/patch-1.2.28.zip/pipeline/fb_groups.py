"""Kho NHOM cua tung page + luat XOAY VONG chon nhom cho moi bai dang.

Vi sao co file nay
------------------
Facebook GIOI HAN cung: moi bai chi chia se duoc TOI DA 3 NHOM ("Chon toi da 3 nhom de
chia se" — doc that tu composer 2026-07-27). Page co 13 nhom thi khong the dang het 1 luot,
phai chia ra nhieu bai. Neu bai nao cung chon 3 nhom DAU danh sach thi 10 nhom con lai
khong bao gio duoc dung.

Luat xoay vong (nguoi dung chot)
-------------------------------
Moi bai lay k = min(3, tong so nhom), bat dau tu con tro, VONG TRON; xong con tro nhich
dung k. Vi du:
    1 nhom : bai nao cung [1]
    2 nhom : bai nao cung [1,2]
    4 nhom : [1,2,3] -> [4,1,2] -> [3,4,1] ...   (moi bai 1 nhom moi, bo 1 nhom cu)
    6 nhom : [1,2,3] -> [4,5,6] -> [1,2,3] ...   (chia doi, khong lap)

Dinh danh nhom = ID, KHONG phai ten
-----------------------------------
Nguoi dung canh bao "nhieu nhom trung ten" — thuc te dung: trong 13 nhom cua page
Goc Suy Ngam co "CAU NOI HAY Y NGHIA @" va "CAU NOI HAY Y NGHIA" gan giong het nhau.
DO THAT 2026-07-27: the `[role="option"]` trong o chon nhom mang thuoc tinh
`id="<group_id>"`. Kiem chung bang cach mo `facebook.com/groups/<id>` — 3/3 ra dung ten
nhom. Vay moi nhom luu {id, name, members}; xoay vong + so khop deu theo ID.

Thu tu danh sach GIU BEN theo lan quet dau (nhom moi noi vao CUOI) — neu de Facebook
quyet dinh thu tu moi lan quet thi con tro se nhay lung tung, co nhom bi bo qua mai.

Con tro luu ben trong `_page_groups.json` (co khoa lien tien-trinh vi nhieu job dang
song song co the ghi cung luc).

Graph API KHONG dung duoc: Facebook da khai tu Groups API — do that 2026-07-27, ca v19 lan
v21, `/me/groups` va `/{page}/groups` deu tra "(#100) nonexisting field (groups)". Danh sach
nhom CHI doc duoc bang Chrome, o buoc "Chia se" cua composer.
"""
import json
import os
import re
import time

ROOT = os.environ.get("CS_FB_ROOT") or os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "facebook")
STORE = os.path.join(ROOT, "_page_groups.json")

GROUP_MAX = 3          # tran CUNG cua Facebook, khong phai lua chon cua tool


# ─────────────── QUET NHOM BANG API (nhanh gap ~50 lan duong composer) ───────────────
# DO THAT 2026-07-27 (bat request bang CDP Network domain, tim ID nhom da biet trong body):
# danh sach nhom di qua XHR `business.facebook.com/api/graphql/` voi
#   fb_api_req_friendly_name = ReelComposerGroupShareSelectorQuery
#   doc_id                   = 9227517497354334
#   variables                = {}          <- KHONG co tham so nao
#   av                       = <page_id>   <- page duoc xac dinh BANG DAY
# Tra ve viewer.actor.groups_eligible_for_post_crossposting.nodes[] {id,name,audience_size}.
#
# Vi variables rong va page nam o `av`, ta KHONG can upload video, KHONG can mo composer —
# doi `av` la quet duoc page khac. Duong composer (scan_groups) ton ~1-2 phut/page vi phai
# tai video len; duong nay vai giay cho ca danh sach.
#
# ⚠️ Ket luan cu "khong bat duoc request" (ghi trong skill hom nay) la SAI — luc do do bang
# cach boc fetch/XHR bang JS, ma `fb_session.CDP.send()` doc roi VUT BO moi event nen khong
# thay gi. Do lai bang CDP Network domain thi ra ngay.
GQL_URL = "https://business.facebook.com/api/graphql/"
GQL_DOC_ID = "9227517497354334"
GQL_NAME = "ReelComposerGroupShareSelectorQuery"


def _dtsg_from_html(html: str) -> str:
    import re
    for pat in (r'"DTSGInitialData",\[\],\{"token":"(.*?)"',
                r'name="fb_dtsg" value="(.*?)"',
                r'"dtsg":\{"token":"(.*?)"'):
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return ""


def _lsd_from_html(html: str) -> str:
    import re
    m = re.search(r'"LSD",\[\],\{"token":"(.*?)"', html)
    return m.group(1) if m else ""


def harvest_api_creds(port: int = 0) -> dict:
    """Lay cookie + fb_dtsg + lsd + user_id 1 LAN, dung chung cho MOI page.

    fb_dtsg la cua NGUOI DUNG (khong phai cua page) nen harvest mot lan la quet duoc het.
    """
    import urllib.request
    import fb_session as S
    port = port or S.DEFAULT_PORT
    # Tu mo tab RIENG (dung CDP.attach lay targets[0] = cuop tab cua bo dang — da tung
    # giet mot bai dang dang vi loi nay).
    req = urllib.request.Request(
        "http://127.0.0.1:%d/json/new?https://business.facebook.com/latest/home" % port,
        method="PUT")
    tab = json.loads(urllib.request.urlopen(req, timeout=10).read().decode())
    c = S.CDP(tab["webSocketDebuggerUrl"])
    html = ""
    try:
        c.send("Network.enable")
        ua = c.eval("navigator.userAgent")
        for _ in range(20):
            html = c.eval("document.documentElement.outerHTML") or ""
            dtsg = _dtsg_from_html(html)
            if dtsg:
                break
            time.sleep(1)
        cks = c.send("Network.getCookies",
                     {"urls": ["https://business.facebook.com",
                               "https://www.facebook.com"]}).get("cookies", [])
        cookie = "; ".join("%s=%s" % (k["name"], k["value"]) for k in cks)
        uid = ""
        for k in cks:
            if k["name"] == "c_user":
                uid = k["value"]
        return {"cookie": cookie, "ua": ua, "dtsg": dtsg,
                "lsd": _lsd_from_html(html), "user": uid}
    finally:
        try:
            c.close()
        except Exception:
            pass
        try:
            urllib.request.urlopen("http://127.0.0.1:%d/json/close/%s" % (port, tab["id"]),
                                   timeout=5).read()
        except Exception:
            pass


def fetch_groups_api(page_id: str, cred: dict, timeout: float = 25.0) -> list:
    """Doc danh sach nhom cua 1 page bang API. Tra [{id,name,members}]. Nem loi neu FB tu choi."""
    import requests
    body = {
        "av": str(page_id),                 # <- page dong vai; doi day la doi page
        "__user": cred.get("user") or "0",
        "__a": "1",
        "fb_dtsg": cred.get("dtsg") or "",
        "lsd": cred.get("lsd") or "",
        "fb_api_caller_class": "RelayModern",
        "fb_api_req_friendly_name": GQL_NAME,
        "variables": "{}",
        "server_timestamps": "true",
        "doc_id": GQL_DOC_ID,
    }
    h = {
        "content-type": "application/x-www-form-urlencoded",
        "cookie": cred.get("cookie") or "",
        "user-agent": cred.get("ua") or "Mozilla/5.0",
        "origin": "https://business.facebook.com",
        "referer": "https://business.facebook.com/latest/reels_composer?asset_id=%s" % page_id,
        "accept": "*/*",
        "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin",
        "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
        "x-fb-friendly-name": GQL_NAME,
    }
    r = requests.post(GQL_URL, data=body, headers=h, timeout=timeout)
    txt = r.text
    if txt.startswith("for (;;);"):
        txt = txt[9:]
    d = json.loads(txt)
    if d.get("errors"):
        raise RuntimeError(str(d["errors"])[:200])
    actor = ((d.get("data") or {}).get("viewer") or {}).get("actor")
    # PHAN BIET "page that su khong co nhom" voi "phep do hong". Neu cred het han / FB doi
    # cau truc, response van co the la HTTP 200 khong co `errors` nhung thieu han khoa nay
    # -> tra [] am tham, roi set_groups(prune=True) XOA TRANG kho da quet. Thieu khoa thi
    # NEM LOI de nguoi goi biet, con nodes rong that su moi la 0 nhom.
    if not isinstance(actor, dict) or "groups_eligible_for_post_crossposting" not in actor:
        raise RuntimeError(
            "response khong co 'groups_eligible_for_post_crossposting' "
            "(cred het han hay FB doi cau truc?) — KHONG coi la 'page khong co nhom'")
    nodes = actor.get("groups_eligible_for_post_crossposting") or {}
    out = []
    for n in (nodes.get("nodes") or []):
        if not n.get("id"):
            continue
        # KHOA ANH DAI DIEN: composer BAI VIET ANH khong gan group_id vao o tick (chi co
        # id React kieu js_q4), nen phai co cach khac de nhan dien -> dung ma anh dai dien
        # (vd 292411544_547058960499146_...) vi CA HAI ben deu co. Ten thi trung nhau
        # (page nay co ca "CAU NOI HAY Y NGHIA @" lan "CAU NOI HAY Y NGHIA").
        link = (((n.get("cover_photo") or {}).get("photo") or {}).get("download_link") or "")
        m = re.search(r"/(\d+_\d+_\d+)_n\.", link)
        out.append({"id": str(n["id"]), "name": n.get("name") or str(n["id"]),
                    "members": int(n.get("audience_size") or 0),
                    "cover": m.group(1) if m else ""})
    return out


# Query dung composer BAI VIET — danh sach nhom nam san trong do (khong co query rieng).
PHOTO_DOC_ID = "27092208143781466"
PHOTO_NAME = "BusinessCometComposerRootQuery"


def fetch_photo_groups_api(page_id: str, cred: dict, timeout: float = 30.0) -> list:
    """Nhom ma composer BAI VIET ANH se cho chon. Tra [{id,name,members,cover}].

    KHAC voi fetch_groups_api (duong reel): day la `suggested_groups` — nhom Facebook
    GOI Y, chi vai nhom (do that: 7 trong khi duong reel co 26). Do la GIOI HAN CUA
    FACEBOOK chu khong phai giao dien cat bot — bam "Xem them cac nhom" roi cuon cung
    khong ra them.
    """
    import requests
    variables = {"business_presence_id": str(page_id), "creative_id": None,
                 "creative_ids": None, "content_id": None, "entry_point": None,
                 "is_edit_composer": False, "photo_id": None, "shouldOptimizeSATP": False,
                 "__relay_internal__pv__BizWebShouldShowCTASectionCardProviderrelayprovider":
                     False}
    body = {"av": str(page_id), "__user": cred.get("user") or "0", "__a": "1",
            "fb_dtsg": cred.get("dtsg") or "", "lsd": cred.get("lsd") or "",
            "fb_api_caller_class": "RelayModern",
            "fb_api_req_friendly_name": PHOTO_NAME,
            "variables": json.dumps(variables, separators=(",", ":")),
            "server_timestamps": "true", "doc_id": PHOTO_DOC_ID}
    h = {"content-type": "application/x-www-form-urlencoded",
         "cookie": cred.get("cookie") or "", "user-agent": cred.get("ua") or "Mozilla/5.0",
         "origin": "https://business.facebook.com",
         "referer": "https://business.facebook.com/latest/composer?asset_id=%s" % page_id,
         "accept": "*/*", "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
         "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin",
         "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
         "x-fb-friendly-name": PHOTO_NAME}
    r = requests.post(GQL_URL, data=body, headers=h, timeout=timeout)
    txt = r.text
    if txt.startswith("for (;;);"):
        txt = txt[9:]
    d = json.loads(txt.splitlines()[0] if txt.strip() else "{}")
    if d.get("errors"):
        raise RuntimeError(str(d["errors"])[:200])
    grp = ((((d.get("data") or {}).get("businessContent") or {})
            .get("business_composer_config") or {}).get("group") or {})
    out = []
    for n in (grp.get("suggested_groups") or []):
        if not n.get("id"):
            continue
        uri = ((n.get("profile_picture") or {}).get("uri") or "")
        m = re.search(r"/(\d+_\d+_\d+)_n\.", uri)
        out.append({"id": str(n["id"]), "name": n.get("name") or str(n["id"]),
                    "members": int((n.get("group_member_profiles") or {}).get("count") or 0),
                    "cover": m.group(1) if m else ""})
    return out


def _load() -> dict:
    try:
        with open(STORE, encoding="utf-8-sig") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d: dict) -> None:
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    tmp = "%s.tmp%d" % (STORE, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STORE)


def _patch(fn):
    """Doc-sua-ghi CO KHOA (nhieu job dang song song cung ghi con tro)."""
    from fb_slots import _Lock
    with _Lock(STORE):
        d = _load()
        fn(d)
        _save(d)
        return d


def _norm(g) -> dict:
    """Chap nhan {id,name,members} hoac chuoi ten tran (du lieu cu / test)."""
    if isinstance(g, dict):
        gid = str(g.get("id") or "").strip()
        name = str(g.get("name") or "").strip()
        rec = {"id": gid or name, "name": name or gid}
        if g.get("cover"):
            rec["cover"] = str(g["cover"])
        if g.get("members"):
            try:
                rec["members"] = int(g["members"])
            except Exception:
                pass
        return rec
    s = str(g).strip()
    return {"id": s, "name": s}


# ── HAI DANH SACH KHAC NHAU, PHAI GIU SO RIENG ──────────────────────────────
# DO THAT 2026-07-27: nhom cho REEL va nhom cho BAI VIET ANH la HAI danh sach khac nhau.
#   reel  : ReelComposerGroupShareSelectorQuery -> groups_eligible_for_post_crossposting
#           = TRON BO nhom du dieu kien (page Goc Suy Ngam: 26 nhom)
#   anh   : BusinessCometComposerRootQuery -> business_composer_config.group.suggested_groups
#           = nhom Facebook GOI Y (chi 7) — day la ly do composer anh chi thay 7, khong
#             phai do giao dien cat bot. Cuon/bam "Xem them" cung khong ra them.
# Dung chung mot con tro thi hai luong pha nhau (bai anh nhich con tro cua reel va nguoc
# lai) -> moi loai giu so rieng trong cung mot ban ghi page.
_KEYS = {"reel": ("groups", "cursor"), "photo": ("pgroups", "pcursor")}


def _k(kind: str):
    return _KEYS.get(str(kind or "reel"), _KEYS["reel"])


def get(page_id: str) -> dict:
    return _load().get(str(page_id)) or {}


def all_pages() -> dict:
    return _load()


def groups(page_id: str, kind: str = "reel") -> list:
    gk, _ = _k(kind)
    return list(get(page_id).get(gk) or [])


def set_groups(page_id: str, glist: list, prune: bool = True,
               kind: str = "reel") -> list:
    """Ghi danh sach nhom quet duoc (moi phan tu {id,name[,members]}).

    - GIU THU TU cu cho nhom van con; nhom MOI noi vao cuoi.
    - Con tro bam theo ID (khong phai chi so) nen nhom bi xoa khong lam lech vong xoay.

    prune=True  : danh sach dua vao la DAY DU -> nhom khong con trong do thi BO
                  (dung cho duong API: query tra tron bo).
    prune=False : danh sach dua vao chi la MOT PHAN -> chi THEM, khong bao gio bo
                  (dung cho duong composer: no tai dung DOM, moi luc chi ve ~13 the du
                  page co 26 nhom — do that 2026-07-27, ghi de kieu prune se an mat
                  13 nhom con lai).
    Tra ve danh sach sau khi gop.
    """
    page_id = str(page_id)
    incoming = [_norm(g) for g in (glist or []) if _norm(g)["id"]]

    # CHONG XOA TRANG: danh sach moi RONG khong du bang chung de ket luan "page mat het
    # nhom". DO THAT 2026-07-27: Facebook loi phia ho (`field_exception`) khien 33/34 page
    # tra 0 nhom trong mot lan quet -> prune=True xoa kho reel 535 -> 29, mat sach cong
    # quet. (Kho ANH song sot nguyen ven vi dung prune=False.) Nhom da roi that thi luc
    # dang se khong tick duoc va con tro tu nhich qua — nhe hon nhieu so voi mat du lieu.
    if prune and not incoming:
        gk, _ = _k(kind)
        old_n = len(_load().get(page_id, {}).get(gk) or [])
        if old_n:
            return list(_load().get(page_id, {}).get(gk) or [])
    inc_by_id, seen = {}, []
    for g in incoming:                      # bo trung id ngay tu dau vao
        if g["id"] not in inc_by_id:
            inc_by_id[g["id"]] = g
            seen.append(g["id"])

    gk, ck = _k(kind)
    out = []

    def _do(d):
        old = d.get(page_id) or {}
        old_list = list(old.get(gk) or [])
        old_ids = [g.get("id") for g in old_list]
        cur = int(old.get(ck) or 0)
        # nhom o vi tri con tro TRUOC khi gop -> de bam lai dung cho sau khi gop
        anchor = old_ids[cur % len(old_ids)] if old_ids else None

        old_by_id = {g.get("id"): g for g in old_list}
        if prune:
            kept = [inc_by_id[i] for i in old_ids if i in inc_by_id]   # giu thu tu cu
        else:                       # chi cap nhat ten/so thanh vien, KHONG bo nhom nao
            kept = [inc_by_id.get(i) or old_by_id[i] for i in old_ids]
        added = [inc_by_id[i] for i in seen if i not in old_by_id]
        merged = kept + added

        if not merged:
            new_cur = 0
        elif anchor and anchor in inc_by_id:
            new_cur = [g["id"] for g in merged].index(anchor)        # bam theo ID
        else:
            new_cur = cur % len(merged)
        rec = dict(old)                 # GIU nguyen so cua loai kia
        rec[gk], rec[ck] = merged, new_cur
        rec["ts"] = int(time.time())
        d[page_id] = rec
        out.extend(merged)
    _patch(_do)
    return out


def pick(page_id: str, n_max: int = GROUP_MAX, advance: bool = True) -> list:
    """Chon nhom cho BAI KE TIEP theo luat xoay vong -> danh sach {id,name}.

    Chua quet nhom / page khong co nhom -> tra [] (bai VAN dang binh thuong, chi la khong
    kem nhom nao). advance=False = chi XEM truoc, khong nhich con tro.
    """
    page_id = str(page_id)
    rec = get(page_id)
    gl = list(rec.get("groups") or [])
    if not gl:
        return []
    k = min(int(n_max or GROUP_MAX), len(gl))
    cur = int(rec.get("cursor") or 0) % len(gl)
    out = [gl[(cur + i) % len(gl)] for i in range(k)]
    if advance:
        def _do(d):
            r = d.get(page_id) or {"groups": gl, "cursor": 0}
            n = len(r.get("groups") or gl)
            r["cursor"] = (int(r.get("cursor") or 0) + k) % max(1, n)
            d[page_id] = r
        _patch(_do)
    return out


def pick_from(page_id: str, present, n_max: int = GROUP_MAX, advance_cur: bool = True,
              kind: str = "reel") -> list:
    """Nhu pick() nhung CHI chon trong so nhom composer DANG CO.

    Vi sao can: composer BAI VIET ANH chi cho thay 7 nhom (do that 2026-07-27, bam
    "Xem them cac nhom" roi cuon cung khong ra them — NOSCROLL), trong khi kho co 26.
    Neu cu lay 3 nhom ke tiep theo con tro thi phan lon lan se roi vao nhom KHONG co
    tren man hinh -> tick hut, bai nao cung khong kem nhom.

    `present` = tap khoa nhan dien dang co (cover / id / ten). Di theo dung THU TU xoay
    vong tu con tro, nhat nhung nhom co mat, toi da n_max; con tro nhich qua nhom CUOI
    da nhat (khong phai qua ca danh sach) -> lan sau di tiep tu do.
    """
    gl = groups(page_id, kind)
    if not gl:
        return []
    _, ck = _k(kind)
    keys = {str(x) for x in (present or []) if x}
    n = len(gl)
    cur = int(get(page_id).get(ck) or 0) % n
    out, steps = [], 0
    for i in range(n):
        g = gl[(cur + i) % n]
        if (g.get("cover") and g["cover"] in keys) or str(g.get("id")) in keys \
                or (g.get("name") or "") in keys:
            out.append(g)
            steps = i + 1
            if len(out) >= int(n_max or GROUP_MAX):
                break
    if advance_cur and steps:
        advance(page_id, steps, kind)
    return out


def advance(page_id: str, k: int, kind: str = "reel") -> None:
    """Nhich con tro DUNG so nhom THUC SU tick duoc.

    Vi sao tach khoi pick(): neu tick hut (FB doi giao dien, nhom bien mat giua chung) ma
    van nhich du k thi so nhom hut se bi BO QUA han o cac bai sau — dung y do xoay vong.
    """
    k = int(k or 0)
    if k <= 0:
        return

    gk, ck = _k(kind)

    def _do(d):
        r = d.get(str(page_id))
        if not r:
            return
        n = len(r.get(gk) or [])
        if n:
            r[ck] = (int(r.get(ck) or 0) + k) % n
    _patch(_do)


def count(page_id: str, kind: str = "reel") -> int:
    return len(groups(page_id, kind))


def names(page_id: str, kind: str = "reel") -> list:
    return [g.get("name") or g.get("id") for g in groups(page_id, kind)]


if __name__ == "__main__":                       # tu kiem luat xoay vong
    import sys
    STORE = os.path.join(os.environ.get("TEMP", "."), "_test_page_groups.json")
    if os.path.isfile(STORE):
        os.remove(STORE)
    fails = 0

    def chk(name, got, want):
        global fails
        ok = got == want
        fails += 0 if ok else 1
        print(("  OK   " if ok else "  FAIL ") + f"{name}: {got}" + ("" if ok else f" (mong {want})"))

    def ids(lst):
        return [g["id"] for g in lst]

    def mk(n):
        return [{"id": "g%d" % i, "name": "Nhom %d" % i} for i in range(1, n + 1)]

    for n, want in ((1, [["g1"], ["g1"], ["g1"]]),
                    (2, [["g1", "g2"], ["g1", "g2"]]),
                    (4, [["g1", "g2", "g3"], ["g4", "g1", "g2"], ["g3", "g4", "g1"]]),
                    (6, [["g1", "g2", "g3"], ["g4", "g5", "g6"], ["g1", "g2", "g3"]])):
        set_groups("p%d" % n, mk(n))
        chk("%d nhom" % n, [ids(pick("p%d" % n)) for _ in want], want)

    set_groups("trong", [])
    chk("page khong co nhom -> [] (van dang binh thuong)", pick("trong"), [])
    chk("page chua quet bao gio -> []", pick("chua_co"), [])

    set_groups("p4", mk(4))                       # quet lai DUNG danh sach cu
    chk("quet lai y het -> giu con tro", ids(pick("p4")), ["g2", "g3", "g4"])

    # TRUNG TEN: hai nhom cung ten nhung khac id -> van la 2 nhom rieng
    set_groups("dup", [{"id": "111", "name": "Cau Noi Hay"},
                       {"id": "222", "name": "Cau Noi Hay"},
                       {"id": "333", "name": "Khac"}])
    chk("trung ten van du 3 nhom", count("dup"), 3)
    chk("trung ten -> xoay theo ID", ids(pick("dup")), ["111", "222", "333"])

    # Facebook tra ve THU TU KHAC + them nhom moi -> thu tu cu phai giu, nhom moi xuong cuoi
    set_groups("pmix", mk(6))
    chk("pmix bai 1", ids(pick("pmix")), ["g1", "g2", "g3"])   # con tro -> g4
    set_groups("pmix", [{"id": "g6", "name": "x"}, {"id": "g9", "name": "moi"},
                        {"id": "g3", "name": "x"}, {"id": "g1", "name": "x"},
                        {"id": "g2", "name": "x"}, {"id": "g4", "name": "x"},
                        {"id": "g5", "name": "x"}])
    chk("giu thu tu cu, nhom moi xuong cuoi",
        ids(groups("pmix")), ["g1", "g2", "g3", "g4", "g5", "g6", "g9"])
    chk("con tro van bam dung nhom g4", ids(pick("pmix")), ["g4", "g5", "g6"])
    chk("bai ke tiep toi luot nhom MOI", ids(pick("pmix")), ["g9", "g1", "g2"])

    # nhom bi XOA khoi Facebook -> con tro khong duoc lech
    set_groups("p5", mk(5))
    pick("p5")                                     # con tro -> g4
    set_groups("p5", [{"id": "g1", "name": "x"}, {"id": "g4", "name": "x"},
                      {"id": "g5", "name": "x"}])  # g2,g3 bi xoa
    chk("bo nhom da roi", ids(groups("p5")), ["g1", "g4", "g5"])
    chk("con tro van o g4 sau khi nhom truoc bi xoa", ids(pick("p5")), ["g4", "g5", "g1"])

    chk("ten tra ve dung", names("dup"), ["Cau Noi Hay", "Cau Noi Hay", "Khac"])
    print("\n%d loi" % fails)
    sys.exit(1 if fails else 0)
