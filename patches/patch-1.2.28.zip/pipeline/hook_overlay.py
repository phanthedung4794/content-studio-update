# -*- coding: utf-8 -*-
"""
HOOK CHU tren dau video — giu chan nguoi xem 3 giay dau.

Bo cuc (canvas 1080x1920, doc):
  ┌──────────────────────┐
  │  BAND ~29% tren:     │  nen = chinh video phong to + BLUR (lien mach, khong den chet)
  │  CHU HOOK glow vang  │  chu do PIL ve ra PNG trong suot roi overlay
  ├──────────────────────┤
  │  VIDEO THU NHO       │  fit gon vao vung con lai (contain — khong cat mat noi dung)
  └──────────────────────┘

VI SAO PIL chu khong phai drawtext cua ffmpeg: drawtext hong dau tieng Viet
(quy tac CUNG #3 cua du an). PIL + font he thong ve dung dau.

Chu HOOK do Gemini viet (fb_remake.content_pack -> khoa 'hook'), 2 dong, <=9 tu.
"""
import os
import re
import subprocess
import tempfile

from PIL import Image, ImageDraw, ImageFilter, ImageFont

# Font DAM cho hook (chu to, can do day). Du phong dan xuong font thuong.
FONT_CANDIDATES = [
    "C:/Windows/Fonts/arialbd.ttf",       # Arial Bold
    "C:/Windows/Fonts/segoeuib.ttf",      # Segoe UI Bold
    "C:/Windows/Fonts/tahomabd.ttf",
    "C:/Windows/Fonts/arial.ttf",
    "C:/Windows/Fonts/segoeui.ttf",
]

BAND_RATIO = float(os.environ.get("CS_HOOK_BAND", "0.29"))   # ty le chieu cao band chu
GLOW = (255, 190, 60)                                        # vang cam (glow)
FILL = (255, 250, 225)                                       # trang nga (chu)


def _font_path():
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            return p
    raise RuntimeError("Khong tim thay font he thong de ve chu hook.")


def _probe_size(video):
    out = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height", "-of", "csv=p=0:s=x", video]).decode().strip()
    w, h = out.split("x")[:2]
    return int(w), int(h)


def _wrap(text, n=2):
    """Chia hook thanh toi da n dong. Uu tien xuong dong Gemini da dat ('\\n')."""
    t = " ".join((text or "").split("\n"))
    t = re.sub(r"\s+", " ", t).strip()
    if "\n" in (text or ""):
        lines = [x.strip() for x in text.split("\n") if x.strip()]
        if len(lines) <= n:
            return lines
    words = t.split()
    if len(words) <= 3 or n <= 1:
        return [t]
    # cat sao cho 2 dong CAN BANG do dai ky tu
    best, bi = None, 1
    for i in range(1, len(words)):
        a, b = " ".join(words[:i]), " ".join(words[i:])
        d = abs(len(a) - len(b))
        if best is None or d < best:
            best, bi = d, i
    return [" ".join(words[:bi]), " ".join(words[bi:])]


def render_text_png(text, out_png, cw=1080, chh=1920, band_ratio=BAND_RATIO):
    """Ve chu hook (glow vang) ra PNG TRONG SUOT kich thuoc canvas. Tra duong dan."""
    band_h = int(chh * band_ratio)
    img = Image.new("RGBA", (cw, chh), (0, 0, 0, 0))
    lines = _wrap(text, 2)
    fp = _font_path()
    # co chu lon nhat sao cho MOI dong vua be ngang (chua le 8%) va tong cao vua band
    size, pad = 120, int(cw * 0.08)
    for s in range(160, 40, -2):
        f = ImageFont.truetype(fp, s)
        wmax = max(f.getbbox(ln)[2] - f.getbbox(ln)[0] for ln in lines)
        htot = sum(f.getbbox(ln)[3] - f.getbbox(ln)[1] for ln in lines) + int(s * 0.35) * (len(lines) - 1)
        if wmax <= cw - 2 * pad and htot <= band_h * 0.72:
            size = s
            break
    font = ImageFont.truetype(fp, size)
    gap = int(size * 0.35)
    hs = [font.getbbox(ln)[3] - font.getbbox(ln)[1] for ln in lines]
    total = sum(hs) + gap * (len(lines) - 1)
    y = (band_h - total) // 2

    glow = Image.new("RGBA", (cw, chh), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    d = ImageDraw.Draw(img)
    for ln, h in zip(lines, hs):
        bb = font.getbbox(ln)
        x = (cw - (bb[2] - bb[0])) // 2 - bb[0]
        gd.text((x, y - bb[1]), ln, font=font, fill=GLOW + (255,))
        y += h + gap
    glow = glow.filter(ImageFilter.GaussianBlur(int(size * 0.18)))
    img = Image.alpha_composite(img, glow)
    img = Image.alpha_composite(img, glow)          # 2 lop -> quang sang ro hon
    d = ImageDraw.Draw(img)                          # ve chu NET de len quang sang
    y = (band_h - total) // 2
    for ln, h in zip(lines, hs):
        bb = font.getbbox(ln)
        x = (cw - (bb[2] - bb[0])) // 2 - bb[0]
        d.text((x, y - bb[1]), ln, font=font, fill=FILL + (255,))
        y += h + gap
    img.save(out_png)
    return out_png


def _norm_full(src, out, ss=0.0, threads=1):
    """Chuan hoa 1 doan video ve 1080x1920 (khong band chu) — dung cho phan SAU 3 giay."""
    cmd = ["ffmpeg", "-v", "error", "-y"]
    if ss:
        cmd += ["-ss", "%.3f" % ss]
    cmd += ["-i", src, "-vf",
            "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,fps=30",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-ac", "2", out]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError("ffmpeg chuan hoa loi: %s" % p.stderr.decode("utf-8", "ignore")[-300:])
    return out


def apply_hook_head(video_in, video_out, text, seconds=3.0, band_ratio=BAND_RATIO,
                    work="", fit="cover"):
    """Hook CHI o N GIAY DAU: doan 0..N co band chu (video thu nho), sau do video FULL 9:16.

    Lam 2 doan roi noi (concat demuxer) thay vi 1 filter_complex khong lo: filter phuc tap
    tung gay libx264 loi -22 tren may khach (bai hoc 2026-07-25).
    Video ngan hon N giay -> quay ve hook suot video.
    """
    text = (text or "").strip()
    if not text:
        return video_in
    work = work or tempfile.mkdtemp()
    os.makedirs(work, exist_ok=True)
    dur = float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", video_in]).decode().strip())
    if dur <= seconds + 0.5:
        return apply_hook(video_in, video_out, text, band_ratio, work, fit)

    head_raw = os.path.join(work, "hk_head_raw.mp4")
    p = subprocess.run(["ffmpeg", "-v", "error", "-y", "-t", "%.3f" % seconds, "-i", video_in,
                        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium",
                        "-crf", "20", "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
                        "-ac", "2", head_raw], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError("ffmpeg cat dau loi: %s" % p.stderr.decode("utf-8", "ignore")[-300:])
    head = apply_hook(head_raw, os.path.join(work, "hk_head.mp4"), text, band_ratio, work, fit)
    tail = _norm_full(video_in, os.path.join(work, "hk_tail.mp4"), ss=seconds)

    lst = os.path.join(work, "hk_concat.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p_ in (head, tail):
            f.write("file '%s'\n" % p_.replace("\\", "/"))
    p = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0",
                        "-i", lst, "-c", "copy", "-movflags", "+faststart", video_out],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:      # copy that bai (khac tham so) -> encode lai cho chac
        p = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0",
                            "-i", lst, "-c:v", "libx264", "-pix_fmt", "yuv420p",
                            "-preset", "medium", "-crf", "20", "-c:a", "aac", "-b:a", "192k",
                            "-movflags", "+faststart", video_out],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0 or not os.path.isfile(video_out):
        raise RuntimeError("ffmpeg noi doan loi: %s" % p.stderr.decode("utf-8", "ignore")[-300:])
    return video_out


def apply_hook(video_in, video_out, text, band_ratio=BAND_RATIO, work="", fit="cover"):
    """Nuong chu hook len video: band tren (nen blur) + video o duoi.

    fit='cover'   (mac dinh) video LAP DAY be ngang, cat bot tren/duoi -> giong anh mau,
                  khong phi dien tich. Hop voi video remake (nhan vat o giua).
    fit='contain' video thu nho VUA KHIT, khong cat mat gi, co le hai ben (nen blur lap).

    Tra `video_out`. Khong co chu -> tra `video_in` (khong dung toi ffmpeg).
    """
    text = (text or "").strip()
    if not text:
        return video_in
    cw, chh = 1080, 1920                                  # khung reel chuan
    band = int(chh * band_ratio) // 2 * 2                 # chan (yuv420p doi chan)
    vid_h = (chh - band) // 2 * 2
    work = work or tempfile.mkdtemp()
    os.makedirs(work, exist_ok=True)
    png = render_text_png(text, os.path.join(work, "hook.png"), cw, chh, band_ratio)
    if fit == "contain":
        fg = ("[0:v]scale=%d:%d:force_original_aspect_ratio=decrease[fg];"
              "[bg][fg]overlay=(W-w)/2:%d+((%d-h)/2)[v1];" % (cw, vid_h, band, vid_h))
    else:                                                 # cover: lap day ngang, cat giua
        fg = ("[0:v]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d[fg];"
              "[bg][fg]overlay=0:%d[v1];" % (cw, vid_h, cw, vid_h, band))
    # [bg] nen blur phu kin canvas (lien mach, khong den chet)
    fc = ("[0:v]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,"
          "boxblur=42:2,eq=brightness=-0.12[bg];" % (cw, chh, cw, chh)
          + fg + "[v1][1:v]overlay=0:0:format=auto[vo]")
    cmd = ["ffmpeg", "-v", "error", "-y", "-i", video_in, "-i", png,
           "-filter_complex", fc, "-map", "[vo]", "-map", "0:a?",
           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "medium", "-crf", "20",
           "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", video_out]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0 or not os.path.isfile(video_out):
        raise RuntimeError("ffmpeg hook loi: %s" % p.stderr.decode("utf-8", "ignore")[-300:])
    return video_out


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Nuong chu hook len dau video.")
    ap.add_argument("--in", dest="src", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--text", required=True)
    ap.add_argument("--band", type=float, default=BAND_RATIO)
    a = ap.parse_args()
    print(apply_hook(a.src, a.out, a.text, a.band))
