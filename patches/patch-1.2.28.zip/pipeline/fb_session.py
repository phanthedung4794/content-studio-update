"""
Phien Chrome quan ly de tai video Facebook.

Muc tieu (Giai doan 1):
- Mo mot cua so Chrome do tool quan ly (--remote-debugging-port) voi HO SO RIENG
  (--user-data-dir) -> cookie SONG trong ho so -> dang nhap TAY 1 lan, dong/mo lai
  KHONG phai dang nhap lai.
- Vao san trang login Facebook.
- Cung cap CDP helper (websocket) de cac buoc sau (liet ke / lam giau) dung lai.

KHONG tu dang nhap ho, KHONG luu mat khau. Nguoi dung tu go tay.

Kiem THAT (theo nguyen tac co van trung thuc):
  python -m pipeline.fb_session open      # mo Chrome + login FB
  python -m pipeline.fb_session status     # in trang thai + danh sach tab
  (dong Chrome, chay lai 'open' -> van con dang nhap = cookie song)
"""
import json
import os
import shutil
import socket
import subprocess
import time
import urllib.request

# websocket-client (da co trong moi truong)
import websocket

# Thu muc du an
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Ho so Chrome rieng cho tinh nang nay -> cookie song o day (da .gitignore facebook/)
PROFILE_DIR = os.path.join(ROOT, "facebook", "_chrome_profile")
DEFAULT_PORT = 9333
LOGIN_URL = "https://www.facebook.com/login"

# Cac vi tri Chrome hay gap tren Windows
CHROME_CANDIDATES = [
    os.environ.get("CHROME_PATH", ""),
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    # Edge lam du phong (cung Chromium, cung noi CDP)
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


def find_chrome() -> str:
    for p in CHROME_CANDIDATES:
        if p and os.path.isfile(p):
            return p
    which = shutil.which("chrome") or shutil.which("chrome.exe")
    if which:
        return which
    raise RuntimeError(
        "Khong tim thay Chrome. Dat bien moi truong CHROME_PATH tro toi chrome.exe."
    )


def _port_open(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


def _http_json(port: int, path: str = "/json", timeout: float = 3.0):
    url = "http://127.0.0.1:%d%s" % (port, path)
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def is_alive(port: int = DEFAULT_PORT) -> bool:
    """Chrome CDP dang song va tra loi khong?"""
    if not _port_open(port):
        return False
    try:
        _http_json(port, "/json/version")
        return True
    except Exception:
        return False


def list_targets(port: int = DEFAULT_PORT):
    """Danh sach tab dang mo (chi loai 'page')."""
    try:
        return [t for t in _http_json(port) if t.get("type") == "page"]
    except Exception:
        return []


def close_extra_tabs(port: int = DEFAULT_PORT, keep: int = 1) -> int:
    """Dong bot tab thua sau khi xong tac vu -> tra ve so tab da dong.

    LUON chua lai it nhat `keep` tab: dong TAB CUOI la Chrome tat han -> mat phien
    dang nhap (phai quet ma dang nhap lai). Giu tab MOI NHAT, dong cac tab cu hon.
    """
    keep = max(1, int(keep))
    try:
        pages = [t for t in list_targets(port) if t.get("type") == "page"]
    except Exception:
        return 0
    if len(pages) <= keep:
        return 0
    closed = 0
    for t in pages[:-keep]:            # /json/list xep tab moi nhat o cuoi
        tid = t.get("id")
        if not tid:
            continue
        try:
            urllib.request.urlopen("http://127.0.0.1:%d/json/close/%s" % (port, tid),
                                   timeout=4.0).read()
            closed += 1
        except Exception:
            pass
    return closed


def open_session(port: int = DEFAULT_PORT, url: str = LOGIN_URL,
                 profile_dir: str = None, new_tab: bool = False) -> dict:
    """Mo (hoac gan vao) phien Chrome quan ly. Tra ve trang thai.

    profile_dir=None -> dung PROFILE_DIR mac dinh. Truyen dir rieng cho MOI tai khoan.
    Neu Chrome CDP da song o cong nay -> chi mo them tab url (giu phien cu).
    """
    profile_dir = profile_dir or PROFILE_DIR
    if is_alive(port):
        # DUNG LAI tab san co. Truoc day lan nao cung mo THEM 1 tab home.php roi khong
        # bao gio dong -> cao/phan tich 30+ page = 30+ tab Facebook nang -> lag may.
        # Chi mo tab moi khi KHONG con tab nao dung duoc (hoac goi yeu cau new_tab).
        pages = [t for t in list_targets(port) if t.get("type") == "page"]
        if new_tab or not pages:
            try:                    # Chrome doi moi: /json/new can PUT.
                req = urllib.request.Request("http://127.0.0.1:%d/json/new?%s" % (port, url),
                                             method="PUT")
                urllib.request.urlopen(req, timeout=5.0)
            except Exception:
                pass
        return {"launched": False, "port": port, "profile": profile_dir,
                "targets": len(list_targets(port))}

    os.makedirs(profile_dir, exist_ok=True)
    chrome = find_chrome()
    args = [
        chrome,
        "--remote-debugging-port=%d" % port,
        # Chrome doi moi CHAN websocket CDP neu thieu co nay (loi 403 origin)
        "--remote-allow-origins=*",
        "--user-data-dir=%s" % profile_dir,
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-features=Translate",
        url,
    ]
    # Chay nen, khong chan tien trinh cha
    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
    subprocess.Popen(args, creationflags=creationflags,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # Cho CDP len (toi da ~15s)
    for _ in range(30):
        if is_alive(port):
            break
        time.sleep(0.5)
    if not is_alive(port):
        raise RuntimeError("Chrome khoi dong nhung CDP khong tra loi o cong %d." % port)
    return {"launched": True, "port": port, "profile": profile_dir,
            "targets": len(list_targets(port))}


class CDP:
    """CDP client toi gian qua websocket (dung lai cho buoc liet ke/lam giau).

    Vi du:
        with CDP.attach(port) as c:
            c.navigate("https://www.facebook.com/<page>/videos")
            html = c.eval("document.body.innerText")
    """

    def __init__(self, ws_url: str):
        self.ws = websocket.create_connection(ws_url, timeout=30)
        self._id = 0

    @classmethod
    def attach(cls, port: int = DEFAULT_PORT, target: dict = None) -> "CDP":
        targets = list_targets(port)
        if not targets:
            raise RuntimeError("Khong co tab nao de gan CDP (mo phien truoc).")
        t = target or targets[0]
        return cls(t["webSocketDebuggerUrl"])

    def send(self, method: str, params: dict = None, timeout: float = 30.0) -> dict:
        self._id += 1
        mid = self._id
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params or {}}))
        # Doc toi khi gap dung id (bo qua event)
        end = time.time() + timeout
        while time.time() < end:
            self.ws.settimeout(max(0.1, end - time.time()))
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError("CDP error: %s" % msg["error"])
                return msg.get("result", {})
        raise TimeoutError("CDP khong tra loi method %s" % method)

    def navigate(self, url: str, wait: float = 2.0) -> None:
        self.send("Page.enable")
        self.send("Page.navigate", {"url": url})
        time.sleep(wait)

    def eval(self, expression: str):
        r = self.send("Runtime.evaluate", {
            "expression": expression,
            "returnByValue": True,
            "awaitPromise": True,
        })
        return r.get("result", {}).get("value")

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


def logged_in(port: int = DEFAULT_PORT) -> bool:
    """Uoc luong da dang nhap FB chua (co cookie c_user).

    Neo vao cookie c_user cua Facebook -> ben hon do DOM.
    """
    try:
        with CDP.attach(port) as c:
            c.send("Network.enable")
            res = c.send("Network.getCookies", {"urls": ["https://www.facebook.com"]})
            names = {ck.get("name") for ck in res.get("cookies", [])}
            return "c_user" in names
    except Exception:
        return False


if __name__ == "__main__":
    import sys

    cmd = sys.argv[1] if len(sys.argv) > 1 else "open"
    if cmd == "open":
        st = open_session()
        print(json.dumps(st, ensure_ascii=False))
        print("Da mo Chrome. Hay dang nhap Facebook bang tay trong cua so do.")
    elif cmd == "status":
        alive = is_alive()
        print("CDP alive:", alive)
        if alive:
            tabs = list_targets()
            print("So tab:", len(tabs))
            for t in tabs:
                print(" -", t.get("title", "")[:60], "|", t.get("url", "")[:80])
            print("Da dang nhap FB:", logged_in())
    else:
        print("Lenh: open | status")
