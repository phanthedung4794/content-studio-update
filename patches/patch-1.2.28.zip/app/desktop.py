"""
Cua so app desktop cho Content Studio.

Phan mem la web app (FastAPI + trinh duyet). File nay boc no thanh 1 CUA SO
NATIVE bang pywebview (WebView2 co san tren Win10/11): khong thanh dia chi,
khong tab, co tieu de rieng. Dong cua so = tat luon may chu.

Chay: pythonw.exe app/desktop.py   (Chay.bat goi ban an console nay)

CACH HOAT DONG (v2 - chiu duoc may cham):
  - Bat may chu (server.py) an console.
  - Mo cua so NGAY voi trang "Dang khoi dong..." (khong de nguoi dung thay
    trang loi "refused to connect" xau xi cua trinh duyet luc may chu chua len).
  - Mot luong nen doi may chu len (toi da ~150s - lan dau bien dich .pyc rat
    lau) roi CHUYEN cua so sang app that.
  - Neu pywebview loi (thieu WebView2...) -> tu roi xuong mo trinh duyet thuong.
Moi loi ghi vao desktop-log.txt (chay bang pythonw KHONG co console).
"""
import os
import sys
import time
import threading
import subprocess
import traceback
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
URL = "http://127.0.0.1:8760"
LOG = os.path.join(ROOT, "desktop-log.txt")

# Bao lau cho may chu len. Lan dau (bien dich .pyc) co the >1 phut tren may cham.
WAIT_SECONDS = 150

# Trang cho hien ngay khi mo cua so, trong luc may chu chua len. Tu lam moi
# de neu vi ly do nao do luong nen khong chuyen trang, no van tu vao app.
LOADING_HTML = """<!doctype html><html lang="vi"><head><meta charset="utf-8">
<title>Content Studio</title>
<style>
  html,body{height:100%;margin:0}
  body{display:flex;align-items:center;justify-content:center;
       font-family:'Segoe UI',Arial,sans-serif;background:#14110d;color:#e8dcc6}
  .box{text-align:center;max-width:520px;padding:24px}
  .spin{width:52px;height:52px;margin:0 auto 22px;border:5px solid #3a3527;
        border-top-color:#d9a441;border-radius:50%;animation:r 0.9s linear infinite}
  @keyframes r{to{transform:rotate(360deg)}}
  h1{font-size:22px;font-weight:600;margin:0 0 10px;color:#f0e6d2}
  p{font-size:14px;line-height:1.6;color:#b7ab92;margin:6px 0}
  .small{font-size:12px;color:#8a7f68;margin-top:18px}
</style></head><body><div class="box">
  <div class="spin"></div>
  <h1>Dang khoi dong Content Studio...</h1>
  <p>Lan chay dau tien co the mat 1-2 phut (may chuan bi thu vien).<br>
     Nhung lan sau se nhanh hon nhieu. Vui long doi.</p>
  <p class="small">Neu qua lau, dong cua so va mo lai Chay.bat.</p>
</div>
<script>
  // Do may chu; len thi tu vao app (phong khi luong nen khong chuyen kip).
  (function(){
    var url="http://127.0.0.1:8760/";
    function ping(){
      fetch(url,{cache:"no-store"}).then(function(r){
        if(r.ok){location.replace(url);} else {setTimeout(ping,1500);}
      }).catch(function(){setTimeout(ping,1500);});
    }
    setTimeout(ping,2000);
  })();
</script>
</body></html>"""


def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("%s  %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def server_up():
    try:
        with urllib.request.urlopen(URL, timeout=1):
            return True
    except Exception:
        return False


SRVLOG = os.path.join(ROOT, "server-log.txt")


def _server_python():
    """Chay may chu bang python.exe (KHONG pythonw).

    QUAN TRONG: neu chay may chu bang pythonw.exe thi sys.stdout/stderr = None
    -> uvicorn/logging ghi ra stderr co the CRASH may chu tren mot so may
    (im lang, khong dau vet). Dung python.exe (van an console nho
    CREATE_NO_WINDOW) thi luong xuat hop le. desktop.py chay pythonw (an
    console cho nguoi dung), rieng may chu con chay python.exe.
    """
    exe = sys.executable or ""
    low = exe.lower()
    if low.endswith("pythonw.exe"):
        cand = exe[:-len("pythonw.exe")] + "python.exe"
        if os.path.exists(cand):
            return cand
    return exe


def start_server():
    """Chay app/server.py lam tien trinh con, AN console, GHI LOG ra file."""
    flags = 0
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        out = open(SRVLOG, "w", encoding="utf-8", errors="replace")
    except Exception:
        out = subprocess.DEVNULL
    # CS_DESKTOP=1 -> server biet dang chay duoi desktop (nut 'Cap nhat & mo lai' hoat dong).
    # PYTHONIOENCODING=utf-8 BAT BUOC: stdout cua may chu duoc chuyen huong ra FILE, ma khi
    # ghi ra file Python lay encoding theo locale (cp1252 tren Windows VN) -> in mot chu
    # tieng Viet co dau la nem UnicodeEncodeError. Do that 2026-07-27:
    #   python -c "print('HỒI ỨC')" > f.txt   ->  UnicodeEncodeError, exit 1
    # Vong watchdog dang bai chay TRONG may chu va co in TEN NHOM (tieng Viet) -> thieu
    # dong nay thi vong nen chet, khong bai nao dang duoc nua.
    env = dict(os.environ, CS_DESKTOP="1", PYTHONIOENCODING="utf-8")
    return subprocess.Popen(
        [_server_python(), os.path.join(HERE, "server.py")],
        cwd=ROOT, creationflags=flags,
        stdout=out, stderr=subprocess.STDOUT, env=env,
    )


# Nut "Cap nhat & mo lai" trong app ghi co nay -> giam sat ben duoi thay -> kill server
# con roi os.execv chinh desktop.py: lan chay moi check_update() TU KEO ban moi -> nap code moi.
RESTART_FLAG = os.path.join(ROOT, "app-restart.flag")
_PROC = [None]   # giu tien trinh server de monitor kill truoc khi execv


def _restart_monitor():
    while True:
        try:
            if os.path.exists(RESTART_FLAG):
                try:
                    os.remove(RESTART_FLAG)
                except Exception:
                    pass
                log("Nhan yeu cau 'Cap nhat & mo lai' -> tat server + mo lai app.")
                p = _PROC[0]
                if p is not None:
                    try:
                        p.terminate(); p.wait(timeout=6)
                    except Exception:
                        try:
                            p.kill()
                        except Exception:
                            pass
                time.sleep(1)   # nha cong 8760 (tranh ket TIME_WAIT khi server moi bind)
                try:
                    os.execv(sys.executable, [sys.executable, os.path.abspath(__file__)])
                except Exception:
                    log("execv loi -> spawn moi roi thoat:\n" + traceback.format_exc())
                    try:
                        subprocess.Popen([sys.executable, os.path.abspath(__file__)], cwd=ROOT)
                    except Exception:
                        pass
                    os._exit(0)
        except Exception:
            pass
        time.sleep(1)


def check_update():
    """Tai ban moi tu GitHub (neu co) TRUOC khi bat may chu -> server con nap
    code moi ngay. Moi loi deu nuot, KHONG chan mo app."""
    try:
        pl = os.path.join(ROOT, "pipeline")
        if pl not in sys.path:
            sys.path.insert(0, pl)
        import updater
        res = updater.run(ROOT, timeout=8)
        if res.get("updated"):
            log("DA CAP NHAT len %s (%s file). %s"
                % (res.get("version"), res.get("files"), res.get("notes", "")))
        else:
            log("Update: %s (dang %s)"
                % (res.get("reason", "moi nhat"), res.get("version", "?")))
    except Exception:
        log("updater loi (bo qua):\n" + traceback.format_exc())


def main():
    # xoa log cu (chi giu phien nay)
    try:
        open(LOG, "w", encoding="utf-8").close()
    except Exception:
        pass

    # Kiem + ap ban moi TRUOC khi bat may chu (server con se nap code moi).
    check_update()

    # Xoa co restart cu (neu con sot) truoc khi chay.
    try:
        if os.path.exists(RESTART_FLAG):
            os.remove(RESTART_FLAG)
    except Exception:
        pass

    if server_up():
        log("May chu da chay san (khong tu bat them).")
        proc = None
    else:
        log("Bat may chu (server.py, an console)...")
        proc = start_server()

    # Giam sat co 'Cap nhat & mo lai' (nut trong app) -> kill + execv desktop.py.
    _PROC[0] = proc
    threading.Thread(target=_restart_monitor, daemon=True).start()

    try:
        import webview
        log("pywebview OK - mo cua so 'dang khoi dong'.")
        window = webview.create_window(
            "Content Studio",
            html=LOADING_HTML,
            width=1360, height=900,
            min_size=(1024, 680),
        )

        def wait_then_load():
            # Doi may chu len roi chuyen cua so sang app that.
            deadline = time.time() + WAIT_SECONDS
            while time.time() < deadline:
                if server_up():
                    log("May chu san sang - chuyen sang app.")
                    try:
                        window.load_url(URL)
                    except Exception:
                        log("load_url loi:\n" + traceback.format_exc())
                    return
                time.sleep(0.5)
            log("Cho may chu qua %ss van chua len - thu vao app." % WAIT_SECONDS)
            try:
                window.load_url(URL)   # trang loading cung tu ping lai
            except Exception:
                pass

        webview.start(wait_then_load)   # KHOA den khi nguoi dung dong cua so
        log("Nguoi dung dong cua so.")
    except Exception:
        # pywebview khong chay duoc -> roi xuong trinh duyet thuong
        log("pywebview LOI, roi xuong trinh duyet:\n" + traceback.format_exc())
        # Doi may chu len roi hang mo trinh duyet (dep hon la mo trang loi ngay).
        deadline = time.time() + WAIT_SECONDS
        while time.time() < deadline and not server_up():
            time.sleep(0.5)
        import webbrowser
        webbrowser.open(URL)
        try:
            if proc is not None:
                proc.wait()
            else:
                while server_up():
                    time.sleep(2)
        except KeyboardInterrupt:
            pass
    finally:
        # Dong cua so = tat may chu (neu la con cua ta)
        if proc is not None:
            try:
                proc.terminate()
                proc.wait(timeout=8)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            log("Da tat may chu.")


if __name__ == "__main__":
    main()
