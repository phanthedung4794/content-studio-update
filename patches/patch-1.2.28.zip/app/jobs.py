"""
Hang doi chay nen.

Moi viec ton thoi gian (ve tranh, doc loi, ghep video) deu chay o day,
khong lam treo giao dien. Tien do day ve trinh duyet qua SSE.

Chay tuan tu 1 job mot luc - vi ca 3 dich vu (79ai, ElevenLabs, Claude)
deu co gioi han, chay song song chi lam ro loi.
"""
import asyncio
import itertools
import os
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

PY = sys.executable

# "Khong gioi han so luong" = tran cao vo thuc te (khong dung None de moi phep so sanh
# `len(tasks) < max_concurrent` giu nguyen, khong phai vá rai rac).
NO_LIMIT = 10_000

# Workspace root — pipeline scripts live here, not inside each channel.
# Channel isolation is data-only via cwd; code is shared.
_APP_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(_APP_DIR)


def _resolve_pipeline(cmd: list) -> list:
    """Rewrite relative pipeline/* paths to absolute paths in workspace root.

    Before: each channel had its own copy of pipeline/ (drifted over time).
    Now: cwd stays at channel root (for data isolation), but the script itself
    is loaded from the single workspace copy.
    """
    out = []
    for arg in cmd:
        if isinstance(arg, str) and arg.startswith(("pipeline/", "pipeline\\")):
            out.append(os.path.join(ROOT, arg))
        else:
            out.append(arg)
    return out

PENDING = "cho"
RUNNING = "dang chay"
DONE = "xong"
FAILED = "loi"
CANCELLED = "da huy"


@dataclass
class Job:
    id: int
    kind: str                       # ve-tranh | doc-loi | ghep-video | ...
    label: str                      # hien cho nguoi doc
    cmd: list                        # lenh python
    cwd: str                         # thu muc kenh
    episode: Optional[str] = None
    status: str = PENDING
    lines: list = field(default_factory=list)
    started_at: Optional[float] = None
    ended_at: Optional[float] = None
    error: str = ""

    # Cac viec noi thanh mot day (vd: viet kich ban -> ve tranh -> doc loi).
    # Mot mat xich dut thi ca day sau no phai dung, KHONG duoc chay tiep.
    chain: Optional[str] = None
    step: str = ""                  # "2/5" - hien cho nguoi dung biet dang o dau

    def to_dict(self) -> dict:
        elapsed = 0.0
        if self.started_at:
            end = self.ended_at or time.time()
            elapsed = end - self.started_at
        return {
            "id": self.id,
            "kind": self.kind,
            "label": self.label,
            "episode": self.episode,
            "status": self.status,
            "elapsed": round(elapsed, 1),
            "lines": self.lines[-40:],
            "error": self.error,
            "chain": self.chain,
            "step": self.step,
        }


class JobQueue:
    """
    LUU Y VE LUONG:
    FastAPI chay endpoint dong bo (def) trong THREADPOOL - o do KHONG co
    event loop. Nen moi thao tac cham vao asyncio phai di qua loop chinh
    bang call_soon_threadsafe. Neu goi thang asyncio.create_task() se chet:
        RuntimeError: no running event loop
    """

    def __init__(self):
        self._seq = itertools.count(1)
        self.jobs: dict = {}
        self.order: deque = deque()
        self.current: Optional[Job] = None
        self.running: dict = {}          # jid -> Job dang chay (SONG SONG)
        # So job chay ĐỒNG THỜI toi da. Auto-fb (2 page tich song song) chay cung luc.
        # Trong 1 CHUOI (video san xuat) van tuan tu (buoc sau cho buoc truoc).
        # CS_MAX_JOBS=0 -> KHONG GIOI HAN (chay het cung luc).
        try:
            _n = int(os.environ.get("CS_MAX_JOBS", "3"))
            self.max_concurrent = NO_LIMIT if _n <= 0 else _n
        except ValueError:
            self.max_concurrent = 3
        self._cancel_ids: set = set()    # job id can huy (chay song song -> theo tung id)
        self._wake = asyncio.Event()     # danh thuc worker khi CO JOB MOI (dang cho job khac)
        # Callback khi 1 job KET THUC (done/loi/huy). Server gan de NOI BAI TIEP THEO ngay
        # khi job auto-fb xong (khong cho cron 30'). Nhan doi tuong Job. Loi trong callback
        # KHONG duoc lam sap _run.
        self._on_end = None
        self._listeners: list = []
        self._task: Optional[asyncio.Task] = None
        self._cancel_current = False     # (giu tuong thich, khong con dung)
        self._evloop: Optional[asyncio.AbstractEventLoop] = None
        self._lock = threading.Lock()
        # Cac day da dut. Moi viec con lai thuoc day nay se bi bo, khong chay.
        self._broken_chains: set = set()

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Goi 1 lan khi may chu khoi dong."""
        self._evloop = loop

    def set_max_concurrent(self, n) -> int:
        """Doi so job chay DONG THOI (tu Cai dat, ap NGAY khong can restart).

        n = 0 (hoac so am) -> KHONG GIOI HAN: moi job da xep deu chay cung luc.
        Nang tran -> thuc worker quet them job dang cho lien.
        """
        try:
            n = int(n)
            n = NO_LIMIT if n <= 0 else n
        except (TypeError, ValueError):
            return self.max_concurrent
        self.max_concurrent = n
        # Endpoint dong bo chay o threadpool -> phai day sang loop chinh (nhu add()).
        if self._evloop and self._evloop.is_running():
            self._evloop.call_soon_threadsafe(self._bump)
        return n

    def _bump(self) -> None:
        """Tren loop chinh: dam bao worker chay + thuc day quet lai (nhan them job ngay)."""
        self._ensure_running()
        self._wake.set()

    # ---------- Dang ky nhan tien do ----------
    def subscribe(self) -> asyncio.Queue:
        q = asyncio.Queue(maxsize=200)
        self._listeners.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        if q in self._listeners:
            self._listeners.remove(q)

    def _emit(self, event: dict) -> None:
        for q in list(self._listeners):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass

    # ---------- Them viec ----------
    def add(self, kind: str, label: str, cmd: list, cwd: str,
            episode: str = None, chain: str = None, step: str = "") -> Job:
        with self._lock:
            job = Job(id=next(self._seq), kind=kind, label=label,
                      cmd=cmd, cwd=cwd, episode=episode, chain=chain, step=step)
            self.jobs[job.id] = job
            self.order.append(job.id)

        # Endpoint dong bo chay o threadpool -> phai day sang loop chinh.
        if self._evloop and self._evloop.is_running():
            self._evloop.call_soon_threadsafe(self._kick, job.to_dict())
        else:
            self._emit({"type": "queued", "job": job.to_dict()})
            self._ensure_running()
            self._wake.set()          # thuc day worker (neu dang cho) -> nhan job moi ngay
        return job

    def _kick(self, snapshot: dict) -> None:
        """Chay TREN loop chinh."""
        self._emit({"type": "queued", "job": snapshot})
        self._ensure_running()
        self._wake.set()          # worker dang cho job khac -> thuc day nhan job MOI ngay (song song)

    def cancel(self, job_id: int) -> bool:
        job = self.jobs.get(job_id)
        if not job:
            return False
        if job.status == PENDING:
            job.status = CANCELLED
            if job_id in self.order:
                self.order.remove(job_id)
            # Huy mot mat xich cho -> ca day sau no phai dung, khong duoc chay tiep.
            # _worker() chi add chain vao _broken_chains sau khi _run xong, nen phai
            # ganh o day cho truong hop viec bi huy khi con la PENDING.
            if job.chain:
                self._broken_chains.add(job.chain)
            self._emit({"type": "update", "job": job.to_dict()})
            return True
        if job.status == RUNNING:
            self._cancel_ids.add(job_id)              # huy dung job nay (song song)
            return True
        return False

    def clear_finished(self) -> None:
        for jid in [j.id for j in self.jobs.values()
                    if j.status in (DONE, FAILED, CANCELLED)]:
            self.jobs.pop(jid, None)
        self._emit({"type": "cleared"})

    def snapshot(self) -> dict:
        running = [j.to_dict() for j in self.running.values()]
        return {
            "current": running[0] if running else None,   # (tuong thich cu)
            "running": running,                            # TAT CA job dang chay song song
            "jobs": [self.jobs[i].to_dict() for i in self.order if i in self.jobs],
            "history": [j.to_dict() for j in self.jobs.values()
                        if j.status in (DONE, FAILED, CANCELLED)][-12:],
        }

    # ---------- Vong chay ----------
    def _ensure_running(self) -> None:
        # LUU Y: khong dat ten ham nay la _loop - se dung ten voi self._evloop
        # (event loop), khien self._evloop() goi nham vao doi tuong loop.
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._worker())

    def _pick_next(self) -> Optional[Job]:
        """Chon job PENDING dau tien DU DIEU KIEN chay:
          - bo job cua chuoi DA DUT (mat xich truoc that bai -> khong dot credit tiep);
          - KHONG chay 2 buoc cung 1 CHUOI cung luc (giu tuan tu trong 1 video san xuat);
          - job KHONG chuoi (auto-fb) luon du dieu kien -> nhieu page chay SONG SONG.
        Lay job ra khoi hang cho (order)."""
        running_chains = {j.chain for j in self.running.values() if j.chain}
        for jid in list(self.order):
            job = self.jobs.get(jid)
            if not job or job.status != PENDING:
                self.order.remove(jid)
                continue
            if job.chain and job.chain in self._broken_chains:
                self.order.remove(jid)
                job.status = CANCELLED
                job.error = "Bo qua: buoc truoc trong day da that bai"
                job.ended_at = time.time()
                self._emit({"type": "end", "job": job.to_dict()})
                continue
            if job.chain and job.chain in running_chains:
                continue                              # buoc cua chuoi dang chay -> cho
            self.order.remove(jid)
            return job
        return None

    async def _worker(self) -> None:
        """Chay toi da `max_concurrent` job cung luc. Thuc day khi 1 job XONG hoac co JOB MOI
        (qua self._wake) -> job moi bat dau NGAY neu con cho trong, khong cho job cu xong."""
        tasks: set = set()
        while True:
            while len(tasks) < self.max_concurrent:
                job = self._pick_next()
                if job is None:
                    break
                self.running[job.id] = job
                tasks.add(asyncio.create_task(self._run(job)))
            if not tasks and not self.order:
                break                                 # khong con gi chay + khong con cho
            # cho: 1 job bat ky xong  HOAC  co job moi them vao (danh thuc) -> quet lai
            self._wake.clear()
            waker = asyncio.create_task(self._wake.wait())
            try:
                await asyncio.wait(set(tasks) | {waker},
                                   return_when=asyncio.FIRST_COMPLETED)
            finally:
                if not waker.done():
                    waker.cancel()
            tasks = {t for t in tasks if not t.done()}
            # _run tu don self.running + danh dau chuoi dut TRUOC khi vong sau pick tiep.
        self.current = None

    async def _run(self, job: Job) -> None:
        job.status = RUNNING
        job.started_at = time.time()
        self.current = job
        self._emit({"type": "start", "job": job.to_dict()})

        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUNBUFFERED"] = "1"

        try:
            proc = await asyncio.create_subprocess_exec(
                PY, *_resolve_pipeline(job.cmd),
                cwd=job.cwd,
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )

            while True:
                if job.id in self._cancel_ids:            # huy DUNG job nay (song song)
                    proc.terminate()
                    job.status = CANCELLED
                    break

                try:
                    raw = await asyncio.wait_for(proc.stdout.readline(), timeout=0.4)
                except asyncio.TimeoutError:
                    continue

                if not raw:
                    break

                line = raw.decode("utf-8", errors="replace").rstrip()
                if line:
                    job.lines.append(line)
                    self._emit({"type": "log", "id": job.id, "line": line})

            code = await proc.wait()

            if job.status != CANCELLED:
                if code == 0:
                    job.status = DONE
                else:
                    job.status = FAILED
                    tail = [l for l in job.lines[-6:] if l.strip()]
                    job.error = tail[-1] if tail else f"exit {code}"

        except Exception as exc:
            job.status = FAILED
            job.error = str(exc)[:200]

        job.ended_at = time.time()
        self.running.pop(job.id, None)
        self._cancel_ids.discard(job.id)
        if job.chain and job.status in (FAILED, CANCELLED):
            self._broken_chains.add(job.chain)          # chuoi dut -> buoc sau bi bo
        self._emit({"type": "end", "job": job.to_dict()})
        if self._on_end:                                # NOI bai tiep theo ngay (khong cho cron)
            try:
                self._on_end(job)
            except Exception as exc:
                print(f"[jobs] _on_end loi: {exc}", flush=True)


queue = JobQueue()
