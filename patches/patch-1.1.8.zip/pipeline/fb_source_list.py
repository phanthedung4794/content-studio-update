"""
DANH SACH NGUON — khau TRUNG GIAN giua CAO va LAM LAI (Xuong).

Xem docs/danh-sach-nguon-ke-hoach.md. Y tuong:
- Tai dung reel da cao (facebook/<slug>/index.json) — KHONG cao lai.
- AI phan tich cap LO (vai thumbnail dai dien) -> chot "lo nay dang X" -> ap ca lo. RE.
  (Validate THAT 2026-07-24: GPT-4o phan loai dung tu 4 thumbnail, ~1 call/page.)
- Anh xa Dang -> Huong dung + Model de xuat + Credit uoc tinh.
- Tick chon -> day sang Xuong (remake) kem preset.

Ket qua phan tich luu facebook/_source_list.json (gitignore) keyed theo slug.
"""
import base64
import json
import os

import requests   # bundled (khong dung httpx -> tranh sap server ban khach thieu httpx)

import fb_lister

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_DIR = os.path.join(ROOT, "facebook")
STORE = os.path.join(FB_DIR, "_source_list.json")

# Anh xa DANG lo -> huong dung + model i2v de xuat + kieu anh mac dinh + co ho tro.
# CHI map sang pipeline remake DA CHAY (rule #1). Motion Control/lipsync CHUA wire -> supported=False.
DANG_MAP = {
    "slideshow_anh": {
        "huong": "Vẽ lại ảnh theo kiểu + i2v (giữ nội dung + giọng gốc)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "video_that_nguoi": {
        "huong": "Vẽ lại giữ nhân vật + i2v (bám khung gốc)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "text_card": {
        "huong": "Ken Burns / ảnh tĩnh + nhạc (chữ do tool vẽ)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "talking_head": {
        "huong": "⚠️ Cần lipsync (chưa hỗ trợ tốt) — tạm vẽ lại giữ nhân vật",
        "clip": "grok_video_heavy", "style": "real", "supported": False},
    "khac": {
        "huong": "⚠️ Chưa rõ dạng — kiểm tay trước khi làm",
        "clip": "grok_video_heavy", "style": "real", "supported": False},
}

# Chi phi uoc tinh 1 CANH (credit ~ dong). banana_pro 1k ~600, grok i2v ~1000. Xem [[co-van-trung-thuc]].
_IMG_CR = 600
_CLIP_CR = {"grok_video_heavy": 1000, "veo_3_1": 800, "wan_2_2": 200}

_PROMPT = """Ban la chuyen gia phan tich video ngan (reel) tieng Viet.
Duoi day la vai anh THUMBNAIL DAI DIEN cua MOT LO reel tu 1 page (gia dinh ca lo CUNG DANG).
Tra ve JSON THUAN (khong markdown, khong giai thich):
{
 "dang": "slideshow_anh"|"video_that_nguoi"|"text_card"|"talking_head"|"khac",
 "dang_mo_ta": "<1 cau tieng Viet>",
 "kieu_anh": "real"|"cartoon"|"hoat_hinh"|"anime"|"mau_nuoc"|"pixar_3d"|"son_dau"|"ngam_doi",
 "chu_de": "<chu de chinh>",
 "do_tin_cay": <0-100>
}
dang: slideshow_anh=chuoi anh tinh+giong ke; video_that_nguoi=quay nguoi that chuyen dong;
text_card=chu tren nen; talking_head=1 nguoi noi vao camera. CHI tra JSON."""


def _load():
    if os.path.isfile(STORE):
        try:
            return json.load(open(STORE, encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save(d):
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    tmp = STORE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STORE)


def _dl_thumb(url):
    try:
        r = requests.get(url, timeout=15)
        if r.status_code == 200 and r.content:
            return base64.b64encode(r.content).decode()
    except Exception:
        pass
    return None


def analyze_batch(slug, n_sample=4):
    """Phan tich LO reel cua 1 page -> dict phan loai. Luu vao _source_list.json.

    Lay n_sample thumbnail (reel view cao nhat) -> GPT-4o vision. RAISE neu thieu OPENAI/thumb.
    """
    # import muon: chi can khi phan tich (khong keo openai/vision vao moi import)
    import fb_remake
    idx = fb_lister.load_index(slug)
    reels = sorted((idx.get("reels") or {}).values(),
                   key=lambda x: x.get("views") or 0, reverse=True)
    imgs = []
    for r in reels:
        if r.get("thumb"):
            b = _dl_thumb(r["thumb"])
            if b:
                imgs.append(b)
        if len(imgs) >= n_sample:
            break
    if not imgs:
        raise RuntimeError("Khong co thumbnail de phan tich (cao lai nguon truoc).")
    out = fb_remake._openai_vision(_PROMPT, imgs, max_tokens=300).strip().strip("`")
    if out.startswith("json"):
        out = out[4:].strip()
    data = json.loads(out)
    dang = data.get("dang", "khac")
    m = DANG_MAP.get(dang, DANG_MAP["khac"])
    result = {
        "dang": dang,
        "dang_mo_ta": data.get("dang_mo_ta", ""),
        "kieu_anh": data.get("kieu_anh") or m["style"],
        "chu_de": data.get("chu_de", ""),
        "do_tin_cay": data.get("do_tin_cay"),
        "huong": m["huong"],
        "clip": m["clip"],
        "supported": m["supported"],
        "n_sample": len(imgs),
        "analyzed_at": int(__import__("time").time()),
    }
    store = _load()
    store[slug] = result
    _save(store)
    return result


def credit_per_reel(clip="grok_video_heavy", n_scenes=7):
    """Uoc tinh credit lam lai 1 reel = n_scenes x (anh + clip)."""
    return n_scenes * (_IMG_CR + _CLIP_CR.get(clip, 1000))


def grid(slug):
    """Du lieu luoi Danh Sach Nguon cho 1 page: reels + phan tich + uoc tinh."""
    idx = fb_lister.load_index(slug)
    reels = sorted((idx.get("reels") or {}).values(),
                   key=lambda x: x.get("views") or 0, reverse=True)
    analysis = _load().get(slug)
    rows = [{
        "id": r["id"], "href": r.get("href"), "views": r.get("views"),
        "view_text": r.get("view_text"), "thumb": r.get("thumb"),
        "length": r.get("length"),
        "downloaded": bool(r.get("downloaded")),
        "status": r.get("status", "listed"),
    } for r in reels]
    return {"slug": slug, "count": len(rows), "analysis": analysis, "reels": rows}


if __name__ == "__main__":
    import sys
    slug = sys.argv[1] if len(sys.argv) > 1 else "tuoitho89x"
    print("Phan tich lo:", slug)
    print(json.dumps(analyze_batch(slug), ensure_ascii=False, indent=1))
