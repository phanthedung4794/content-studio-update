"""
Quan ly PAGE + token cho tinh nang dang hang loat.
Doc token nguoi dung/System User -> liet ke page + page token (qua /me/accounts).
Cache ra facebook/_fb_pages.json (da .gitignore). KHONG log token.

Token doc theo thu tu: bien moi truong FB_SYS_TOKEN -> keys.env.
"""
import json
import os
import time
import urllib.parse
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.join(ROOT, "facebook", "_fb_pages.json")
TOKENS = os.path.join(ROOT, "facebook", "_tokens.json")     # [{name, token}] nhieu BM
GRAPH = "https://graph.facebook.com/v19.0"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120 Safari/537.36"


def load_token() -> str:
    t = os.environ.get("FB_SYS_TOKEN", "").strip()
    if t:
        return t
    kp = os.path.join(ROOT, "keys.env")
    if os.path.isfile(kp):
        for ln in open(kp, encoding="utf-8-sig"):
            if ln.strip().startswith("FB_SYS_TOKEN="):
                return ln.strip().split("=", 1)[1].strip()
    return ""


def load_tokens() -> list:
    """Danh sach token (nhieu BM). Migrate FB_SYS_TOKEN cu -> muc 'chính'."""
    if os.path.isfile(TOKENS):
        try:
            with open(TOKENS, encoding="utf-8") as f:
                items = json.load(f)
            if items:
                return items
        except Exception:
            pass
    t = load_token()
    return [{"name": "chính", "token": t}] if t else []


def save_tokens(items: list):
    os.makedirs(os.path.dirname(TOKENS), exist_ok=True)
    with open(TOKENS, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False)


def add_token(name: str, token: str) -> dict:
    """Them/cap nhat 1 token BM (kiem hop le truoc)."""
    r = fetch_pages(token)
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error")}
    items = load_tokens()
    name = (name or r.get("me") or "BM").strip()
    items = [x for x in items if x.get("name") != name]      # thay neu trung ten
    items.append({"name": name, "token": token})
    save_tokens(items)
    return {"ok": True, "name": name, "me": r.get("me"), "count": r.get("count")}


def remove_token(name: str):
    save_tokens([x for x in load_tokens() if x.get("name") != name])


def _get(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": True, "http": e.code, "body": e.read().decode()[:300]}
    except Exception as e:
        return {"error": True, "exc": str(e)[:200]}


def fetch_pages(token: str = None) -> dict:
    """Goi /me/accounts -> {ok, me, pages:[{id,name,tasks,access_token,can_post}]}."""
    token = token or load_token()
    if not token:
        return {"ok": False, "error": "Chua co FB_SYS_TOKEN (dan token vao keys.env)."}
    me = _get("%s/me?fields=name&access_token=%s" % (GRAPH, urllib.parse.quote(token)))
    if me.get("error"):
        return {"ok": False, "error": "Token loi", "detail": me}
    acc = _get("%s/me/accounts?fields=name,id,tasks,access_token,followers_count,"
               "fan_count,picture.width(100).height(100)&limit=200&access_token=%s"
               % (GRAPH, urllib.parse.quote(token)))
    if acc.get("error"):
        return {"ok": False, "error": "Khong lay duoc danh sach page", "detail": acc}
    pages = []
    for p in acc.get("data", []):
        tasks = p.get("tasks") or []
        pic = ((p.get("picture") or {}).get("data") or {}).get("url")
        pages.append({"id": p.get("id"), "name": p.get("name"), "tasks": tasks,
                      "access_token": p.get("access_token"),
                      "can_post": "CREATE_CONTENT" in tasks,
                      "followers_count": p.get("followers_count") or p.get("fan_count"),
                      "picture": pic})
    return {"ok": True, "me": me.get("name"), "count": len(pages), "pages": pages}


def save_cache(data: dict) -> str:
    os.makedirs(os.path.dirname(CACHE), exist_ok=True)
    data = {**data, "cached_at": int(time.time())}
    with open(CACHE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    return CACHE


def load_cache() -> dict:
    if os.path.isfile(CACHE):
        try:
            with open(CACHE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            # File cache hong (ghi do dang / JSON loi) -> KHONG lam sap endpoint.
            return {"ok": False, "pages": []}
    return {"ok": False, "pages": []}


def fetch_all() -> dict:
    """Gop page tu MOI token (nhieu BM). Dedup theo page id. Moi page co 'bm'."""
    toks = load_tokens()
    if not toks:
        return {"ok": False, "error": "Chưa có token nào (dán ở Cài đặt).", "pages": []}
    pages, me_names, errs = {}, [], []
    for tk in toks:
        r = fetch_pages(tk["token"])
        if not r.get("ok"):
            errs.append("%s: %s" % (tk.get("name"), r.get("error")))
            continue
        me_names.append("%s(%s)" % (tk.get("name"), r.get("me")))
        for p in r.get("pages", []):
            p["bm"] = tk.get("name")
            pages.setdefault(p["id"], p)      # BM dau tien giu page (khong trung)
    plist = list(pages.values())
    return {"ok": bool(plist), "me": " · ".join(me_names) or None,
            "count": len(plist), "pages": plist,
            "tokens": len(toks), "errors": errs}


def refresh() -> dict:
    """Lay moi (mọi BM) + luu cache. Tra ve ban KHONG kem token (an toan de hien)."""
    data = fetch_all()
    if data.get("ok"):
        save_cache(data)
    safe = {**data, "pages": [{k: v for k, v in p.items() if k != "access_token"}
                              for p in data.get("pages", [])]}
    return safe


def page_token(page_id: str) -> str:
    for p in load_cache().get("pages", []):
        if p.get("id") == page_id:
            return p.get("access_token", "")
    return ""


if __name__ == "__main__":
    r = fetch_pages()
    if not r.get("ok"):
        print("LOI:", r.get("error"), r.get("detail", ""))
    else:
        save_cache(r)
        print("ME:", r["me"], "| SO PAGE:", r["count"])
        for p in r["pages"][:10]:
            print("  -", p["name"], "| id", p["id"], "| dang duoc:", p["can_post"])
