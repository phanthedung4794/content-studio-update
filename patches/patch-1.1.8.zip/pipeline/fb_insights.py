"""
So lieu bai da dang (viral) qua Graph API — do THAT tren page that (2026-07-22).

SU THAT DO DUOC (probe reel that, KHONG tin tai lieu suong):
- Token System User hien CO du quyen: read_insights + pages_read_engagement.
- Edge `/{page}/videos` tra TRUC TIEP field `views` (so xem), `post_views`,
  `length`, `permalink_url`, `created_time`, + likes/comments summary — TRONG 1 CALL.
  -> KHONG can loop /{post}/video_insights (dat + hay doi ten metric).
- Phan trang qua paging.next (cursor). Newest first.
- viral = views >= moc CO DINH (chinh trong Cai dat).

Cache: facebook/_insights/<page_id>.json  {synced_at, page_id, name, videos:[...]}.
Incremental: moi lan sync lay newest toi max_videos, MERGE theo id (cap nhat views
bai gan day + them bai moi); bai cu ngoai cua so giu views cu (da on dinh).
"""
import json
import os
import time
import urllib.parse

import fb_graph as g

ROOT = g.ROOT
INS_DIR = os.path.join(ROOT, "facebook", "_insights")
VIDEO_FIELDS = ("id,title,description,views,post_views,length,permalink_url,"
                "created_time,thumbnails{uri,is_preferred},"
                "likes.summary(true).limit(0),comments.summary(true).limit(0)")
DEFAULT_VIRAL = 100000


def _cache_path(page_id: str) -> str:
    return os.path.join(INS_DIR, f"{page_id}.json")


def read_cache(page_id: str) -> dict:
    p = _cache_path(page_id)
    if os.path.isfile(p):
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"page_id": page_id, "videos": [], "synced_at": 0}


def _save_cache(data: dict) -> None:
    os.makedirs(INS_DIR, exist_ok=True)
    p = _cache_path(data["page_id"])
    tmp = p + f".tmp{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, p)


def _thumb(d: dict) -> str:
    """Anh dai dien: uu tien is_preferred, khong thi cai dau tien."""
    ths = (d.get("thumbnails") or {}).get("data") or []
    if not ths:
        return ""
    for t in ths:
        if t.get("is_preferred"):
            return t.get("uri") or ""
    return ths[0].get("uri") or ""


def _norm(d: dict) -> dict:
    """Chuan hoa 1 video tu Graph -> ban ghi gon."""
    likes = ((d.get("likes") or {}).get("summary") or {}).get("total_count")
    comments = ((d.get("comments") or {}).get("summary") or {}).get("total_count")
    return {
        "id": d.get("id"),
        "title": (d.get("title") or d.get("description") or "").strip()[:200],
        "views": int(d.get("views") or 0),
        "post_views": int(d.get("post_views") or 0),
        "likes": int(likes or 0),
        "comments": int(comments or 0),
        "length": round(float(d.get("length") or 0), 1),
        "permalink": d.get("permalink_url") or "",
        "thumb": _thumb(d),
        "created": d.get("created_time") or "",
    }


def page_posts(page_id: str) -> dict:
    """Toan bo bai da dang cua 1 page (tu cache) — cho Thu vien noi dung."""
    cache = read_cache(page_id)
    return {"page_id": page_id, "name": cache.get("name", ""),
            "synced_at": cache.get("synced_at", 0),
            "posts": cache.get("videos", [])}


def sync_page(page_id: str, page_token: str, name: str = "",
              max_videos: int = 200) -> dict:
    """Quet videos cua 1 page (newest first, phan trang), MERGE vao cache.

    Tra {ok, page_id, name, count, new, synced_at, error?}.
    """
    if not page_token:
        return {"ok": False, "page_id": page_id, "error": "Thieu page token"}
    Q = urllib.parse.quote
    url = ("%s/%s/videos?fields=%s&limit=50&access_token=%s"
           % (g.GRAPH, page_id, VIDEO_FIELDS, Q(page_token)))
    fetched = []
    for _ in range(0, max(1, max_videos // 50) + 1):
        r = g._get(url)
        if r.get("error"):
            # Loi giua chung -> tra cai da lay duoc, ghi ro loi (KHONG nuot).
            if not fetched:
                return {"ok": False, "page_id": page_id, "name": name,
                        "error": str(r.get("body") or r.get("exc") or r)[:200]}
            break
        for d in r.get("data", []):
            fetched.append(_norm(d))
        nxt = (r.get("paging") or {}).get("next")
        if not nxt or len(fetched) >= max_videos:
            break
        url = nxt

    cache = read_cache(page_id)
    by_id = {v["id"]: v for v in cache.get("videos", [])}
    new = 0
    for v in fetched:
        if v["id"] not in by_id:
            new += 1
        by_id[v["id"]] = v                       # merge: cap nhat views bai gan day
    videos = sorted(by_id.values(), key=lambda x: x.get("created", ""), reverse=True)
    data = {"page_id": page_id, "name": name or cache.get("name", ""),
            "videos": videos, "synced_at": int(time.time())}
    _save_cache(data)
    return {"ok": True, "page_id": page_id, "name": data["name"],
            "count": len(videos), "new": new, "synced_at": data["synced_at"]}


def page_summary(page_id: str, viral_views: int = DEFAULT_VIRAL,
                 top_n: int = 10) -> dict:
    """Tong hop tu cache 1 page: tong views, so bai viral, top bai."""
    cache = read_cache(page_id)
    vids = cache.get("videos", [])
    now = time.time()
    # dung .get(...,0): cache tu ban CU co the thieu key "views" -> tranh KeyError 500.
    days30 = [v for v in vids if _age_days(v.get("created", "")) <= 30]
    views30 = sum(int(v.get("views") or 0) for v in days30)
    viral = [v for v in vids if int(v.get("views") or 0) >= viral_views]
    top = sorted(vids, key=lambda x: int(x.get("views") or 0), reverse=True)[:top_n]
    return {
        "page_id": page_id, "name": cache.get("name", ""),
        "synced_at": cache.get("synced_at", 0),
        "total_videos": len(vids),
        "views_30d": views30,
        "viral_count": len(viral),
        "viral_views": viral_views,
        "top": top,
    }


def _age_days(created: str) -> float:
    if not created:
        return 1e9
    try:
        # 2026-07-22T04:39:38+0000
        from datetime import datetime, timezone
        s = created.replace("+0000", "+00:00")
        dt = datetime.fromisoformat(s)
        return (datetime.now(timezone.utc) - dt).total_seconds() / 86400
    except Exception:
        return 1e9


def sync_all(pages: list, viral_views: int = DEFAULT_VIRAL,
             max_videos: int = 200) -> dict:
    """Quet nhieu page (list {id,name,access_token}). Tra {results, summaries}."""
    results, summaries = [], []
    for p in pages:
        pid = p.get("id")
        r = sync_page(pid, p.get("access_token") or "", p.get("name", ""),
                      max_videos=max_videos)
        results.append(r)
        if r.get("ok"):
            summaries.append(page_summary(pid, viral_views))
    return {"results": results, "summaries": summaries}
