# -*- coding: utf-8 -*-
"""
GOVERNOR — bo ham cho autopilot: chan chay credit + tran video/ngay.
"Full-auto" van phai qua day. Doc credit THAT tu 79AI de quyet dinh.

Config: facebook/_governor.json ; State (dem theo ngay): facebook/_governor_state.json
"""
import json
import os
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.path.join(ROOT, "facebook")
CFG = os.path.join(FB_ROOT, "_governor.json")
STATE = os.path.join(FB_ROOT, "_governor_state.json")

DEFAULT = {
    "enabled": True,
    "floor_credit": 8000,      # duoi nay -> DUNG lam (phanh THAT, bảo vệ credit)
    "video_per_day": 60,       # TRAN AN TOAN tong/ngay (chan runaway). Nhip THAT do
                               # scheduler per-page lo (post_per_page_day + plan_for_page).
                               # 20 page x 2 = 40 -> 60 co margin.
    "post_per_page_day": 2,    # NHIP dang: bai/page/ngay (scheduler + autopilot dung)
    "jitter_min": 25,          # lech gio dang +-phut
    "est_per_video": 7200,     # uoc credit 1 video (de tinh truoc)
}


def _read(path, default):
    if os.path.isfile(path):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return dict(default)
    return dict(default)


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def load_config() -> dict:
    return {**DEFAULT, **_read(CFG, DEFAULT)}


def save_config(cfg: dict) -> dict:
    cur = load_config()
    for k in DEFAULT:
        if k in cfg:
            cur[k] = cfg[k]
    _write(CFG, cur)
    return cur


def _today() -> str:
    return time.strftime("%Y-%m-%d")


def _state() -> dict:
    s = _read(STATE, {"date": _today(), "produced": 0})
    if s.get("date") != _today():          # sang ngay moi -> reset dem
        s = {"date": _today(), "produced": 0}
        _write(STATE, s)
    return s


def _credit() -> int:
    """Credit 79AI THAT (None neu khong doc duoc)."""
    try:
        from gommo_client import GommoClient
        return GommoClient().credits()
    except Exception:
        return None


_SUB_CACHE = {"t": 0.0, "active": False}


def sub_active() -> bool:
    """Co goi thue bao (Starter Video...) dang ACTIVE + CON quota video khong?

    Work bang model TRONG goi (veo_3_1/grok/banana_pro) khi con quota = 0 credit
    -> governor KHONG duoc chan theo credit. Cache 10' de khoi goi API moi lan.
    Loi mang -> giu trang thai cache cu (khong chan oan nguoi da mua goi).
    """
    now = time.time()
    if now - _SUB_CACHE["t"] < 600:
        return _SUB_CACHE["active"]
    active = _SUB_CACHE["active"]
    try:
        from gommo_client import GommoClient
        info = GommoClient().subscription()
        if info.get("status") == "ACTIVE":
            opt = info.get("options") or {}
            cap = int(opt.get("videoMonth") or 0)
            used = int(opt.get("videoMonthUsage") or 0)
            active = (cap <= 0) or (used < cap)   # con quota (cap<=0 = khong gioi han)
        else:
            active = False
        _SUB_CACHE.update(t=now, active=active)
    except Exception:
        pass   # giu cache cu
    return active


def can_produce(est_cost: int = None, plan_free: bool = False) -> dict:
    """Co duoc phep LAM them 1 video khong? Tra {ok, reason, credit, produced}.

    plan_free=True (work bang model trong goi thue bao, con quota) -> BO QUA san credit
    (video khong tru credit, tru quota goi) — chi con chan tran video/ngay.
    """
    cfg = load_config()
    st = _state()
    if not cfg["enabled"]:
        return {"ok": False, "reason": "Governor đang TẮT", "produced": st["produced"]}
    if st["produced"] >= cfg["video_per_day"]:
        return {"ok": False, "reason": "Đã đủ %d video hôm nay" % cfg["video_per_day"],
                "produced": st["produced"]}
    cr = _credit()
    if plan_free:                                   # goi thue bao bao -> khong dung credit
        return {"ok": True, "reason": "OK (gói thuê bao — free theo quota)",
                "credit": cr, "produced": st["produced"]}
    est = est_cost or cfg["est_per_video"]
    if cr is None:
        return {"ok": False, "reason": "Không đọc được credit 79AI", "produced": st["produced"]}
    if cr - est < cfg["floor_credit"]:
        return {"ok": False, "reason": "Credit %d - %d < sàn %d → DỪNG" % (cr, est, cfg["floor_credit"]),
                "credit": cr, "produced": st["produced"]}
    return {"ok": True, "reason": "OK", "credit": cr, "produced": st["produced"]}


def record_produced():
    st = _state()
    st["produced"] = st.get("produced", 0) + 1
    _write(STATE, st)


def status(plan_free: bool = False) -> dict:
    cfg = load_config()
    st = _state()
    dec = can_produce(plan_free=plan_free)
    return {"config": cfg, "produced_today": st["produced"],
            "credit": dec.get("credit"), "can_produce": dec["ok"], "reason": dec["reason"]}


if __name__ == "__main__":
    print(json.dumps(status(), ensure_ascii=False, indent=1))
