# -*- coding: utf-8 -*-
"""
WATCHER — canh page NGUON, phat hien reel MOI (chua xu ly).
Dung fb_lister (cao qua Chrome dang dang nhap). So DA XU LY theo (nguon).

Ledger: facebook/_watch_ledger.json = { "<slug>": ["reel_id", ...] }
"""
import json
import os

import fb_lister

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LEDGER = os.path.join(ROOT, "facebook", "_watch_ledger.json")


def _load() -> dict:
    if os.path.isfile(LEDGER):
        with open(LEDGER, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save(d: dict):
    os.makedirs(os.path.dirname(LEDGER), exist_ok=True)
    with open(LEDGER, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)


def is_source(link: str) -> bool:
    """Link la NGUON (page) hay reel co dinh? Nguon = khong co /reel/<so>."""
    import re
    return not bool(re.search(r"/reel/\d+", link or ""))


def scan(link: str, progress=None, max_scroll: int = 8) -> dict:
    """Cao nguon -> tra ve reel MOI (chua trong so). {slug, new:[...], total, done}.

    max_scroll nho (8) = quet nhanh, chi lay reel moi nhat (du de phat hien video moi).
    """
    slug = fb_lister.page_slug(link)
    idx = fb_lister.list_reels(link, max_scroll=max_scroll, progress=progress)
    reels = idx.get("reels", {})            # id -> {views, href, thumb, ...}
    done = set(_load().get(slug, []))
    new = [{"id": rid, **info} for rid, info in reels.items() if rid not in done]
    # moi nhat truoc (reels tab cao tu tren = moi nhat)
    return {"slug": slug, "new": new, "new_count": len(new),
            "total": len(reels), "done": len(done)}


def next_new(link: str) -> str:
    """Reel MOI ke tiep de xu ly (moi nhat chua lam). '' neu het."""
    r = scan(link)
    return r["new"][0]["id"] if r["new"] else ""


# ── BACKLOG xep CU->MOI (cach A): xu tu dau (cu nhat), them bai moi vao DUOI ──
BACKLOG = os.path.join(ROOT, "facebook", "_backlog.json")


def _bl_load() -> dict:
    if os.path.isfile(BACKLOG):
        try:
            with open(BACKLOG, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def _bl_save(d: dict):
    os.makedirs(os.path.dirname(BACKLOG), exist_ok=True)
    tmp = "%s.%d.tmp" % (BACKLOG, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    for _ in range(8):
        try:
            os.replace(tmp, BACKLOG); return
        except OSError:
            import time as _t; _t.sleep(0.05)
    with open(BACKLOG, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    try:
        os.remove(tmp)
    except OSError:
        pass


def _scroll_ids(slug: str) -> list:
    """Id reel theo thu tu CUON (moi->cu) tu index.json da cao."""
    return list((fb_lister.load_index(slug).get("reels") or {}).keys())


def build_backlog(link: str, refresh: bool = False, max_scroll: int = 60,
                  progress=None) -> dict:
    """Dung/ cap nhat backlog CU->MOI cho 1 nguon. Them id MOI vao DUOI.

    refresh=True -> cao lai qua Chrome (fb_lister) truoc; nguoc lai dung index co san.
    Thu tu cuon = moi->cu; DAO lai = cu->moi. Id chua co trong backlog = moi hon
    (nguon chi them bai moi) -> noi vao duoi (dau moi nhat).
    """
    slug = fb_lister.page_slug(link)
    if refresh:
        fb_lister.list_reels(link, max_scroll=max_scroll, progress=progress)
    scroll = _scroll_ids(slug)                 # moi->cu
    d = _bl_load()
    cur = d.get(slug, [])                       # cu->moi
    have = set(cur)
    # id moi (chua trong backlog), dao ve cu->moi, noi vao duoi
    new_ids = [rid for rid in reversed(scroll) if rid not in have]
    if new_ids:
        cur = cur + new_ids
        d[slug] = cur
        _bl_save(d)
    return {"slug": slug, "total": len(cur), "added": len(new_ids)}


def next_oldest(link: str, auto_build: bool = True) -> str:
    """Reel CU NHAT chua xu ly (dau backlog, bo qua so da lam). '' neu het."""
    slug = fb_lister.page_slug(link)
    d = _bl_load()
    if slug not in d and auto_build:
        build_backlog(link, refresh=False)      # dung index co san (khong can Chrome)
        d = _bl_load()
    done = set(_load().get(slug, []))
    for rid in d.get(slug, []):
        if rid not in done:
            return rid
    return ""


def backlog_status(link: str) -> dict:
    """Thong ke backlog 1 nguon: tong / da lam / con lai."""
    slug = fb_lister.page_slug(link)
    bl = _bl_load().get(slug, [])
    done = set(_load().get(slug, []))
    remain = [r for r in bl if r not in done]
    return {"slug": slug, "total": len(bl), "done": len(bl) - len(remain),
            "remain": len(remain), "next": remain[0] if remain else ""}


def mark(slug: str, reel_id: str):
    d = _load()
    d.setdefault(slug, [])
    if reel_id not in d[slug]:
        d[slug].append(reel_id)
        _save(d)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "build":
        # build/refresh backlog cu->moi (cao qua Chrome)
        link = sys.argv[2] if len(sys.argv) > 2 else "https://www.facebook.com/tuoitho89x/reels/"
        r = build_backlog(link, refresh=True,
                          progress=lambda n, s: print("  ...%d reel (buoc %d)" % (n, s), flush=True))
        st = backlog_status(link)
        print("BACKLOG %s: tong %d (them %d) | da lam %d | con %d | ke tiep %s"
              % (r["slug"], st["total"], r["added"], st["done"], st["remain"], st["next"]))
    elif len(sys.argv) > 1 and sys.argv[1] == "build-many-parallel":
        # Cao SONG SONG nhieu nguon (httpx 1 cookie) -> sync backlog -> fallback cuon.
        links = [x for x in sys.argv[2:] if x.strip()]
        sp = None
        try:
            import fb_scrape_parallel as sp
        except Exception as e:
            # Ban khach chua co httpx -> KHONG song song duoc -> cao TUAN TU (van chay).
            print("Thieu httpx (%s) -> cao TUAN TU thay the." % e, flush=True)
        if sp is None:
            print("CAO TUAN TU %d nguon..." % len(links), flush=True)
            for i, link in enumerate(links, 1):
                slug = fb_lister.page_slug(link)
                print("\n[%d/%d] %s" % (i, len(links), slug), flush=True)
                try:
                    build_backlog(link, refresh=True,
                                  progress=lambda n, s: print("  ...%d reel (buoc %d)" % (n, s), flush=True))
                    bs = backlog_status(link)
                    print("  XONG %s: tong %d | con %d" % (slug, bs["total"], bs["remain"]), flush=True)
                except Exception as e:
                    print("  LOI %s: %s -> cao tiep" % (slug, e), flush=True)
            print("\nTONG: %d nguon (tuan tu)." % len(links), flush=True)
            sys.exit(0)
        print("CAO SONG SONG %d nguon (concurrency=%d)..." % (len(links), sp.CONCURRENCY), flush=True)
        out = sp.crawl_many_parallel(
            links, progress=lambda slug, n: print("  [%s] %d reel" % (slug, n), flush=True))
        for r in out["results"]:
            try:
                build_backlog(r["url"], refresh=False)   # dung index vua luu, KHONG cao lai
                bs = backlog_status(r["url"])
                print("  XONG %s: tong %d | con %d" % (r["slug"], bs["total"], bs["remain"]), flush=True)
            except Exception as e:
                print("  backlog loi %s: %s" % (r["slug"], e), flush=True)
        for url in out["failed_bootstrap"]:               # page khong bootstrap duoc -> cuon du phong
            slug = fb_lister.page_slug(url)
            print("  [fallback cuon] %s" % slug, flush=True)
            try:
                build_backlog(url, refresh=True)
            except Exception as e:
                print("  fallback loi %s: %s" % (slug, e), flush=True)
        print("\nTONG: %d page song song, %d fallback." % (len(out["results"]), len(out["failed_bootstrap"])), flush=True)
    elif len(sys.argv) > 1 and sys.argv[1] == "build-many":
        # Cao NHIEU nguon TUAN TU trong 1 job (tranh tranh 1 tab Chrome).
        # Moi page try/except RIENG -> 1 page loi KHONG chan cac page con lai.
        links = [x for x in sys.argv[2:] if x.strip()]
        print("CAO %d nguon lan luot..." % len(links), flush=True)
        ok, fail = 0, 0
        for i, link in enumerate(links, 1):
            slug = fb_lister.page_slug(link)
            print("\n[%d/%d] %s" % (i, len(links), slug), flush=True)
            try:
                r = build_backlog(link, refresh=True,
                                  progress=lambda n, s: print("  ...%d reel (buoc %d)" % (n, s), flush=True))
                st = backlog_status(link)
                print("  XONG %s: tong %d (them %d) | con %d"
                      % (r["slug"], st["total"], r["added"], st["remain"]), flush=True)
                ok += 1
            except Exception as e:
                print("  LOI %s: %s -> bo qua, cao tiep" % (slug, e), flush=True)
                fail += 1
        print("\nTONG: %d nguon xong, %d loi." % (ok, fail), flush=True)
    else:
        link = sys.argv[1] if len(sys.argv) > 1 else "https://www.facebook.com/tuoitho89x/reels/"
        r = scan(link, progress=lambda n, s: print("  ...%d reel (buoc %d)" % (n, s), flush=True))
        print("NGUON %s: %d moi / %d tong (da lam %d)" % (r["slug"], r["new_count"], r["total"], r["done"]))
        for x in r["new"][:8]:
            print("  MOI:", x["id"], x.get("view_text"), x.get("href"))
