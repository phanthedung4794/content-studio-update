"""
Cao SONG SONG nhieu page bang 1 cookie (authenticated scraping, HTTP replay).

DO THAT (phien 2026-07-24, xem docs/cao-song-song-1-cookie.md):
- httpx replay NGOAI browser CHAY (can du header sec-fetch-* + x-fb-lsd/x-asbd-id).
- concurrency 20 chuoi tu 1 cookie: 0 throttle (FB chiu, browser that cung ban song song).
- 2 page song song: wall-clock = page CHAM NHAT (khong cong don).

KIEN TRUC:
  [1] harvest cookie + UA + header template (1 lan, qua CDP).
  [2] BOOTSTRAP tung page qua browser (tuan tu): navigate -> bat 1 request pagination
      that -> lay collection-id + cursor dau + DOM newest. (doc_id/fb_dtsg nam trong body,
      tu do moi lan -> FB xoay cung khong gay.)
  [3] httpx async PAGINATE tat ca page SONG SONG (bounded concurrency) toi has_next=false.
      Governor: loi/rong -> retry backoff (lo DU-DATA, khong de sot reel).
  [4] merge index.json qua fb_lister._merge_save (giu trang thai da tai).

Gay HTTP bat ky -> page do rot ve list_reels (cuon browser) o lop goi (fb_watch), khong trang tay.

Kiem THAT:
  python -m pipeline.fb_scrape_parallel https://www.facebook.com/tuoitho89x/reels/ https://www.facebook.com/Vemienannhien257/reels/
"""
import asyncio
import json
import os
import time
import urllib.parse

import httpx

import fb_lister
from fb_session import CDP, DEFAULT_PORT, list_targets, open_session

GRAPHQL = "https://www.facebook.com/api/graphql/"
CONCURRENCY = max(1, int(os.environ.get("CS_CRAWL_CONCURRENCY", "8")))
MAX_RETRY = 3   # so lan thu lai 1 buoc khi throttle/loi truoc khi bo (lo du-data)

# Bat CA fetch LAN XHR request graphql -> ghi body + headers (de replay ngoai browser).
_WRAP_JS = r'''(function(){
  if(window.__spInstalled) return 'already';
  window.__spCap=[];
  function hobj(h){var o={};try{if(!h)return o;if(h.forEach){h.forEach(function(v,k){o[k]=v;});return o;}
    if(typeof h==='object'){for(var k in h)o[k]=h[k];}}catch(e){}return o;}
  var of=window.fetch;
  window.fetch=function(i,n){try{var u=(typeof i==='string')?i:(i&&i.url)||'';
    if(u.indexOf('/api/graphql')>=0&&n&&n.body)window.__spCap.push({body:String(n.body),headers:hobj(n.headers)});
  }catch(e){}return of.apply(this,arguments);};
  var oo=XMLHttpRequest.prototype.open,osh=XMLHttpRequest.prototype.setRequestHeader,osd=XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open=function(m,u){this.__u=u;this.__h={};return oo.apply(this,arguments);};
  XMLHttpRequest.prototype.setRequestHeader=function(k,v){try{this.__h[k]=v;}catch(e){}return osh.apply(this,arguments);};
  XMLHttpRequest.prototype.send=function(b){try{if(this.__u&&this.__u.indexOf('/api/graphql')>=0&&b)
    window.__spCap.push({body:String(b),headers:this.__h||{}});}catch(e){}return osd.apply(this,arguments);};
  window.__spInstalled=true;return 'installed';
})()'''


def _std_headers(cap_headers, cookie_hdr, ua, referer, friendly):
    """Header day du de FB chap nhan request ngoai browser (thieu sec-fetch-* -> loi 1357054)."""
    h = {k.lower(): v for k, v in (cap_headers or {}).items()}
    h.update({
        "content-type": "application/x-www-form-urlencoded",
        "cookie": cookie_hdr, "user-agent": ua,
        "origin": "https://www.facebook.com", "referer": referer, "accept": "*/*",
        "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin",
        "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
    })
    h.setdefault("x-fb-friendly-name", friendly)
    return h


def _row_from_edge(e):
    """Trich 1 reel tu edge GraphQL -> {id, href, view_text, thumb, length} (khop _merge_save)."""
    try:
        m = e["profile_reel_node"]["node"]["attachments"][0]["media"]
    except Exception:
        return None
    if not m.get("id"):
        return None
    return {
        "id": m["id"],
        "href": (m.get("permalink_url") or m.get("shareable_url") or "").split("?")[0] or None,
        "view_text": m.get("play_count_reduced"),
        "thumb": (m.get("thumbnailImage") or {}).get("uri") or m.get("first_frame_thumbnail"),
        "length": m.get("length_in_second"),
    }


def _harvest(c):
    """Cookie + UA tu CDP (phien Chrome dang login)."""
    ua = c.eval("navigator.userAgent")
    c.send("Network.enable")
    cks = c.send("Network.getCookies", {"urls": ["https://www.facebook.com"]}).get("cookies", [])
    cookie_hdr = "; ".join("%s=%s" % (ck["name"], ck["value"]) for ck in cks)
    return cookie_hdr, ua


def _bootstrap(c, page_url, tries=6):
    """Navigate page -> bat 1 request pagination that + DOM newest.

    Tra {slug, url, fields, cursor, headers, dom} hoac None neu khong bat duoc.
    """
    slug = fb_lister.page_slug(page_url)
    c.navigate(page_url, wait=4.0)
    c.eval(_WRAP_JS)
    dom = {}
    for r in (c.eval(fb_lister._COLLECT_JS) or []):     # reel moi nhat (server-render)
        dom[r["id"]] = r
    for _ in range(tries):
        c.eval("window.scrollTo(0, document.body.scrollHeight)")
        time.sleep(2.0)
        for r in (c.eval(fb_lister._COLLECT_JS) or []):
            dom.setdefault(r["id"], r)
        for x in (c.eval("window.__spCap || []") or []):
            f = dict(urllib.parse.parse_qsl(x["body"]))
            if "ReelsRendererPaginationQuery" in f.get("fb_api_req_friendly_name", ""):
                return {"slug": slug, "url": page_url, "fields": f,
                        "cursor": json.loads(f["variables"]).get("cursor"),
                        "headers": x["headers"], "dom": dom}
    return None


async def _paginate(client, boot, cookie_hdr, ua, max_pages, progress=None):
    """Di het chuoi cursor 1 page qua httpx. Tra acc {id: row}. Governor retry khi throttle."""
    fields = boot["fields"]
    friendly = fields.get("fb_api_req_friendly_name", "")
    headers = _std_headers(boot["headers"], cookie_hdr, ua, boot["url"], friendly)
    acc = {}
    # seed DOM newest (nhung reel truoc cursor dau -> khong sot moi nhat)
    for rid, r in boot["dom"].items():
        acc[rid] = {"id": rid, "href": r.get("href"), "thumb": r.get("thumb"),
                    "view_text": r.get("view_text"), "length": None}
    cursor = boot["cursor"]
    for pg in range(max_pages):
        body = None
        f = dict(fields)
        v = json.loads(f["variables"]); v["count"] = 30; v["cursor"] = cursor
        f["variables"] = json.dumps(v)
        body = urllib.parse.urlencode(f)
        agg = None
        for attempt in range(MAX_RETRY):
            try:
                r = await client.post(GRAPHQL, content=body, headers=headers)
                j = None
                for line in r.text.split("\n"):
                    try:
                        j = json.loads(line); break
                    except Exception:
                        pass
                agg = (((j or {}).get("data") or {}).get("node") or {}).get("aggregated_fb_shorts") if j else None
                if agg and agg.get("edges") is not None:
                    break                                    # OK
            except Exception:
                agg = None
            await asyncio.sleep(2.0 * (attempt + 1))         # backoff khi throttle/loi
        if not agg or agg.get("edges") is None:
            break                                            # het duong (da retry) -> dung page nay
        for e in agg["edges"]:
            row = _row_from_edge(e)
            if row:
                acc[row["id"]] = row
        pi = agg.get("page_info", {})
        cursor = pi.get("end_cursor")
        if progress:
            progress(boot["slug"], len(acc))
        if not pi.get("has_next_page") or not cursor or not agg["edges"]:
            break
    return boot, acc


async def _run_all(boots, cookie_hdr, ua, max_pages, concurrency, progress=None):
    sem = asyncio.Semaphore(concurrency)

    async def one(client, boot):
        async with sem:
            return await _paginate(client, boot, cookie_hdr, ua, max_pages, progress)

    async with httpx.AsyncClient(http2=True, timeout=30) as client:
        return await asyncio.gather(*[one(client, b) for b in boots])


def crawl_many_parallel(page_urls, port=None, concurrency=None, max_pages=60,
                        progress=None) -> dict:
    """Cao SONG SONG nhieu page. Tra {results:[{slug,count,ok}], failed_bootstrap:[url]}.

    progress(slug, n) goi khi 1 page them reel. Page bootstrap that bai -> nam trong
    failed_bootstrap (lop goi tu rot ve list_reels cuon cho page do).
    """
    port = port or DEFAULT_PORT
    concurrency = concurrency or CONCURRENCY
    open_session(port)
    targets = list_targets(port)
    if not targets:
        raise RuntimeError("Khong co tab Chrome. Mo phien va dang nhap truoc.")
    c = CDP(targets[0]["webSocketDebuggerUrl"])
    boots, failed = [], []
    try:
        cookie_hdr, ua = _harvest(c)
        for url in page_urls:
            b = _bootstrap(c, url)
            if b:
                boots.append(b)
                print("  bootstrap OK: %s" % b["slug"], flush=True)
            else:
                failed.append(url)
                print("  bootstrap FAIL: %s" % fb_lister.page_slug(url), flush=True)
    finally:
        c.close()

    results = []
    if boots:
        paginated = asyncio.run(_run_all(boots, cookie_hdr, ua, max_pages, concurrency, progress))
        for boot, acc in paginated:
            fb_lister._merge_save(boot["slug"], boot["url"], acc)
            results.append({"slug": boot["slug"], "url": boot["url"], "count": len(acc)})
    return {"results": results, "failed_bootstrap": failed, "concurrency": concurrency}


if __name__ == "__main__":
    import sys
    urls = [u for u in sys.argv[1:] if u.strip()]
    if not urls:
        urls = ["https://www.facebook.com/tuoitho89x/reels/"]

    def _p(slug, n):
        print("  [%s] %d reel" % (slug, n), flush=True)

    t0 = time.time()
    print("CAO SONG SONG %d page (concurrency=%d)..." % (len(urls), CONCURRENCY), flush=True)
    out = crawl_many_parallel(urls, progress=_p)
    print("\n== XONG %.1fs ==" % (time.time() - t0))
    for r in out["results"]:
        print("  %-24s: %d reel" % (r["slug"], r["count"]))
    if out["failed_bootstrap"]:
        print("  bootstrap that bai (can cuon du phong):", out["failed_bootstrap"])
