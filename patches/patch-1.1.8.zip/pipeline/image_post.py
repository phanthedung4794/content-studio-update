"""
Tao ANH DANG FACEBOOK tu noi dung: tranh 79ai o DUOI + chu tieng Viet o TREN.

Khac video: KHONG intake, KHONG kich ban. Nguoi dung dien 2 o:
  - Y tuong tranh  -> ghep STYLE_SUFFIX (co dinh duoi day) -> prompt gui 79ai.
  - Chu (bai tho)  -> CHI de PIL ghi len, KHONG vao prompt (dau tieng Viet
                      se hong neu de 79ai ve chu — luat cung #3 cua du an).

Bo cuc (theo vi du nguoi dung gui 15/07): chu tren nen kem trong, tranh duoi.
KHONG scrim (chu khong de len tranh) -> khong can lop toi mo.

Ghep lien mach: LAY MAU mau nen kem tu goc tranh 79ai roi to ca canvas mau do
-> vung chu tren va tranh duoi cung mot mau kem, khong lo vet ghep.

Module nay THUAN PIL, khong goi mang. Server lo phan goi 79ai + tai anh ve.
"""
import os

from PIL import Image, ImageDraw, ImageFont, ImageOps

from compose_video import wrap_text, draw_centered, fit_illustration, hex_to_rgb

# ── LOAI ANH (style) — nguoi dung CHON, dich tieng Viet cho de hieu ──
# Moi style = mot doan mo ta phong cach (tieng Anh, AI hieu tot hon) ghep sau
# "y tuong". GUARD chung o duoi luon cam CHU trong tranh + full bleed (khong vien).
# Style KHONG phu thuoc model — la loi nhac prompt, chay tren moi model ve anh.
_GUARD = ("full bleed background filling the entire frame edge to edge, "
          "NO text, NO letters, NO words, NO captions, no watermark, no border, no frame")

# key -> (nhan tieng Viet, doan phong cach tieng Anh). key dau = MAC DINH.
STYLES = {
    "hoat_hinh": ("Hoạt hình dễ thương (mặc định)",
                  "cute simple hand-drawn cartoon illustration, thin clean black ink outlines, "
                  "soft warm cream beige paper background, adorable chibi characters, gentle "
                  "expressions, minimal soft color accents, cozy warm tender mood"),
    "anh_that": ("Ảnh chụp thật",
                 "ultra realistic photograph, photorealistic, natural soft lighting, sharp focus, "
                 "fine detail, 85mm lens, lifelike skin and textures"),
    "chan_dung_dien_anh": ("Chân dung điện ảnh",
                           "cinematic portrait, dramatic moody lighting, shallow depth of field, "
                           "film still, ultra detailed, atmospheric"),
    "anime": ("Anime Nhật Bản",
              "Japanese anime style, clean crisp line art, cel shading, expressive eyes, "
              "vibrant colors, studio anime key visual"),
    "mau_nuoc": ("Tranh màu nước",
                 "soft watercolor painting, delicate translucent washes, textured watercolor paper, "
                 "gentle bleeding colors, hand painted"),
    "pixar_3d": ("Hoạt hình 3D (kiểu Pixar)",
                 "3D animated character render, Pixar Disney style, soft global illumination, "
                 "cute rounded shapes, subsurface scattering, high quality render"),
    "son_dau": ("Tranh sơn dầu",
                "classical oil painting, visible textured brush strokes, rich warm tones, "
                "canvas texture, painterly"),
    "ngam_doi": ("Đen trắng xúc động (Ngẫm Đời)",
                 "minimalist 2D cartoon illustration, STRICTLY grayscale black white and gray only, "
                 "no color, simple rounded egg-shaped heads with minimal facial features, a dramatic "
                 "warm glowing spotlight halo behind the characters, long dark shadows on the floor, "
                 "dark vignette background, emotional cinematic mood, clean thin black ink line art"),
    "theo_mo_ta": ("Theo mô tả (không thêm phong cách)", ""),
}
DEFAULT_STYLE = "hoat_hinh"
# Giu ten cu de cho khong vo neu noi khac import (tro toi style mac dinh).
STYLE_SUFFIX = STYLES[DEFAULT_STYLE][1] + ", " + _GUARD


def style_options() -> list:
    """[{value, label}] cho o chon 'Loai anh' o giao dien."""
    return [{"value": k, "label": v[0]} for k, v in STYLES.items()]

# Kho anh CUOI = NEN TANG x MUC DICH (nguoi dung chon 2 o). Kich thuoc DUNG CHUAN
# tung nen tang. Key composite: "<platform>_<purpose>". Anh dai dien 3 nen deu VUONG.
PLATFORMS = [
    {"value": "facebook", "label": "Facebook"},
    {"value": "tiktok",   "label": "TikTok"},
    {"value": "youtube",  "label": "YouTube"},
]
PURPOSES = [
    {"value": "avatar", "label": "Ảnh đại diện"},
    {"value": "cover",  "label": "Ảnh bìa"},
    {"value": "post",   "label": "Bài đăng"},
    {"value": "story",  "label": "Story / Reel / Shorts"},
]
SIZES = {
    # Facebook
    "facebook_avatar": (1080, 1080), "facebook_cover": (1640, 624),
    "facebook_post": (1080, 1350),   "facebook_story": (1080, 1920),
    # TikTok (khong co bia ho so that -> dung khung doc chuan TikTok)
    "tiktok_avatar": (1080, 1080),   "tiktok_cover": (1080, 1920),
    "tiktok_post": (1080, 1920),     "tiktok_story": (1080, 1920),
    # YouTube
    "youtube_avatar": (1080, 1080),  "youtube_cover": (2560, 1440),
    "youtube_post": (1920, 1080),    "youtube_story": (1080, 1920),
    # Legacy (giu tuong thich): ti le bai dang cu
    "9:16": (1080, 1920), "4:5": (1080, 1350), "1:1": (1080, 1080),
}
DEFAULT_PLATFORM = "facebook"
DEFAULT_PURPOSE = "avatar"
DEFAULT_RATIO = "facebook_avatar"


def platform_options() -> list:
    return list(PLATFORMS)


def purpose_options() -> list:
    return list(PURPOSES)


def size_key(platform: str, purpose: str) -> str:
    """Ghep key kich thuoc tu nen tang + muc dich; khong hop le -> DEFAULT_RATIO."""
    k = "%s_%s" % (platform, purpose)
    return k if k in SIZES else DEFAULT_RATIO

# Phan CHIEU CAO danh cho chu (tinh tu tren). Con lai la tranh.
TEXT_FRAC = 0.30
TEXT_MARGIN = 90          # le trai/phai cua khoi chu
TEXT_TOP_PAD = 70         # khoang trong tren cung toi thieu
LINE_GAP = 16
TEXT_COLOR = "#3d3630"    # nau xam dam (giong vi du)

# Font: Arial thuong (vi du la chu thuong, khong dam). Co du phong.
FONT_CANDIDATES = [
    "C:/Windows/Fonts/arial.ttf",
    "C:/Windows/Fonts/segoeui.ttf",
    "C:/Windows/Fonts/tahoma.ttf",
]


def build_prompt(idea: str, style: str = DEFAULT_STYLE) -> str:
    """Ghep y tuong nguoi dung + phong cach da chon + guard -> prompt ve tranh."""
    idea = " ".join((idea or "").split())
    if not idea:
        raise ValueError("Thieu y tuong tranh.")
    suffix = STYLES.get(style, STYLES[DEFAULT_STYLE])[1]
    parts = [idea] + ([suffix] if suffix else []) + [_GUARD]
    return ", ".join(parts)


def _font_path() -> str:
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            return p
    raise SystemExit("Khong tim thay font he thong de ghi chu.")


def pick_illustration_ratio(available: list, ratio_key: str, full: bool = False) -> str:
    """Chon ti le YEU CAU 79ai ve sao cho khop dai tranh (it phai cat nhat).

    `available` = danh sach ten ti le model ho tro (vd ['16:9','9:16','1:1',...]).
    full=False: khop DAI TRANH (bai co chu, tranh chiem ~70% duoi).
    full=True : khop CA KHUNG (anh dai dien khong chu -> phu het khung).
    Tra ve ten ti le gan nhat; khong co thi tra ratio_key.
    """
    W, H = SIZES.get(ratio_key, SIZES[DEFAULT_RATIO])
    band_h = H if full else (H - int(H * TEXT_FRAC))
    target = W / band_h                       # ti le rong/cao can ve

    best, best_gap = None, 1e9
    for name in available or []:
        if not isinstance(name, str) or ":" not in name:
            continue                          # bo qua 'auto'
        try:
            a, b = name.split(":")
            val = float(a) / float(b)
        except (ValueError, ZeroDivisionError):
            continue
        gap = abs(val - target)
        if gap < best_gap:
            best, best_gap = name, gap
    return best or ratio_key


def _sample_bg(img: Image.Image) -> tuple:
    """Lay mau mau nen kem tu 2 goc TREN cua tranh (noi thuong la nen trong)."""
    w, h = img.size
    patches = []
    for (x, y) in [(6, 6), (w - 16, 6)]:
        x = max(0, min(x, w - 10)); y = max(0, min(y, h - 10))
        px = img.crop((x, y, x + 10, y + 10)).resize((1, 1)).getpixel((0, 0))
        patches.append(px[:3] if isinstance(px, tuple) else (px, px, px))
    return tuple(sum(c[i] for c in patches) // len(patches) for i in range(3))


def _wrap_multiline(draw, text: str, font, max_w: int) -> list:
    """Giu xuong dong CHU DICH cua nguoi dung, van tu ngat dong qua dai.

    Bai tho co ngat dong that (4 cau). wrap_text goc chi cat theo do rong ->
    se pha vo cau tho. Nen: tach theo '\\n' truoc, moi cau moi wrap tiep.
    Dong trong ('') giu lai lam khoang cach kho tho.
    """
    lines = []
    for para in (text or "").replace("\r", "").split("\n"):
        para = para.strip()
        if not para:
            lines.append("")
        else:
            lines.extend(wrap_text(draw, para, font, max_w))
    return lines


def compose_card(illustration_path: str, text: str, out_path: str,
                 ratio_key: str = DEFAULT_RATIO) -> str:
    """Ghep the: nen kem (lay mau tu tranh) + tranh nua duoi + chu nua tren.

    Tra ve out_path. THUAN PIL — khong mang.
    """
    W, H = SIZES.get(ratio_key, SIZES[DEFAULT_RATIO])
    text_band_h = int(H * TEXT_FRAC)
    illo_band_h = H - text_band_h

    illo = Image.open(illustration_path).convert("RGB")
    bg = _sample_bg(illo)

    canvas = Image.new("RGB", (W, H), bg)
    canvas.paste(fit_illustration(illo, W, illo_band_h), (0, text_band_h))

    draw = ImageDraw.Draw(canvas)
    # Co chu theo chieu rong canvas; 46px hop cho 1080. Co the tinh chinh sau.
    font = ImageFont.truetype(_font_path(), 48)
    max_w = W - 2 * TEXT_MARGIN
    lines = _wrap_multiline(draw, text, font, max_w)

    ascent, descent = font.getmetrics()
    line_h = ascent + descent + LINE_GAP
    block_h = max(0, len(lines) * line_h - LINE_GAP)
    top = max(TEXT_TOP_PAD, (text_band_h - block_h) // 2)
    draw_centered(draw, lines, font, top, W, hex_to_rgb(TEXT_COLOR), LINE_GAP)

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    canvas.save(out_path, quality=95)
    return out_path


def compose_plain(illustration_path: str, out_path: str,
                  ratio_key: str = DEFAULT_RATIO) -> str:
    """Anh KHONG chu (vd anh dai dien): phu KIN khung theo ti le, cat giua neu lech.

    Dung cho truong hop nguoi dung khong nhap chu. THUAN PIL.
    """
    W, H = SIZES.get(ratio_key, SIZES[DEFAULT_RATIO])
    illo = Image.open(illustration_path).convert("RGB")
    canvas = ImageOps.fit(illo, (W, H), method=Image.LANCZOS, centering=(0.5, 0.5))
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    canvas.save(out_path, quality=95)
    return out_path
