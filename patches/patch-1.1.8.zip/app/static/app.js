const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => (n ?? 0).toLocaleString('vi-VN');

let S = { page: 'intake', data: { episodes: [] }, ep: null, jobs: {}, balance: {}, busy: false, err: null };
// GOI GON 4.0: cau hinh toan cuc (che do nang cao). Cac module cu bi an o tang UI
// khi advanced_mode=false — code backend GIU nguyen (fbpost dung chung).
// MAC DINH false = an: neu /config loi thi VAN an (fail-safe, dung y dong goi khach).
let appConfig = { advanced_mode: false, edition: 'internal' };
const ADVANCED_PAGES = ['intake', 'board', 'library', 'aivideo', 'fbvideo', 'voices', 'voice'];
let intakeData = null;                      // null = chua tai, {} = da tai
let profiles = [], elevenVoices = [], voiceDraft = null, voiceTab = 'eleven';
let selIntake = new Set(), selEp = new Set(), selDone = new Set();
// Tab "Tao anh" (bai dang Facebook)
let imgModels = [], imgErr = null, imgStyles = [], imgPlatforms = [], imgPurposes = [], imgSizes = {};
let imgSel = { model: '', mode: '', resolution: '', style: '', platform: 'facebook', purpose: 'avatar' };
let imgIdea = '', imgText = '', imgList = [], imgResult = null, imgRef = null;
/* ── Tạo video AI ── */
let avData = { video_models: [], image_models: [], eleven_voices: [], music: [] };
let avSel = { imgModel: '', imgMode: '', imgRes: '', vidModel: '', vidMode: '', vidRes: '',
              ratio: '9:16', audio: 'music', voice: '', music: '', musicDb: -12, voiceSpeed: 1.0 };
const AV_MUSIC_DB = [{ v: -6, t: 'To' }, { v: -12, t: 'Vừa' }, { v: -18, t: 'Nhỏ' }, { v: -24, t: 'Rất nhỏ' }];
const avMusicDbOpts = cur => AV_MUSIC_DB.map(o => `<option value="${o.v}" ${o.v === cur ? 'selected' : ''}>${o.t}</option>`).join('');
const AV_SPEED = [{ v: 0.85, t: 'Chậm' }, { v: 1.0, t: 'Vừa (gốc)' }, { v: 1.15, t: 'Nhanh' }, { v: 1.3, t: 'Rất nhanh' }];
const avSpeedOpts = cur => AV_SPEED.map(o => `<option value="${o.v}" ${Math.abs(o.v - cur) < 0.01 ? 'selected' : ''}>${o.t}</option>`).join('');
let avScenes = [{ prompt_img: '', prompt_action: '', narration: '', seconds: 5 }];
let avTitle = '', avEst = null, avErr = null, avList = [], avStatus = null, avScripts = [];
let avEditId = null, avEdit = { audio_mode: 'music', voice: '', music: '', music_db: -18 };
// Bang dieu khien (Overview)
let avTab = 'over';                 // over | batch | cfg
let avFilter = 'all';              // all | building | wait | done | error | draft
let avSearch = '';
let avSelSet = new Set();          // id video da tick (thao tac hang loat)
let avBatchClosed = new Set();     // ma me dang gap (Bang dieu khien)
let avSummary = null;              // {total, counts, spent_month, cap_month, warn_pct}
let avBudget = { cap_month: 0, warn_pct: 90 };
// Me hang loat (Pha 2)
let avBatchMode = 'auto';         // auto | paste
let avBatchTheme = '';            // chu de kenh (auto)
let avBatchN = 5;                 // so video tu sinh
let avBatchNScenes = 6;           // so canh moi video
let avBatchText = '';             // danh sach de dan (moi dong 1 de)
let avBatchScripts = [];          // [{id,title,character,scenes,approved,credit,editing}]
let avBatchBusy = false;
let avBatchProg = '';
let apiKeys = [];

/* ══════════ NEN ══════════ */
async function api(path, options = {}) {
  const init = { ...options, headers: { ...(options.body ? {'Content-Type':'application/json'} : {}), ...(options.headers || {}) } };
  if (options.body && typeof options.body !== 'string') init.body = JSON.stringify(options.body);
  const r = await fetch('/api' + path, init);
  if (!r.ok) {
    let msg = await r.text();
    try { msg = JSON.parse(msg).detail || msg; } catch {}
    throw new Error(friendly(msg) || `Lỗi ${r.status}`);
  }
  return r.json();
}

// Loi ky thuat -> loi nguoi doc hieu. Nguoi dung khong can biet 'HTTPException'.
const ERRORS = [
  [/ELEVENLABS_API_KEY|Thieu ELEVENLABS/i, 'Thiếu API key ElevenLabs. Nạp key rồi khởi động lại phần mềm.'],
  [/401|Unauthorized/i, 'API key không hợp lệ hoặc hết hạn.'],
  [/402|quota|insufficient/i, 'Hết hạn mức ElevenLabs. Nâng gói hoặc chờ tháng sau.'],
  [/429|rate limit/i, 'Gọi API quá nhanh. Chờ một lát rồi thử lại.'],
  [/Chua chon profile|Chưa có profile/i, 'Chưa có giọng OmniVoice. Vào Voice Lab tạo trước.'],
  [/ECONNREFUSED|Failed to fetch|NetworkError/i, 'Mất kết nối tới máy chủ. Kiểm tra phần mềm còn chạy không.'],
  [/timeout|timed out/i, 'Quá thời gian chờ. Mạng chậm hoặc dịch vụ đang bận.'],
];
function friendly(msg) {
  const s = String(msg || '');
  for (const [re, nice] of ERRORS) if (re.test(s)) return nice;
  return s.slice(0, 180);
}

function toast(text, kind = '') {
  const e = document.createElement('div');
  e.className = `toast ${kind}`; e.textContent = text;
  document.body.append(e);
  setTimeout(() => e.remove(), kind === 'err' ? 6000 : 3800);
}
async function act(fn, ok) {
  S.busy = true; paintBusy();
  try { const out = await fn(); if (ok) toast(ok, 'ok'); return out; }
  catch (e) { toast(friendly(e.message), 'err'); }
  finally { S.busy = false; paintBusy(); }
}
function paintBusy() { document.body.classList.toggle('busy', S.busy); }
function badge(sel, n) { const e = $(sel); if (!e) return; e.hidden = !n; e.textContent = n || ''; }
function copy(text, what = 'đường dẫn') {
  navigator.clipboard.writeText(text).then(() => toast(`Đã copy ${what}`, 'ok'))
    .catch(() => toast('Trình duyệt chặn copy', 'err'));
}
const skeleton = (rows = 3) => `<div class="skel">${'<div class="skel-row"></div>'.repeat(rows)}</div>`;
const empty = (icon, title, hint = '') =>
  `<div class="empty"><div class="big">${icon}</div><div><b>${esc(title)}</b></div>${hint ? `<div class="mut" style="margin-top:6px">${hint}</div>` : ''}</div>`;

/* ══════════ ROUTER ══════════ */
// render() chi VE. Khong bao gio goi API — neu goi, loader se goi lai render()
// va tao vong lap vo han khien moi nut chet.
function render() {
  const fn = { intake: pgIntake, board: pgBoard, episode: pgEpisode,
               library: pgLibrary, images: pgImages, aivideo: pgAiVideo, fbvideo: pgFbVideo, fbpost: pgFbPost, voices: pgVoices, voice: pgVoice, settings: pgSettings }[S.page] || pgIntake;
  $('#main').innerHTML = fn();
}
const loaders = { intake: loadIntake, voices: loadVoice, voice: loadVoice, board: loadOverview,
                  library: loadLibrary, images: loadImages, aivideo: loadAiVideo, fbvideo: loadFbVideo, fbpost: loadFbPost, settings: loadSettings };

// An/hien nav theo che do nang cao. Advanced OFF -> chi con fbvideo/fbpost/settings.
function applyNavConfig() {
  const adv = !!appConfig.advanced_mode;
  $$('.nav-item').forEach(el => {
    if (ADVANCED_PAGES.includes(el.dataset.page)) el.hidden = !adv;
  });
}

async function go(page, ep = null) {
  // Chan vao trang bi an (phim tat/deep-link) khi advanced OFF.
  if (!appConfig.advanced_mode && ADVANCED_PAGES.includes(page)) page = 'fbpost';
  S.page = page; S.ep = ep;
  $$('.nav-item').forEach(e => e.classList.toggle('on', e.dataset.page === page));
  render();
  if (loaders[page]) await act(loaders[page]);
}

async function loadOverview() {
  // KHONG cho /api/balance vao day. No spawn subprocess goi 2 API that (~4 giay).
  // Cho no -> ca trang treo o skeleton 4 giay. Da mac loi nay mot lan roi.
  const [ov, jobs] = await Promise.all([api('/overview'), api('/jobs')]);
  S.data = ov; S.jobs = jobs;
  $('#ch-name').textContent = ov.channel || '—';
  badge('#b-intake', ov.intake_pending);
  badge('#b-art', (ov.counts || {}).art);
  render();
  loadBalance();                 // chay nen, khong cho
}

// So du tai NEN. Trang van dung duoc khi chua co so du.
//
// Chi ve lai nhung trang CO hien so du (board, settings). Ve lai trang co o
// nhap (voice, episode) se xoa mat thu nguoi dung dang go.
function loadBalance() {
  api('/balance').then(b => {
    S.balance = b;
    paintQuota();
    if (['board', 'settings'].includes(S.page)) render();
  }).catch(() => {});
  loadSubQuota();
  loadAppVersion();
}
function loadSubQuota(refresh) {
  api('/fb-post/subscription' + (refresh ? '?refresh=true' : '')).then(s => {
    S.sub = s; paintQuota();
  }).catch(() => {});
}
function loadAppVersion() {
  api('/app/version').then(v => { S.appVer = v; if (S.page === 'settings') render(); }).catch(() => {});
}
/* Nút "Cập nhật & mở lại": ghi cờ restart → desktop.py tự cập nhật + mở lại app. */
async function doAppUpdate() {
  if (!confirm('Cập nhật lên bản mới nhất và KHỞI ĐỘNG LẠI phần mềm?\n\nApp sẽ tự tắt rồi mở lại (vài giây). Key + dữ liệu giữ nguyên.')) return;
  let r;
  try { r = await api('/app/restart', { method: 'POST' }); } catch (e) { return toast('Lỗi: ' + (e.message || e), 'err'); }
  if (!r || !r.will_restart) {
    return toast('Đang chạy bản DEV (python server.py) — tự mở lại chỉ có ở bản đóng gói .exe. Đóng & mở lại thủ công.', 'err');
  }
  const o = document.createElement('div'); o.id = 'restart-ov';
  o.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:#14110dee;color:#e8dcc6;text-align:center;flex-direction:column;gap:16px';
  o.innerHTML = '<div style="width:52px;height:52px;border:5px solid #3a3527;border-top-color:#d9a441;border-radius:50%;animation:rspin .9s linear infinite"></div>'
    + '<h2 style="margin:0">Đang cập nhật &amp; khởi động lại…</h2><p style="opacity:.7">App sẽ tự mở lại sau vài giây.</p>'
    + '<style>@keyframes rspin{to{transform:rotate(360deg)}}</style>';
  document.body.appendChild(o);
  setTimeout(pollBackAndReload, 5000);
}
async function pollBackAndReload() {
  try { const res = await fetch('/api/app/version', { cache: 'no-store' }); if (res.ok) { location.reload(); return; } } catch (e) {}
  setTimeout(pollBackAndReload, 2000);
}
async function loadIntake() {
  const [report] = await Promise.all([api('/intake'), loadOverview()]);
  intakeData = report;
  selIntake = new Set([...selIntake].filter(n => report.pending.some(p => p.name === n)));
  selDone = new Set([...selDone].filter(ep => (report.processed || []).some(x => x.episode === ep)));
  render();
}
async function loadVoice() {
  // Nap TOAN BO kho giong 1 lan (khong loc server) — Kho giong loc client-side tuc thi.
  const [pv, v, sm, pt] = await Promise.all([
    api('/voice-profiles'),
    api('/voice-lab/eleven-voices?limit=5000').catch(() => ({ voices: [] })),
    api('/voice-lab/samples').catch(() => ({ samples: [] })),
    api('/voice-lab/probe-text').catch(() => probeText),
  ]);
  profiles = pv.profiles || [];
  elevenVoices = v.voices || [];
  samples = sm.samples || [];
  probeText = pt;
  probeCost = pt.chars || 0;
  vcMeta = { total: v.total, matched: v.matched, measured: v.measured };
  await fetchRoster(true);       // roster = giong dang dung, khoi tao tick tu day
  deriveRoster();
  await loadOverview();
  updateLen();
}

/* ── Roster "giong dang dung": tick o Kho giong -> Luu -> hien moi noi ── */
let rosterSel = new Set();        // voice_id Eleven da tick (da stage, chua chac luu)
let rosterSaved = new Set();      // ban da LUU tren server — de biet co thay doi
let rosterProfiles = [];          // ref profile: da tick (co the doi o tab Kho giong)
let rosterProfSaved = [];         // ban da LUU — de biet Omni co thay doi khong
function deriveRoster() {
  const r = ROSTER || [];
  rosterSaved = new Set(r.filter(v => v.engine === 'eleven').map(v => v.id));
  rosterSel = new Set(rosterSaved);
  rosterProfiles = r.filter(v => v.engine === 'omnivoice').map(v => v.ref);
  rosterProfSaved = [...rosterProfiles];
}
function rosterDirty() {
  const profChanged = rosterProfiles.length !== rosterProfSaved.length
    || rosterProfiles.some(r => !rosterProfSaved.includes(r));
  return profChanged
    || rosterSel.size !== rosterSaved.size || [...rosterSel].some(id => !rosterSaved.has(id));
}
function toggleRoster(id, on) { on ? rosterSel.add(id) : rosterSel.delete(id); render(); }
// Tick giong OmniVoice (profile) vao/khoi roster — giu thu tu, khong trung.
function toggleRosterProfile(ref, on) {
  if (on) { if (!rosterProfiles.includes(ref)) rosterProfiles.push(ref); }
  else rosterProfiles = rosterProfiles.filter(r => r !== ref);
  render();
}
// "Chon tat ca" — tick/bo tich MOI giong DANG HIEN (theo bo loc tim/tram).
function toggleAllVisible(on) {
  voiceRows().forEach(r => {
    if (r.engine === 'eleven') { on ? rosterSel.add(r.id) : rosterSel.delete(r.id); }
    else {
      const ref = `profile:${r.id}`;
      if (on) { if (!rosterProfiles.includes(ref)) rosterProfiles.push(ref); }
      else rosterProfiles = rosterProfiles.filter(x => x !== ref);
    }
  });
  render();
}
function allVisibleSel() {
  const rows = voiceRows();
  return rows.length && rows.every(r => r.engine === 'eleven'
    ? rosterSel.has(r.id) : rosterProfiles.includes(`profile:${r.id}`));
}
async function saveRoster() {
  const refs = [...rosterSel].map(id => `eleven:${id}`).concat(rosterProfiles);
  const r = await act(() => api('/voices/roster', { method: 'POST', body: { refs } }),
    'Đã lưu giọng đang dùng — hiện ở mọi nơi chọn giọng');
  if (!r) return;
  ROSTER = r.voices || [];
  deriveRoster();
  render();
}
function resetRoster() { rosterSel = new Set(rosterSaved); rosterProfiles = [...rosterProfSaved]; render(); }

/* ══════════ QUOTA — canh bao TRUOC khi het tien ══════════ */
function paintQuota() {
  const b = S.balance, el = $('#quota');
  const sub = S.sub || {};
  const hasBal = b && b.ok;
  if (!el || (!hasBal && !sub.active)) { if (el) el.hidden = true; return; }
  el.hidden = false;
  // Gói thuê bao (Starter Video…): video + ảnh CÒN LẠI tháng này (0 credit trong quota).
  let subHtml = '';
  if (sub.active) {
    const vLow = sub.video_left <= 50, iLow = sub.image_left <= 50;
    subHtml = `
    <div class="q-item ${vLow ? 'low' : ''}" title="${esc(sub.plan_name || 'Gói')}: video CÒN LẠI tháng này (đã dùng ${fmt(sub.video_used)}/${fmt(sub.video_month)}). Làm trong quota = 0 credit.">
      <span class="ico">🎬</span><b>${fmt(sub.video_left)}</b>
      <span class="mut">/${fmt(sub.video_month)} video</span></div>
    <div class="q-item ${iLow ? 'low' : ''}" title="${esc(sub.plan_name || 'Gói')}: ảnh CÒN LẠI tháng này (đã dùng ${fmt(sub.image_used)}/${fmt(sub.image_month)}).">
      <span class="ico">🖼️</span><b>${fmt(sub.image_left)}</b>
      <span class="mut">/${fmt(sub.image_month)} ảnh</span></div>`;
  }
  let balHtml = '';
  if (hasBal) {
    const eps = b.credits_per_image ? Math.floor(b.credits / (b.credits_per_image * 5)) : 0;
    const epsChars = Math.floor(b.chars / 900);
    balHtml = `
    <div class="q-item ${b.low_credits ? 'low' : ''}" title="Credit 79ai (dự phòng ngoài gói). Mỗi tranh ~${fmt(b.credits_per_image)} credit.">
      <span class="ico">🎨</span><b>${fmt(b.credits)}</b>
      <span class="mut">~${eps} tập</span></div>
    <div class="q-item ${b.low_chars ? 'low' : ''}" title="Hạn mức ký tự ElevenLabs còn lại tháng này. Một tập ~900 ký tự.">
      <span class="ico">🔊</span><b>${fmt(b.chars)}</b>
      <span class="mut">~${epsChars} tập</span></div>`;
  }
  el.innerHTML = subHtml + balHtml +
    `<button class="btn ghost sm" onclick="refreshBalance()" title="Cập nhật số dư + quota gói">↻</button>`;
}
async function refreshBalance() {
  S.balance = await act(() => api('/balance?refresh=true'), 'Đã cập nhật số dư') || S.balance;
  loadSubQuota(true);
  paintQuota();
}

/* ══════════ THANH TIEN DO ══════════ */
function runningBar() {
  const j = S.jobs.current;
  if (!j) return '';
  return `<div class="running"><div class="spin"></div><div class="txt">
    <div class="t1">${j.step ? `<span class="step">${esc(j.step)}</span>` : ''}${esc(j.label)}</div>
    <div class="t2">${esc((j.lines || []).slice(-1)[0] || 'đang chạy…')}</div></div>
    <div class="el">${Math.round(j.elapsed || 0)}s</div></div>`;
}

/* ══════════ KICH BAN DAU VAO ══════════ */
function pgIntake() {
  if (!intakeData) return `<div class="head"><h1>Kịch bản đầu vào</h1></div>${skeleton(4)}`;

  const p = intakeData.pending || [], bad = intakeData.invalid || [], done = intakeData.processed || [];
  const dir = intakeData.intake_dir || '';
  const allSel = p.length && p.every(x => selIntake.has(x.name));
  const totalVideos = p.reduce((s, x) => s + (x.count || 1), 0);
  const ready = S.data.voice_ready;

  return `<div class="head">
    <h1>Kịch bản đầu vào</h1>
    <div class="right">
      <button class="btn" onclick="loadIntake()" title="Quét lại thư mục (R)">↻ Quét lại</button>
      <button class="btn" onclick="$('#file-in').click()" title="Chọn file JSON từ máy (U)">⬆ Tải file lên</button>
      <button class="btn primary" onclick="importIntake()" ${!totalVideos || !ready ? 'disabled' : ''}
        title="${!ready ? 'Chưa chọn giọng đọc' : !totalVideos ? 'Không có file hợp lệ trong intake/' : 'Nhập vào xưởng'}">
        ${totalVideos ? `Nhập ${totalVideos} video` : 'Nhập kịch bản'}</button>
    </div></div>
    <input type="file" id="file-in" accept=".json,application/json" multiple hidden onchange="uploadFiles(this.files)">
    ${runningBar()}
    ${!ready ? `<div class="warn">
      <b>Chưa sẵn sàng đọc lời.</b> ${S.data.engine === 'eleven'
        ? 'Chưa chọn giọng ElevenLabs.' : 'Chưa có profile OmniVoice.'}
      <button class="btn sm" style="margin-left:8px" onclick="go('voice')">Đi tới Voice Lab →</button>
    </div>` : ''}

    <div class="card" style="margin-bottom:14px">
      <h3>Thư mục kịch bản của kênh này</h3>
      <div class="copy">${esc(dir)}<button onclick="copy('${esc(dir).replace(/\\/g,'\\\\')}')">Copy</button></div>
      <div class="brief-hint">Thả file <b>.json</b> vào thư mục trên, hoặc kéo thả vào ô dưới.
        <b>Một file có thể chứa nhiều video.</b> Nhập <b>không tiêu credit</b> — credit chỉ tốn khi vẽ tranh.</div>
      <button class="btn sm" style="margin-top:10px" onclick="copyPrompt()"
        title="Copy prompt chuẩn để dán cho Claude viết kịch bản">📋 Copy prompt cho Claude</button>
    </div>

    <div id="drop" class="brief-box drop" ondragover="event.preventDefault();this.classList.add('drag')"
      ondragleave="this.classList.remove('drag')" ondrop="dropFiles(event,this)" onclick="$('#file-in').click()">
      <div class="brief-label">KÉO THẢ FILE JSON VÀO ĐÂY</div>
      <div class="mut">hoặc bấm để chọn từ máy</div>
    </div>

    ${selIntake.size ? `<div class="grid-bar">
      <span class="n">Đã chọn ${selIntake.size}</span><span class="sp"></span>
      <button class="btn sm danger" onclick="deleteIntake()">Xóa khỏi intake</button>
      <button class="btn sm ghost" onclick="selIntake.clear();render()">Bỏ chọn</button>
    </div>` : ''}

    <div class="card">
      <h3>Chờ nhập — ${p.length} file${totalVideos !== p.length ? ` · ${totalVideos} video` : ''}</h3>
      ${p.length ? `<table class="grid"><thead><tr>
        <th class="ck"><input type="checkbox" ${allSel ? 'checked' : ''} onclick="toggleAllIntake(this.checked)"></th>
        <th>Tên file</th><th>Nội dung</th><th style="width:90px">Video</th><th style="width:70px">Đoạn</th>
      </tr></thead><tbody>${p.map(x => {
        const n = x.count || 1;
        return `<tr class="${selIntake.has(x.name) ? 'sel' : ''}">
        <td class="ck"><input type="checkbox" ${selIntake.has(x.name) ? 'checked' : ''} onclick="toggleIntake('${esc(x.name)}',this.checked)"></td>
        <td><b>${esc(x.name)}</b></td>
        <td>${n > 1 ? (x.titles || []).map(t => `<div class="mut">· ${esc(t)}</div>`).join('') : esc(x.title || '—')}</td>
        <td>${n > 1 ? `<span class="tag art">${n} video</span>` : '1'}</td>
        <td>${x.beats}</td></tr>`; }).join('')}</tbody></table>`
      : empty('📄', 'Chưa có file nào chờ nhập', 'Kéo thả JSON vào ô trên, hoặc bấm Tải file lên.')}
    </div>

    ${bad.length ? `<details class="card bad-det" style="margin-top:14px">
      <summary><b class="red">Không hợp lệ — ${bad.length} file</b>
        <span class="mut" style="font-weight:400">· bấm để mở / thu gọn</span></summary>
      <div style="margin-top:10px">
        <div class="grid-bar" style="margin-bottom:8px">
          <span class="mut" style="font-size:12px">File lỗi không tạo tập. Sửa rồi <b>Quét lại</b>, hoặc xóa cho gọn.</span>
          <span class="sp"></span>
          <button class="btn sm danger" onclick="deleteBad()">Xóa hết ${bad.length} file lỗi</button>
        </div>
        <table class="grid"><thead><tr>
          <th style="width:200px">Tên file</th><th>Lỗi</th><th style="width:56px"></th>
        </tr></thead><tbody>${bad.map(x => `<tr>
          <td><b>${esc(x.name)}</b></td>
          <td class="red">${esc((x.errors || []).join(' · '))}</td>
          <td class="right"><button class="btn sm danger" onclick="deleteBad('${esc(x.name)}')" title="Xóa file lỗi này">✕</button></td>
        </tr>`).join('')}</tbody></table>
      </div>
    </details>` : ''}

    ${done.length ? `<div class="card" style="margin-top:14px">
      <h3>Đã nhập — ${done.length} gần nhất</h3>
      ${selDone.size ? `<div class="grid-bar">
        <span class="n">Đã chọn ${selDone.size}</span><span class="sp"></span>
        <button class="btn sm danger" onclick="deleteDone()">Xóa ${selDone.size} tập</button>
        <button class="btn sm ghost" onclick="selDone.clear();render()">Bỏ chọn</button>
      </div>` : ''}
      <table class="grid"><thead><tr>
        <th class="ck"><input type="checkbox" ${done.length && done.every(x => selDone.has(x.episode)) ? 'checked' : ''}
          onclick="toggleAllDone(this.checked)" title="Chọn tất cả"></th>
        <th style="width:80px">Tập</th><th>Tiêu đề</th><th style="width:180px">File gốc</th><th style="width:80px"></th>
      </tr></thead><tbody>${done.map(x => `<tr class="${selDone.has(x.episode) ? 'sel' : ''}">
        <td class="ck"><input type="checkbox" ${selDone.has(x.episode) ? 'checked' : ''}
          onclick="toggleDone('${esc(x.episode)}',this.checked)"></td>
        <td><b>${esc(x.episode)}</b></td><td>${esc(x.title || '—')}</td>
        <td class="mut">${esc(x.source_file)}</td>
        <td class="right"><button class="btn sm ghost" onclick="openEpisode('${esc(x.episode)}')">Mở</button></td>
      </tr>`).join('')}
      </tbody></table>
      <div class="brief-hint">File nhập xong <b>rời khỏi</b> <code>intake/</code> → chuyển sang <code>intake/processed/</code>.
        Tích dòng + <b>Xóa</b> để dọn lịch sử — <b class="red">xóa luôn tranh/giọng/video</b> của tập (tranh đã tốn credit sẽ mất).</div>
    </div>` : ''}`;
}

const CLAUDE_PROMPT = `Viết kịch bản video ngắn tiếng Việt. Xuất ra MỘT file JSON duy nhất. Không thêm chữ nào ngoài JSON.

MỘT file có thể chứa NHIỀU video — dùng mảng:

[
  {
    "title": "Tiêu đề video 1. Dưới 34 ký tự.",
    "pillar": "tam-ly-chua-lanh",
    "tone": "dong-cam",
    "beats": [
      {
        "caption": "Câu chữ hiện dưới tranh. Tiếng Việt, ngắn gọn.",
        "voice": "Lời đọc. Tiếng Việt, đầy đủ dấu câu.",
        "scene_prompt": "English only. What the person is doing, where, what lighting.",
        "image_idx": 1
      }
    ]
  }
]

Chỉ có 1 video thì xuất object đơn, không cần mảng.

QUY TẮC BẮT BUỘC:

1. caption và voice: TIẾNG VIỆT. Nói như người thật nói, không văn vẻ.

2. scene_prompt: TIẾNG ANH. Chỉ tả: nhân vật đang làm gì, ở đâu, ánh sáng thế nào.
   - KHÔNG tả màu sắc, phong cách vẽ (đã khóa trong config)
   - TUYỆT ĐỐI KHÔNG chứa: text, word, letter, sign, caption, writing, label, title
     (AI vẽ chữ tiếng Việt sẽ hỏng dấu — tool sẽ TỪ CHỐI file nếu thấy các từ này)
   - Bối cảnh đời thường Việt Nam
   - Nhân vật NHẤT QUÁN giữa các cảnh trong cùng một video

3. image_idx: số nguyên dương, đếm lại từ 1 cho MỖI video.
   Nhiều beat CÓ THỂ dùng chung một image_idx để tái sử dụng tranh.
   Mỗi tranh tốn ~600 credit — dùng chung để tiết kiệm.

NỘI DUNG:
[dán ý tưởng của bạn vào đây]`;

function copyPrompt() { copy(CLAUDE_PROMPT, 'prompt — dán vào Claude, thay phần NỘI DUNG'); }
function toggleIntake(n, on) { on ? selIntake.add(n) : selIntake.delete(n); render(); }
function toggleAllIntake(on) { selIntake = on ? new Set((intakeData.pending || []).map(x => x.name)) : new Set(); render(); }
// Lich su "Da nhap": chon + xoa tap de don luoi (xoa ca tranh/giong/video).
function toggleDone(ep, on) { on ? selDone.add(ep) : selDone.delete(ep); render(); }
function toggleAllDone(on) { selDone = on ? new Set((intakeData.processed || []).map(x => x.episode)) : new Set(); render(); }
async function deleteDone() {
  const eps = [...selDone];
  if (!eps.length) return;
  if (!confirm(`XÓA ${eps.length} tập khỏi lịch sử?\n\nToàn bộ tranh/giọng/video của tập sẽ MẤT.\nTranh đã tốn credit không lấy lại được.`)) return;
  const r = await act(() => api('/episodes/bulk/delete', { method: 'POST', body: { episodes: eps } }));
  if (!r) return;
  toast(`Đã xóa ${r.removed.length} tập`, 'ok');
  selDone.clear();
  intakeData = null; lib = null;      // lam moi ca luoi Muc luc video
  await act(loadIntake);
}

async function uploadFiles(files) {
  if (!files || !files.length) return;
  const fd = new FormData();
  [...files].forEach(f => fd.append('files', f));
  const r = await act(async () => {
    const res = await fetch('/api/intake/upload', { method: 'POST', body: fd });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  });
  if (!r) return;
  if (r.saved.length) toast(`Đã tải lên ${r.saved.length} file`, 'ok');
  r.rejected.forEach(x => toast(`${x.name}: ${x.error}`, 'err'));
  await act(loadIntake);
}
function dropFiles(ev, el) { ev.preventDefault(); el.classList.remove('drag'); uploadFiles(ev.dataTransfer.files); }
async function deleteIntake() {
  const names = [...selIntake];
  if (!confirm(`Xóa ${names.length} file khỏi intake/?`)) return;
  await act(() => api('/intake/delete', { method:'POST', body:{ names } }), `Đã xóa ${names.length} file`);
  selIntake.clear(); await act(loadIntake);
}
// Xoa file loi (1 file khi co ten, khong thi xoa het) — don khu "Khong hop le".
async function deleteBad(name) {
  const names = name ? [name] : (intakeData.invalid || []).map(x => x.name);
  if (!names.length) return;
  if (!confirm(`Xóa ${names.length} file lỗi khỏi intake/?`)) return;
  await act(() => api('/intake/delete', { method:'POST', body:{ names } }), `Đã xóa ${names.length} file`);
  await act(loadIntake);
}
async function importIntake() {
  await act(() => api('/intake/import', { method:'POST' }), 'Đã đưa vào hàng đợi nhập');
}

/* ══════════ XUONG SAN XUAT ══════════ */
const STAGE = { script:'Kịch bản', art_partial:'Đang vẽ', art:'Chờ duyệt tranh',
                video:'Có video', packed:'Sẵn sàng', published:'Đã đăng' };

function pgBoard() {
  const eps = S.data.episodes || [];
  const allSel = eps.length && eps.every(e => selEp.has(e.episode));
  const sel = [...selEp];
  const pick = id => eps.find(e => e.episode === id);
  const canArt = sel.filter(id => ['script','art_partial'].includes(pick(id)?.stage));
  const canFin = sel.filter(id => pick(id)?.stage === 'art');
  const perImg = S.balance.credits_per_image || 600;
  const artCredits = canArt.reduce((s, id) => {
    const e = pick(id); return s + Math.max(0, e.images_needed - e.scenes_done) * perImg;
  }, 0);
  const finChars = S.data.engine === 'eleven'
    ? canFin.reduce((s, id) => s + (pick(id)?.chars || 0), 0) : 0;

  return `<div class="head"><h1>Xưởng sản xuất</h1>
    <span class="sub">${eps.length} tập · giọng <b>${S.data.engine === 'eleven' ? 'ElevenLabs' : 'OmniVoice'}</b></span>
    <div class="right"><button class="btn" onclick="loadOverview()" title="Làm mới (R)">↻ Làm mới</button></div></div>
    ${runningBar()}

    ${sel.length ? `<div class="grid-bar">
      <span class="n">Đã chọn ${sel.length}</span><span class="sp"></span>
      ${canArt.length ? `<button class="btn sm primary" onclick="bulkArt()"
        title="Tiêu ~${fmt(artCredits)} credit">Vẽ tranh (${canArt.length}) · ~${fmt(artCredits)} cr</button>` : ''}
      ${canFin.length ? `<button class="btn sm primary" onclick="bulkFinish()"
        title="${finChars ? `Tiêu ~${fmt(finChars)} ký tự ElevenLabs` : 'OmniVoice — miễn phí'}">
        Hoàn tất (${canFin.length})${finChars ? ` · ~${fmt(finChars)} kt` : ''}</button>` : ''}
      <button class="btn sm danger" onclick="bulkDelete()">Xóa (${sel.length})</button>
      <button class="btn sm ghost" onclick="selEp.clear();render()">Bỏ chọn</button>
    </div>` : ''}

    <div class="card">${eps.length ? `<table class="grid"><thead><tr>
      <th class="ck"><input type="checkbox" ${allSel ? 'checked' : ''} onclick="toggleAllEp(this.checked)"></th>
      <th style="width:74px">Tập</th><th>Tiêu đề</th>
      <th style="width:130px">Chặng</th><th style="width:110px">Tranh</th>
      <th style="width:110px">Giọng</th><th style="width:160px"></th>
    </tr></thead><tbody>${eps.map(e => {
      const pct = e.images_needed ? Math.round(e.scenes_done / e.images_needed * 100) : 0;
      return `<tr class="${selEp.has(e.episode) ? 'sel' : ''}">
      <td class="ck"><input type="checkbox" ${selEp.has(e.episode) ? 'checked' : ''} onclick="toggleEp('${esc(e.episode)}',this.checked)"></td>
      <td><b>${esc(e.episode)}</b></td>
      <td class="click" onclick="openEpisode('${esc(e.episode)}')">${esc(e.title)}</td>
      <td><span class="tag ${e.stage}">${STAGE[e.stage] || e.stage}</span></td>
      <td>${e.scenes_done}/${e.images_needed}
        <div class="bar"><i class="${pct >= 100 ? 'ok' : ''}" style="width:${pct}%"></i></div></td>
      <td><button class="voicecell" onclick="pickVoice('${esc(e.episode)}')"
          title="Bấm để CHỌN GIỌNG cho tập này (trước khi sản xuất)">
        ${e.has_voice
          ? `<span class="tag ${e.voice_engine === 'eleven' ? 'video' : 'script'}">${e.voice_engine === 'eleven' ? 'Eleven' : 'Omni'}</span>`
          : `<span class="tag plan ${e.planned_engine === 'eleven' ? 'video' : 'script'}">${e.planned_engine === 'eleven' ? 'Eleven' : 'Omni'}</span>`}
        ${e.voice_pick ? '<span class="pick-dot" title="Đã chọn giọng riêng cho tập này">●</span>' : ''}
        ${e.voice_label ? `<span class="vlab" title="Giọng sẽ đọc tập này">${esc(e.voice_label)}</span>` : ''}
        <span class="ed">✎</span>
      </button></td>
      <td class="right">
        ${['script','art_partial'].includes(e.stage) ? `<button class="btn sm" onclick="drawArt('${esc(e.episode)}')">Vẽ</button>` : ''}
        ${e.stage === 'art' ? `<button class="btn sm primary" onclick="finish('${esc(e.episode)}')">Hoàn tất</button>` : ''}
        <button class="btn sm ghost" onclick="openEpisode('${esc(e.episode)}')">Mở</button>
      </td></tr>`; }).join('')}</tbody></table>`
    : empty('🎬', 'Chưa có tập nào', 'Nhập kịch bản ở tab "Kịch bản đầu vào" trước.')}</div>`;
}
function toggleEp(id, on) { on ? selEp.add(id) : selEp.delete(id); render(); }
function toggleAllEp(on) { selEp = on ? new Set((S.data.episodes || []).map(e => e.episode)) : new Set(); render(); }

async function bulkArt() {
  const eps = [...selEp].filter(id => ['script','art_partial'].includes(
    (S.data.episodes || []).find(e => e.episode === id)?.stage));
  const r = await act(() => api('/episodes/bulk/art', { method:'POST', body:{ episodes: eps } }));
  if (!r) return;
  if (!confirm(`Vẽ ${r.images} tranh cho ${eps.length} tập?\n\nTIÊU ~${fmt(r.credits)} CREDIT THẬT.\nCòn lại: ${fmt(S.balance.credits)} credit.`)) {
    return toast('Đã hủy — nhưng việc đã vào hàng đợi. Vào panel Hàng đợi để hủy.', 'err');
  }
  toast(`Đã xếp ${r.queued} tập vào hàng đợi vẽ`, 'ok');
  selEp.clear(); await act(loadOverview);
}
function bulkFinish() {
  const eps = [...selEp].filter(id => (S.data.episodes || []).find(e => e.episode === id)?.stage === 'art');
  if (!eps.length) return toast('Chưa chọn tập nào ở chặng "Sẵn sàng".', 'err');
  produceModal(eps, 'finish');
}
async function bulkDelete() {
  const eps = [...selEp];
  if (!confirm(`XÓA ${eps.length} tập và toàn bộ tranh/giọng/video?\n\nTranh đã tốn credit sẽ MẤT.`)) return;
  const r = await act(() => api('/episodes/bulk/delete', { method:'POST', body:{ episodes: eps } }));
  if (!r) return;
  toast(`Đã xóa ${r.removed.length} tập`, 'ok');
  selEp.clear();
  // Xoa tap -> lưới "Đã nhập" ben tab Kịch bản cung phai bo dong do.
  // Khong lam moi thi quay lai tab kia van thay tap ma khong mo duoc.
  intakeData = null;
  lib = null;
  await act(loadOverview);
}

/* ══════════ CHI TIET TAP ══════════ */
async function openEpisode(ep) {
  S.page = 'episode'; S.ep = null; $$('.nav-item').forEach(e => e.classList.remove('on'));
  render();
  const data = await act(() => api(`/episodes/${ep}`));
  if (data) { S.ep = data; render(); } else { go('board'); }
}
function pgEpisode() {
  const e = S.ep;
  if (!e) return `<div class="head"><button class="btn ghost" onclick="go('board')">← Xưởng</button></div>${skeleton(3)}`;

  const est = e.timing && e.timing.timing_source === 'whisper_estimated';
  const eng = e.voice_engine === 'eleven' ? 'ElevenLabs' : e.voice_engine === 'omnivoice' ? 'OmniVoice' : null;
  const toDraw = Math.max(0, e.images_needed - e.scenes_done);
  const cr = toDraw * (S.balance.credits_per_image || 600);

  return `<div class="head">
    <button class="btn ghost" onclick="go('board')">← Xưởng</button>
    <div><h1>${esc(e.title)}</h1>
      <div class="sub">${esc(e.episode)} · <span class="tag ${e.stage}">${STAGE[e.stage] || e.stage}</span>
      · ${e.chars} ký tự${eng ? ` · đọc bằng <b>${eng}</b>` : ''}</div></div>
    <div class="right">
      ${['script','art_partial'].includes(e.stage) ? `<button class="btn primary" onclick="drawArt('${esc(e.episode)}')"
        title="Tiêu ~${fmt(cr)} credit">Vẽ ${toDraw} tranh · ~${fmt(cr)} cr</button>` : ''}
      ${e.stage === 'art' ? `<button class="btn primary" onclick="finish('${esc(e.episode)}')">Duyệt &amp; hoàn tất</button>` : ''}
      ${e.has_voice ? `<button class="btn" onclick="renarrateModal('${esc(e.episode)}')">Đọc lại…</button>` : ''}
    </div></div>
    ${runningBar()}
    ${est ? '<div class="warn">Mốc thời gian do Whisper <b>ước lượng</b> — có thể lệch vài phần mười giây.</div>' : ''}
    <div class="det"><div>
      ${e.has_video ? `<video controls src="/media/video/${esc(e.episode)}"></video>
        <div class="row" style="margin-top:10px">
          <a class="btn" href="/media/video/${esc(e.episode)}" download="${esc(e.episode)}.mp4">⬇ Tải MP4</a>
          <a class="btn" href="/media/srt/${esc(e.episode)}" download="${esc(e.episode)}.srt">⬇ Tải phụ đề</a>
        </div>` : ''}
      ${e.has_voice ? `<div class="card" style="margin-top:14px"><h3>Giọng đọc${eng ? ` — ${eng}` : ''}</h3>
        <audio id="ep-audio" controls src="/media/audio/${esc(e.episode)}"></audio>
        <div class="mut" style="margin-top:6px">
          ${e.duration ? `${e.duration.toFixed(1)}s · ${(e.chars / e.duration).toFixed(1)} ký tự/giây` : ''}
          <span style="margin-left:8px">Phím <b>Space</b> để phát/dừng</span></div></div>` : ''}
      <div class="card" style="margin-top:14px"><h3>Cảnh — ${e.beats_detail.length} đoạn / ${e.images_needed} tranh</h3>
      <div class="scenes">${e.beats_detail.map(b => `<div class="scene"><div class="wrap">
        <span class="num">tranh ${b.image_idx}</span>
        ${b.has_image ? `<img loading="lazy" src="/media/scene/${esc(e.episode)}/${b.image_idx}?t=${Date.now()}">`
          : '<div class="no-img">chưa vẽ</div>'}</div>
        <div class="body"><div class="cap">${b.index}. ${esc(b.caption)}</div>
        <div class="mut" style="font-size:11.5px;margin-bottom:7px">${esc(b.voice)}</div>
        <textarea onchange="savePrompt('${esc(e.episode)}',${b.index},this.value)"
          title="Mô tả cảnh (tiếng Anh). Sửa rồi bấm Vẽ lại.">${esc(b.scene_prompt)}</textarea>
        <div class="acts"><button class="btn sm" onclick="redraw('${esc(e.episode)}',${b.image_idx})">Vẽ lại · ~600 cr</button></div>
      </div></div>`).join('')}</div></div>
    </div>
    <div><div class="card"><h3>Mốc thời gian</h3>
      ${e.beats_detail.some(b => b.start != null) ? `<div class="timeline">
        ${e.beats_detail.map(b => `<div class="tl-row" onclick="seekTo(${b.start})" title="Bấm để nghe từ đây">
        <span class="t">${b.start != null ? b.start.toFixed(1) + 's' : '—'}</span>
        <span>${esc(b.caption)}</span></div>`).join('')}</div>`
      : '<p class="mut">Chưa có giọng đọc.</p>'}
    </div></div></div>`;
}
function seekTo(s) { const a = $('#ep-audio'); if (a) { a.currentTime = s; a.play(); } }

async function drawArt(ep) {
  const c = await act(() => api(`/episodes/${ep}/cost`));
  if (!c) return;
  if (!confirm(`Vẽ ${c.images_total - c.images_done} tranh cho ${ep}?\n\nTIÊU ~${fmt(c.credits_to_draw)} CREDIT THẬT.\nCòn lại: ${fmt(S.balance.credits)} credit.`)) return;
  await act(() => api(`/episodes/${ep}/art`, { method:'POST' }), 'Đã xếp vẽ tranh');
  await act(loadOverview);
}
function finish(ep) { produceModal([ep], 'finish'); }
function renarrateModal(ep) { produceModal([ep], 'narrate'); }
function pickVoice(ep) { produceModal([ep], 'set'); }   // chon giong truoc, tren luoi

// Hop chon giong khi san xuat / doc lai. Thay confirm()/prompt() tho so.
// Backend (finish + bulk/finish + narrate) da nhan { engine, profile_id } —
// day chi la lo ra cho nguoi dung chon, va bao ro se doc giong nao.
let ROSTER = null;   // roster giong dang dung (CA 2 engine) — tu /voices/roster
async function fetchRoster(force) {
  if (ROSTER !== null && !force) return ROSTER;
  try { const r = await api('/voices/roster'); ROSTER = r.voices || []; }
  catch { ROSTER = []; }
  return ROSTER;
}
function produceModal(eps, mode) {
  // Nap lai roster moi lan mo: tick giong o Kho giong xong quay lai phai thay ngay.
  ROSTER = null;
  const d = S.data || {};
  const rows = d.episodes || [];
  const first = rows.find(e => e.episode === eps[0]);
  const pk = (first && first.voice_pick) || {};   // lua chon rieng da luu cua tap
  // ref dang chon: lua chon rieng -> snapshot tap -> '' (giong mac dinh kenh)
  let selRef = pk.profile_id ? `profile:${pk.profile_id}`
    : pk.eleven_voice ? `eleven:${pk.eleven_voice}`
    : (first && first.voice_profile_id) ? `profile:${first.voice_profile_id}`
    : (first && first.eleven_voice_id) ? `eleven:${first.eleven_voice_id}`
    : '';
  // Tab engine trong modal (2 tab như cũ): theo giọng đang chọn, không thì engine kênh.
  let pmTab = selRef.startsWith('eleven:') ? 'eleven'
    : selRef.startsWith('profile:') ? 'omni'
    : (d.engine === 'eleven' ? 'eleven' : 'omni');

  const curVoice = () => (ROSTER || []).find(v => v.ref === selRef);
  // Engine theo giong dang chon; 'giong mac dinh kenh' thi theo engine kenh.
  const isEleven = () => { const v = curVoice(); return v ? v.engine === 'eleven' : d.engine === 'eleven'; };
  const chars = () => isEleven()
    ? eps.reduce((s, id) => s + (rows.find(e => e.episode === id)?.chars || 0), 0) : 0;

  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  const close = () => { bg.remove(); if (window.__pm === pm) delete window.__pm; };

  function draw() {
    const isE = isEleven();
    const c = chars();
    const engLabel = d.engine === 'eleven' ? 'ElevenLabs' : 'OmniVoice';
    const title = mode === 'set' ? `Chọn giọng cho ${eps[0]}`
      : mode === 'narrate' ? `Đọc lại ${eps[0]}`
      : (eps.length > 1 ? `Sản xuất ${eps.length} tập` : `Sản xuất ${eps[0]}`);
    bg.innerHTML = `<div class="modal">
      <h3>${title} — chọn giọng đọc</h3>
      ${ROSTER === null
        ? '<div class="sel mut">Đang tải danh sách giọng…</div>'
        : (() => {
            const eleven = ROSTER.filter(v => v.engine === 'eleven');
            const omni = ROSTER.filter(v => v.engine === 'omnivoice');
            const list = pmTab === 'eleven' ? eleven : omni;
            return `<div class="tabs">
              <button class="tab ${pmTab === 'omni' ? 'on' : ''}" onclick="__pm.tab('omni')">OmniVoice <span class="mut">miễn phí (${omni.length})</span></button>
              <button class="tab ${pmTab === 'eleven' ? 'on' : ''}" onclick="__pm.tab('eleven')">ElevenLabs <span class="mut">tốn ký tự (${eleven.length})</span></button>
            </div>
            <div class="field"><label>Chọn giọng — chỉ hiện giọng đã tick ở Kho giọng</label>
              ${list.length
                ? `<select class="sel" onchange="__pm.pick(this.value)">
                    <option value="" ${selRef === '' ? 'selected' : ''}>— dùng giọng mặc định kênh (${engLabel}) —</option>
                    ${list.map(v => `<option value="${esc(v.ref)}" ${v.ref === selRef ? 'selected' : ''}>${esc(v.name)}${v.pitch_hz ? ` · ${Math.round(v.pitch_hz)} Hz` : ''}</option>`).join('')}
                  </select>`
                : `<div class="warn">Chưa tick giọng ${pmTab === 'eleven' ? 'ElevenLabs' : 'OmniVoice'} nào. Vào <b>Kho giọng</b> tick + 💾 Lưu.</div>`}
            </div>`;
          })()}
      ${mode === 'set'
        ? `<div class="info">Chọn xong bấm <b>Lưu</b>. Giọng này áp dụng khi sản xuất tập — chọn trước, khỏi lo ra nhầm giọng.</div>`
        : `<div class="${isE ? 'warn' : 'info'}">${isE
            ? `Tiêu ~<b>${fmt(c)}</b> ký tự ElevenLabs · còn ${fmt((S.balance || {}).chars || 0)}`
            : 'Miễn phí — nhưng chậm.'}</div>`}
      <div class="acts">
        ${mode === 'set' && first && first.voice_pick
          ? '<button class="btn ghost" onclick="__pm.clear()" title="Xóa lựa chọn riêng, quay về giọng kênh">Về giọng kênh</button>' : ''}
        <button class="btn ghost" onclick="__pm.close()">Hủy</button>
        <button class="btn primary" onclick="__pm.go()">${mode === 'set' ? 'Lưu giọng' : mode === 'narrate' ? 'Đọc lại' : 'Sản xuất'}</button>
      </div></div>`;
  }

  async function loadRoster() {
    await fetchRoster(true);
    if (document.body.contains(bg)) draw();     // chi ve lai neu hop con mo
  }

  const pm = {
    pick(ref) { selRef = ref; draw(); },
    tab(t) {                       // doi tab engine; giong dang chon khac engine -> bo chon
      pmTab = t;
      const selEng = selRef.startsWith('eleven:') ? 'eleven' : selRef.startsWith('profile:') ? 'omni' : '';
      if (selEng && selEng !== t) selRef = '';
      draw();
    },
    close,
    async clear() {          // set mode: bo lua chon rieng -> ve giong kenh
      close();
      await act(() => api(`/episodes/${eps[0]}/voice`, { method: 'PATCH', body: {} }),
        'Đã về giọng kênh');
      await act(loadOverview);
    },
    async go() {
      const v = curVoice();
      const body = {};
      if (!selRef) body.engine = d.engine;      // giong mac dinh kenh
      else if (v) {
        body.engine = v.engine;
        if (v.engine === 'omnivoice') body.profile_id = v.id;
        else body.eleven_voice = v.id;
      }
      const eLabel = body.engine === 'eleven' ? 'ElevenLabs' : 'OmniVoice';
      close();
      if (mode === 'set') {           // chi LUU lua chon, khong san xuat
        await act(() => api(`/episodes/${eps[0]}/voice`, { method: 'PATCH', body: selRef ? body : {} }),
          selRef ? `Đã chọn ${v ? v.name : eLabel} cho ${eps[0]}` : 'Đã về giọng kênh');
        await act(loadOverview);
        return;
      }
      if (mode === 'narrate') {
        await act(() => api(`/episodes/${eps[0]}/narrate`, { method: 'POST', body }),
          `Đã xếp đọc lại bằng ${eLabel}`);
        return;
      }
      const single = eps.length === 1;
      const url = single ? `/episodes/${eps[0]}/finish` : '/episodes/bulk/finish';
      const payload = single ? body : { episodes: eps, ...body };
      const r = await act(() => api(url, { method: 'POST', body: payload }), 'Đã xếp sản xuất');
      if (r) { selEp.clear(); await act(loadOverview); }
    },
  };
  window.__pm = pm;
  bg.onclick = (e) => { if (e.target === bg) close(); };
  draw();
  document.body.appendChild(bg);
  loadRoster();
}
async function redraw(ep, idx) {
  if (!confirm(`Vẽ lại tranh ${idx}?\n\nTIÊU ~600 CREDIT.`)) return;
  await act(() => api(`/episodes/${ep}/scenes/${idx}/redraw`, { method:'POST', body:{} }), 'Đã xếp vẽ lại');
}
async function savePrompt(ep, index, scene_prompt) {
  await act(() => api(`/episodes/${ep}/prompt`, { method:'PATCH', body:{ index, scene_prompt } }), 'Đã lưu prompt');
}

/* ══════════ VOICE LAB ══════════ */
// KHONG co doan mau mac dinh. Nguoi dung tu nhap — chu cua ho, giong cua ho.
const MIN_SAMPLE = 150;

function updateLen() {
  const el = $('#vl-text'), box = $('#vl-len');
  if (!el || !box) return;
  const n = el.value.trim().length;
  box.innerHTML = n
    ? `<span class="${n >= MIN_SAMPLE ? 'gold' : 'red'}">${n} ký tự</span>
       · tối thiểu ${MIN_SAMPLE} · ước ${Math.round(n / 14)}s`
    : '<span class="red">chưa nhập đoạn mẫu</span>';
}

// ── Tab "Kho giọng": MOT luoi phang, TAT CA giong ca 2 engine ──
// Tick -> roster (selected_voices.json) = cong DUY NHAT, lan sang moi noi chon giong
// (modal san xuat, Voice Lab clone). Ten sua TAI CHO: Eleven->alias, Omni->rename.
let vcEngine = 'all';   // chip loc engine: all | eleven | omni

// Gop Omni + Eleven thanh 1 mang, loc CLIENT-side (tuc thi), sap tram truoc.
function voiceRows() {
  const q = (vcFilter.q || '').trim().toLowerCase();
  const omni = S.data.omnivoice_installed === false ? [] : profiles.map(p => {
    const a = p.audio || {};
    return { engine: 'omni', id: p.id, name: p.name || p.id, hz: a.pitch_hz || 0,
      label: a.pitch_label || '', active: !!p.active, sub: `${p.id}${a.seconds ? ` · ${a.seconds}s` : ''}`,
      saved: rosterProfSaved.includes(`profile:${p.id}`), on: rosterProfiles.includes(`profile:${p.id}`) };
  });
  const el = elevenVoices.map(v => ({
    engine: 'eleven', id: v.id, name: v.name, hz: v.pitch_hz || 0, label: v.pitch_label || '',
    active: v.id === S.data.eleven_voice_id, stale: v.stale, saved: rosterSaved.has(v.id),
    sub: [v.users ? `${fmt(v.users)} người` : '', v.source === 'mine' ? 'thư viện' : ''].filter(Boolean).join(' · '),
    on: rosterSel.has(v.id) }));
  let rows = vcEngine === 'eleven' ? el : vcEngine === 'omni' ? omni : [...omni, ...el];
  if (q) rows = rows.filter(r => (r.name || '').toLowerCase().includes(q));
  if (vcFilter.measured_only) rows = rows.filter(r => r.hz);
  if (vcFilter.deep_only) rows = rows.filter(r => r.hz && r.hz < 130);
  rows.sort((a, b) => (a.hz || 9999) - (b.hz || 9999));
  return rows;
}

function pgVoices() {
  const eng = S.data.engine || 'eleven';
  const noKey = !S.data.eleven_key;
  const rows = voiceRows();
  const nUse = rosterSel.size + rosterProfiles.length;
  return `<div class="head"><h1>Kho giọng</h1>
    <span class="sub">một lưới — tất cả giọng cả 2 engine · <b>tick</b> để dùng · bấm tên để sửa</span>
    <div class="right"><button class="btn" onclick="loadVoice()">↻ Làm mới</button></div></div>
    ${runningBar()}
    ${noKey ? '<div class="warn"><b>Thiếu ELEVENLABS_API_KEY.</b> Nạp key rồi khởi động lại — vẫn dùng được giọng OmniVoice.</div>' : ''}

    <div class="kgbar">
      <label class="pick" title="Tích tất cả giọng đang hiện vào 'Giọng đang dùng'"><input type="checkbox" ${allVisibleSel() ? 'checked' : ''}
        onchange="toggleAllVisible(this.checked)"> Chọn tất cả</label>
      <label class="pick" title="Chỉ hiện giọng ĐÃ ĐO cao độ (bấm ▶ nghe lại)"><input type="checkbox" ${vcFilter.measured_only ? 'checked' : ''}
        onchange="vcFilter.measured_only=this.checked;render()"> Chỉ giọng đã đo</label>
      <label class="pick" title="Chỉ hiện giọng đã đo dưới 130 Hz"><input type="checkbox" ${vcFilter.deep_only ? 'checked' : ''}
        onchange="vcFilter.deep_only=this.checked;render()"> Chỉ giọng trầm</label>
      <div class="kg-searchbox">
        <input class="kg-search" type="text" placeholder="Tìm tên giọng…" value="${esc(vcFilter.q)}"
          oninput="vcFilter.q=this.value;applyVoiceFilter()"
          onkeydown="if(event.key==='Enter'){event.preventDefault();render();}">
        ${vcFilter.q ? `<button class="btn sm ghost" onclick="vcFilter.q='';render()" title="Xóa tìm">✕</button>` : ''}
        <button class="btn sm" onclick="render()" title="Lọc theo tên (hoặc gõ rồi Enter)">Tìm</button>
      </div>
    </div>

    <div class="kgbar2">
      <span class="n">Đang dùng: <b>${nUse}</b> giọng <span class="mut">(${rosterSel.size} Eleven · ${rosterProfiles.length} Omni)</span></span>
      <span class="sp"></span>
      ${vcUnmeasured() ? `<button class="btn sm ghost" onclick="probeSelected()"
        title="Đo cao độ cho giọng đã tích mà chưa đo">Đo ${vcUnmeasured()} giọng · ~${fmt(vcUnmeasured() * probeCost)} kt</button>` : ''}
      ${rosterDirty() ? `<button class="btn sm primary" onclick="saveRoster()">💾 Lưu</button>
        <button class="btn sm ghost" onclick="resetRoster()">Bỏ thay đổi</button>`
        : '<span class="mut" style="font-size:12px">đã lưu — hiện ở modal sản xuất + Voice Lab</span>'}
    </div>

    <details class="probe-det"${probeText.text ? '' : ' open'}>
      <summary>Đoạn nghe thử — dùng để đo giọng &amp; làm mẫu nhân bản · ${probeText.chars || 0} ký tự</summary>
      <div class="probe-box ${probeText.text ? '' : 'empty'}" style="margin-top:8px">
        <textarea id="pt" rows="3" placeholder="Dán một đoạn văn của bạn. Mọi giọng đọc chính đoạn này để so sánh."
          oninput="probeTyping(this.value)" onblur="saveProbeText(this.value)">${esc(probeText.text || '')}</textarea>
        <div class="probe-foot">
          <span id="pt-len" class="${probeText.usable_as_reference ? 'gold' : probeText.chars ? '' : 'red'}">${probeText.chars || 0} ký tự</span>
          <span class="mut">·</span>
          <span class="mut">${probeText.usable_as_reference ? '<b class="gold">đủ dài</b> — dùng luôn làm mẫu nhân bản' : `từ <b>${probeText.min_chars || 150}</b> ký tự thì dùng được làm mẫu`}</span>
          <span class="sp"></span><span id="pt-save" class="mut"></span>
        </div>
      </div>
    </details>

    ${!rows.length
      ? empty('🎙', 'Không có giọng khớp', vcFilter.q ? 'Đổi từ khoá tìm.' : 'Đo giọng hoặc đổi bộ lọc.')
      : `<table class="vtbl kgtbl"><thead><tr>
          <th class="c-tick">Dùng</th><th class="c-hz">Cao độ</th><th>Tên giọng <span class="mut" style="font-weight:400">(bấm để sửa)</span></th>
          <th class="c-cls">Phân loại</th><th class="c-act2">Thao tác</th>
        </tr></thead><tbody id="kg-tbody">${rows.map(voiceRowHtml).join('')}</tbody></table>
        <div class="mut" style="margin-top:8px;font-size:11.5px">
          ${rows.length} giọng · <b>tick</b> + 💾 Lưu để đưa vào "Giọng đang dùng" · bấm <b>tên</b> để sửa (rời ô tự lưu, lan mọi nơi) ·
          nút đo tốn <b>~${probeCost} ký tự</b>.</div>`}`;
}

// Ve lai RIENG tbody khi go tim — de o tim khong mat focus (render() ca trang lam mat).
function applyVoiceFilter() {
  const tb = document.getElementById('kg-tbody');
  if (tb) tb.innerHTML = voiceRows().map(voiceRowHtml).join('');
}

function voiceRowHtml(r) {
  const tone = !r.hz ? '' : r.hz < 100 ? 'deep2' : r.hz < 130 ? 'deep' : r.hz < 165 ? 'mid' : 'high';
  const isEl = r.engine === 'eleven';
  const eng = `<span class="engtag ${isEl ? 'el' : 'om'}">${isEl ? 'Eleven' : 'Omni'}</span>`;
  // Nut LUON HIEN, nam ngang. Xoa TACH RO nghia: Eleven "Bỏ đo" (chi xoa ban do,
  // KHONG xoa giong cong khai) · Omni "Xóa" (xoa han profile).
  const acts = isEl
    ? (r.hz ? `<button class="pbtn" onclick="playProbe('${esc(r.id)}',this)" title="Nghe thử">▶</button>
        <button class="btn sm ghost" onclick="probeVoice('${esc(r.id)}',true)" title="Đọc lại — ~${probeCost} ký tự">↻ Đo lại</button>
        <button class="btn sm ghost" onclick="pickEleven('${esc(r.id)}')" title="Đặt làm giọng mặc định kênh">Đặt kênh</button>
        <button class="btn sm ghost red" onclick="forgetVoice('${esc(r.id)}')" title="Xóa bản đo (KHÔNG xóa giọng)">Bỏ đo</button>`
      : `<button class="btn sm primary" onclick="probeVoice('${esc(r.id)}')" title="~${probeCost} ký tự · bản đo dùng làm mẫu nhân bản">Đo &amp; nghe</button>`)
    : `<button class="pbtn" onclick="playUrl('/media/voice-profiles/${esc(r.id)}/preview',this)" title="Nghe giọng đã nhân bản">▶</button>
        ${r.active ? '' : `<button class="btn sm ghost" onclick="activateProfile('${esc(r.id)}')" title="Đặt làm giọng mặc định kênh">Đặt kênh</button>`}
        <button class="btn sm ghost red" onclick="deleteProfile('${esc(r.id)}')" title="Xóa hẳn giọng clone này">Xóa</button>`;
  const toggle = isEl
    ? `onclick="toggleRoster('${esc(r.id)}',this.checked)"`
    : `onclick="toggleRosterProfile('profile:${esc(r.id)}',this.checked)"`;
  return `<tr class="vrow ${r.on ? 'on' : ''}">
    <td class="c-tick"><input type="checkbox" ${r.on ? 'checked' : ''} ${toggle} title="Tích = đưa vào 'Giọng đang dùng'"></td>
    <td class="c-hz"><span class="vhz2 ${tone}">${r.hz ? `<b>${hzText(r.hz)}</b><small>Hz</small>` : '<span class="q">?</span>'}</span></td>
    <td class="c-name">
      <input class="vn-edit" value="${esc(r.name)}" onchange="renameRowName('${r.engine}','${esc(r.id)}',this.value)"
        title="Sửa tên — rời ô tự lưu, lan tỏa mọi nơi">
      <div class="vnrow">${eng}
        ${r.active ? '<span class="tag published">giọng kênh</span>' : ''}
        ${r.saved ? '<span class="tag script" title="Đang trong Giọng đang dùng">✓ dùng</span>' : ''}
        ${r.stale ? '<span class="tag rejected" title="Bản đo đọc đoạn CŨ">đoạn cũ</span>' : ''}
        ${r.sub ? `<span class="vsub">${esc(r.sub)}</span>` : ''}</div>
    </td>
    <td class="c-cls">${r.hz ? `<span class="cls ${tone}">${esc(r.label || '')}</span>` : '<span class="mut">chưa đo</span>'}</td>
    <td class="c-act2"><div class="vacts2">${acts}</div></td>
  </tr>`;
}

// Doi ten TAI CHO (inline). Eleven -> alias (voice_catalog); Omni -> rename profile.
async function renameRowName(engine, id, val) {
  const name = (val || '').trim();
  const cur = engine === 'eleven'
    ? (elevenVoices.find(v => v.id === id) || {}).name
    : (profiles.find(p => p.id === id) || {}).name;
  if (name === (cur || '')) return;                       // khong doi gi -> bo qua
  if (engine === 'omni' && !name) { toast('Tên không được để trống', 'err'); return render(); }
  const r = engine === 'eleven'
    ? await act(() => api('/voice-catalog/rename', { method: 'POST', body: { voice_id: id, name } }), 'Đã đổi tên')
    : await act(() => api(`/voice-profiles/${id}/rename`, { method: 'POST', body: { name } }), 'Đã đổi tên');
  if (r) await act(loadVoice);
}

// Voice Lab = CHI lo tao/nhan ban giong OmniVoice + nghe thu. Duyet & tick giong
// (ca 2 engine) da tach sang tab "Kho giong". Bo sub-tab ElevenLabs o day.
function pgVoice() {
  const eng = S.data.engine || 'omnivoice';
  return `<div class="head"><h1>Voice Lab</h1>
    <span class="sub">tạo / nhân bản giọng OmniVoice · chọn giọng đang dùng ở
      <b onclick="go('voices')" style="cursor:pointer;text-decoration:underline">Kho giọng</b></span>
    <div class="right"><button class="btn" onclick="loadVoice()">↻ Làm mới</button></div></div>
    ${runningBar()}
    ${tabOmni(eng)}`;
}

// (tabEleven cu da bo — luoi giong gio nam trong pgVoices, gop ca 2 engine)

let vcFilter = { q: '', deep_only: false };
let vcMeta = {};
let vcOpen = false;              // bang kho giong: thu gon (cuon) hay mo het
let showHidden = false;          // dang xem giong da an (de hien lai) hay khong
let selVoice = new Set();        // giong da tich de do hang loat
let probeCost = 0;               // ky tu moi lan do = do dai doan nghe thu
// Doan nghe thu: NGUOI DUNG tu nhap, khong co mau mac dinh.
let probeText = { text: '', chars: 0, min_chars: 150, usable_as_reference: false };
let ptTimer = null;

// Go den dau cap nhat den do — nhung KHONG goi API moi phim.
// Dung go 800ms thi moi luu. Khong lam vay thi go 200 chu = 200 lan ghi file.
function probeTyping(v) {
  const n = v.trim().length;
  probeCost = n;
  const el = $('#pt-len');
  if (el) {
    el.textContent = `${n} ký tự`;
    el.className = n >= probeText.min_chars ? 'gold' : n ? '' : 'red';
  }
  const mark = $('#pt-save');
  if (mark) mark.textContent = 'đang gõ…';
  clearTimeout(ptTimer);
  ptTimer = setTimeout(() => saveProbeText(v), 800);
}

async function saveProbeText(v) {
  clearTimeout(ptTimer);
  const text = (v || '').trim();
  if (text === probeText.text) {
    const m = $('#pt-save'); if (m) m.textContent = '';
    return;
  }
  try {
    const r = await api('/voice-lab/probe-text', { method: 'PUT', body: { text } });
    probeText = r;
    probeCost = r.chars;
    const m = $('#pt-save');
    if (m) {
      m.textContent = '✓ đã lưu';
      m.className = 'gold';
      setTimeout(() => { if (m) { m.textContent = ''; m.className = 'mut'; } }, 2000);
    }
  } catch (e) {
    toast(friendly(e.message), 'err');
  }
}

// 99.7 Hz lam tron thanh "100 Hz" nhung nhan la "nam rat tram" (vi 99.7 < 100)
// -> nguoi dung thay 100 Hz ma chu noi "rat tram", tuong phan mem sai.
// Sat nguong thi hien mot chu so thap phan.
function hzText(hz) {
  const near = [100, 130, 165].some(b => Math.abs(hz - b) < 1);
  return near ? hz.toFixed(1) : Math.round(hz);
}

// Giong da TICH (roster) mà HIEN & CHUA DO — chi dem giong dang thay tren luoi.
function vcUnmeasured() {
  return [...rosterSel].filter(id => { const v = elevenVoices.find(x => x.id === id); return v && !v.pitch_hz; }).length;
}
function vcAllSel() { return elevenVoices.length && elevenVoices.every(v => rosterSel.has(v.id)); }
function toggleAllVoice(on) {
  if (on) elevenVoices.forEach(v => rosterSel.add(v.id));
  else elevenVoices.forEach(v => rosterSel.delete(v.id));
  render();
}
async function probeSelected(force = false) {
  if (!probeText.chars) {
    $('#pt')?.focus();
    return toast('Chưa có đoạn nghe thử. Gõ một đoạn văn vào ô ở trên trước.', 'err');
  }
  // Chi do giong da tich MA DANG HIEN tren luoi (khoi do nham giong ngoai bo loc).
  const ids = [...rosterSel].filter(id => elevenVoices.find(v => v.id === id));
  const n = force ? ids.length : vcUnmeasured();
  if (!n) return toast('Tất cả giọng đã tích đều đã đo rồi. Bấm "Đọc lại" nếu muốn đọc bằng đoạn mới.', 'err');

  const head = force ? `Đọc LẠI ${n} giọng bằng đoạn hiện tại?` : `Đo ${n} giọng?`;
  if (!confirm(`${head}\n\nTIÊU ~${fmt(n * probeCost)} KÝ TỰ ElevenLabs.\nCòn lại: ${fmt(S.balance.chars)} ký tự.`
    + (probeText.usable_as_reference ? '\n\nBản đo đủ dài — dùng luôn làm mẫu nhân bản OmniVoice.' : ''))) return;

  const r = await act(() => api('/voice-lab/probe-bulk', { method:'POST', body:{ voice_ids: ids, force } }));
  if (!r) return;
  toast(`Đã xếp ${r.queued} giọng vào hàng đợi`
    + (r.skipped ? ` (bỏ qua ${r.skipped} đã đo)` : ''), 'ok');
  render();
}

// Đổi tên giọng Eleven -> lưu alias, lan tỏa mọi màn hình (catalog áp alias 1 chỗ).
async function renameVoice(id) {
  const v = elevenVoices.find(x => x.id === id);
  const cur = v ? v.name : '';
  const name = prompt('Đổi tên giọng (để trống = về tên gốc ElevenLabs):', cur);
  if (name === null) return;                 // bam Huy
  const r = await act(() => api('/voice-catalog/rename', { method: 'POST', body: { voice_id: id, name: name.trim() } }),
    'Đã đổi tên giọng');
  if (r) await act(loadVoice);
}

/* ── Kho mau giong (tab OmniVoice) ── */
let samples = [], smpOpen = false, smpUsed = null;
let omniCreateOpen = false;       // khoi "tao giong moi" o tab OmniVoice: mac dinh dong
let selSmp = new Set();          // mau da tich de xoa hang loat ("kind:id")

async function loadSamples() {
  const r = await act(() => api('/voice-lab/samples'));
  if (r) { samples = r.samples || []; render(); }
}
async function uploadSamples(files) {
  if (!files || !files.length) return;
  const fd = new FormData();
  [...files].forEach(f => fd.append('files', f));
  const r = await act(async () => {
    const res = await fetch('/api/voice-lab/samples/upload', { method: 'POST', body: fd });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  });
  if (!r) return;
  if (r.saved.length) toast(`Đã tải lên ${r.saved.length} file`, 'ok');
  r.rejected.forEach(x => toast(`${x.name}: ${x.error}`, 'err'));
  await act(loadSamples);
}
// Dung mau CO SAN -> khong goi ElevenLabs -> KHONG ton ky tu.
async function useSample(kind, id) {
  const s = samples.find(x => x.kind === kind && x.id === id);
  const r = await act(() => api('/voice-lab/samples/use', { method:'POST', body:{ kind, id, name: s ? s.label : '' } }),
    'Đã chọn mẫu — không tốn ký tự. Giờ bấm "Nhân bản bằng OmniVoice".');
  if (r) { voiceDraft = r.draft_id; smpUsed = id; render(); }
}
const SMP_KIND = { upload: 'file của bạn', draft: 'bản nháp Voice Lab', probe: 'bản đo giọng' };

function smpAllSel() { return samples.length && samples.every(s => selSmp.has(`${s.kind}:${s.id}`)); }
function toggleSmp(key, on) { on ? selSmp.add(key) : selSmp.delete(key); render(); }
function toggleAllSmp(on) {
  selSmp = on ? new Set(samples.map(s => `${s.kind}:${s.id}`)) : new Set();
  render();
}

async function delSample(kind, id) {
  const s = samples.find(x => x.kind === kind && x.id === id);
  const warn = kind === 'probe'
    ? '\n\nĐây là bản đo giọng — muốn nghe lại phải đo lại (tốn ký tự).' : '';
  if (!confirm(`Xóa "${s ? s.label : id}"?\n(${SMP_KIND[kind] || kind})${warn}`)) return;
  await act(() => api(`/voice-lab/samples/${kind}/${encodeURIComponent(id)}`, { method:'DELETE' }),
    'Đã xóa mẫu');
  await act(loadVoice);
}

async function delSelectedSamples() {
  const items = [...selSmp].map(k => {
    const i = k.indexOf(':');
    return { kind: k.slice(0, i), id: k.slice(i + 1) };
  });
  const probes = items.filter(i => i.kind === 'probe').length;
  const warn = probes
    ? `\n\n${probes} bản đo giọng — muốn nghe lại phải đo lại (tốn ký tự).` : '';
  if (!confirm(`Xóa ${items.length} mẫu?${warn}`)) return;
  const r = await act(() => api('/voice-lab/samples/delete-bulk', { method:'POST', body:{ items } }));
  if (!r) return;
  toast(`Đã xóa ${r.removed} mẫu` + (r.failed.length ? ` · ${r.failed.length} lỗi` : ''), 'ok');
  selSmp.clear();
  await act(loadVoice);
}

async function loadCatalog() {
  const p = new URLSearchParams(Object.entries(vcFilter).filter(([, v]) => v));
  if (showHidden) p.set('show_hidden', 'true');
  const r = await act(() => api('/voice-lab/eleven-voices?' + p));
  if (!r) return;
  elevenVoices = r.voices || [];
  vcMeta = { total: r.total, matched: r.matched, measured: r.measured, hidden: r.hidden };
  render();
}
async function probeVoice(id, force = false) {
  if (!probeText.chars) {
    $('#pt')?.focus();
    return toast('Chưa có đoạn nghe thử. Gõ một đoạn văn vào ô ở trên trước.', 'err');
  }
  if (force && !confirm(`Đọc lại giọng này bằng đoạn hiện tại?\n\nTIÊU ~${fmt(probeCost)} KÝ TỰ.\nCòn lại: ${fmt(S.balance.chars)} ký tự.`)) return;
  const r = await act(() => api('/voice-lab/probe', { method:'POST', body:{ voice_id: id, force } }),
    force ? 'Đã đọc lại' : 'Đã đo — bấm nghe thử');
  if (!r) return;
  const v = elevenVoices.find(x => x.id === id);
  if (v) {
    if (!v.pitch_hz) vcMeta.measured = (vcMeta.measured || 0) + 1;
    v.pitch_hz = r.pitch_hz; v.pitch_label = r.pitch_label;
    v.deep = r.pitch_hz < 130; v.stale = false;
  }
  probeText.stale = Math.max(0, (probeText.stale || 0) - (force ? 1 : 0));
  render();
  loadBalance();
}

// Xoa ban do. Muon nghe lai phai do lai -> ton ky tu. Noi ro truoc.
async function forgetVoice(id) {
  if (!confirm('Xóa bản đo của giọng này?\n\nMuốn nghe lại phải đo lại — tốn ký tự.')) return;
  await act(() => api(`/voice-lab/probe/${id}`, { method:'DELETE' }), 'Đã xóa bản đo');
  const v = elevenVoices.find(x => x.id === id);
  if (v) { v.pitch_hz = null; v.pitch_label = null; v.deep = false; v.stale = false;
           vcMeta.measured = Math.max(0, (vcMeta.measured || 1) - 1); }
  render();
}
async function forgetSelected() {
  const ids = [...selVoice].filter(id => elevenVoices.find(v => v.id === id)?.pitch_hz);
  if (!ids.length) return toast('Không có bản đo nào để xóa', 'err');
  if (!confirm(`Xóa ${ids.length} bản đo?\n\nMuốn nghe lại phải đo lại — tốn ký tự.`)) return;
  const r = await act(() => api('/voice-lab/probe/forget-bulk', { method:'POST', body:{ voice_ids: ids } }),
    `Đã xóa ${ids.length} bản đo`);
  if (r) { selVoice.clear(); await act(loadVoice); }
}

// (Ẩn/Hiện giọng đã BỎ — thay bằng roster "Giọng đang dùng": không tick = không hiện
//  ở các nơi chọn giọng. Lưới Kho giọng vẫn hiện tất cả để khám phá.)

function tabOmni(eng) {
  const uploads = samples.filter(s => s.kind === 'upload');   // CHI file nguoi dung tai len
  // Bo cong cu tao giong chi mo khi: chua co profile (nguoi moi) hoac dang lam do (voiceDraft).
  // Da co profile roi thi dong lai cho man hinh gon — chi con danh sach giong cua ho.
  const createOpen = omniCreateOpen || !profiles.length || !!voiceDraft;

  // Ban phat hanh KHONG kem OmniVoice (9 GB). Chua cai -> chi hien huong dan,
  // khong bay ra mot man hinh day nut khong bam duoc.
  if (S.data.omnivoice_installed === false) {
    return `<div class="card">
      <h3>OmniVoice chưa được cài</h3>
      <div class="info">Giọng đọc <b>miễn phí</b>, chạy ngay trên máy này —
        không tốn ký tự ElevenLabs.</div>

      <div class="grid g2" style="margin:14px 0">
        <div>
          <div class="gold" style="font-weight:600;margin-bottom:6px">Được gì</div>
          <div class="brief-hint">
            · Miễn phí hoàn toàn<br>
            · Nhân bản giọng từ file mẫu<br>
            · Không cần mạng khi dùng
          </div>
        </div>
        <div>
          <div class="red" style="font-weight:600;margin-bottom:6px">Đánh đổi</div>
          <div class="brief-hint">
            · Phải tải <b>9 GB</b><br>
            · Chậm — <b>~25 giây mỗi đoạn</b><br>
            · Giấy phép <b>CC-BY-NC: cấm dùng thương mại</b>
          </div>
        </div>
      </div>

      <div class="warn">
        <b>Video kiếm tiền thì đừng cài.</b> OmniVoice cấm dùng thương mại —
        phải dùng ElevenLabs. ElevenLabs cũng nhanh hơn nhiều.
      </div>

      <div class="brief-hint">
        Vẫn muốn cài? Đóng phần mềm, bấm đúp file
        <code>cai-giong-mien-phi.bat</code> trong thư mục cài đặt.
      </div>
      <button class="btn" style="margin-top:12px" onclick="go('voices')">
        ← Về Kho giọng</button>
    </div>`;
  }

  return `
    ${eng === 'omnivoice' ? '<div class="info">Video đang dùng <b>OmniVoice</b> — chạy local, miễn phí, nhưng chậm (~25s mỗi đoạn).</div>'
    : '<div class="info">Video đang dùng ElevenLabs. Chọn một giọng OmniVoice rồi bấm <b>Dùng OmniVoice cho video</b> để chuyển.</div>'}

    <button class="btn ghost expand" onclick="omniCreateOpen=!omniCreateOpen;render()"
      ${!profiles.length || voiceDraft ? 'disabled' : ''}
      title="Tạo / nhân bản một giọng OmniVoice mới">
      <span class="arrow ${createOpen ? 'up' : ''}">▾</span>
      ${createOpen ? 'Thu gọn phần tạo giọng' : '＋ Tạo giọng OmniVoice mới'}
    </button>

    ${createOpen ? `
    <div class="card" style="margin-bottom:14px">
      <h3>Mẫu giọng của bạn — tải lên${uploads.length ? ` · ${uploads.length} file` : ''}</h3>
      <div class="row" style="margin-bottom:10px">
        <button class="btn" onclick="$('#smp-in').click()">⬆ Tải file giọng / video của tôi</button>
        <button class="btn ghost" onclick="loadSamples()">↻ Quét lại</button>
      </div>
      <input type="file" id="smp-in" accept="audio/*,video/*,.mp4,.mov,.mkv,.webm,.m4v" multiple hidden onchange="uploadSamples(this.files)">
      ${uploads.length ? `<table class="grid"><thead><tr>
        <th>Mẫu</th><th style="width:64px">Dài</th><th style="width:120px">Cao độ</th>
        <th style="width:56px">Nghe</th><th style="width:150px"></th>
      </tr></thead><tbody>${uploads.map(s => {
        const cls = !s.pitch_hz ? 'mut' : s.deep ? 'gold' : s.pitch_hz < 165 ? '' : 'red';
        return `<tr>
        <td><b>${esc(s.label)}</b></td>
        <td class="${s.usable ? '' : 'red'}">${s.seconds}s</td>
        <td>${s.pitch_hz ? `<b class="${cls}">${Math.round(s.pitch_hz)} Hz</b>` : '<span class="mut">—</span>'}</td>
        <td><button class="pbtn" onclick="playUrl('${esc(s.url)}',this)" title="Nghe thử">▶</button></td>
        <td class="right">
          ${s.usable
            ? `<button class="btn sm primary" onclick="useSample('${esc(s.kind)}','${esc(s.id)}')" title="Không tốn ký tự">Dùng</button>`
            : '<span class="mut" title="Cần ít nhất 8 giây">quá ngắn</span>'}
          <button class="btn sm danger" onclick="delSample('${esc(s.kind)}','${esc(s.id)}')" title="Xóa mẫu này">✕</button>
        </td></tr>`; }).join('')}</tbody></table>`
      : '<div class="mut" style="font-size:12px">Chưa có file nào. Tải <b>audio</b> hoặc <b>video mp4</b> — video sẽ tự tách tiếng làm mẫu.</div>'}
    </div>

    <div class="grid g2">
    <div class="card"><h3>1 · Tạo mẫu mới bằng ElevenLabs</h3>
      <div class="field"><label>Giọng nguồn — <b>cao độ của nó sẽ thành cao độ video</b></label>
      <select id="vl-voice">${(() => {
        const rl = (ROSTER || []).filter(v => v.engine === 'eleven');
        return rl.length
          ? rl.map(v => {
              const hz = v.pitch_hz ? ` · ${Math.round(v.pitch_hz)} Hz` : '';
              return `<option value="${esc(v.id)}">${esc(v.name)}${hz}</option>`;
            }).join('')
          : '<option value="">— chưa có giọng trong roster —</option>';
      })()}</select>
      <div class="mut" style="font-size:11.5px;margin-top:4px">
        Chỉ hiện giọng trong <b>"Giọng đang dùng"</b>. Thêm giọng: tab <b onclick="go('voices')"
        style="cursor:pointer;text-decoration:underline">Kho giọng</b> → tick + 💾 Lưu</div></div>
      <div class="field"><label>Đoạn mẫu — <b>dạy OmniVoice cách kể chuyện</b></label>
      <textarea id="vl-text" rows="4" oninput="updateLen()"
        placeholder="Dán đoạn văn của bạn. Từ 150 ký tự trở lên.">${esc(probeText.text || '')}</textarea>
      <div id="vl-len" class="mut" style="font-size:11.5px;margin-top:4px"></div>
      ${probeText.text ? '<div class="mut" style="font-size:11px">Lấy từ đoạn nghe thử — sửa được.</div>' : ''}
      </div>
      <div class="row">
        <div><label>Stability</label><input type="number" id="vl-stability" min="0" max="1" step=".05" value="0.28"></div>
        <div><label>Style</label><input type="number" id="vl-style" min="0" max="1" step=".05" value="0.55"></div>
        <div><label>Speed</label><input type="number" id="vl-speed" min=".7" max="1.2" step=".01" value="0.86"></div>
      </div>
      <button class="btn primary" style="width:100%;margin-top:12px;justify-content:center"
        onclick="createElevenPreview()">Tạo mẫu</button>
    </div>

    <div class="card"><h3>2 · Nhân bản bằng OmniVoice</h3>
      <div class="warn" style="font-size:11.5px">
        <b>Cao độ mẫu quyết định video trầm hay cao.</b> OmniVoice clone <b>đúng</b> giọng bạn đưa.
        Nam trầm kể chuyện: <b>85–130 Hz</b>. Trên 165 Hz là giọng cao.</div>
      ${voiceDraft ? `
        <div class="field"><label>Mẫu ElevenLabs (nguồn)</label>
        <audio controls src="/media/voice-lab/${esc(voiceDraft)}/eleven"></audio></div>
        <button class="btn" style="width:100%;justify-content:center;margin-bottom:12px"
          onclick="createOmniPreview()">Nhân bản (chậm — xem hàng đợi)</button>
        <div class="field"><label>Mẫu OmniVoice (giọng sẽ vào video)</label>
        <audio controls src="/media/voice-lab/${esc(voiceDraft)}/omnivoice?t=${Date.now()}"></audio></div>`
      : empty('🎚', 'Tạo mẫu ElevenLabs trước', '')}
    </div></div>

    <div class="card" style="margin-top:14px"><h3>3 · Lưu profile</h3>
      <div class="row">
        <div><label>ID (chữ thường, số, gạch)</label><input type="text" id="vp-id" placeholder="giong-tram-01"></div>
        <div><label>Tên hiển thị</label><input type="text" id="vp-name" placeholder="Giọng trầm kể chuyện"></div>
      </div>
      <label class="pick" style="margin-top:12px;display:inline-flex">
        <input type="checkbox" id="vp-rights"> Tôi xác nhận có quyền dùng mẫu giọng này</label>
      <button class="btn primary" style="width:100%;margin-top:12px;justify-content:center"
        onclick="saveProfile()" ${!voiceDraft ? 'disabled' : ''}>Lưu &amp; đặt mặc định</button>
    </div>` : ''}

    <div class="card" style="margin-top:14px"><h3>Giọng OmniVoice của bạn — ${profiles.length}</h3>
      ${profiles.length ? `<table class="grid"><thead><tr>
        <th>Tên</th><th style="width:150px">Cao độ</th>
        <th style="width:56px">Nghe</th><th style="width:190px"></th>
      </tr></thead><tbody>${profiles.map(p => {
        const a = p.audio || {}, hz = a.pitch_hz || 0;
        const cls = !hz ? 'mut' : hz < 130 ? 'gold' : hz < 165 ? '' : 'red';
        return `<tr class="${p.active ? 'sel' : ''}">
        <td><b>${esc(p.name)}</b> ${p.active ? '<span class="tag published">mặc định</span>' : ''}
          <div class="mut" style="font-size:11px">${esc(p.id)}${a.seconds ? ` · ${a.seconds}s` : ''}</div></td>
        <td>${hz ? `<b class="${cls}">${hz} Hz</b> <span class="mut" style="font-size:11px">${esc(a.pitch_label||'')}</span>` : '<span class="mut">—</span>'}</td>
        <td><button class="pbtn" onclick="playUrl('/media/voice-profiles/${esc(p.id)}/preview',this)" title="Nghe giọng đã nhân bản">▶</button></td>
        <td class="right">
          <button class="btn sm ghost" onclick="renameProfile('${esc(p.id)}')" title="Đổi tên (không đổi ID)">✎</button>
          ${!p.active
          ? `<button class="btn sm" onclick="activateProfile('${esc(p.id)}')">Đặt mặc định</button>
             <button class="btn sm danger" onclick="deleteProfile('${esc(p.id)}')">Xóa</button>`
          : '<span class="mut">đang dùng</span>'}</td>
      </tr>`; }).join('')}</tbody></table>
      <div class="row" style="margin-top:14px">
        <button class="btn ${eng === 'omnivoice' ? '' : 'primary'}" onclick="setEngine('omnivoice')"
          ${eng === 'omnivoice' ? 'disabled' : ''}>
          ${eng === 'omnivoice' ? '✓ Đang dùng OmniVoice cho video' : 'Dùng OmniVoice cho video'}</button>
      </div>`
      : empty('🎙', 'Chưa có profile', 'Làm 3 bước ở trên.')}
    </div>`;
}

// MOT trinh phat dung chung cho ca luoi.
//
// Truoc day moi dong mot <audio controls> — 60 trinh phat cua trinh duyet,
// moi cai cao 30px, xau va chiem het cot. Gio: mot nut ▶ nho, mot the Audio.
let _audio = null, _playBtn = null;

function playProbe(id, btn) {
  // Ban do doc doan CU (mau cu tu ban truoc) -> KHONG phat lai file cu.
  // Doc lai bang doan nghe thu hien tai (co hoi xac nhan chi phi) roi moi nghe.
  const vv = elevenVoices.find(x => x.id === id);
  if (vv && vv.stale) {
    toast('Bản đo này đọc đoạn cũ — đọc lại bằng đoạn nghe thử hiện tại rồi nghe.');
    // Bo buffer cu cua giong nay: doc lai xong, lan phat sau phai tai file moi.
    if (_audio && _audio.dataset.id === id) _audio.dataset.id = '';
    probeVoice(id, true);
    return;
  }
  if (_playBtn && _playBtn !== btn) _playBtn.textContent = '▶';

  if (_audio && _audio.dataset.id === id && !_audio.paused) {
    _audio.pause();
    btn.textContent = '▶';
    return;
  }
  if (!_audio) {
    _audio = new Audio();
    _audio.onended = () => { if (_playBtn) _playBtn.textContent = '▶'; };
    _audio.onerror = () => { toast('Không phát được — thử Đo lại', 'err');
                             if (_playBtn) _playBtn.textContent = '▶'; };
  }
  if (_audio.dataset.id !== id) {
    _audio.src = `/media/voice-probe/${id}`;
    _audio.dataset.id = id;
    _audio.dataset.url = '';
  }
  _audio.play();
  btn.textContent = '❚❚';
  _playBtn = btn;
}

// Nut ▶ dung chung cho am thanh NGOAI luoi eleven: mau giong, profile OmniVoice.
// Cung mot the Audio nhu playProbe — khong de trinh duyet de ra chuc trinh phat.
function playUrl(url, btn) {
  if (_playBtn && _playBtn !== btn) _playBtn.textContent = '▶';
  if (_audio && _audio.dataset.url === url && !_audio.paused) {
    _audio.pause(); btn.textContent = '▶'; return;
  }
  if (!_audio) {
    _audio = new Audio();
    _audio.onended = () => { if (_playBtn) _playBtn.textContent = '▶'; };
    _audio.onerror = () => { toast('Không phát được', 'err'); if (_playBtn) _playBtn.textContent = '▶'; };
  }
  if (_audio.dataset.url !== url) {
    _audio.src = url; _audio.dataset.url = url; _audio.dataset.id = '';
  }
  _audio.play();
  btn.textContent = '❚❚';
  _playBtn = btn;
}

async function pickEleven(id) {
  await act(() => api('/voice-setup', { method:'PUT', body:{ eleven_voice_id: id } }), 'Đã chọn giọng');
  await act(loadVoice);
}
async function setEngine(engine) {
  await act(() => api('/voice-setup', { method:'PUT', body:{ engine } }),
    `Video sẽ dùng ${engine === 'eleven' ? 'ElevenLabs' : 'OmniVoice'}`);
  await act(loadVoice);
}
async function createElevenPreview() {
  const voice_id = $('#vl-voice').value;
  if (!voice_id) return toast('Chưa chọn được giọng ElevenLabs', 'err');
  const text = $('#vl-text').value.trim();
  // CANH BAO, khong CHAN. Nguoi dung co the chi muon nghe thu giong.
  // Chan that nam o buoc Luu profile — do bang SO GIAY, khong phai so ky tu.
  if (text.length < MIN_SAMPLE)
    toast(`Mẫu ngắn (${text.length}/${MIN_SAMPLE} ký tự) — nghe thử thì được, `
      + 'nhưng lưu profile sẽ bị từ chối vì giọng nhân bản sẽ vô hồn.', 'err');
  const src = (ROSTER || []).find(v => v.ref === `eleven:${voice_id}`);
  const r = await act(() => api('/voice-lab/eleven-preview', { method:'POST', body:{
    voice_id, text, stability: +$('#vl-stability').value,
    style: +$('#vl-style').value, speed: +$('#vl-speed').value,
    name: src ? src.name : '',        // giu dau vet ten giong nguon trong draft
  }}), 'Đang tạo mẫu — xem hàng đợi');
  if (r) { voiceDraft = r.draft_id; render(); }
}
async function createOmniPreview() {
  if (!voiceDraft) return toast('Chưa có mẫu ElevenLabs', 'err');
  const r = await act(() => api('/voice-lab/omnivoice-preview', { method:'POST', body:{ draft_id: voiceDraft }}),
    'Đang nhân bản — lần đầu tải model có thể lâu (xem hàng đợi)');
  if (!r) return;
  // Cho job xong roi NAP LAI player (khong chi dua SSE — chac an hon).
  for (let i = 0; i < 200; i++) {
    await new Promise(res => setTimeout(res, 3000));
    const j = await api('/jobs').catch(() => null);
    if (!j) continue;
    if (!(j.current && j.current.kind === 'omnivoice-preview')) {
      if (S.page === 'voice') { await loadVoice(); toast('Nhân bản xong — nghe thử ở "Mẫu OmniVoice"', 'ok'); }
      return;
    }
  }
}
async function saveProfile() {
  const id = $('#vp-id').value.trim(), name = $('#vp-name').value.trim();
  if (!id || !name) return toast('Nhập ID và tên profile', 'err');
  if (!$('#vp-rights').checked) return toast('Phải xác nhận quyền dùng mẫu giọng', 'err');
  const r = await act(() => api('/voice-profiles', { method:'POST', body:{
    draft_id: voiceDraft, id, name, rights_confirmed: true, activate: true }}),
    'Đã lưu và đặt làm giọng mặc định');
  if (r) { voiceDraft = null; await act(loadVoice); }
}
async function activateProfile(id) {
  await act(() => api(`/voice-profiles/${id}/activate`, { method:'POST' }), 'Đã đổi giọng mặc định');
  await act(loadVoice);
}
async function deleteProfile(id) {
  if (!confirm(`Xóa profile "${id}"?`)) return;
  await act(() => api(`/voice-profiles/${id}`, { method:'DELETE' }), 'Đã xóa profile');
  await act(loadVoice);
}
// Đổi TÊN hiển thị profile (không đổi ID/slug). Lan tỏa: overview phân giải tên lúc đọc.
async function renameProfile(id) {
  const p = profiles.find(x => x.id === id);
  const name = prompt('Đổi tên hiển thị (không đổi ID):', p ? p.name : '');
  if (name === null) return;
  if (!name.trim()) return toast('Tên không được để trống', 'err');
  const r = await act(() => api(`/voice-profiles/${id}/rename`, { method: 'POST', body: { name: name.trim() } }),
    'Đã đổi tên profile');
  if (r) await act(loadVoice);
}

/* ══════════ MUC LUC VIDEO — moi kenh, nhom theo ngay ══════════ */
let lib = null;                                   // null = chua tai
let libFilter = { channel: '', days: 0, only_video: false };
let libView = 'grid';                             // grid | list

const DAY_VN = ['Chủ nhật','Thứ hai','Thứ ba','Thứ tư','Thứ năm','Thứ sáu','Thứ bảy'];
function dayLabel(iso) {
  const d = new Date(iso + 'T00:00:00');
  const today = new Date(); today.setHours(0,0,0,0);
  const diff = Math.round((today - d) / 86400000);
  const base = `${DAY_VN[d.getDay()]}, ${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
  if (diff === 0) return `Hôm nay · ${base}`;
  if (diff === 1) return `Hôm qua · ${base}`;
  if (diff > 1 && diff < 7) return `${diff} ngày trước · ${base}`;
  return base;
}
const mmss = s => s ? `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}` : '—';

async function loadLibrary() {
  const p = new URLSearchParams();
  if (libFilter.channel) p.set('channel', libFilter.channel);
  if (libFilter.days) p.set('days', libFilter.days);
  const r = await act(() => api('/library?' + p));
  if (!r) return;
  lib = r;
  badge('#b-lib', r.with_video);
  render();
}

function pgLibrary() {
  if (!lib) return `<div class="head"><h1>Mục lục video</h1></div>${skeleton(4)}`;

  // Loc "chi video xong" o phia trinh duyet — khong goi lai API.
  const days = lib.days
    .map(g => ({ ...g, videos: libFilter.only_video ? g.videos.filter(v => v.has_video) : g.videos }))
    .filter(g => g.videos.length);
  const shown = days.reduce((n, g) => n + g.videos.length, 0);

  return `<div class="head">
    <h1>Mục lục video</h1>
    <span class="sub">${fmt(lib.total)} tập · <b class="gold">${fmt(lib.with_video)}</b> đã có video
      · ${lib.channels.length} kênh</span>
    <div class="right">
      <button class="btn ghost sm ${libView === 'grid' ? 'on' : ''}" onclick="libView='grid';render()" title="Dạng lưới">▦</button>
      <button class="btn ghost sm ${libView === 'list' ? 'on' : ''}" onclick="libView='list';render()" title="Dạng bảng">☰</button>
      <button class="btn" onclick="loadLibrary()">↻ Làm mới</button>
    </div></div>
    ${runningBar()}

    <div class="filters" style="margin-bottom:14px">
      <select onchange="libFilter.channel=this.value;loadLibrary()">
        <option value="">Mọi kênh (${lib.channels.length})</option>
        ${lib.channels.map(c => `<option value="${esc(c.id)}" ${libFilter.channel === c.id ? 'selected' : ''}>
          ${esc(c.name)}${c.active ? ' · đang mở' : ''}</option>`).join('')}
      </select>
      <select onchange="libFilter.days=+this.value;loadLibrary()">
        <option value="0">Mọi thời gian</option>
        <option value="1" ${libFilter.days === 1 ? 'selected' : ''}>Hôm nay</option>
        <option value="7" ${libFilter.days === 7 ? 'selected' : ''}>7 ngày qua</option>
        <option value="30" ${libFilter.days === 30 ? 'selected' : ''}>30 ngày qua</option>
      </select>
      <label class="pick">
        <input type="checkbox" ${libFilter.only_video ? 'checked' : ''}
          onchange="libFilter.only_video=this.checked;render()"> Chỉ tập đã có video
      </label>
      <span class="sp"></span>
      <span class="mut">${fmt(shown)} tập</span>
    </div>

    ${!days.length
      ? empty('▦', 'Không có tập nào khớp bộ lọc', 'Đổi bộ lọc, hoặc nhập kịch bản ở tab Kịch bản đầu vào.')
      : days.map(g => {
        const done = g.videos.filter(v => v.has_video).length;
        const mins = g.videos.reduce((s, v) => s + (v.duration || 0), 0) / 60;
        return `<div class="day">
          <div class="day-head">
            <b>${dayLabel(g.day)}</b>
            <span class="mut">${g.videos.length} tập${done ? ` · ${done} video` : ''}${
              mins >= 1 ? ` · ${mins.toFixed(0)} phút` : ''}</span>
          </div>
          ${libView === 'grid' ? libGrid(g.videos) : libList(g.videos)}
        </div>`;
      }).join('')}`;
}

function libGrid(vids) {
  return `<div class="lib-grid">${vids.map(v => {
    const img = v.thumb ? `/media/ch/${esc(v.channel_id)}/scene/${esc(v.episode)}/1` : '';
    const pct = v.images_needed ? Math.round(v.images_done / v.images_needed * 100) : 0;
    return `<div class="lib-card" onclick="openLibEp('${esc(v.channel_id)}','${esc(v.episode)}')">
      <div class="lib-thumb">
        ${img ? `<img loading="lazy" src="${img}">` : '<div class="no-img">chưa vẽ</div>'}
        ${v.has_video ? `<span class="play">▶</span>
          <span class="dur">${mmss(v.duration)}</span>` : ''}
        ${!v.has_video && pct ? `<div class="bar" style="position:absolute;bottom:0;left:0;right:0;border-radius:0">
          <i style="width:${pct}%"></i></div>` : ''}
      </div>
      <div class="lib-body">
        <div class="lib-title">${esc(v.title)}</div>
        <div class="lib-meta">
          <span class="tag ${v.stage}">${STAGE[v.stage] || v.stage}</span>
          ${v.voice_engine ? `<span class="tag ${v.voice_engine === 'eleven' ? 'video' : 'script'}">${
            v.voice_engine === 'eleven' ? 'Eleven' : 'Omni'}</span>` : ''}
        </div>
        <div class="lib-foot">
          <span>${esc(v.episode)}</span>
          <span class="mut">${esc(v.channel)}</span>
        </div>
      </div>
    </div>`; }).join('')}</div>`;
}

function libList(vids) {
  return `<table class="grid"><thead><tr>
    <th style="width:74px">Tập</th><th>Tiêu đề</th>
    <th style="width:130px">Chặng</th><th style="width:90px">Tranh</th>
    <th style="width:75px">Dài</th><th style="width:80px">Giọng</th>
    <th style="width:130px">Kênh</th><th style="width:130px"></th>
  </tr></thead><tbody>${vids.map(v => `<tr>
    <td><b>${esc(v.episode)}</b></td>
    <td class="click" onclick="openLibEp('${esc(v.channel_id)}','${esc(v.episode)}')">${esc(v.title)}</td>
    <td><span class="tag ${v.stage}">${STAGE[v.stage] || v.stage}</span></td>
    <td class="mut">${v.images_done}/${v.images_needed}</td>
    <td class="mut">${mmss(v.duration)}</td>
    <td class="mut">${v.voice_engine === 'eleven' ? 'Eleven' : v.voice_engine === 'omnivoice' ? 'Omni' : '—'}</td>
    <td class="mut">${esc(v.channel)}</td>
    <td class="right">
      ${v.has_video ? `<a class="btn sm ghost" href="/media/ch/${esc(v.channel_id)}/video/${esc(v.episode)}"
        download="${esc(v.episode)}.mp4" onclick="event.stopPropagation()">⬇ MP4</a>` : ''}
      ${v.srt ? `<a class="btn sm ghost" href="/media/ch/${esc(v.channel_id)}/srt/${esc(v.episode)}"
        download="${esc(v.episode)}.srt" onclick="event.stopPropagation()">SRT</a>` : ''}
    </td></tr>`).join('')}</tbody></table>`;
}

// Mo tap tu muc luc. Tap o kenh KHAC -> phai chuyen kenh truoc,
// vi /api/episodes/{ep} chi doc kenh dang mo.
async function openLibEp(cid, ep) {
  const cur = (lib.channels.find(c => c.active) || {}).id;
  if (cid !== cur) {
    if (!confirm(`Tập này ở kênh khác. Chuyển sang kênh đó?`)) return;
    await act(() => api(`/channels/${cid}/switch`, { method: 'POST' }), 'Đã chuyển kênh');
    await act(loadOverview);
  }
  openEpisode(ep);
}

/* ══════════ CAI DAT ══════════ */
function pgSettings() {
  const b = S.balance;
  const adv = !!appConfig.advanced_mode;
  return `<div class="head"><h1>Cài đặt</h1></div>
    <div class="card" style="margin-bottom:14px"><h3>Chế độ nâng cao</h3>
      <div class="brief-hint">Bật để hiện lại các module sản xuất cũ:
        <b>Kịch bản đầu vào · Xưởng sản xuất · Mục lục video · Tạo ảnh · Tạo video AI · Kho giọng · Voice Lab</b>.
        Tắt (mặc định) chỉ còn luồng <b>Đăng hàng loạt</b>. Không xoá code — chỉ ẩn menu.</div>
      <label style="display:flex;align-items:center;gap:10px;margin-top:10px;cursor:pointer">
        <input type="checkbox" ${adv ? 'checked' : ''} onchange="toggleAdvanced(this.checked)">
        <b>${adv ? 'Đang BẬT' : 'Đang TẮT'}</b> chế độ nâng cao
      </label>
    </div>
    <div class="card" style="margin-bottom:14px"><h3>🔄 Cập nhật phần mềm</h3>
      <div class="brief-hint">Bấm để tải bản mới nhất rồi <b>tự khởi động lại</b> — không cần cài lại.
        Phiên bản hiện tại: <b>${esc((S.appVer || {}).version || '…')}</b>.</div>
      <button class="btn primary" style="margin-top:10px" onclick="doAppUpdate()">🔄 Cập nhật &amp; mở lại</button>
      <div class="mut" style="margin-top:8px;font-size:12px">Tự động tải bản mới từ máy chủ cập nhật, kiểm an toàn (sha256), giữ nguyên key + dữ liệu.</div>
    </div>
    <div class="grid g2">
    <div class="card"><h3>Số dư</h3>
      <div class="stat"><div class="num ${b.low_credits ? 'red' : ''}">${fmt(b.credits)}</div>
        <div class="lbl">credit 79ai · vẽ được ~${Math.floor((b.credits||0)/(b.credits_per_image||600))} tranh</div></div>
      <div class="hr"></div>
      <div class="stat"><div class="num ${b.low_chars ? 'red' : ''}">${fmt(b.chars)}</div>
        <div class="lbl">ký tự ElevenLabs · đọc được ~${Math.floor((b.chars||0)/900)} tập</div></div>
      <button class="btn sm" style="margin-top:12px" onclick="refreshBalance()">↻ Cập nhật</button>
    </div>
    <div class="card"><h3>Giọng đọc video</h3>
      <div class="info">Engine: <b>${S.data.engine === 'eleven' ? 'ElevenLabs' : 'OmniVoice'}</b></div>
      <div class="brief-hint">
        <b>OmniVoice</b> — chạy local, miễn phí. Clone giọng từ file mẫu.
        Chậm (~25s/đoạn). Giấy phép CC-BY-NC: <b>cấm dùng thương mại</b>.<br><br>
        <b>ElevenLabs</b> — tốn ký tự, nhưng có cảm xúc thật và mốc thời gian
        chính xác từ API. Dùng được cho video kiếm tiền.</div>
      <button class="btn" style="margin-top:10px" onclick="go('voice')">Đổi giọng ở Voice Lab →</button>
    </div></div>
    <div class="card" style="margin-top:14px"><h3>Phím tắt</h3>
      <table><tbody>
        <tr><td style="width:90px"><kbd>7</kbd></td><td class="mut">mở Đăng hàng loạt (các phím số khác chỉ hoạt động khi bật Chế độ nâng cao)</td></tr>
        <tr><td><kbd>R</kbd></td><td class="mut">làm mới trang hiện tại</td></tr>
        <tr><td><kbd>Esc</kbd></td><td class="mut">bỏ chọn / quay lại</td></tr>
      </tbody></table>
    </div>
    <div class="card" style="margin-top:14px"><h3>API keys
      <button class="btn sm" style="float:right" onclick="checkOnboarding(true)">🚀 Thiết lập & kiểm tra key</button></h3>
      <div class="brief-hint">Dán key rồi bấm <b>Lưu</b> — có hiệu lực ngay (không cần khởi động lại).
        Key lưu ở <b>keys.env</b> (không lên git). Key đã có hiện <b>••••</b> ẩn; bấm 👁 để hiện chữ khi gõ key mới.</div>
      <div class="keys">${apiKeys.map(k => `
        <div class="keyrow">
          <div class="keylbl"><b>${esc(k.label)}</b>
            <div class="mut" style="font-size:11px">${esc(k.help)}</div></div>
          <div class="keyin">
            <input id="key-${esc(k.name)}" type="password" autocomplete="off"
              placeholder="${k.set ? esc(k.masked) + '  (đã có — dán để đổi)' : 'chưa có — dán key vào đây'}">
            <button class="pbtn" onclick="toggleKeyShow('${esc(k.name)}')" title="Ẩn/hiện">👁</button>
            <button class="btn sm primary" onclick="saveKey('${esc(k.name)}')">Lưu</button>
            ${k.set ? `<button class="btn sm ghost red" onclick="saveKey('${esc(k.name)}',true)" title="Xóa key">✕</button>` : ''}
          </div>
        </div>`).join('')}</div>
    </div>
    <div class="card" style="margin-top:14px"><h3>File cấu hình</h3>
      <div class="brief-hint">
        <b>pipeline/config.yaml</b> — kỹ thuật: phong cách vẽ, nhịp đọc, thông số giọng.<br>
        <b>content/channel.yaml</b> — kênh: tên, engine giọng, ngân sách.</div>
    </div>`;
}
/* ══════════ ONBOARDING (nhap + TEST key, chay-lan-dau) ══════════ */
let onboard = null, onboardShow = false, onboardStatus = {};
async function checkOnboarding(force = false) {
  try { onboard = await api('/onboarding'); } catch { return; }
  if (force || !onboard.ready) { onboardShow = true; onboardStatus = {}; paintOnboard(); }
}
function onboardClose() { onboardShow = false; paintOnboard(); }
function paintOnboard() {
  let el = document.getElementById('onboard-overlay');
  if (!onboardShow) { if (el) el.remove(); return; }
  if (!el) { el = document.createElement('div'); el.id = 'onboard-overlay'; el.className = 'ob-overlay'; document.body.append(el); }
  const ks = (onboard && onboard.keys) || [];
  const ready = ks.filter(k => k.required).every(k => k.set);
  el.innerHTML = `<div class="ob-box">
    <div class="ob-head"><h2>Thiết lập lần đầu — API key</h2>
      <div class="mut">Nhập & <b>kiểm tra thật</b> từng key. Key lưu ở <b>keys.env</b> (không lên git) —
      máy mới phải nhập lại. Thiếu key <b>bắt buộc</b> thì chưa vào được.</div></div>
    <div class="ob-keys">${ks.map(k => {
      const st = onboardStatus[k.name];
      const dot = st && st.testing ? '⏳' : (k.set ? '🟢' : (st && !st.ok ? '🔴' : '⚪'));
      return `<div class="ob-row">
        <div class="ob-lbl"><b>${esc(k.label)}</b> ${k.required ? '<span class="ob-req">bắt buộc</span>' : '<span class="mut">tuỳ chọn</span>'}
          <div class="mut" style="font-size:12px">${esc(k.help)}</div></div>
        <div class="ob-in">
          <span class="ob-dot">${dot}</span>
          <input id="ob-${esc(k.name)}" type="password" autocomplete="off"
            placeholder="${k.set ? 'đã có — dán để đổi, hoặc bấm để kiểm tra lại' : 'dán key vào đây'}">
          <button class="btn sm primary" onclick="onboardSave('${esc(k.name)}')">Lưu & kiểm tra</button>
        </div>
        ${st && st.detail ? `<div class="ob-msg ${st.ok ? 'ok' : 'err'}">${esc(st.detail)}</div>` : ''}
      </div>`;
    }).join('')}</div>
    <div class="ob-foot">
      <div class="mut">${ready ? '✅ Đã đủ key bắt buộc.' : '⚠️ Còn thiếu key bắt buộc — nhập để mở khoá.'}</div>
      <button class="btn primary" ${ready ? '' : 'disabled'} onclick="onboardClose()">Vào phần mềm →</button>
    </div>
  </div>`;
}
async function onboardSave(name) {
  const inp = document.getElementById('ob-' + name);
  const value = (inp ? inp.value : '').trim();
  onboardStatus[name] = { testing: true, detail: 'Đang kiểm tra…' }; paintOnboard();
  try {
    // Co gia tri moi -> luu+test; rong -> chi test key da luu (khong ghi de).
    const ep = value ? '/onboarding/save' : '/settings/keys/test';
    const r = await api(ep, { method: 'POST', body: { name, value } });
    onboardStatus[name] = { ok: r.ok, detail: r.detail };
    if (r.ok && value) { onboard = await api('/onboarding'); }
  } catch (e) { onboardStatus[name] = { ok: false, detail: friendly(e.message) }; }
  paintOnboard();
}

async function toggleAdvanced(on) {
  await act(async () => {
    appConfig = { ...appConfig, ...(await api('/config', { method: 'POST', body: { advanced_mode: !!on } })) };
    applyNavConfig();
    render();
  }, on ? 'Đã bật chế độ nâng cao' : 'Đã tắt chế độ nâng cao');
}
async function loadKeys() {
  const r = await api('/settings/keys').catch(() => ({ keys: [] }));
  apiKeys = r.keys || []; render();
}
async function loadSettings() { await loadOverview(); await loadKeys(); }
function toggleKeyShow(name) {
  const el = document.getElementById('key-' + name);
  if (el) el.type = el.type === 'password' ? 'text' : 'password';
}
async function saveKey(name, clear) {
  const el = document.getElementById('key-' + name);
  const value = clear ? '' : (el ? el.value.trim() : '');
  if (!clear && !value) return toast('Chưa dán key', 'err');
  const out = await act(() => api('/settings/keys', { method: 'POST', body: { name, value } }),
    clear ? 'Đã xóa key' : 'Đã lưu key — dùng được ngay');
  if (out) { if (el) el.value = ''; await loadKeys(); }
}

/* ══════════ HANG DOI ══════════ */
function paintQueue() {
  const j = S.jobs, cur = j.current, list = j.jobs || [], hist = (j.history || []).slice(-6).reverse();
  $('#qdot').className = 'dot' + (cur ? ' run' : '');
  $('#qtitle').textContent = cur ? cur.label : 'Hàng đợi';
  $('#qcount').innerHTML = list.length ? `${list.length} chờ`
    : hist.length ? `<button class="btn ghost sm" onclick="event.stopPropagation();clearJobs()">Dọn</button>` : '';
  const rows = [cur, ...list, ...hist].filter(Boolean);
  $('#qbody').innerHTML = rows.length ? rows.map(x => `
    <div class="q-job"><div class="r">
      ${x.step ? `<span class="step">${esc(x.step)}</span>` : ''}
      <span>${esc(x.label)}</span>
      <span class="s s-${(x.status || '').split(' ')[0]}">${esc(x.status)}</span>
      ${x.status === 'cho' ? `<button class="btn ghost sm" onclick="cancelJob(${x.id})" title="Hủy">✕</button>` : ''}
    </div>
    ${x.error ? `<div class="log red">${esc(friendly(x.error))}</div>`
      : (x.lines || []).length ? `<div class="log">${esc((x.lines || []).slice(-3).join('\n'))}</div>` : ''}
    </div>`).join('') : '<p class="mut">Chưa có việc nào.</p>';
}
async function cancelJob(id) { await act(() => api(`/jobs/${id}`, { method:'DELETE' }), 'Đã hủy'); }
async function clearJobs() {
  await act(() => api('/jobs/clear', { method:'POST' }));
  S.jobs.history = [];
  paintQueue();
}
$('#qh').onclick = () => $('#qp').classList.toggle('open');

// SSE chi cap nhat thanh hang doi. Re-render toan trang moi dong log se xoa
// input dang go va lam mat voiceDraft. Chi tai lai du lieu khi job XONG.
function initQueue() {
  const es = new EventSource('/api/stream');
  es.onerror = () => { $('#qtitle').textContent = 'Mất kết nối…'; };
  es.onmessage = ev => {
    const d = JSON.parse(ev.data);
    if (d.type === 'hello') { S.jobs = d; paintQueue(); render(); return; }
    if (d.type === 'queued' || d.type === 'start') { S.jobs.current = d.job; paintQueue(); render(); return; }
    if (d.type === 'log' && S.jobs.current) {
      (S.jobs.current.lines = S.jobs.current.lines || []).push(d.line);
      paintQueue(); return;
    }
    if (d.type === 'end') {
      S.jobs.current = null;
      S.jobs.history = [...(S.jobs.history || []), d.job];
      paintQueue();
      if (d.job.status === 'loi') toast(`Lỗi: ${d.job.label} — ${friendly(d.job.error)}`, 'err');
      else if (d.job.status === 'xong') toast(`Xong: ${d.job.label}`, 'ok');
      const l = loaders[S.page];
      if (l) l().catch(() => {}); else render();
    }
  };
}

/* ══════════ PHIM TAT ══════════ */
/* ══════════ TAO ANH — bai dang Facebook ══════════ */
async function loadImages() {
  const [m, l] = await Promise.all([
    api('/image-post/models').catch(e => ({ models: [], _err: friendly(e.message) })),
    api('/image-post/list').catch(() => ({ images: [] })),
  ]);
  imgModels = m.models || [];
  imgStyles = m.styles || [];
  imgPlatforms = m.platforms || imgPlatforms;
  imgPurposes = m.purposes || imgPurposes;
  imgSizes = m.sizes || imgSizes;
  imgErr = m._err || null;
  imgList = l.images || [];
  if (!imgSel.style && imgStyles.length) imgSel.style = imgStyles[0].value;
  if (!imgSel.model && imgModels.length) {          // lan dau: dat mac dinh
    const d = m.default || {};
    imgSel.model = imgModels.find(x => x.model === d.model) ? d.model : imgModels[0].model;
    if (d.platform) imgSel.platform = d.platform;
    if (d.purpose) imgSel.purpose = d.purpose;
    applyModelDefaults(d);
  }
  render();
}
const imgCur = () => imgModels.find(m => m.model === imgSel.model) || null;
// Moi model co bo mode/resolution KHAC nhau -> doi model phai chon lai hop le.
function applyModelDefaults(d = {}) {
  const m = imgCur(); if (!m) return;
  const modes = m.modes.map(o => o.value), res = m.resolutions.map(o => o.value);
  imgSel.mode = modes.includes(d.mode) ? d.mode : (modes[0] || '');
  imgSel.resolution = res.includes(d.resolution) ? d.resolution
    : (res.includes('2k') ? '2k' : (res[0] || ''));
}
function imgCost() {
  const m = imgCur(); if (!m) return null;
  const hit = (m.prices || []).find(p => p.mode === imgSel.mode && p.resolution === imgSel.resolution);
  return hit ? hit.price : m.price;
}
function imgPickRef(input) {
  const f = input.files && input.files[0];
  if (!f) return;
  if (f.size > 8 * 1024 * 1024) return toast('Ảnh mẫu quá nặng (>8MB)', 'err');
  const r = new FileReader();
  r.onload = () => { imgRef = r.result; render(); };
  r.readAsDataURL(f);
}
function imgClearRef() { imgRef = null; render(); }
async function createImagePost() {
  const idea = (imgIdea || '').trim(), text = (imgText || '').trim();
  if (!idea && !imgRef) return toast('Nhập ý tưởng hoặc tải ảnh mẫu để AI tự phân tích', 'err');
  const body = { idea, text, style: imgSel.style, model: imgSel.model, mode: imgSel.mode,
                 resolution: imgSel.resolution, platform: imgSel.platform, purpose: imgSel.purpose,
                 ref: imgRef || null };
  const out = await act(() => api('/image-post/create', { method: 'POST', body }), 'Đã tạo ảnh');
  if (out) {
    imgResult = out;
    await api('/image-post/list').then(l => imgList = l.images || []).catch(() => {});
    render();
  }
}

function pgImages() {
  const m = imgCur(), cost = imgCost();
  const sel = (arr, cur) => (arr || []).map(o =>
    `<option value="${esc(o.value)}" ${o.value === cur ? 'selected' : ''}>${esc(o.label)}</option>`).join('');
  const modelOpts = imgModels.map(x =>
    `<option value="${esc(x.model)}" ${x.model === imgSel.model ? 'selected' : ''}>${esc(x.name)}</option>`).join('');
  const platOpts = imgPlatforms.map(p =>
    `<option value="${esc(p.value)}" ${p.value === imgSel.platform ? 'selected' : ''}>${esc(p.label)}</option>`).join('');
  const purpOpts = imgPurposes.map(p =>
    `<option value="${esc(p.value)}" ${p.value === imgSel.purpose ? 'selected' : ''}>${esc(p.label)}</option>`).join('');
  const szKey = `${imgSel.platform}_${imgSel.purpose}`, sz = imgSizes[szKey];
  const szTxt = sz ? `${sz[0]}×${sz[1]}px` : '';
  const styleOpts = imgStyles.map(s =>
    `<option value="${esc(s.value)}" ${s.value === imgSel.style ? 'selected' : ''}>${esc(s.label)}</option>`).join('');

  return `<div class="head"><h1>Tạo ảnh</h1>
    <span class="sub">tranh AI — để làm ảnh đại diện / ảnh đăng (có thể ghi chữ tiếng Việt lên)</span>
    <div class="right"><button class="btn" onclick="loadImages()">↻ Làm mới</button></div></div>
    ${imgErr ? `<div class="warn"><b>Không lấy được danh sách model 79AI.</b> ${esc(imgErr)}</div>` : ''}

    <div class="img-wrap">
      <div class="card">
        <label class="fld"><b>Ý tưởng tranh</b> <span class="mut">${imgRef
          ? '— đã có ảnh mẫu: <b>để TRỐNG cũng được, AI tự phân tích</b>'
          : '— tả cảnh muốn vẽ (nên tiếng Anh)'}</span></label>
        <textarea id="img-idea" rows="3" oninput="imgIdea=this.value"
          placeholder="${imgRef ? '(để trống — AI sẽ phân tích ảnh mẫu và vẽ lại)' : 'vd: chân dung một cô gái Việt mỉm cười / a smiling vietnamese girl portrait'}">${esc(imgIdea)}</textarea>

        <label class="fld"><b>Chữ ghi lên ảnh</b> <span class="mut">— tùy chọn · để TRỐNG nếu vẽ ảnh đại diện · giữ xuống dòng · KHÔNG vào tranh</span></label>
        <textarea id="img-text" rows="3" oninput="imgText=this.value"
          placeholder="(để trống = ảnh không chữ, hợp làm ảnh đại diện)">${esc(imgText)}</textarea>

        <label class="fld"><b>Ảnh mẫu</b> <span class="mut">— tải lên là AI TỰ phân tích rồi vẽ lại (bám nhân vật/bố cục) · khỏi gõ ý tưởng</span></label>
        <div class="img-ref">${imgRef
          ? `<img src="${imgRef}" class="img-refthumb" alt="ảnh mẫu"><button class="btn sm ghost" onclick="imgClearRef()">✕ Bỏ ảnh mẫu</button>`
          : `<input type="file" accept="image/*" onchange="imgPickRef(this)">`}</div>

        <div class="img-opts">
          ${imgStyles.length ? `<label>Loại ảnh
            <select onchange="imgSel.style=this.value;render()">${styleOpts}</select></label>` : ''}
          <label>Nền tảng
            <select onchange="imgSel.platform=this.value;render()">${platOpts}</select></label>
          <label>Mục đích${szTxt ? ` <span class="mut">· ${szTxt}</span>` : ''}
            <select onchange="imgSel.purpose=this.value;render()">${purpOpts}</select></label>
          <label>Model AI
            <select onchange="imgSel.model=this.value;applyModelDefaults();render()">${modelOpts}</select></label>
          ${m && m.modes.length ? `<label>Chế độ
            <select onchange="imgSel.mode=this.value;render()">${sel(m.modes, imgSel.mode)}</select></label>` : ''}
          ${m && m.resolutions.length ? `<label>Độ phân giải
            <select onchange="imgSel.resolution=this.value;render()">${sel(m.resolutions, imgSel.resolution)}</select></label>` : ''}
        </div>

        <div class="img-foot">
          <span class="mut">${cost != null ? `~${fmt(cost)} credit/ảnh` : ''}</span>
          <button class="btn primary" onclick="createImagePost()" ${imgModels.length ? '' : 'disabled'}>Tạo ảnh</button>
        </div>
        <div class="mut" style="margin-top:8px;font-size:12px">Chữ Việt do tool ghi (AI không vẽ chữ → không lỗi dấu). Ảnh mất ~10–60 giây.</div>
      </div>

      <div class="card img-preview">
        ${imgResult
          ? `<img src="${imgResult.url}?t=${Date.now()}" alt="ảnh vừa tạo">
             <div class="img-actions">
               <a class="btn sm" href="${imgResult.url}" download="${esc(imgResult.name)}">⬇ Tải ảnh</a>
               <button class="btn sm ghost" onclick="copy(location.origin+'${imgResult.url}','link ảnh')">Copy link</button>
             </div>`
          : empty('▨', 'Chưa có ảnh', 'Điền ý tưởng, chọn loại ảnh rồi bấm Tạo ảnh')}
      </div>
    </div>

    ${imgList.length ? `<div class="card"><h3>Ảnh đã tạo — ${imgList.length}</h3>
      <div class="img-gallery">${imgList.map(x =>
        `<a href="${x.url}" target="_blank" title="${esc(x.name)}"><img src="${x.url}" loading="lazy"></a>`).join('')}</div></div>` : ''}`;
}

/* ══════════ TẠO VIDEO AI ══════════ */
async function loadAiVideo() {
  const [m, l, sc] = await Promise.all([
    api('/ai-video/models').catch(e => ({ _err: friendly(e.message) })),
    api('/ai-video/list').catch(() => ({ videos: [] })),
    api('/ai-video/scripts').catch(() => ({ scripts: [] })),
  ]);
  avScripts = sc.scripts || [];
  avErr = m._err || null;
  if (!m._err) {
    avData = { video_models: m.video_models || [], image_models: m.image_models || [],
               eleven_voices: m.eleven_voices || [], omni_voices: m.omni_voices || [], music: m.music || [] };
    if (!avSel.vidModel && avData.video_models.length) {
      const d = m.default || {};
      avSel.imgModel = (avData.image_models.find(x => x.model === (d.image || {}).model) || avData.image_models[0] || {}).model || '';
      avSel.vidModel = avData.video_models[0].model;
      avSel.ratio = (d.ratio) || '9:16';
      avApplyImgDefaults(d.image || {});
      avApplyVidDefaults();
      const av0 = avAllVoices()[0];
      if (av0) avSel.voice = av0.key;
    }
  }
  avList = l.videos || [];
  avSummary = l.summary || null;
  if (avSummary) avBudget = { cap_month: avSummary.cap_month || 0, warn_pct: avSummary.warn_pct || 90 };
  // don id da tick khong con ton tai
  const ids = new Set(avList.map(v => v.id));
  avSelSet = new Set([...avSelSet].filter(id => ids.has(id)));
  render();
}
const avCurVid = () => avData.video_models.find(m => m.model === avSel.vidModel) || null;
const avCurImg = () => avData.image_models.find(m => m.model === avSel.imgModel) || null;
const avElevenId = v => (v.ref || '').replace(/^eleven:/, '') || v.voice_id || v.id || '';
// Danh sach giong gop CA 2 engine, khoa dang "eleven:<id>" / "omni:<profile>"
function avAllVoices() {
  return [
    ...(avData.eleven_voices || []).map(v => ({ key: 'eleven:' + avElevenId(v), label: '[Eleven] ' + (v.name || avElevenId(v)) })),
    ...(avData.omni_voices || []).map(v => ({ key: 'omni:' + v.profile_id, label: '[Omni] ' + (v.name || v.profile_id) })),
  ];
}
function avVoiceDict(key) {
  if (!key) return {};
  if (key.startsWith('eleven:')) return { engine: 'eleven', eleven_voice: key.slice(7) };
  if (key.startsWith('omni:')) return { engine: 'omnivoice', profile_id: key.slice(5) };
  return {};
}
function avVoiceKey(v) {
  if (!v) return '';
  if (v.eleven_voice) return 'eleven:' + v.eleven_voice;
  if (v.profile_id) return 'omni:' + v.profile_id;
  return '';
}
const avVoiceOpts = cur => avAllVoices().map(o =>
  `<option value="${esc(o.key)}" ${o.key === cur ? 'selected' : ''}>${esc(o.label)}</option>`).join('');
// Gia clip re nhat cua 1 model video (credit) — de hien "tu X/clip"
const avClipMin = m => { const ps = (m.prices || []).map(p => p.price).filter(x => x > 0); return ps.length ? Math.min(...ps) : (m.price || 0); };
const avVidOpts = cur => avData.video_models.map(m => {
  const c = avClipMin(m), tot = c * (avScenes.length || 1);
  return `<option value="${esc(m.model)}" ${m.model === cur ? 'selected' : ''}>${esc(m.name)} — ~${fmt(c)}cr/clip · ${fmt(tot)}cr/video</option>`;
}).join('');
function avApplyImgDefaults(d = {}) {
  const m = avCurImg(); if (!m) return;
  const modes = m.modes.map(o => o.value), res = m.resolutions.map(o => o.value);
  avSel.imgMode = modes.includes(d.mode) ? d.mode : (modes[0] || '');
  avSel.imgRes = res.includes(d.resolution) ? d.resolution : (res.includes('1k') ? '1k' : (res[0] || ''));
}
function avApplyVidDefaults() {
  const m = avCurVid(); if (!m) return;
  const modes = m.modes.map(o => o.value), res = m.resolutions.map(o => o.value);
  avSel.vidMode = modes[0] || '';
  avSel.vidRes = res[0] || '';
  // dat lai seconds cac canh ve moc hop le cua model nay
  const durs = m.durations.map(o => +o.value);
  if (durs.length) avScenes.forEach(s => { if (!durs.includes(+s.seconds)) s.seconds = durs[0]; });
}
function avSpec() {
  return {
    title: (avTitle || 'video-ai').trim(), ratio: avSel.ratio, audio_mode: avSel.audio,
    image: { model: avSel.imgModel, mode: avSel.imgMode, resolution: avSel.imgRes },
    video: { model: avSel.vidModel, mode: avSel.vidMode, resolution: avSel.vidRes },
    music: avSel.music, music_db: avSel.musicDb,
    voice: avSel.audio === 'voice' ? avVoiceDict(avSel.voice) : {},
    voice_speed: avSel.voiceSpeed,
    scenes: avScenes.map(s => ({
      prompt_img: (s.prompt_img || '').trim(), prompt_action: (s.prompt_action || '').trim(),
      narration: (s.narration || '').trim(), seconds: +s.seconds || 5,
    })),
  };
}
async function avEstimate() {
  const spec = avSpec();
  if (!spec.scenes.some(s => s.prompt_img)) return toast('Chưa có cảnh nào có mô tả tranh', 'err');
  const out = await act(() => api('/ai-video/estimate', { method: 'POST', body: spec }), '');
  if (out) { avEst = out; render(); }
}
async function avCreate() {
  const spec = avSpec();
  for (let i = 0; i < spec.scenes.length; i++)
    if (!spec.scenes[i].prompt_img) return toast(`Cảnh ${i + 1} chưa có mô tả tranh`, 'err');
  if (spec.audio_mode === 'voice' && !spec.voice.eleven_voice)
    return toast('Chế độ giọng: chưa chọn giọng ElevenLabs', 'err');
  if (!confirm(`Tạo video ${spec.scenes.length} cảnh` + (avEst ? ` (~${fmt(avEst.total)} credit)` : '') +
               `?\nVideo AI chạy chậm (vài phút/cảnh) — theo dõi ở hàng đợi.`)) return;
  const out = await act(() => api('/ai-video/create', { method: 'POST', body: spec }), 'Đã xếp việc — đang tạo');
  if (out) { avStatus = { id: out.id, done: false }; avPoll(out.id); render(); }
}
async function avPoll(id) {
  try {
    const s = await api('/ai-video/status/' + id);
    avStatus = s;
    if (s.done) { avList = (await api('/ai-video/list')).videos || []; render(); return; }
  } catch (e) {}
  if (avStatus && avStatus.id === id && !avStatus.done) setTimeout(() => avPoll(id), 8000);
  render();
}
async function avRegen(id, scene) {
  if (!confirm(`Tạo lại cảnh ${scene + 1}? (các cảnh khác giữ nguyên, không tốn thêm)`)) return;
  const out = await act(() => api(`/ai-video/regen/${id}/${scene}`, { method: 'POST' }), 'Đang tạo lại cảnh');
  if (out) { avStatus = { id, done: false }; avPoll(id); }
}
async function avUploadMusic(input) {
  if (!input.files || !input.files.length) return;
  const fd = new FormData();
  [...input.files].forEach(f => fd.append('files', f));
  const out = await act(async () => {
    const res = await fetch('/api/ai-video/music/upload', { method: 'POST', body: fd });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  }, 'Đã tải nhạc');
  if (out && out.saved && out.saved.length) {
    avData.music = [...new Set([...out.saved, ...avData.music])];
    avSel.music = out.saved[0];
    render();
  }
}
async function avExtractMusic(input) {
  if (!input.files || !input.files.length) return;
  const fd = new FormData();
  [...input.files].forEach(f => fd.append('files', f));
  const out = await act(async () => {
    const res = await fetch('/api/ai-video/music/extract', { method: 'POST', body: fd });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  }, 'Đã tách nhạc từ video');
  input.value = '';
  if (out) {
    (out.rejected || []).forEach(x => toast(`${x.name}: ${x.error}`, 'err'));
    if (out.saved && out.saved.length) {
      avData.music = [...new Set([...out.saved, ...avData.music])];
      avSel.music = out.saved[0];
      render();
    }
  }
}
async function avGenScript() {
  const theme = prompt('Chủ đề / ý tưởng (vd: ký ức tuổi thơ, người mẹ tảo tần)…');
  if (!theme || !theme.trim()) return;
  const n = Math.max(2, Math.min(parseInt(prompt('Số cảnh?', '8')) || 8, 15));
  const out = await act(() => api('/ai-video/gen-script', { method: 'POST', body: { theme: theme.trim(), n_scenes: n } }),
    'Đã tạo kịch bản — duyệt rồi bấm Tạo video');
  if (out && out.scenes && out.scenes.length) {
    avTitle = out.title || theme.trim();
    avScenes = out.scenes.map(s => ({ prompt_img: s.prompt_img, prompt_action: s.prompt_action, narration: s.narration, seconds: s.seconds || 5 }));
    avSel.audio = 'voice';
    avEst = null;
    render();
  }
}
async function avUseScript(id) {
  const s = await act(() => api('/ai-video/scripts/' + id), 'Đã nạp kịch bản — sửa rồi bấm Tạo video');
  if (s && s.scenes) {
    avTitle = s.title || '';
    avScenes = s.scenes.map(x => ({ prompt_img: x.prompt_img, prompt_action: x.prompt_action, narration: x.narration, seconds: x.seconds || 5 }));
    avSel.audio = 'voice'; avEst = null; render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
async function avDelScript(id) {
  if (!confirm('Xóa kịch bản này khỏi danh sách?')) return;
  await act(() => api('/ai-video/scripts/' + id, { method: 'DELETE' }), 'Đã xóa');
  avScripts = avScripts.filter(s => s.id !== id); render();
}
function avAddScene() { avScenes.push({ prompt_img: '', prompt_action: '', narration: '', seconds: avScenes.at(-1)?.seconds || 5 }); avEst = null; render(); }
function avDelScene(i) { avScenes.splice(i, 1); if (!avScenes.length) avAddScene(); else { avEst = null; render(); } }

function avSetTab(t) { avTab = t; render(); }

function pgAiVideo() {
  const tab = (id, label) => `<div class="tab ${avTab === id ? 'on' : ''}" onclick="avSetTab('${id}')">${label}</div>`;
  const body = avTab === 'batch' ? avPageBatch()
             : avTab === 'cfg' ? avPageCfg()
             : avPageOver();
  return `<div class="head"><h1>Tạo video AI</h1>
      <span class="sub">quản lý &amp; dựng hàng loạt · montage i2v dọc 9:16</span>
      <div class="right">
        <button class="btn ghost" onclick="loadAiVideo()">↻ Làm mới</button>
        <button class="btn primary" onclick="avSetTab('batch')">＋ Mẻ mới</button></div></div>
    ${avErr ? `<div class="warn"><b>Không lấy được model 79AI.</b> ${esc(avErr)}</div>` : ''}
    <div class="tabs">
      ${tab('over', 'Bảng điều khiển')}
      ${tab('batch', 'Mẻ mới')}
      ${tab('cfg', 'Preset &amp; Ngân sách')}
    </div>
    ${body}`;
}

// ---------- TAB: BẢNG ĐIỀU KHIỂN (Overview) ----------
const AV_ST = {
  done:     { c: 'done',  t: 'Xong' },
  building: { c: 'run',   t: 'Đang dựng' },
  error:    { c: 'err',   t: 'Lỗi' },
  draft:    { c: 'draft', t: 'Nháp' },
};
function avFilteredList() {
  const q = avSearch.trim().toLowerCase();
  return avList.filter(v =>
    (avFilter === 'all' || v.status === avFilter) &&
    (!q || (v.title || v.id).toLowerCase().includes(q)));
}
function avProgDots(v) {
  if (v.status === 'draft') return `<span class="mut" style="font-size:12px">chưa dựng</span>`;
  const n = v.n_scenes || 0, dn = v.n_clip || 0;
  let dots = '';
  for (let i = 0; i < n; i++) {
    if (i < dn) dots += `<span class="sdot ok">✓</span>`;
    else if (v.status === 'error' && i === dn) dots += `<span class="sdot err">!</span>`;
    else dots += `<span class="sdot">·</span>`;
  }
  return `<div class="dots">${dots}<span class="pnum">${dn}/${n}</span></div>`;
}
const AV_STEMO = { done: '🎬', building: '⏳', error: '⚠️', draft: '📝' };
function avThumb(v) {
  if (v.done && v.url)
    return `<div class="avthumb" onclick="avPlay('${esc(v.id)}')" title="Xem video">
      <video src="${v.url}#t=0.6" preload="metadata" muted></video><span class="avplay">▶</span></div>`;
  return `<div class="avthumb none" title="${(AV_ST[v.status] || {}).t || ''}">${AV_STEMO[v.status] || '🎞️'}</div>`;
}
function avRowActions(v) {
  if (v.done) return `<button class="btn xs ghost" onclick="avPlay('${esc(v.id)}')" title="Xem">▶</button>
    <a class="btn xs ghost" href="${v.url}" download="${esc(v.title || v.id)}.mp4" title="Tải">⬇</a>
    <button class="btn xs ghost" onclick="avOpenEdit('${esc(v.id)}')" title="Sửa giọng/nhạc">✎</button>
    <button class="btn xs ghost" onclick="avCaption('${esc(v.id)}')" title="${v.caption ? 'Tạo lại tus' : 'Tạo tus đăng'}">✍</button>`;
  return `<button class="btn xs ghost" onclick="avResume('${esc(v.id)}')" title="Tiếp tục dựng">▶ Tiếp</button>
    <button class="btn xs ghost" onclick="avOpenEdit('${esc(v.id)}')" title="Sửa">✎</button>`;
}
function avPlay(id) {
  const v = avList.find(x => x.id === id);
  if (!v || !v.url) return;
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.onclick = e => { if (e.target === bg) bg.remove(); };
  bg.innerHTML = `<div class="avplayer">
    <div class="avplayer-h"><b>${esc(v.title || id)}</b>
      <button class="btn xs ghost" onclick="this.closest('.modal-bg').remove()">✕ Đóng</button></div>
    <video src="${v.url}" controls autoplay playsinline></video>
    <div class="avplayer-a">
      <span class="mut" style="font-size:12px">${v.n_scenes} cảnh · ${esc(v.created || '')}${v.credit != null ? ' · ~' + fmt(v.credit) + ' cr' : ''}</span>
      <a class="btn xs" href="${v.url}" download="${esc(v.title || id)}.mp4">⬇ Tải MP4</a></div>
  </div>`;
  document.body.appendChild(bg);
}
function avVideoRow(v, indent) {
  const st = AV_ST[v.status] || AV_ST.draft;
  const sel = avSelSet.has(v.id);
  const meta = [
    `${v.n_scenes} cảnh`,
    v.audio_mode === 'voice' ? 'giọng' : (v.music ? 'nhạc' : 'không tiếng'),
    v.video_model || '',
  ].filter(Boolean).join(' · ');
  const clickTitle = v.done ? `onclick="avPlay('${esc(v.id)}')" style="cursor:pointer"` : '';
  const rowHtml = `<tr class="${sel ? 'sel' : ''}">
    <td class="col-chk"><input type="checkbox" ${sel ? 'checked' : ''} onclick="avSelToggle('${esc(v.id)}')"></td>
    <td class="col-thumb ${indent ? 'indent' : ''}">${avThumb(v)}</td>
    <td><div class="vtitle" ${clickTitle}>${esc(v.title || v.id)}</div><div class="vmeta">${esc(meta)}</div></td>
    <td><span class="tag ${st.c}">${st.t}</span></td>
    <td>${avProgDots(v)}</td>
    <td class="col-cr">${v.credit == null ? '—' : fmt(v.credit)}</td>
    <td class="col-date">${esc(v.created || '')}</td>
    <td class="col-act">${avRowActions(v)}</td></tr>`;
  const editRow = avEditId === v.id
    ? `<tr class="editrow"><td></td><td colspan="7">${avEditPanel()}</td></tr>` : '';
  const capRow = (v.done && v.caption)
    ? `<tr class="caprow"><td></td><td colspan="7"><div class="av-cap"><div class="av-cap-t">${esc(v.caption)}</div>
        <button class="btn xs primary" onclick="copy(${JSON.stringify(v.caption)},'tus đăng')">📋 Copy tus</button></div></td></tr>` : '';
  return rowHtml + editRow + capRow;
}
function avBatchHeaderRow(batch, kids, closed) {
  const done = kids.filter(k => k.status === 'done').length;
  const err = kids.some(k => k.status === 'error');
  const run = kids.some(k => k.status === 'building');
  const st = err ? AV_ST.error : run ? AV_ST.building : done === kids.length ? AV_ST.done : AV_ST.draft;
  const total = kids.reduce((a, k) => a + (k.credit || 0), 0);
  let when = '';
  const ms = parseInt((batch || '').replace(/^b/, ''), 10);
  if (ms) { const d = new Date(ms); when = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`; }
  const allSel = kids.every(k => avSelSet.has(k.id));
  return `<tr class="batchrow ${closed ? 'closed' : ''}">
    <td class="col-chk"><input type="checkbox" ${allSel ? 'checked' : ''} onclick="avSelBatch('${esc(batch)}',this.checked)"></td>
    <td class="col-thumb"><span class="caret" onclick="avToggleGroup('${esc(batch)}')">▾</span></td>
    <td><div class="vtitle bname" onclick="avToggleGroup('${esc(batch)}')" style="cursor:pointer">Mẻ · ${kids.length} video</div>
      <div class="vmeta">${when ? when + ' · ' : ''}tạo hàng loạt</div></td>
    <td><span class="tag ${st.c}">${st.t}</span></td>
    <td><span class="mut" style="font-size:12px">${done}/${kids.length} xong</span></td>
    <td class="col-cr">${fmt(total)}</td>
    <td class="col-date"></td>
    <td class="col-act"></td></tr>`;
}
function avToggleGroup(b) { avBatchClosed.has(b) ? avBatchClosed.delete(b) : avBatchClosed.add(b); render(); }
function avSelBatch(b, on) {
  avList.filter(v => v.batch === b).forEach(v => on ? avSelSet.add(v.id) : avSelSet.delete(v.id));
  render();
}
function avPageOver() {
  const s = avSummary || { total: 0, counts: {}, spent_month: 0, cap_month: 0, warn_pct: 90 };
  const c = s.counts || {};
  const cap = s.cap_month || 0, spent = s.spent_month || 0;
  const pct = cap ? Math.min(100, Math.round(spent / cap * 100)) : 0;
  const meterCls = !cap ? '' : pct >= 100 ? 'crit' : pct >= (s.warn_pct || 90) ? 'warn' : '';
  const budgetCard = cap
    ? `<div class="big">${fmt(spent)} <small>/ ${fmt(cap)} credit</small></div>
       <div class="meter"><i class="${meterCls}" style="width:${pct}%"></i></div>
       <div class="mut" style="font-size:12px;margin-top:7px">Còn <b>${fmt(Math.max(0, cap - spent))} cr</b> · ước tính đã tiêu tháng này</div>`
    : `<div class="big" style="font-size:16px;color:var(--ink-3)">Chưa đặt hạn mức</div>
       <div class="mut" style="font-size:12px;margin-top:7px">Vào <a href="#" onclick="avSetTab('cfg');return false">Ngân sách</a> để đặt cap tháng</div>`;

  const chip = (f, label, n) => `<span class="avchip ${avFilter === f ? 'on' : ''}" onclick="avFilter='${f}';render()">${label} <span class="c">${n}</span></span>`;

  // Gom theo me: video co `batch` xep duoi 1 hang cha (gap/mo); video le hien thang.
  const list = avFilteredList();
  const seen = new Set();
  const rows = list.map(v => {
    if (!v.batch) return avVideoRow(v, false);
    if (seen.has(v.batch)) return '';
    seen.add(v.batch);
    const kids = list.filter(x => x.batch === v.batch);
    const closed = avBatchClosed.has(v.batch);
    const kidRows = closed ? '' : kids.map(k => avVideoRow(k, true)).join('');
    return avBatchHeaderRow(v.batch, kids, closed) + kidRows;
  }).join('');

  const nsel = avSelSet.size;
  return `
    <div class="summary">
      <div class="card"><div class="lab">Ngân sách 79AI — tháng này</div>${budgetCard}</div>
      <div class="card"><div class="lab">Trạng thái</div>
        <div class="kpi-row">
          <div class="kpi"><div class="n g">${c.done || 0}</div><div class="t">Xong</div></div>
          <div class="kpi"><div class="n b">${c.building || 0}</div><div class="t">Đang dựng</div></div>
          <div class="kpi"><div class="n r">${c.error || 0}</div><div class="t">Lỗi</div></div>
          <div class="kpi"><div class="n">${c.draft || 0}</div><div class="t">Nháp</div></div>
        </div></div>
      <div class="card"><div class="lab">Tổng video</div><div class="big">${s.total || 0}</div>
        <div class="mut" style="font-size:12px;margin-top:7px">${avScripts.length} kịch bản đã tạo</div></div>
    </div>

    <div class="toolbar">
      <div class="chips">
        ${chip('all', 'Tất cả', s.total || 0)}
        ${chip('building', 'Đang dựng', c.building || 0)}
        ${chip('done', 'Xong', c.done || 0)}
        ${chip('error', 'Lỗi', c.error || 0)}
        ${chip('draft', 'Nháp', c.draft || 0)}
      </div>
      <div class="search"><span class="ico">🔍</span>
        <input placeholder="Tìm theo tên video…" value="${esc(avSearch)}"
          oninput="avSearch=this.value;render()"></div>
    </div>

    ${nsel ? `<div class="bulk"><span class="bn">${nsel} đã chọn</span>
      <div class="right">
        <button class="btn xs" onclick="avBulkResume()">↻ Dựng lại</button>
        <button class="btn xs red" onclick="avBulkDelete()">✕ Xoá</button>
        <button class="btn xs ghost" onclick="avSelSet=new Set();render()">Bỏ chọn</button>
      </div></div>` : ''}

    <div class="tablewrap"><div class="tscroll">
      <table><thead><tr>
        <th class="col-chk"><input type="checkbox" ${avSelSet.size && avSelSet.size === avFilteredList().length ? 'checked' : ''} onclick="avSelAllVisible(this)"></th>
        <th class="col-thumb"></th>
        <th>Video</th><th>Trạng thái</th><th>Tiến độ cảnh</th>
        <th class="col-cr">Credit</th><th class="col-date">Ngày</th><th class="col-act">Thao tác</th>
      </tr></thead>
      <tbody>${rows || `<tr><td colspan="8" class="mut" style="text-align:center;padding:26px">Chưa có video nào khớp bộ lọc. Bấm <b>＋ Mẻ mới</b> để tạo.</td></tr>`}</tbody></table>
    </div></div>`;
}
function avSelToggle(id) { avSelSet.has(id) ? avSelSet.delete(id) : avSelSet.add(id); render(); }
function avSelAllVisible(cb) {
  const vis = avFilteredList().map(v => v.id);
  if (cb.checked) vis.forEach(id => avSelSet.add(id));
  else vis.forEach(id => avSelSet.delete(id));
  render();
}
async function avBulkDelete() {
  const ids = [...avSelSet];
  if (!ids.length) return;
  if (!confirm(`Xoá hẳn ${ids.length} video đã chọn? Không khôi phục được.`)) return;
  await api('/ai-video/delete', { method: 'POST', body: { ids } }).catch(e => alert(friendly(e.message)));
  avSelSet = new Set();
  await loadAiVideo();
}
async function avBulkResume() {
  const ids = [...avSelSet].filter(id => { const v = avList.find(x => x.id === id); return v && !v.done; });
  if (!ids.length) { alert('Không có video dở nào trong danh sách chọn.'); return; }
  for (const id of ids) await avResume(id);
  avSelSet = new Set(); render();
}

// ---------- TAB: PRESET & NGÂN SÁCH ----------
function avPageCfg() {
  const b = avBudget;
  return `<div class="card" style="max-width:560px">
      <h3 style="margin-top:0">Ngân sách 79AI</h3>
      <div class="mut" style="font-size:13px;margin-bottom:14px">Đặt trần credit mỗi tháng. Bảng điều khiển sẽ hiện meter + cảnh báo.
        <b>Đây là tuyến phòng thủ chính chống đốt tiền khi tạo hàng loạt.</b></div>
      <div class="av-row">
        <label>Hạn mức tháng (credit)
          <input type="number" min="0" step="1000" value="${b.cap_month || 0}"
            oninput="avBudget.cap_month=+this.value" style="width:140px"></label>
        <label>Cảnh báo khi đạt (%)
          <input type="number" min="50" max="100" value="${b.warn_pct || 90}"
            oninput="avBudget.warn_pct=+this.value" style="width:90px"></label>
      </div>
      <div style="margin-top:14px"><button class="btn primary" onclick="avSaveBudget()">Lưu ngân sách</button>
        <span class="mut" id="avBudgetMsg" style="margin-left:10px;font-size:12px"></span></div>
    </div>
    <div class="card" style="max-width:560px;margin-top:14px">
      <h3 style="margin-top:0">Preset phong cách <span class="tag draft" style="font-weight:600">sắp có</span></h3>
      <div class="mut" style="font-size:13px">Gói style tái dùng (model ảnh/video, giọng, nhạc, tỉ lệ, số cảnh) để tạo mẻ hàng loạt
        không phải khai lại từng video — Pha 2.</div>
    </div>`;
}
async function avSaveBudget() {
  const out = await api('/ai-video/budget', { method: 'POST', body: { cap_month: avBudget.cap_month, warn_pct: avBudget.warn_pct } })
    .catch(e => { alert(friendly(e.message)); return null; });
  if (out) {
    avBudget = { cap_month: out.cap_month, warn_pct: out.warn_pct };
    const el = document.getElementById('avBudgetMsg');
    if (el) el.textContent = '✓ Đã lưu';
    await loadAiVideo();
  }
}

// ---------- MẺ HÀNG LOẠT (Pha 2) ----------
function avBatchThemes() {
  if (avBatchMode === 'paste')
    return avBatchText.split('\n').map(s => s.trim()).filter(Boolean);
  const t = avBatchTheme.trim();
  return t ? Array(Math.max(1, Math.min(20, avBatchN))).fill(t) : [];
}
async function avBatchGen() {
  const themes = avBatchThemes();
  if (!themes.length) { toast('Chưa nhập chủ đề / danh sách đề.', 'warn'); return; }
  if (avBatchMode === 'auto' && themes.length > 20) { toast('Tối đa 20 video/mẻ.', 'warn'); return; }
  avBatchBusy = true; avBatchScripts = []; render();
  const style = avBatchStyleSpec();
  for (let i = 0; i < themes.length; i++) {
    avBatchProg = `${i + 1}/${themes.length}`; render();
    try {
      const doc = await api('/ai-video/gen-script', { method: 'POST', body: { theme: themes[i], n_scenes: avBatchNScenes } });
      let credit = null;
      try { credit = (await api('/ai-video/estimate', { method: 'POST', body: { ...style, scenes: doc.scenes } })).total; } catch (e) {}
      avBatchScripts.push({ id: doc.id, title: doc.title, character: doc.character || '',
        theme: themes[i], scenes: doc.scenes, approved: true, credit });
    } catch (e) {
      avBatchScripts.push({ id: 'err_' + i, title: `⚠ Lỗi: ${themes[i].slice(0, 40)}`, scenes: [],
        approved: false, credit: null, error: friendly(e.message) });
    }
    render();
  }
  avBatchBusy = false; avBatchProg = ''; render();
}
// Spec style dung chung cho ca me (khong gom scenes)
function avBatchStyleSpec() {
  return {
    ratio: avSel.ratio || '9:16', audio_mode: avSel.audio,
    image: { model: avSel.imgModel, mode: avSel.imgMode, resolution: avSel.imgRes },
    video: { model: avSel.vidModel, mode: avSel.vidMode, resolution: avSel.vidRes },
    music: avSel.music || '', music_db: avSel.musicDb,
    voice: avSel.audio === 'voice' ? avVoiceDict(avSel.voice) : {},
    voice_speed: avSel.voiceSpeed || 1.0,
  };
}
function avBatchToggle(i) { avBatchScripts[i].approved = !avBatchScripts[i].approved; render(); }
function avBatchRemove(i) { avBatchScripts.splice(i, 1); render(); }
function avBatchEditItem(i) {
  const s = avBatchScripts[i]; if (!s || !s.scenes.length) return;
  avTitle = s.title;
  avScenes = s.scenes.map(x => ({ prompt_img: x.prompt_img || '', prompt_action: x.prompt_action || '',
    narration: x.narration || '', seconds: x.seconds || 5 }));
  avEst = null;
  toast('Đã đổ kịch bản xuống khu soạn cảnh bên dưới — sửa rồi bấm "Tạo video".', 'ok');
  render();
}
const avBatchApproved = () => avBatchScripts.filter(s => s.approved && s.scenes.length);
const avBatchTotal = () => avBatchApproved().reduce((a, s) => a + (s.credit || 0), 0);
async function avBatchBuildAll() {
  const list = avBatchApproved();
  if (!list.length) { toast('Chưa có kịch bản nào được duyệt.', 'warn'); return; }
  const total = avBatchTotal();
  const cap = (avSummary || {}).cap_month || 0, spent = (avSummary || {}).spent_month || 0;
  if (cap > 0 && spent + total > cap) {
    alert(`Vượt ngân sách: đã tiêu ~${fmt(spent)} + mẻ này ~${fmt(total)} > hạn mức ${fmt(cap)} credit.\n` +
      `Bỏ bớt kịch bản, hoặc tăng hạn mức ở tab Ngân sách.`);
    return;
  }
  if (!confirm(`Dựng ${list.length} video (tổng ~${fmt(total)} credit)? Sẽ chạy lần lượt qua hàng đợi.`)) return;
  const batchId = 'b' + Date.now();
  const style = avBatchStyleSpec();
  avBatchBusy = true; render();
  let ok = 0;
  for (let i = 0; i < list.length; i++) {
    avBatchProg = `dựng ${i + 1}/${list.length}`; render();
    try {
      await api('/ai-video/create', { method: 'POST', body: { ...style, title: list[i].title, batch: batchId, scenes: list[i].scenes } });
      ok++;
    } catch (e) { toast(`Lỗi dựng "${list[i].title}": ${friendly(e.message)}`, 'err'); }
  }
  avBatchBusy = false; avBatchProg = ''; avBatchScripts = [];
  toast(`Đã đưa ${ok}/${list.length} video vào hàng đợi.`, 'ok');
  await loadAiVideo();
  avSetTab('over');
}
function avBatchCard() {
  const seg = (m, label) => `<button class="btn sm ${avBatchMode === m ? 'primary' : 'ghost'}" onclick="avBatchMode='${m}';render()">${label}</button>`;
  const total = avBatchTotal(), nap = avBatchApproved().length;
  const cap = (avSummary || {}).cap_month || 0, spent = (avSummary || {}).spent_month || 0;
  const over = cap > 0 && spent + total > cap;
  const reviewHtml = avBatchScripts.map((s, i) => `
    <div class="bx-item ${s.approved ? 'on' : ''} ${s.error ? 'err' : ''}">
      <label class="bx-chk"><input type="checkbox" ${s.approved ? 'checked' : ''} ${s.error ? 'disabled' : ''}
        onchange="avBatchToggle(${i})"></label>
      <div class="bx-info"><b>${esc(s.title)}</b>
        <span class="mut" style="font-size:11px">${s.error ? esc(s.error) : `${s.scenes.length} cảnh${s.credit != null ? ' · ~' + fmt(s.credit) + ' cr' : ''}${s.character ? ' · nhân vật khoá' : ''}`}</span></div>
      <div class="bx-act">
        ${!s.error ? `<button class="btn xs ghost" onclick="avBatchEditItem(${i})" title="Sửa tay khu dưới">✎ Sửa</button>` : ''}
        <button class="btn xs ghost red" onclick="avBatchRemove(${i})" title="Bỏ">✕</button></div>
    </div>`).join('');

  return `<div class="card bx">
    <div class="bx-h"><h3>Mẻ hàng loạt <span class="mut" style="font-weight:400;font-size:12px">— sinh nhiều kịch bản → duyệt → dựng tất cả</span></h3></div>
    <div class="bx-src">
      <div class="seg">${seg('auto', '🤖 Tự sinh đề')} ${seg('paste', '📋 Dán danh sách')}</div>
      ${avBatchMode === 'auto'
      ? `<div class="av-row" style="margin-top:8px">
          <label style="flex:1">Chủ đề kênh
            <input placeholder="vd: hoài niệm tuổi thơ làng quê Việt" value="${esc(avBatchTheme)}" oninput="avBatchTheme=this.value"></label>
          <label>Số video<input type="number" min="1" max="20" value="${avBatchN}" oninput="avBatchN=+this.value" style="width:70px"></label>
          <label>Cảnh/video<input type="number" min="3" max="12" value="${avBatchNScenes}" oninput="avBatchNScenes=+this.value" style="width:80px"></label>
        </div>`
      : `<div style="margin-top:8px"><label>Danh sách đề — mỗi dòng 1 video
          <textarea rows="4" placeholder="Chiếc đèn dầu ngày ấy&#10;Con đường làng tan học&#10;Bức thư tay không gửi" oninput="avBatchText=this.value">${esc(avBatchText)}</textarea></label>
          <label style="margin-top:6px">Cảnh/video<input type="number" min="3" max="12" value="${avBatchNScenes}" oninput="avBatchNScenes=+this.value" style="width:80px"></label></div>`}
      <div style="margin-top:8px;display:flex;align-items:center;gap:10px">
        <button class="btn primary" onclick="avBatchGen()" ${avBatchBusy ? 'disabled' : ''}>✨ Sinh kịch bản</button>
        ${avBatchBusy ? `<span class="mut">⏳ đang sinh ${esc(avBatchProg)}…</span>`
          : `<span class="mut" style="font-size:12px">Sinh xong duyệt bên dưới — CHƯA tốn credit (chỉ token AI). Dựng mới tốn.</span>`}
      </div>
    </div>
    ${avBatchScripts.length ? `
      <div class="bx-review">
        <div class="bx-review-h"><b>Cổng duyệt — ${nap}/${avBatchScripts.length} kịch bản</b>
          <span class="mut" style="font-size:12px">bỏ tick để loại; ✎ Sửa để chỉnh tay</span></div>
        ${reviewHtml}
        <div class="bx-foot ${over ? 'over' : ''}">
          <div>Tổng đã duyệt: <b>${fmt(total)} credit</b> / ${nap} video
            ${cap > 0 ? `<span class="mut">· đã tiêu ~${fmt(spent)} / hạn mức ${fmt(cap)}${over ? ' ⚠ VƯỢT' : ''}</span>` : ''}</div>
          <button class="btn primary" onclick="avBatchBuildAll()" ${avBatchBusy || !nap || over ? 'disabled' : ''}>
            ${over ? 'Vượt ngân sách' : `Duyệt &amp; dựng ${nap} video`}</button>
        </div>
      </div>` : ''}
  </div>`;
}

// ---------- TAB: MẺ MỚI (composer thủ công 1 video) ----------
function avPageBatch() {
  const opt = (arr, cur) => (arr || []).map(o =>
    `<option value="${esc(o.value)}" ${o.value === cur ? 'selected' : ''}>${esc(o.label)}</option>`).join('');
  const vm = avCurVid(), im = avCurImg();
  const durs = vm ? vm.durations : [];
  const voice = avSel.audio === 'voice';

  const modelOpts = (arr, key, cur) => arr.map(x =>
    `<option value="${esc(x.model)}" ${x.model === cur ? 'selected' : ''}>${esc(x.name)}</option>`).join('');

  const scenesHtml = avScenes.map((s, i) => `
    <div class="av-scene">
      <div class="av-scene-h"><b>Cảnh ${i + 1}</b>
        <div class="right">
          ${avStatus && avStatus.done && avStatus.id ? `<button class="btn xs ghost" onclick="avRegen('${avStatus.id}',${i})">↻ tạo lại</button>` : ''}
          <button class="btn xs ghost" onclick="avDelScene(${i})" ${avScenes.length <= 1 ? 'disabled' : ''}>✕</button></div>
      </div>
      <textarea rows="2" placeholder="Mô tả TRANH (nên tiếng Anh): a boy running after chicks in a village yard, golden light"
        oninput="avScenes[${i}].prompt_img=this.value;avEst=null">${esc(s.prompt_img)}</textarea>
      <textarea rows="1" placeholder="Mô tả CHUYỂN ĐỘNG (i2v): the boy runs forward, chicks scatter, gentle camera follow"
        oninput="avScenes[${i}].prompt_action=this.value">${esc(s.prompt_action)}</textarea>
      ${voice
        ? `<textarea rows="2" placeholder="Lời đọc cảnh này (tiếng Việt)…"
             oninput="avScenes[${i}].narration=this.value;avEst=null">${esc(s.narration)}</textarea>`
        : `<label class="av-sec">Độ dài <select onchange="avScenes[${i}].seconds=+this.value;avEst=null;render()">
             ${durs.map(d => `<option value="${d.value}" ${+s.seconds === +d.value ? 'selected' : ''}>${esc(d.label)}</option>`).join('')}
           </select></label>`}
    </div>`).join('');

  const estHtml = avEst ? `<span class="mut">~${fmt(avEst.total)} credit cho ${avEst.per_scene.length} cảnh</span>`
    : `<span class="mut">bấm Ước tính để xem chi phí</span>`;

  let statusHtml = '';
  if (avStatus) {
    if (avStatus.done) statusHtml = `<div class="ok-line">✓ Xong. <a href="${avStatus.url}" target="_blank">mở video</a></div>`;
    else {
      const scs = (avStatus.state && avStatus.state.scenes) || [];
      const done = scs.filter(s => s.status === 'xong').length;
      const prog = scs.map(s => {
        const cls = s.status === 'xong' ? 'ok' : s.status === 'loi' ? 'err' : s.percent ? 'run' : 'wait';
        return `<span class="av-dot ${cls}" title="cảnh ${s.i + 1}: ${s.status}${s.percent ? ' ' + s.percent + '%' : ''}">${s.status === 'xong' ? '✓' : s.percent ? s.percent : '·'}</span>`;
      }).join('');
      statusHtml = `<div class="run-line">⏳ Đang tạo… ${done}/${avScenes.length} cảnh xong ${prog}
        <div class="mut" style="margin-top:4px;font-size:11px">Video AI chậm (vài phút–chục phút/clip khi 79ai tải nặng). Cứ để chạy, đóng trình duyệt cũng được — xem hàng đợi.</div></div>`;
    }
  }

  return `
    ${avBatchCard()}
    <div class="av-wrap">
      <div class="card av-cfg">
        <input class="av-title" placeholder="Tên video (vd: Hành trình tuổi thơ)" value="${esc(avTitle)}"
          oninput="avTitle=this.value">

        <div class="av-row">
          <label>Kiểu ảnh (khung đầu)
            <select onchange="avSel.imgModel=this.value;avApplyImgDefaults();avEst=null;render()">${modelOpts(avData.image_models, 'img', avSel.imgModel)}</select></label>
          ${im && im.modes.length ? `<label>Chế độ ảnh<select onchange="avSel.imgMode=this.value;avEst=null;render()">${opt(im.modes, avSel.imgMode)}</select></label>` : ''}
          ${im && im.resolutions.length ? `<label>Nét ảnh<select onchange="avSel.imgRes=this.value;avEst=null;render()">${opt(im.resolutions, avSel.imgRes)}</select></label>` : ''}
        </div>

        <div class="av-row">
          <label>Model video <span class="mut" style="font-size:11px">— giá credit/clip · /video (${avScenes.length} cảnh)</span>
            <select onchange="avSel.vidModel=this.value;avApplyVidDefaults();avEst=null;render()">${avVidOpts(avSel.vidModel)}</select></label>
          ${vm && vm.modes.length ? `<label>Chế độ<select onchange="avSel.vidMode=this.value;avEst=null;render()">${opt(vm.modes, avSel.vidMode)}</select></label>` : ''}
          ${vm && vm.resolutions.length ? `<label>Độ phân giải<select onchange="avSel.vidRes=this.value;avEst=null;render()">${opt(vm.resolutions, avSel.vidRes)}</select></label>` : ''}
        </div>

        <div class="av-row">
          <label>Âm thanh
            <select onchange="avSel.audio=this.value;avEst=null;render()">
              <option value="music" ${!voice ? 'selected' : ''}>Chỉ nhạc nền</option>
              <option value="voice" ${voice ? 'selected' : ''}>Giọng đọc + nhạc</option>
            </select></label>
          ${voice ? (avAllVoices().length ? `<label>Giọng đọc
            <select onchange="avSel.voice=this.value">${avVoiceOpts(avSel.voice)}</select></label>`
            : `<label>Giọng đọc<span class="mut" style="font-size:12px">— chưa có giọng nào. Vào <a href="#" onclick="go('voices');return false">Kho giọng</a> tick giọng (Eleven hoặc OmniVoice).</span></label>`) : ''}
          ${voice ? `<label>Tốc độ đọc<select onchange="avSel.voiceSpeed=+this.value">${avSpeedOpts(avSel.voiceSpeed)}</select></label>` : ''}
          <label class="av-upl">＋ tải nhạc<input type="file" accept="audio/*" multiple hidden onchange="avUploadMusic(this)"></label>
          <label class="av-upl">🎬 tách nhạc từ video<input type="file" accept="video/*" multiple hidden onchange="avExtractMusic(this)"></label>
          <label>Âm lượng nhạc<select onchange="avSel.musicDb=+this.value">${avMusicDbOpts(avSel.musicDb)}</select></label>
        </div>
        <div class="av-music">
          <div class="av-music-h"><b>Nhạc nền</b> <span class="mut">— bấm ▶ nghe thử, chọn 1</span></div>
          <label class="av-mtrack ${avSel.music === '' ? 'on' : ''}">
            <input type="radio" name="avmusic" ${avSel.music === '' ? 'checked' : ''} onchange="avSel.music='';render()">
            <span class="av-mname">— Không nhạc —</span></label>
          ${avData.music.length ? avData.music.map(n => `
            <label class="av-mtrack ${n === avSel.music ? 'on' : ''}">
              <input type="radio" name="avmusic" ${n === avSel.music ? 'checked' : ''} onchange="avSel.music='${esc(n)}';render()">
              <button type="button" class="pbtn" onclick="event.preventDefault();playUrl('/media/music/${encodeURIComponent(n)}',this)" title="Nghe thử">▶</button>
              <span class="av-mname">${esc(n)}</span></label>`).join('')
            : '<div class="mut" style="font-size:12px;padding:4px 2px">Chưa có nhạc. Bấm "＋ tải nhạc" để thêm.</div>'}
        </div>
        <div class="mut" style="font-size:12px">i2v: 79AI vẽ ảnh khung đầu rồi cho chuyển động. Chữ Việt không nhúng (AI không vẽ chữ). Chế độ giọng: độ dài mỗi cảnh tự khớp lời đọc.</div>
      </div>

      <div class="card av-scenes">
        <div class="av-scenes-h"><h3>Cảnh — ${avScenes.length}</h3>
          <div style="display:flex;gap:6px">
            <button class="btn sm" onclick="avGenScript()">✨ Tạo kịch bản tự động</button>
            <button class="btn sm" onclick="avAddScene()">＋ Thêm cảnh</button></div></div>
        ${scenesHtml}
        <div class="av-foot">
          ${estHtml}
          <div class="right">
            <button class="btn ghost" onclick="avEstimate()">Ước tính</button>
            <button class="btn primary" onclick="avCreate()" ${avData.video_models.length ? '' : 'disabled'}>Tạo video</button>
          </div>
        </div>
        ${statusHtml}
      </div>
    </div>

    ${avScripts.length ? `<div class="card"><h3>Kịch bản đã tạo — ${avScripts.length}</h3>
      <div class="mut" style="font-size:12px;margin-bottom:8px">Bấm "Dùng lại" để đổ vào bảng soạn cảnh (chưa tốn tiền — chỉ tạo video mới tốn).</div>
      <div class="scrlist">${avScripts.map(s => `
        <div class="scrrow">
          <div class="scrinfo"><b>${esc(s.title)}</b>
            <span class="mut" style="font-size:11px"> · ${s.n_scenes} cảnh · ${esc(s.created)}${s.theme ? ' · ' + esc(s.theme) : ''}</span></div>
          <div style="display:flex;gap:6px">
            <button class="btn xs primary" onclick="avUseScript('${esc(s.id)}')">Dùng lại</button>
            <button class="btn xs ghost red" onclick="avDelScript('${esc(s.id)}')">✕</button></div>
        </div>`).join('')}</div></div>` : ''}`;
}

function avEditPanel() {
  const voice = avEdit.audio_mode === 'voice';
  return `<div class="av-edit">
    <label>Âm thanh
      <select onchange="avEdit.audio_mode=this.value;render()">
        <option value="music" ${!voice ? 'selected' : ''}>Chỉ nhạc nền</option>
        <option value="voice" ${voice ? 'selected' : ''}>Giọng đọc + nhạc</option>
      </select></label>
    ${voice ? (avAllVoices().length ? `<label>Giọng đọc
      <select onchange="avEdit.voice=this.value">${avVoiceOpts(avEdit.voice)}</select></label>`
      : `<div class="warn" style="margin-bottom:8px">Chưa có giọng nào trong Kho giọng. Vào <a href="#" onclick="go('voices');return false">Kho giọng</a> tick giọng (Eleven hoặc OmniVoice) rồi quay lại.</div>`) : ''}
    <div class="av-edit-m">
      <label class="av-mtrack ${avEdit.music === '' ? 'on' : ''}"><input type="radio" name="avem" ${avEdit.music === '' ? 'checked' : ''} onchange="avEdit.music='';render()"><span class="av-mname">— Không nhạc —</span></label>
      ${avData.music.map(n => `<label class="av-mtrack ${n === avEdit.music ? 'on' : ''}">
        <input type="radio" name="avem" ${n === avEdit.music ? 'checked' : ''} onchange="avEdit.music='${esc(n)}';render()">
        <button type="button" class="pbtn" onclick="event.preventDefault();playUrl('/media/music/${encodeURIComponent(n)}',this)">▶</button>
        <span class="av-mname">${esc(n)}</span></label>`).join('')}
    </div>
    ${voice ? `<label>Tốc độ đọc <span class="mut" style="font-size:11px">(đổi miễn phí — ghép lại)</span>
      <select onchange="avEdit.voice_speed=+this.value">${avSpeedOpts(avEdit.voice_speed)}</select></label>` : ''}
    <label>Âm lượng nhạc <span class="mut" style="font-size:11px">(đổi miễn phí — ghép lại)</span>
      <select onchange="avEdit.music_db=+this.value">${avMusicDbOpts(avEdit.music_db)}</select></label>
    <label>Đổi model video <span class="mut" style="font-size:11px">(làm lại clip — dùng khi hết tiền / muốn rẻ hơn; ảnh giữ nguyên)</span>
      <select onchange="avEdit.video=this.value">
        <option value="">— giữ nguyên —</option>
        ${avData.video_models.map(m => `<option value="${esc(m.model)}">${esc(m.name)}${m.price ? ' (~' + fmt(m.price) + 'cr)' : ''}</option>`).join('')}
      </select></label>
    <div class="av-edit-f">
      <span class="mut">Đổi giọng tốn 1 lần đọc; đổi nhạc miễn phí (clip đã có). Đổi model = làm lại clip (tốn tiền clip).</span>
      <div class="right">
        <button class="btn xs ghost" onclick="avEditId=null;render()">Hủy</button>
        <button class="btn xs primary" onclick="avApplyEdit()">Áp dụng</button>
      </div>
    </div>
  </div>`;
}
async function avOpenEdit(id) {
  const v = avList.find(x => x.id === id); if (!v) return;
  avEditId = id;
  avEdit = { audio_mode: v.audio_mode || 'music', voice: avVoiceKey(v.voice), music: v.music || '', music_db: (v.music_db != null ? v.music_db : -12), voice_speed: (v.voice_speed != null ? v.voice_speed : 1.0), video: '' };
  await loadAiVideo();            // nạp lại roster (giọng vừa tick ở Kho giọng hiện ra)
  if (!avEdit.voice) { const a0 = avAllVoices()[0]; if (a0) avEdit.voice = a0.key; }
  render();
}
async function avCaption(id) {
  const out = await act(() => api('/ai-video/caption/' + id, { method: 'POST' }), 'Đã tạo tus đăng');
  if (out && out.caption) {
    const v = avList.find(x => x.id === id); if (v) v.caption = out.caption;
    render();
  }
}
async function avResume(id) {
  if (!confirm('Tiếp tục tạo video này?\nẢnh đã vẽ được giữ nguyên (không vẽ lại) — chỉ trả tiền cho clip còn thiếu.')) return;
  const out = await act(() => api('/ai-video/resume/' + id, { method: 'POST' }), 'Đang tiếp tục — theo dõi ở hàng đợi');
  if (out) { avStatus = { id, done: false }; avPoll(id); render(); }
}
async function avApplyEdit() {
  if (avEdit.audio_mode === 'voice' && !avEdit.voice) return toast('Chưa chọn giọng', 'err');
  const id = avEditId;
  const body = { audio_mode: avEdit.audio_mode, music: avEdit.music, music_db: avEdit.music_db,
                 voice_speed: avEdit.voice_speed,
                 voice: avEdit.audio_mode === 'voice' ? avVoiceDict(avEdit.voice) : {} };
  if (avEdit.video) {
    const m = avData.video_models.find(x => x.model === avEdit.video);
    body.video = { model: avEdit.video, mode: (m && m.modes[0] ? m.modes[0].value : ''),
                   resolution: (m && m.resolutions[0] ? m.resolutions[0].value : '') };
    if (!confirm('Đổi model video sẽ LÀM LẠI toàn bộ clip (tốn tiền clip mới, ảnh giữ nguyên). Tiếp tục?')) return;
  }
  const out = await act(() => api('/ai-video/edit/' + id, { method: 'POST', body }), 'Đang áp dụng — ghép lại');
  if (out) { avEditId = null; avStatus = { id, done: false }; avPoll(id); render(); }
}

/* ══════════ ĐĂNG HÀNG LOẠT (reel lên Page qua Graph API) ══════════ */
let fbpPages = null;        // {ok, me, pages:[{id,name,can_post}]}
let fbpVideos = [];         // [{label,path,size}]
let fbpSummary = null;      // {pages,postable,videos,downloaded,scheduled,...}
let fbpScheduled = [];      // [{page,video,when_ts,status}]
let fbpProfiles = [];       // [{name,port,alive,logged_in}]
let fbpFanpages = null;     // {fanpages:[...], credit, buffer_total} — màn Quản lý Fanpage
let fbpFpSearch = '';       // ô tìm fanpage
let fbpFpExpand = new Set();// id page đang bung chi tiết
let fbpFpItemSel = new Set();// id item (bài đang cào) đã tick trong dòng bung
let fbpInsights = null;     // {viral_views, pages:[{page_id,views_30d,viral_count,top}]}
let fbpFpFilter = 'all';    // all | running | paused | token | alert
let fbpFpSel = new Set();   // page id đã tick (bulk)
let fbpHideNames = localStorage.getItem('fbpHideNames') === '1'; // ẩn tên+ảnh page (quay video/bán tool)
function fbpToggleNames() { fbpHideNames = !fbpHideNames; localStorage.setItem('fbpHideNames', fbpHideNames ? '1' : '0'); render(); }
// Thư viện nội dung (Content Library — bám demo Business Suite)
let fbpClib = null;         // {viral_views, count, pages:[{id,name}], posts:[...]}
let fbpClibPage = '';       // page id lọc ('' = tất cả)
let fbpClibSub = 'pages';   // pages(chỉ số page) | published | scheduled | draft
let fbpClibSort = 'views';  // cột đang sắp
let fbpClibDir = 'desc';    // desc | asc
let fbpClibSearch = '';
let fbpTokenInput = '';
let fbpViralInput = null;   // ngưỡng viral đang gõ (null = dùng giá trị đã lưu)
let fbpAutoRows = [];       // [{id,page_id,page_name,link,audio,clip,when_ts,desc}]
let fbpAutoSel = new Set(); // id dong da tick
let fbpGov = null;          // {config, produced_today, credit, can_produce, reason}
let fbpAuto = null;         // {enabled, interval_min} — autopilot cron
let fbpDrip = null;         // {slots:[HH:MM], jitter_min, days} — Khung giờ đăng
let fbpPipe = null;         // {items, summary} — tiến trình auto
let fbpSchedView = 'cal';   // cal | list — Lịch đăng
let fbpSchedStatusFilter = 'all';   // all | sched | done | err
let fbpTokens = [];         // [{name}] — nhiều BM
let fbpBmNew = { name: '', token: '' };
let fbpTab = 'fanpage';     // fanpage(hero) | dash | fbsource(auto) | remake | sched | cfg | pages | acc
let fbpGrab = { busy: false, sel: { name: '' } };
let fbpRemakeSrc = [];      // reel đã tải (nguồn làm lại)
let fbpRemakeSel = new Set();
let fbpRemakeFilter = 'all';    // all | doing | ready | done | err
let fbpRemakeSearch = '';
let fbpProdOpen = new Set();    // page_id đang MỞ ở tab Sản Xuất (mặc định gập cho gọn)
function fbpProdToggle(pid) { fbpProdOpen.has(pid) ? fbpProdOpen.delete(pid) : fbpProdOpen.add(pid); render(); }
let fbpRowCfg = {};             // 'slug|rid' -> {audio, clip, page_id} (page dự kiến + mode)
let fbpVideoModels = [];        // [{model,name,price}] — model i2v 79AI cho ô "Kiểu video"
let fbpPagesSearch = '';

async function loadFbPost() {
  const [pg, vd, sm, sc, pr] = await Promise.all([
    api('/fb-post/pages').catch(e => ({ ok: false, error: e.message })),
    api('/fb-post/videos').catch(() => ({ videos: [] })),
    api('/fb-post/summary').catch(() => null),
    api('/fb-post/scheduled').catch(() => ({ items: [] })),
    api('/fb-post/profiles').catch(() => ({ profiles: [] })),
  ]);
  fbpPages = pg; fbpVideos = vd.videos || []; fbpSummary = sm; fbpScheduled = sc.items || []; fbpProfiles = pr.profiles || [];
  fbpAutoRows = (await api('/fb-post/automap').catch(() => ({ rows: [] }))).rows || [];
  fbpGov = await api('/fb-post/governor').catch(() => null);
  fbpAuto = await api('/fb-post/autopilot').catch(() => null);
  fbpDrip = await api('/fb-post/drip').catch(() => null);
  fbpPipe = await api('/fb-post/pipeline').catch(() => null);
  fbpTokens = (await api('/fb-post/tokens').catch(() => ({ tokens: [] }))).tokens || [];
  fbpRemakeSrc = (await api('/fb-post/remake/sources').catch(() => ({ sources: [] }))).sources || [];
  fbpFanpages = await api('/fb-post/fanpages').catch(() => null);
  fbpInsights = await api('/fb-post/insights').catch(() => null);   // tu CACHE, khong goi Graph
  fbpClib = await api('/fb-post/insights/posts').catch(() => null); // bai da dang (cache)
  render();
  // Model video 79AI cho ô "Kiểu video" — nạp 1 lần (server cache), khỏi chờ theo mỗi lượt.
  if (!fbpVideoModels.length)
    api('/fb-post/video-models').then(r => { fbpVideoModels = r.models || []; render(); }).catch(() => {});
}
function fbpInsFor(pid) {
  return ((fbpInsights || {}).pages || []).find(x => x.page_id === pid) || null;
}
// Dong bo so lieu viral (goi Graph /{page}/videos) — 1 page hoac tat ca.
async function fbpInsSync(pid) {
  await act(async () => {
    await api('/fb-post/insights/sync', { method: 'POST', body: { page_id: pid || '' } });
    fbpInsights = await api('/fb-post/insights').catch(() => fbpInsights);
    fbpClib = await api('/fb-post/insights/posts').catch(() => fbpClib);   // Thư viện dùng dữ liệu này
    render();
  }, 'Đã đồng bộ số liệu.');
}
function fbpFpSelToggle(id, on) { on ? fbpFpSel.add(id) : fbpFpSel.delete(id); render(); }
function fbpFpSelAll(on) {
  const ids = (fbpFanpages && fbpFanpages.fanpages || []).map(r => r.id);
  if (on) ids.forEach(id => fbpFpSel.add(id)); else fbpFpSel.clear();
  render();
}
/* START/STOP gộp 1 chỗ. Start đi qua HỘP ▶ Star (fbpStarOpen) để chọn cách đăng rồi mới chạy.
   Stop (on=false) dừng HẲN page đã tích (hoặc 1 page qua oneId). `post` = cấu hình từ hộp Star. */
async function fbpPagesRun(on, oneId, post) {
  const fps = (fbpFanpages.fanpages || []);
  const sel = oneId ? fps.filter(r => r.id === oneId) : fps.filter(r => fbpFpSel.has(r.id));
  if (!sel.length) return toast('Tích page trước.', 'err');
  if (on) {
    const haveSrc = sel.filter(r => r.automap_id && r.source);
    if (!haveSrc.length) return toast('Page chọn CHƯA gán nguồn — gán ở "Nguồn & Kho đệm" trước.', 'err');
  }
  const ids = sel.map(r => r.id);
  const body = { page_ids: ids, on };
  if (on && post) body.post = post;
  const r = await act(() => api('/fb-post/pages/run', { method: 'POST', body }),
    on ? '▶ Đã bắt đầu — hệ tự tải → làm lại → đăng theo cách đã chọn.' : '⏹ Đã dừng.');
  if (r && on && r.ready < ids.length) toast(`${ids.length - r.ready} page chưa gán nguồn nên bỏ qua.`, 'err');
  await loadFbPost();
}

/* ── HỘP ▶ Star: chọn CÁCH ĐĂNG trước khi chạy (đăng luôn / hẹn giờ + số bài + giãn cách phút) ── */
function fbpStarOpen(oneId) {
  const fps = (fbpFanpages.fanpages || []);
  const sel = oneId ? fps.filter(r => r.id === oneId) : fps.filter(r => fbpFpSel.has(r.id));
  if (!sel.length) return toast('Tích page trước.', 'err');
  const src = sel.filter(r => r.automap_id && r.source);
  if (!src.length) return toast('Page chọn CHƯA gán nguồn — gán ở "Nguồn & Kho đệm" trước.', 'err');
  const c = Object.assign({ post_mode: 'now', post_hhmm: '08:00', post_day_offset: 1, run_target: 1, gap_min: 60 }, fbpDrip || {});
  const bg = document.createElement('div'); bg.className = 'modal-bg';
  const close = () => { bg.remove(); delete window.__star; };
  window.__star = {
    c, oneId, n: src.length, close,
    set(k, v) { this.c[k] = v; this.draw(); },
    async go() { fbpDrip = Object.assign(fbpDrip || {}, this.c); close(); await fbpPagesRun(true, this.oneId, this.c); },
    draw() { bg.innerHTML = fbpStarModalHTML(this.c, this.n); },
  };
  window.__star.draw();
  bg.onclick = e => { if (e.target === bg) close(); };
  document.body.append(bg);
}
function fbpStarSummary(c) {
  const n = c.run_target || 1, g = c.gap_min ?? 60;
  const when = (c.post_mode === 'schedule')
    ? `hẹn ${esc(c.post_hhmm || '08:00')} ${(+c.post_day_offset) === 0 ? 'hôm nay' : (+c.post_day_offset) === 1 ? 'ngày mai' : '+' + c.post_day_offset + ' ngày'}`
    : 'đăng ngay bài đầu';
  return `Làm <b>${n}</b> bài mỗi page · ${when}${(n > 1 || c.post_mode === 'schedule') ? ` · bài sau cách <b>${g}</b> phút, làm tiếp sau khi bài trước đăng xong` : ''}. ⏹ Stop để dừng hẳn.`;
}
function fbpStarModalHTML(c, n) {
  const mBtn = (val, lb) => `<button class="btn ${(c.post_mode || 'now') === val ? 'primary' : 'ghost'}" onclick="__star.set('post_mode','${val}')">${lb}</button>`;
  const dayOpts = [[0, 'Hôm nay'], [1, 'Ngày mai'], [2, '2 ngày nữa'], [3, '3 ngày nữa'], [7, '1 tuần nữa']];
  const isNow = (c.post_mode || 'now') === 'now';
  return `<div class="modal" style="max-width:450px">
    <h3>▶ Bắt đầu ${n} page — cách đăng</h3>
    <div class="field"><label>1 · Đăng khi nào (sau khi video làm xong)</label><br>
      ${mBtn('now', '⚡ Đăng luôn')} ${mBtn('schedule', '🗓 Lên lịch')}</div>
    ${!isNow ? `<div class="fbrow" style="gap:10px;margin:8px 0 2px">
      <div class="field"><label class="mut">Giờ đăng bài đầu</label><br>
        <input type="time" class="txt" value="${esc(c.post_hhmm || '08:00')}" onchange="__star.set('post_hhmm',this.value)"></div>
      <div class="field"><label class="mut">Bắt đầu từ</label><br>
        <select class="txt" onchange="__star.set('post_day_offset',+this.value)">${dayOpts.map(([v, l]) => `<option value="${v}" ${(+c.post_day_offset) === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    </div>` : '<div class="info">Video đầu làm xong là đăng ngay lên Facebook.</div>'}
    <div class="fbrow" style="gap:10px;margin-top:14px">
      <div class="field"><label>2 · Số bài cần làm</label><br>
        <input type="number" class="txt" style="width:90px" min="1" value="${c.run_target || 1}" onchange="__star.set('run_target',Math.max(1,+this.value||1))"></div>
      <div class="field"><label>3 · Giãn cách mỗi bài (phút)</label><br>
        <input type="number" class="txt" style="width:100px" min="0" value="${c.gap_min ?? 60}" onchange="__star.set('gap_min',Math.max(0,+this.value||0))"></div>
    </div>
    <div class="mut" style="font-size:11.5px;margin-top:10px">${fbpStarSummary(c)}</div>
    <div class="acts">
      <button class="btn ghost" onclick="__star.close()">Hủy</button>
      <button class="btn primary" onclick="__star.go()">▶ Bắt đầu</button>
    </div></div>`;
}
function fbpSetTab(t) { fbpTab = t; render(); }
const fbpFmtTime = ts => ts ? new Date(ts * 1000).toLocaleString('vi', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) : '—';

/* Ước tính credit làm lại 1 video — CÔNG THỨC DÙNG CHUNG cho mọi tab (Xưởng + Tự động).
   Mỗi cảnh: ảnh 600 (banana_pro vip 1k) + clip (grok 1000 | veo 800 | wan 200). */
const FBP_CLIP_CR = { grok_video_heavy: 1000, veo_3_1: 800, wan_2_2: 200 };
// Giá 1 clip theo model: ưu tiên bảng giá THẬT 79AI (fbpVideoModels), fallback bảng cũ.
function fbpVideoPrice(model) {
  const m = fbpVideoModels.find(x => x.model === model);
  if (m && m.price) return m.price;
  return FBP_CLIP_CR[model] || 1000;
}
// Nhãn model: tên THẬT từ 79AI, fallback nhãn gọn cũ.
function fbpClipLabel(model) {
  const m = fbpVideoModels.find(x => x.model === model);
  return (m && m.name) || FBP_CLIP_LABEL[model] || model;
}
const FBP_CLIP_LABEL = { grok_video_heavy: 'grok', veo_3_1: 'veo', wan_2_2: 'wan' };
function fbpEstCredit(n, clip) { return n * 600 + n * fbpVideoPrice(clip); }
/* Nhãn audio DÙNG CHUNG — tránh mỗi tab một kiểu chữ. */
const FBP_AUDIO = { B: 'B · giữ tiếng gốc', A: 'A · giọng + nhạc mới' };
/* Kiểu ảnh vẽ lại — DANH SÁCH ĐẦY ĐỦ 79AI (đồng bộ pipeline/fb_remake.STYLE_LABELS). MẶC ĐỊNH thật. */
const FBP_STYLES = [
  ['real', 'Thật (giống ảnh thật)'], ['cartoon', 'Màu nước hoài niệm'],
  ['hoat_hinh', 'Hoạt hình dễ thương'], ['chan_dung_dien_anh', 'Chân dung điện ảnh'],
  ['anime', 'Anime Nhật Bản'], ['mau_nuoc', 'Tranh màu nước'],
  ['pixar_3d', 'Hoạt hình 3D (Pixar)'], ['son_dau', 'Tranh sơn dầu'],
  ['ngam_doi', 'Đen trắng xúc động (Ngẫm Đời)'],
  ['theo_mo_ta', 'Theo mô tả (không thêm)'],
];
const FBP_STYLE = Object.fromEntries(FBP_STYLES);

async function fbpSaveToken() {
  const t = (fbpTokenInput || '').trim();
  if (!t) return toast('Dán token vào ô.', 'err');
  const r = await act(() => api('/fb-post/token', { method: 'POST', body: { token: t } }),
    'Đã lưu token.');
  if (r) { fbpTokenInput = ''; toast(`${r.me} · ${r.count} page`, 'ok'); act(loadFbPost); }
}
/* Nạp lại page từ token (mọi BM) — dùng khi vừa thêm page vào BM. Page mới tự vào whitelist. */
async function fbpReloadPages() {
  const r = await act(() => api('/fb-post/pages/refresh', { method: 'POST' }), 'Đã nạp lại page.');
  if (r) {
    const en = (r.whitelisted || []).length;
    toast(en ? `Tổng ${r.count} page · đã BẬT DÙNG ${en} page mới: ${r.whitelisted.join(', ')}` : `Đủ ${r.count} page — không có page mới cần bật.`, 'ok');
    await loadFbPost();   // nạp lại toàn bộ (page + dropdown + Thư viện)
  }
}
async function fbpOpenProfile(name) {
  await act(() => api('/fb-post/profiles/open', { method: 'POST', body: { name } }),
    'Đã mở Chrome — đăng nhập Facebook trong cửa sổ đó rồi bấm Làm mới.');
  setTimeout(() => act(loadFbPost), 3000);
}
async function fbpCreateProfile() {
  const name = prompt('Tên tài khoản (vd: acc-chinh, acc-2):');
  if (!name) return;
  await act(() => api('/fb-post/profiles', { method: 'POST', body: { name } }),
    'Đã tạo + mở Chrome — đăng nhập Facebook trong cửa sổ đó.');
  setTimeout(() => act(loadFbPost), 3000);
}

function fbpAccTab() {
  const rows = fbpProfiles.map(p => `<tr>
    <td><span class="th-s">🧑</span> ${esc(p.name)}</td>
    <td class="mut">cổng ${p.port}</td>
    <td>${p.alive ? (p.logged_in ? '<span class="tag done">Đã đăng nhập</span>'
      : '<span class="tag draft">Đang mở — chưa login</span>')
      : '<span class="tag wait">Chưa mở</span>'}</td>
    <td><button class="btn sm ghost" onclick="fbpOpenProfile('${esc(p.name)}')">Mở Chrome</button></td></tr>`).join('');
  return `<div class="fbstat">Hồ sơ Chrome đăng nhập Facebook (mỗi tài khoản 1 hồ sơ riêng — phục vụ tải video + nhiều BM).</div>
    <div class="toolbar"><button class="btn" onclick="fbpCreateProfile()">＋ Thêm tài khoản</button>
      <span class="bulk"><button class="btn sm ghost" onclick="act(loadFbPost)">↻ Kiểm tra</button></span></div>
    <div class="tablewrap"><table><thead><tr><th>Tài khoản</th><th>Cổng CDP</th><th>Trạng thái</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="mut" style="margin-top:10px;font-size:12px">Mở Chrome → tự đăng nhập Facebook tay (cookie giữ theo hồ sơ). Token đăng bài vẫn lấy ở tab <b>Cài đặt</b> (System User / Explorer) — cào cookie không đăng được.</div>`;
}

/* ===== MÀN QUẢN LÝ FANPAGE (bám mockup) — header + avatar + token đếm ngược + dòng bung ===== */
const fbpNum = v => (v == null ? '—' : Number(v).toLocaleString('vi'));
function fbpFpToggle(id) { fbpFpExpand.has(id) ? fbpFpExpand.delete(id) : fbpFpExpand.add(id); render(); }
function fbpFpItemToggle(id, on) { on ? fbpFpItemSel.add(id) : fbpFpItemSel.delete(id); render(); }
// Rut gon loi tho (dict-repr / json) cho de doc; day du van o title tooltip.
function fbpShortErr(e) {
  const s = String(e || '').replace(/[{}\[\]"']/g, '').replace(/\s+/g, ' ').trim();
  return s.length > 60 ? s.slice(0, 60) + '…' : (s || 'thất bại');
}
async function fbpItemRetry(id) {
  const r = await act(() => api('/fb-post/pipeline/retry', { method: 'POST', body: { id } }), 'Đã đẩy thử lại vào hàng đợi.');
  if (r) act(loadFbPost);
}
async function fbpItemCancel(id) {
  if (!confirm('Hủy/gỡ bài reel này khỏi Facebook? Không hoàn tác được.')) return;
  const r = await act(() => api('/fb-post/pipeline/cancel', { method: 'POST', body: { id } }), 'Đã hủy bài.');
  if (r) act(loadFbPost);
}
async function fbpItemsBulk(op) {
  const ids = [...fbpFpItemSel];
  if (!ids.length) return;
  if (op === 'cancel' && !confirm(`Hủy/gỡ ${ids.length} bài đã lên lịch? Không hoàn tác được.`)) return;
  const path = op === 'retry' ? '/fb-post/pipeline/retry' : '/fb-post/pipeline/cancel';
  await act(async () => {
    for (const id of ids) await api(path, { method: 'POST', body: { id } });
    fbpFpItemSel.clear(); await loadFbPost();
  }, op === 'retry' ? 'Đã đẩy thử lại các bài chọn.' : 'Đã hủy các bài chọn.');
}
function fbpFpApplySearch() {
  const q = (fbpFpSearch || '').toLowerCase();
  document.querySelectorAll('tr.fprow').forEach(tr => {
    const hit = (tr.dataset.name || '').toLowerCase().includes(q);
    tr.style.display = hit ? '' : 'none';
    const det = tr.nextElementSibling;
    if (det && det.classList.contains('fpdetail')) det.style.display = (hit && tr.classList.contains('open')) ? '' : 'none';
  });
}
function fbpTokChip(days) {
  if (days == null) return '<span class="mut">—</span>';
  if (days < 0) return '<span class="tag err">● Hết hạn</span>';
  if (days >= 9999) return '<span class="tag done">● Vĩnh viễn</span>';
  if (days <= 7) return `<span class="tag wait">● Sắp hết · ${days}d</span>`;
  return `<span class="tag done">● Hợp lệ · ${days}d</span>`;
}
// Nhan mau trang thai DONG NHAT (khop backend _norm_pipe_status + tab Lich/San xuat).
const FBP_ST_CLASS = { loi: 'err', cho: 'wait', tai: 'run', dung: 'run', lich: 'sched',
  huy: 'wait', chua_dang: 'sched', da_dang: 'done', xong: 'draft' };
// Dong bung 1 page = DANH SACH "bai dang cao" chia 4 TAB theo vong doi.
let fbpFpDetTab = {};   // {page_id: 'doing'|'sched'|'posted'|'err'}
function fbpFpDetSetTab(pid, t) { fbpFpDetTab[pid] = t; render(); }
// 4 tab (thu tu vong doi): Dang lam -> Da len lich -> Da dang -> Loi/Huy.
const FBP_DET_TABS = [
  ['doing', '⚙ Đang làm', ['tai', 'dung', 'lich', 'cho', 'xong']],
  ['sched', '🗓 Đã lên lịch', ['chua_dang']],
  ['posted', '✅ Đã đăng', ['da_dang']],
  ['err', '⚠ Lỗi / Hủy', ['loi', 'huy']],
];
const FBP_DET_EMPTY = { doing: 'Không có bài đang làm.', sched: 'Chưa có bài đã lên lịch.',
  posted: 'Chưa có bài đã đăng.', err: 'Không có bài lỗi/hủy.' };
function fbpDetGroupOf(code) {
  for (const [g, , codes] of FBP_DET_TABS) if (codes.includes(code)) return g;
  return 'doing';
}
// Thanh tien do dep cho item DANG LAM: Tải → Dựng → Lên lịch.
function fbpStageBar(it) {
  const seq = [['Tải'], ['Dựng'], ['Lên lịch']];
  const idx = ({ tai: 0, cho: 0, dung: 1, lich: 2, xong: 2 })[it.status_code] ?? 0;
  return `<span class="stagebar">${seq.map(([lb], i) =>
    `<span class="stg ${i < idx ? 'done' : i === idx ? 'cur' : ''}">${lb}</span>`).join('<span class="stgsep"></span>')}</span>`;
}
function fbpFpDetail(r) {
  const items = (r.detail || {}).items || [];
  const sel = fbpFpItemSel;
  const reelUrl = uid => uid ? `https://www.facebook.com/reel/${uid}` : '';
  const cnt = { doing: 0, sched: 0, posted: 0, err: 0 };
  items.forEach(it => { cnt[fbpDetGroupOf(it.status_code)]++; });
  // Lần đầu (chưa chọn) → nhảy vào tab đầu tiên CÓ bài. Đã chọn → tôn trọng (kể cả tab rỗng).
  let tab = fbpFpDetTab[r.id];
  if (tab === undefined) tab = (cnt.doing ? 'doing' : cnt.sched ? 'sched' : cnt.posted ? 'posted' : cnt.err ? 'err' : 'doing');
  const shown = items.filter(it => fbpDetGroupOf(it.status_code) === tab);

  const rowsHtml = shown.length ? shown.map(it => {
    const cls = FBP_ST_CLASS[it.status_code] || 'wait';
    // KẾT QUẢ: chỉ hiện THỜI GIAN (lịch đăng / lúc đăng) — KHÔNG hiện post_id.
    const kqTs = it.when_ts || it.ts;
    const kq = it.post_id
      ? (kqTs ? fbpFmtTime(kqTs) : '<span class="tag done">✓ đã đăng</span>')
      : (it.error ? `<span style="color:var(--red)" title="${esc(it.error)}">⚠ ${esc(fbpShortErr(it.error))}</span>` : '—');
    const acts = [];
    if (it.video) acts.push(`<a class="btn sm ghost" title="Xem video đã dựng" href="/media/fb-remake/${encodeURIComponent(it.slug)}/${encodeURIComponent(it.video)}" target="_blank" onclick="event.stopPropagation()">▶</a>`);
    if (it.status_code === 'loi') acts.push(`<button class="btn sm ghost" title="Thử lại" onclick="event.stopPropagation();fbpItemRetry('${it.id}')">↻</button>`);
    if (it.status_code === 'chua_dang' || it.status_code === 'da_dang') acts.push(`<button class="btn sm ghost" title="Hủy/gỡ bài" onclick="event.stopPropagation();fbpItemCancel('${it.id}')">✕</button>`);
    // Log rõ hơn: bài đã lên lịch/chờ đăng → "⏳ chờ tới giờ đăng".
    const wlog = it.status_code === 'chua_dang' ? '<div class="mut" style="font-size:11px;margin-top:2px">⏳ chờ tới giờ đăng</div>' : '';
    const stCell = tab === 'doing'
      ? `${fbpStageBar(it)}${it.step ? `<div class="mut" style="font-size:11px;margin-top:3px">${esc(it.step)}</div>` : ''}`
      : `<span class="tag ${cls}">${esc(it.status_label)}</span>${wlog}${it.step && tab === 'err' ? ` <span class="mut" style="font-size:11px">${esc(it.step)}</span>` : ''}`;
    return `<tr>
      <td style="text-align:center"><input type="checkbox" ${sel.has(it.id) ? 'checked' : ''} onclick="event.stopPropagation();fbpFpItemToggle('${it.id}',this.checked)"></td>
      <td>${fbpHideNames ? '<span class="mut" style="font-size:11px">••••••</span>' : (it.uid ? `<a href="${reelUrl(it.uid)}" target="_blank" onclick="event.stopPropagation()" style="color:var(--gold);font-size:11px">${esc(it.uid)}</a>` : '<span class="mut">—</span>')}${it.kind === 'remake' ? ' <span class="tag wait" style="font-size:9px">✋ tay</span>' : ' <span class="tag sched" style="font-size:9px">🤖 auto</span>'}</td>
      <td class="num">${it.views != null ? fbpNum(it.views) : '—'}</td>
      <td>${stCell}</td>
      <td class="mut" style="font-size:11px">${kq}</td>
      <td style="text-align:right;white-space:nowrap">${acts.join(' ')}</td></tr>`;
  }).join('') : `<tr><td colspan="6" class="mut" style="text-align:center;padding:16px">${FBP_DET_EMPTY[tab]}</td></tr>`;

  // Trạng thái page dạng LOG (bỏ nút/chip "Đã dừng" riêng): đang chạy / đã dừng + số bài chờ giờ.
  const stateLog = r.producing
    ? `<span class="detlog run">⚙ đang xử lý${r.render_step ? ': ' + esc(r.render_step) : ''}</span>`
    : (r.status === 'running' ? '<span class="detlog run">🤖 đang chạy</span>' : '<span class="detlog stop">■ đã dừng</span>');
  const waitLog = (r.waiting || r.scheduled)
    ? `<span class="detlog wait">⏳ ${(r.waiting || 0) + (r.scheduled || 0)} bài chờ tới giờ đăng</span>` : '';
  const tabBar = `<div class="dettabs">
    <div class="dettabs-l">${FBP_DET_TABS.map(([g, lb]) =>
      `<button class="dettab ${tab === g ? 'on' : ''}" onclick="event.stopPropagation();fbpFpDetSetTab('${r.id}','${g}')">${lb}${cnt[g] ? ` <span class="detn">${cnt[g]}</span>` : ''}</button>`).join('')}</div>
    <div class="dettabs-r">${stateLog}${waitLog}
      <button class="btn sm ghost" onclick="event.stopPropagation();fbpClibPage='${r.id}';fbpSetTab('clib')">📚 Thư viện</button>
      <button class="btn sm ghost" onclick="event.stopPropagation();fbpSetTab('sched')">🗓 Lịch đăng</button></div>
  </div>`;

  const selN = [...sel].filter(id => items.some(it => it.id === id)).length;
  const bulk = selN ? `<div class="fpbulk" style="margin:8px 0">
    <b>${selN}</b> bài chọn
    <button class="btn sm" onclick="event.stopPropagation();fbpItemsBulk('retry')">↻ Thử lại</button>
    <button class="btn sm ghost" onclick="event.stopPropagation();fbpItemsBulk('cancel')">✕ Hủy đăng</button>
    <button class="btn sm ghost" onclick="event.stopPropagation();fbpFpItemSel.clear();render()">Bỏ chọn</button></div>` : '';

  return `<td colspan="12"><div class="detbox">
    ${tabBar}
    ${bulk}
    <div class="tablewrap detgrid"><table class="fpwtbl"><thead><tr>
      <th style="width:28px"></th><th>UID bài nguồn</th><th>Views nguồn</th><th>${tab === 'doing' ? 'Tiến trình' : 'Trạng thái · log'}</th><th>Kết quả (lịch · đăng)</th><th style="width:44px"></th>
    </tr></thead><tbody>${rowsHtml}</tbody></table></div>
  </div></td>`;
}
// Page co "cảnh báo"? (token sắp hết / kho đệm cạn / token hết hạn)
function fbpFpAlert(r) {
  return r.status === 'token_exp' || r.status === 'noperm'
    || (r.token_days != null && r.token_days < 9999 && r.token_days <= 7)
    || (r.source_slug && r.backlog_remain === 0);
}
function fbpFanpageTab() {
  const d = fbpFanpages;
  if (!d) return skeleton(3);
  const all = d.fanpages || [];
  const per = ((d.gov || {}).post_per_page_day) || 2;
  const producing = all.filter(r => r.producing).length;
  const tokWarn = all.filter(r => r.token_days != null && r.token_days < 9999 && r.token_days <= 7).length;
  const tokExp = all.filter(r => r.status === 'token_exp').length;
  const bufEmpty = all.filter(r => r.source_slug && r.backlog_remain === 0).length;
  const gov = fbpGov || {};
  const floor = (gov.config || {}).floor_credit;
  const creditLow = (gov.credit != null && floor != null && gov.credit < floor);
  const totViral = ((fbpInsights || {}).pages || []).reduce((a, p) => a + (p.viral_count || 0), 0);
  const vv = (fbpInsights || {}).viral_views || 100000;

  // ── Dải cảnh báo dính đầu ──
  const bar = [];
  if (tokExp) bar.push(`🔴 <b>${tokExp}</b> page token hết hạn — cấp lại ở Cài đặt`);
  if (tokWarn) bar.push(`🟠 <b>${tokWarn}</b> page token sắp hết (≤7 ngày)`);
  if (bufEmpty) bar.push(`🟠 <b>${bufEmpty}</b> page hết reel chưa làm — cào thêm nguồn (⬇ DS)`);
  if (creditLow) bar.push(`🔴 Credit ${fbpNum(gov.credit)} dưới sàn ${fbpNum(floor)} — nạp thêm`);
  const alertBar = bar.length
    ? `<div class="fpalert">${bar.map(x => `<span>${x}</span>`).join('')}</div>`
    : `<div class="fpalert ok"><span>🟢 Không có cảnh báo — ${all.length} page ổn định</span></div>`;

  // ── Chip lọc ──
  const counts = {
    all: all.length,
    running: all.filter(r => r.status === 'running' || r.status === 'producing').length,
    token: all.filter(r => r.status === 'token_exp' || (r.token_days != null && r.token_days <= 7 && r.token_days < 9999)).length,
    alert: all.filter(fbpFpAlert).length,
  };
  const chip = (id, lb) => `<button class="avchip ${fbpFpFilter === id ? 'on' : ''}" onclick="fbpFpFilter='${id}';render()">${lb} <b>${counts[id]}</b></button>`;
  const chips = `<div class="chips" style="margin:10px 0">${chip('all', 'Tất cả')}${chip('running', 'Đang chạy')}${chip('token', 'Lỗi token')}${chip('alert', 'Cảnh báo')}</div>`;

  const rows = all.filter(r => {
    if (fbpFpFilter === 'running') return r.status === 'running' || r.status === 'producing';
    if (fbpFpFilter === 'token') return r.status === 'token_exp' || (r.token_days != null && r.token_days <= 7 && r.token_days < 9999);
    if (fbpFpFilter === 'alert') return fbpFpAlert(r);
    return true;
  });

  const kpi = (lb, val, sub, cls) => `<div class="kpi ${cls || ''}"><div class="klb">${lb}</div>
    <div class="kval">${val}${sub ? ` <small>${sub}</small>` : ''}</div></div>`;
  const header = `<div class="fphead">
    <div><h2>Tổng quan page</h2>
      <div class="mut" style="font-size:13px">${all.length} page · thành phẩm chờ đăng ${d.buffer_total} video · nhịp mục tiêu ${per} bài/ngày/page</div></div>
    <div class="grow"></div>
    <input class="search" placeholder="Tìm page…" value="${esc(fbpFpSearch)}" oninput="fbpFpSearch=this.value;fbpFpApplySearch()">
    <button class="btn" title="Ẩn/hiện tên + ảnh page (quay video / bán tool)" onclick="fbpToggleNames()">${fbpHideNames ? '👁 Hiện tên' : '🙈 Ẩn tên'}</button>
    <button class="btn" onclick="fbpInsSync('')">📊 Đồng bộ số liệu</button>
    <button class="btn primary" onclick="fbpSetTab('cfg')">＋ Kết nối page</button></div>`;
  const strip = `<div class="fpkpi">
    ${kpi('💰 Credit', fbpNum(d.credit), d.credit != null ? `≈ ${Math.floor(d.credit / 7200)} video` : '')}
    ${kpi('🔥 Bài viral', totViral, `≥ ${fbpNum(vv)} views`, totViral ? 'ok' : '')}
    ${kpi('⚙ Đang render', producing, 'video')}
    ${kpi('🔑 Token cảnh báo', (tokWarn + tokExp) || '✓', (tokWarn + tokExp) ? 'sắp/đã hết' : 'ổn', (tokWarn + tokExp) ? 'alert' : '')}</div>`;

  // ── Thanh bulk ──
  const sel = [...fbpFpSel].filter(id => all.some(r => r.id === id));
  const bulk = sel.length ? `<div class="fpbulk">
    <b>${sel.length}</b> page chọn
    <button class="btn sm primary" title="Chọn cách đăng rồi bắt đầu" onclick="fbpStarOpen()">▶ Star</button>
    <button class="btn sm" title="Cào nguồn tất cả page đã chọn (chạy lần lượt, tránh loạn Chrome)" onclick="fbpBacklogBuildBulk()">⬇ Cào tất cả</button>
    <button class="btn sm" title="Dừng hẳn các page này" onclick="fbpPagesRun(false)">⏹ Stop</button>
    <button class="btn sm ghost" onclick="fbpFpSel.clear();render()">Bỏ chọn</button></div>` : '';

  const stChip = s => ({
    running: '<span class="tag done">● Đang chạy</span>',
    producing: '<span class="tag sched">● Đang render</span>',
    paused: '<span class="tag draft">● Đã dừng</span>',
    unset: '<span class="tag wait">● Chưa gán nguồn</span>',
    noperm: '<span class="tag err">● Thiếu quyền</span>',
    token_exp: '<span class="tag err">● Token hết — cấp lại</span>',
  }[s] || `<span class="tag draft">${esc(s)}</span>`);
  const avatar = r => fbpHideNames
    ? `<span class="fpava ph">🔒</span>`
    : (r.picture
      ? `<img class="fpava" src="${esc(r.picture)}" alt="">`
      : `<span class="fpava ph">${esc((r.name || '?')[0])}</span>`);
  const body = rows.length ? rows.map((r, ri) => {
    const open = fbpFpExpand.has(r.id);
    // NHỊP/NGÀY = số bài đã lịch hôm nay / nhịp mục tiêu.
    const pace = `<b>${r.pace_today} / ${r.pace_target}</b>`;
    // KHO ĐỆM = số bài CHƯA LÀM (reel cào về chưa remake). Chưa cào → '—'; hết → đỏ.
    const rem = r.backlog_remain;
    const buf = r.source_slug
      ? (rem == null ? '<span class="mut" style="font-size:11px">chưa cào</span>'
        : `<b style="font-size:15px;${rem === 0 ? 'color:var(--red)' : ''}">${rem}</b> <span class="mut" style="font-size:11px">${rem === 0 ? 'hết — cào thêm' : 'chưa làm'}</span>`)
      : '<span class="mut">—</span>';
    const num = (n) => n ? `<b style="font-size:15px">${n}</b>` : '<span class="mut">—</span>';
    const produced = num(r.produced);                 // ĐÃ SẢN XUẤT (video đã làm cho page)
    const waitc = num(r.waiting);                      // CHỜ ĐĂNG (đăng luôn, chờ tới lượt)
    const schedc = num(r.scheduled);                   // ĐÃ LÊN LỊCH (hẹn giờ)
    const posted = num(r.posted);                      // ĐÃ ĐĂNG (bài đã lên sóng)
    // Start ở thanh bulk (tích page → Star). Hàng: đang chạy = báo trạng thái; đã dừng = "▶ Làm tiếp".
    const act = r.status === 'token_exp'
      ? `<button class="btn sm primary" onclick="event.stopPropagation();fbpSetTab('cfg')">Cấp token</button>`
      : (r.automap_id
        ? (r.enabled
          ? `<span class="mut" style="font-size:11px">● đang chạy</span> <button class="btn sm ghost" title="Dừng hẳn page này" onclick="event.stopPropagation();fbpPagesRun(false,'${r.id}')">⏹</button>`
          : `<button class="btn sm primary" title="Làm tiếp page này" onclick="event.stopPropagation();fbpStarOpen('${r.id}')">▶ Làm tiếp</button>`)
        : `<button class="btn sm" onclick="event.stopPropagation();fbpSetTab('auto')">＋ Gán nguồn</button>`);
    const nm = fbpHideNames ? `Trang ${ri + 1}` : esc(r.name);   // ẩn tên → nhãn chung
    return `<tr class="fprow ${open ? 'open' : ''}" data-name="${fbpHideNames ? '' : esc(r.name)}" onclick="fbpFpToggle('${r.id}')">
      <td onclick="event.stopPropagation()" style="text-align:center"><input type="checkbox" ${fbpFpSel.has(r.id) ? 'checked' : ''} onchange="fbpFpSelToggle('${r.id}',this.checked)"></td>
      <td><div class="fpname">${avatar(r)}<div><b>${nm}${r.source_slug ? ' <span class="fpcaret">▾</span>' : ''}</b></div></div></td>
      <td>${pace}</td><td>${fbpTokChip(r.token_days)}</td><td>${buf}</td><td>${produced}</td><td>${waitc}</td><td>${schedc}</td><td>${posted}</td>
      <td class="mut">~${fbpNum(r.credit_est)}</td><td>${stChip(r.status)}</td>
      <td style="text-align:right;white-space:nowrap">${act}</td></tr>
      <tr class="fpdetail" style="${open ? '' : 'display:none'}">${fbpFpDetail(r)}</tr>`;
  }).join('') : `<tr><td colspan="12" class="mut" style="text-align:center;padding:20px">${all.length ? 'Không page nào khớp lọc.' : 'Chưa có page nào được dùng. Vào <b>Cài đặt</b> dán token + chọn page ở whitelist.'}</td></tr>`;
  return header + alertBar + strip + chips + bulk + `<div class="card"><div class="tablewrap"><table class="fptbl">
    <thead><tr><th style="width:34px" title="Chọn tất cả page"><input type="checkbox" ${all.length && all.every(r => fbpFpSel.has(r.id)) ? 'checked' : ''} onclick="event.stopPropagation()" onchange="fbpFpSelAll(this.checked)"></th><th>Page</th><th>Nhịp/ngày</th><th>Token</th><th>Kho đệm</th><th>Đã sản xuất</th><th>Chờ đăng</th><th>Đã lên lịch</th><th>Đã đăng</th><th>Credit/bài</th><th>Trạng thái</th><th style="text-align:right">Thao tác</th></tr></thead>
    <tbody>${body}</tbody></table></div></div>
    <div class="mut" style="font-size:11px;margin-top:10px">Bấm 1 page để xem kho đệm · lịch · <b>bài viral</b>. Số liệu viral lấy khi bấm <b>📊 Đồng bộ số liệu</b> (Graph API). Ngưỡng viral chỉnh ở <b>Cài đặt</b>.</div>`;
}

/* ═══════ THƯ VIỆN NỘI DUNG (Content Library — bám demo Business Suite) ═══════ */
function fbpClibDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString('vi', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function fbpClibSetSort(k) {
  if (fbpClibSort === k) fbpClibDir = fbpClibDir === 'desc' ? 'asc' : 'desc';
  else { fbpClibSort = k; fbpClibDir = 'desc'; }
  render();
}
function fbpClibTab() {
  const d = fbpClib;
  const vv = (d && d.viral_views) || 100000;
  const pages = (d && d.pages) || [];
  const allP = !fbpClibPage;

  // ── bộ dữ liệu theo tab con ──
  let published = (d && d.posts || []).filter(p => allP || p.page_id === fbpClibPage);
  // Lịch mang sẵn page_id (server) → lọc theo ID, KHÔNG theo tên (tránh trùng tên / chưa nạp pages).
  let scheduled = fbpScheduled.filter(x => !fbpClibPage || x.page_id === fbpClibPage);
  // fbpPageForVideo cần ĐƯỜNG DẪN ĐẦY ĐỦ (slug/remake/NNN-lamlai.mp4) — KHÔNG cắt .pop().
  let drafts = fbpSchedUnscheduled().filter(v => !fbpClibPage || fbpPageForVideo(v.path) === fbpClibPage);

  // ── CHỈ SỐ PAGE: gom số liệu bài đã đăng theo từng page (nơi quản lý viral/chỉ số) ──
  // SEED tất cả page (kể cả page 0 bài) → luôn hiện đủ TÊN mọi page, không chỉ page có bài.
  const byPage = {};
  (d && d.pages || []).forEach(p => {
    byPage[p.id] = { id: p.id, name: p.name || p.id, n: 0, views: 0, eng: 0, cmt: 0, viral: 0, max: 0, maxTitle: '' };
  });
  (d && d.posts || []).forEach(p => {
    const k = p.page_id || '?';
    const g = byPage[k] || (byPage[k] = { id: k, name: p.page_name || k, n: 0, views: 0, eng: 0, cmt: 0, viral: 0, max: 0, maxTitle: '' });
    g.n++; g.views += (p.views || 0); g.eng += (p.likes || 0) + (p.comments || 0); g.cmt += (p.comments || 0);
    if (p.views >= vv) g.viral++;
    if ((p.views || 0) > g.max) { g.max = p.views || 0; g.maxTitle = p.title || ''; }
  });
  let pageStats = Object.values(byPage).filter(g => !fbpClibPage || g.id === fbpClibPage).sort((a, b) => b.views - a.views);
  const counts = { pages: Object.keys(byPage).length, published: published.length, scheduled: scheduled.length, draft: drafts.length };

  // ── thanh công cụ ──
  const pageSel = `<select onchange="fbpClibPage=this.value;render()">
    <option value="">Tất cả page</option>${pages.map(p => `<option value="${esc(p.id)}" ${fbpClibPage === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select>`;
  const syncedAny = pages.length && (d.posts || []).length;
  const subtab = (id, lb) => `<button class="clib-sub ${fbpClibSub === id ? 'on' : ''}" onclick="fbpClibSub='${id}';render()">${lb} <span class="clib-cnt">${counts[id]}</span></button>`;
  const viralN = published.filter(p => p.views >= vv).length;
  const bar = `<div class="clib-bar">
    <div class="clib-title-row"><h2>Thư viện nội dung</h2>
      <span class="mut" style="font-size:12.5px">${counts.published} bài đã đăng${viralN ? ` · <b style="color:var(--gold)">🔥 ${viralN} viral</b>` : ''} · ngưỡng ${fbpNum(vv)} views</span></div>
    <div class="grow"></div>
    ${pageSel}
    <input class="search" placeholder="Tìm bài viết…" value="${esc(fbpClibSearch)}" oninput="fbpClibSearch=this.value;fbpClibApplySearch()">
    <button class="btn" onclick="fbpInsSync(fbpClibPage)">📊 Đồng bộ số liệu</button></div>`;
  const subs = `<div class="clib-subs">${subtab('pages', '📊 Chỉ số page')}${subtab('published', 'Đã đăng')}${subtab('scheduled', 'Đã lên lịch')}${subtab('draft', 'Bản nháp')}</div>`;

  let table;
  if (fbpClibSub === 'pages') {
    table = !syncedAny
      ? empty('📊', 'Chưa có số liệu', 'Bấm <b>📊 Đồng bộ số liệu</b> để lấy bài đã đăng + lượt xem từ Facebook (Graph API).')
      : pageStats.length
        ? `<div class="tablewrap clib-wrap"><table class="clib-tbl">
            <thead><tr><th>Page</th><th class="num">Bài đã đăng</th><th class="num">Tổng lượt xem</th><th class="num">🔥 Viral</th><th class="num">Views TB</th><th class="num">Cao nhất</th><th class="num">Tương tác</th></tr></thead>
            <tbody>${pageStats.map(g => `<tr class="clib-row">
              <td class="clib-post"><span class="clib-thumb ph">📄</span><div class="clib-metacol"><b class="clib-postname">${esc(g.name)}</b>${g.maxTitle ? `<div class="clib-sub2">Bài đỉnh: ${esc(g.maxTitle.slice(0, 48))}</div>` : ''}</div></td>
              <td class="num">${fbpNum(g.n)}</td>
              <td class="num hot">${fbpNum(g.views)}</td>
              <td class="num">${g.viral ? `<b style="color:var(--gold)">🔥 ${g.viral}</b>` : '<span class="mut">0</span>'}</td>
              <td class="num">${fbpNum(Math.round(g.views / Math.max(1, g.n)))}</td>
              <td class="num ${g.max >= vv ? 'hot' : ''}">${fbpNum(g.max)}</td>
              <td class="num">${fbpNum(g.eng)}</td></tr>`).join('')}</tbody></table></div>
            <div class="mut" style="font-size:11px;margin-top:8px">Viral = bài đạt ≥ ${fbpNum(vv)} lượt xem (chỉnh ngưỡng ở <b>Cài đặt</b>). Số liệu từ Graph API khi bấm <b>Đồng bộ</b>.</div>`
        : empty('🔍', 'Không có page khớp', '');
  } else if (fbpClibSub === 'published') {
    // sắp xếp
    const key = fbpClibSort;
    const val = p => key === 'eng' ? (p.likes + p.comments) : key === 'created' ? p.created : (p[key] || 0);
    published = published.slice().sort((a, b) => {
      const va = val(a), vb = val(b);
      const c = key === 'created' ? String(va).localeCompare(String(vb)) : (va - vb);
      return fbpClibDir === 'desc' ? -c : c;
    });
    const sh = (k, lb) => `<th class="num sortable ${fbpClibSort === k ? 'on' : ''}" onclick="fbpClibSetSort('${k}')">${lb} <span class="clib-arr">${fbpClibSort === k ? (fbpClibDir === 'desc' ? '▾' : '▴') : '⇅'}</span></th>`;
    const rows = published.map(p => {
      const link = p.permalink ? (p.permalink.startsWith('http') ? p.permalink : 'https://facebook.com' + p.permalink) : '';
      const isV = p.views >= vv;
      const thumb = p.thumb ? `<img class="clib-thumb" src="${esc(p.thumb)}" loading="lazy" alt="">` : `<span class="clib-thumb ph">🎬</span>`;
      return `<tr class="clib-row" data-title="${esc((p.title || '').toLowerCase())}">
        <td class="clib-post">${thumb}
          <div class="clib-metacol">
            ${link ? `<a class="clib-postname" href="${esc(link)}" target="_blank">${esc(p.title || '(không có tiêu đề)')}</a>` : `<b class="clib-postname">${esc(p.title || '(không có tiêu đề)')}</b>`}
            <div class="clib-sub2">${fbpClibDate(p.created)}${allP && p.page_name ? ` · ${esc(p.page_name)}` : ''}${isV ? ' · <span class="clib-viral">🔥 Viral</span>' : ''}</div>
          </div></td>
        <td class="num ${isV ? 'hot' : ''}">${fbpNum(p.views)}</td>
        <td class="num">${fbpNum(p.post_views)}</td>
        <td class="num">${fbpNum(p.likes + p.comments)}</td>
        <td class="num">${fbpNum(p.comments)}</td></tr>`;
    }).join('');
    table = !syncedAny
      ? empty('📊', 'Chưa có số liệu', 'Bấm <b>📊 Đồng bộ số liệu</b> để lấy bài đã đăng + lượt xem từ Facebook (Graph API).')
      : published.length
        ? `<div class="tablewrap clib-wrap"><table class="clib-tbl">
            <thead><tr><th>Bài viết</th>${sh('views', 'Lượt xem')}${sh('post_views', 'Người xem')}${sh('eng', 'Tương tác')}${sh('comments', 'Bình luận')}</tr></thead>
            <tbody>${rows}</tbody></table></div>
            <div class="mut" style="font-size:11px;margin-top:8px">Tương tác = cảm xúc + bình luận. Số liệu reel từ Graph API (trễ vài giờ). Cột Hiển thị/Phân phối của Business Suite không có qua API nên không hiện (không bịa số).</div>`
        : empty('🔍', 'Không có bài khớp', '');
  } else if (fbpClibSub === 'scheduled') {
    table = scheduled.length
      ? `<div class="tablewrap clib-wrap"><table class="clib-tbl">
          <thead><tr><th>Video</th><th>Page</th><th class="num">Giờ đăng</th><th>Trạng thái</th></tr></thead>
          <tbody>${scheduled.map(x => `<tr class="clib-row"><td class="clib-post"><span class="clib-thumb ph">🎬</span><div class="clib-metacol"><b class="clib-postname">${esc((x.video || '').split('/').pop().replace('-lamlai.mp4', ''))}</b></div></td>
            <td>${esc(x.page || '—')}</td><td class="num">${fbpFmtTime(x.when_ts)}</td><td><span class="tag wait">${esc(x.status || 'scheduled')}</span></td></tr>`).join('')}</tbody></table></div>`
      : empty('🗓', 'Chưa có bài lên lịch', 'Lên lịch ở tab <b>Lịch đăng</b>.');
  } else {
    table = drafts.length
      ? `<div class="tablewrap clib-wrap"><table class="clib-tbl">
          <thead><tr><th>Video làm lại</th><th>Page dự kiến</th><th></th></tr></thead>
          <tbody>${drafts.map(v => { const pid = fbpPageForVideo(v.path); const pn = (fbpPages.pages || []).find(p => p.id === pid); return `<tr class="clib-row"><td class="clib-post"><span class="clib-thumb ph">🎬</span><div class="clib-metacol"><b class="clib-postname">${esc((v.path || '').split('/').pop())}</b></div></td>
            <td>${pn ? esc(pn.name) : '<span class="mut">chưa gán</span>'}</td><td style="text-align:right"><button class="btn sm" onclick="fbpSetTab('sched')">Lên lịch →</button></td></tr>`; }).join('')}</tbody></table></div>`
      : empty('📝', 'Không có bản nháp', 'Video làm lại xong nhưng chưa lên lịch sẽ hiện ở đây.');
  }
  return bar + subs + table;
}
function fbpClibApplySearch() {
  const q = (fbpClibSearch || '').toLowerCase();
  document.querySelectorAll('tr.clib-row').forEach(tr => {
    const hit = !q || (tr.dataset.title || '').includes(q);
    tr.style.display = hit ? '' : 'none';
  });
}

function pgFbPost() {
  const tab = (id, lb) => `<div class="tab ${fbpTab === id ? 'on' : ''}" onclick="fbpSetTab('${id}')">${lb}</div>`;
  const head = `<div class="head"><h1>Đăng hàng loạt</h1>
    <span class="sub">tải → làm lại → lên lịch tự động · nhiều page</span>
    <div class="right"><button class="btn ghost" onclick="act(loadFbPost)">↻ Làm mới</button></div></div>
    <div class="tabs">${tab('fanpage', 'Tổng quan page')}${tab('clib', '📚 Thư viện nội dung')}${tab('auto', 'Nguồn & Kho đệm')}${tab('srclist', '🗂 Danh Sách Nguồn')}${tab('remake', 'Sản xuất')}${tab('sched', 'Lịch đăng')}${tab('cfg', 'Cài đặt')}</div>`;

  if (!fbpPages) return head + skeleton(4);
  const warn = (!fbpPages.ok) ? `<div class="note" style="margin-bottom:12px">🔑 Token Facebook chưa có / hết hạn (${esc(fbpPages.error || '')}) — vào tab <b>Cài đặt</b> dán token rồi Làm mới. Các bảng dưới vẫn xem được.</div>` : '';
  const body = { fanpage: fbpFanpageTab, clib: fbpClibTab, auto: fbpAutoTab, srclist: fbpSourceListTab, sched: fbpSchedTab, remake: fbpRemakeTab,
                 pages: fbpPagesTab, acc: fbpAccTab, cfg: fbpCfgTab }[fbpTab] || fbpFanpageTab;
  return head + `<div class="wrap">${warn}${body()}</div>`;
}


function fbpSchedUnscheduled() {
  const done = new Set(fbpScheduled.map(x => x.video));
  return fbpVideos.filter(v => !done.has(v.path));
}
/* Lịch đăng: chỉ hiện LỊCH/BẢNG bài đã lên lịch. (Pool "Chưa xếp lịch" + "Tự rải" đã bỏ:
   auto tự lên lịch khi làm xong theo "Cách đăng" ở Cài đặt — không rải slot tay nữa.) */
// Trạng thái ĐỒNG NHẤT với Tổng quan page: 'scheduled' quá giờ = đã đăng (done);
// còn tương lai = chưa đăng (sched). → "đã lên lịch" luôn rõ đã/chưa đăng.
function fbpSchedStatusOf(x) {
  if (x.status === 'error') return 'err';
  if (x.status === 'scheduled') return (x.when_ts && x.when_ts * 1000 <= Date.now()) ? 'done' : 'sched';
  return 'done';
}
const FBP_SCHED_LABEL = { sched: 'Chưa đăng', done: 'Đã đăng', err: 'Lỗi' };
function fbpSchedTab() {
  const flt = fbpSchedStatusFilter;
  const evs = fbpScheduled.filter(x => flt === 'all' || fbpSchedStatusOf(x) === flt);
  const chip = (id, lb) => `<button class="btn sm ${flt === id ? 'primary' : 'ghost'}" onclick="fbpSchedStatusFilter='${id}';render()">${lb}</button>`;
  const toolbar = `<div class="toolbar">
    <span class="chips">${chip('all', 'Tất cả')}${chip('sched', 'Chưa đăng')}${chip('done', 'Đã đăng')}${chip('err', 'Lỗi')}</span>
    <span class="bulk">
      <button class="btn sm ${fbpSchedView === 'cal' ? 'primary' : 'ghost'}" onclick="fbpSchedView='cal';render()">Lịch</button>
      <button class="btn sm ${fbpSchedView === 'page' ? 'primary' : 'ghost'}" onclick="fbpSchedView='page';render()">Theo page</button>
      <button class="btn sm ${fbpSchedView === 'list' ? 'primary' : 'ghost'}" onclick="fbpSchedView='list';render()">Bảng</button>
      ${fbpScheduled.length ? '<a class="btn sm ghost" href="/api/fb-post/export/scheduled.csv">⤓ CSV</a>' : ''}</span></div>`;
  const left = (fbpSchedView === 'list')
    ? (evs.length
      ? `<div class="tablewrap"><table><thead><tr><th>Page</th><th>Video</th><th>Giờ đăng</th><th>Trạng thái</th></tr></thead><tbody>${evs.slice().reverse().map(x => `<tr>
          <td>${esc(x.page)}</td><td class="mut">${esc(x.video)}</td>
          <td>${x.when_ts ? fbpFmtTime(x.when_ts) : 'đăng ngay'}</td>
          <td><span class="tag ${fbpSchedStatusOf(x)}">${FBP_SCHED_LABEL[fbpSchedStatusOf(x)] || esc(x.status)}</span>${x.status === 'scheduled' && fbpSchedStatusOf(x) === 'sched' ? ' <span class="mut" style="font-size:10px">đã lên lịch</span>' : ''}</td></tr>`).join('')}</tbody></table></div>`
      : '<div class="panel"><div class="mut">Chưa có bài nào.</div></div>')
    : (fbpSchedView === 'page') ? fbpSchedPageGrid(evs) : fbpCalendar(evs);
  const note = `<div class="mut" style="font-size:11px;margin-top:8px">Bài do <b>auto</b> tự lên lịch khi làm xong — theo <b>Cách đăng</b> ở <b>Cài đặt</b> (đăng luôn / hẹn sau khi xong).</div>`;
  return toolbar + left + note;
}

/* Lịch PER-PAGE: hàng = page, cột = 7 ngày, ô = giờ đã lên lịch của page đó (nhịp 2/ngày). */
function fbpSchedPageGrid(source) {
  const list = source || fbpScheduled;
  const perDay = ((fbpGov && fbpGov.config) || {}).post_per_page_day || 2;
  const days = [...Array(7)].map((_, i) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + i); return d; });
  const dow = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
  // page có mặt: postable+allowed HOẶC có bài trong list
  const postable = (fbpPages.pages || []).filter(p => p.can_post && p.allowed);
  const byId = {}; postable.forEach(p => byId[p.id] = p.name);
  list.forEach(x => { if (x.page_id && !byId[x.page_id]) byId[x.page_id] = x.page || x.page_id; });
  const pageIds = Object.keys(byId);
  if (!pageIds.length) return '<div class="panel"><div class="mut">Chưa có page nào — tick page ở Page &amp; Token + lên lịch.</div></div>';
  const evOf = (pid, d) => list.filter(x => x.page_id === pid && (() => { const t = new Date((x.when_ts || 0) * 1000); return t >= d && t < new Date(d.getTime() + 864e5); })())
    .sort((a, b) => (a.when_ts || 0) - (b.when_ts || 0));
  const rows = pageIds.map(pid => `<tr>
    <td style="white-space:nowrap"><span class="th-s">📄</span> ${esc(byId[pid])}</td>
    ${days.map(d => { const es = evOf(pid, d); const full = es.length >= perDay;
      return `<td style="vertical-align:top">${es.map(x => `<span class="pgslot ${fbpSchedStatusOf(x)}">${new Date(x.when_ts * 1000).toLocaleTimeString('vi', { hour: '2-digit', minute: '2-digit' })}</span>`).join('') || '<span class="mut" style="font-size:11px">·</span>'}
        ${es.length ? `<div class="mut" style="font-size:10px;margin-top:2px;${full ? 'color:var(--green)' : ''}">${es.length}/${perDay}</div>` : ''}</td>`; }).join('')}</tr>`).join('');
  return `<div class="tablewrap"><table style="min-width:720px"><thead><tr><th>Page</th>${days.map(d => `<th>${dow[d.getDay()]} ${d.getDate()}/${d.getMonth() + 1}</th>`).join('')}</tr></thead>
    <tbody>${rows}</tbody></table></div>
    <div class="mut" style="font-size:11px;margin-top:8px">Mỗi ô = giờ đã lên lịch cho page đó ngày đó · <b>N/${perDay}</b> = đã xếp / nhịp mục tiêu (xanh = đủ nhịp). Autopilot tự lấp cho tới đủ ${perDay}/ngày/page.</div>`;
}

function fbpCalendar(source) {
  const list = source || fbpScheduled;
  const days = [...Array(7)].map((_, i) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + i); return d; });
  const evOf = d => list
    .filter(x => { const t = new Date((x.when_ts || 0) * 1000); return t >= d && t < new Date(d.getTime() + 864e5); })
    .sort((a, b) => (a.when_ts || 0) - (b.when_ts || 0));
  const dow = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
  const cells = days.map(d => {
    const evs = evOf(d).map(x => `<div class="ev ${fbpSchedStatusOf(x)}"><span class="t">${new Date(x.when_ts * 1000).toLocaleTimeString('vi', { hour: '2-digit', minute: '2-digit' })}</span><span class="p">${esc(x.page)}</span></div>`).join('');
    return `<div class="day"><div class="dh"><b>${dow[d.getDay()]}</b> ${d.getDate()}/${d.getMonth() + 1}</div>${evs || '<div class="mut" style="font-size:11px;margin-top:14px;text-align:center">—</div>'}</div>`;
  }).join('');
  return `<div class="cal">${cells}</div>`;
}

async function fbpToggleAllowed(id, on) {
  const p = (fbpPages.pages || []).find(x => x.id === id); if (p) p.allowed = on;
  const ids = (fbpPages.pages || []).filter(x => x.allowed).map(x => x.id);
  await api('/fb-post/whitelist', { method: 'POST', body: { ids } }).catch(() => {});
  render();
}
async function fbpAllowAll(on) {
  (fbpPages.pages || []).forEach(p => p.allowed = on);
  const ids = on ? (fbpPages.pages || []).map(x => x.id) : [];
  await act(() => api('/fb-post/whitelist', { method: 'POST', body: { ids } }),
    on ? 'Đã tick tất cả page' : 'Đã bỏ tất cả (cho phép tất cả)');
  render();
}
function fbpPagesTab() {
  let pages = (fbpPages.pages || []);
  const q = (fbpPagesSearch || '').toLowerCase();
  if (q) pages = pages.filter(p => (p.name || '').toLowerCase().includes(q));
  const wlOn = !!fbpPages.whitelist_on;
  const allowed = (fbpPages.pages || []).filter(p => p.allowed && p.can_post).length;
  const schedOf = (name, st) => fbpScheduled.filter(x => x.page === name && (st ? x.status === st : true)).length;
  const groups = {};
  pages.forEach(p => { const k = p.bm || '—'; (groups[k] = groups[k] || []).push(p); });
  const bmCard = (bm, ps) => {
    const hasTok = fbpTokens.some(t => t.name === bm);
    const postable = ps.filter(p => p.can_post).length;
    const rows = ps.map(p => {
      const anyErr = fbpScheduled.some(x => x.page === p.name && x.status === 'error');
      return `<tr ${p.allowed ? '' : 'style="opacity:.5"'}>
      <td><label class="fbchk"><input type="checkbox" ${p.allowed ? 'checked' : ''} onchange="fbpToggleAllowed('${p.id}',this.checked)"></label></td>
      <td><span class="th-s">📄</span> ${esc(p.name)}</td>
      <td style="font-variant-numeric:tabular-nums">${schedOf(p.name, 'scheduled') || '—'}</td>
      <td style="font-variant-numeric:tabular-nums">${schedOf(p.name, 'published') || '—'}</td>
      <td>${!p.can_post ? '<span class="tag err">Thiếu quyền</span>' : anyErr ? '<span class="tag run">có bài lỗi</span>' : '<span class="tag done">Hoạt động</span>'}</td></tr>`;
    }).join('');
    return `<div class="grp">
      <div class="gh"><span class="th-s">🏢</span><b>${esc(bm)}</b>
        ${hasTok ? '<span class="tag done">Token OK</span>' : '<span class="tag wait">token ?</span>'}
        <span class="mut">${ps.length} page · ${postable} đăng được${hasTok ? ' · System User · không hết hạn' : ''}</span></div>
      <div class="tablewrap" style="border:none"><table style="min-width:600px"><thead><tr>
        <th style="width:40px"></th><th>Page</th><th>Đã lên lịch</th><th>Đã đăng</th><th>Trạng thái</th></tr></thead>
        <tbody>${rows}</tbody></table></div></div>`;
  };
  const cards = Object.entries(groups).map(([bm, ps]) => bmCard(bm, ps)).join('');
  return `<div class="toolbar">
      <input type="text" class="txt" style="width:200px" placeholder="Tìm page…" value="${esc(fbpPagesSearch)}" oninput="fbpPagesSearch=this.value;render()">
      <span class="bulk">
        <button class="btn sm" onclick="fbpAllowAll(true)">✓ Tick tất cả dùng</button>
        <button class="btn sm ghost" onclick="fbpAllowAll(false)">Bỏ tất cả</button>
        <button class="btn sm ghost" onclick="fbpSetTab('cfg')">＋ Thêm Business Manager</button>
        <button class="btn sm ghost" onclick="act(loadFbPost)">↻ Kiểm tra token</button></span></div>
    <div class="fbstat" style="margin-bottom:10px">Token: <b>${esc(fbpPages.me || '?')}</b> · <b>${allowed}</b>/${(fbpPages.pages || []).length} page ĐƯỢC DÙNG ${wlOn ? '' : '· <span style="color:var(--amber)">chưa lọc → đang cho TẤT CẢ</span>'}</div>
    ${cards || '<div class="note">Chưa có page — dán token ở tab <b>Cài đặt</b>.</div>'}
    <div class="foot">Chia nhiều BM để 1 sự cố không khoá cả cụm · tick ô đầu = page CHÍNH CHỦ (whitelist) → đăng/autopilot chỉ chạy page được tick.</div>`;
}

/* ── Xưởng làm lại (bám mockup): 1 bảng — Video · Page dự kiến · Audio · Clip · Tiến độ · Credit · Trạng thái ── */
function fbpRowCfgGet(key) {
  if (!fbpRowCfg[key]) {
    const p0 = (fbpPages.pages || []).find(p => p.can_post && p.allowed) || {};
    fbpRowCfg[key] = { audio: 'B', clip: 'grok_video_heavy', page_id: p0.id || '' };
  }
  return fbpRowCfg[key];
}
function fbpRowCfgEdit(key, field, val) { fbpRowCfgGet(key)[field] = val; render(); }
function fbpRemakeToggle(key, on) { on ? fbpRemakeSel.add(key) : fbpRemakeSel.delete(key); render(); }
/* page dự kiến của 1 video làm lại (đọc bởi tab Lịch đăng) — nối luồng Xưởng → Lịch. */
function fbpPageForVideo(label) {
  const m = /^([^/]+)\/remake\/(\d+)-lamlai\.mp4$/.exec(label || '');
  return m ? (fbpRowCfg[`${m[1]}|${m[2]}`] || {}).page_id || '' : '';
}
async function fbpRemakeRunOne(slug, rid) {
  const c = fbpRowCfgGet(`${slug}|${rid}`);
  const r = await act(() => api('/fb-post/remake/run', { method: 'POST',
    body: { slug, rid, n_scenes: 6, clip: c.clip, audio: c.audio } }),
    'Đã đưa vào hàng đợi làm lại.');
  if (r) setTimeout(() => act(loadFbPost), 1500);
}
async function fbpRemakeDelSel() {
  const keys = [...fbpRemakeSel].filter(k => fbpRemakeRows().find(s => `${s.slug}|${s.rid}` === k && (s.st === 'done' || s.st === 'ready')));
  if (!keys.length) return toast('Chọn video ĐÃ có bản làm lại để xoá.', 'err');
  if (!confirm(`Xoá ${keys.length} bản làm lại? (giữ reel gốc)`)) return;
  for (const k of keys) { const [slug, rid] = k.split('|'); await api('/fb-post/remake/delete', { method: 'POST', body: { slug, rid } }).catch(() => {}); }
  fbpRemakeSel.clear(); toast(`Đã xoá ${keys.length} bản`, 'ok'); act(loadFbPost);
}

/* Trạng thái mỗi reel: todo(chưa làm) · doing · ready(chờ duyệt=đã làm chưa lên lịch) · done(xong=đã lên lịch) · err. */
// Slug nguồn từ link facebook.com/<slug>/... (bỏ các path chung như reel/watch).
function fbpSlugOfLink(link) {
  const m = (link || '').match(/facebook\.com\/([^/?#]+)/i);
  let s = m ? m[1] : '';
  if (['reel', 'reels', 'watch', 'share', 'story.php', 'profile.php'].includes(s.toLowerCase())) s = '';
  return s;
}
// Trạng thái sản xuất gọn từ status pipeline (auto + remake DÙNG CHUNG).
function fbpProdSt(it) {
  if (it.status === 'error') return 'err';
  if (it.status === 'done') return 'done';
  return 'doing';   // downloading | remaking | scheduling | queued
}
// DANH SÁCH ĐÃ SẢN XUẤT — lấy TỪ PIPELINE (gồm cả bài auto/Star lẫn remake tay) → đồng bộ
// với cột "Đã sản xuất" ở Tổng quan. Bỏ item chưa bắt đầu (không có trong pipeline = chưa làm).
function fbpProducedRows() {
  const WORK = ['downloading', 'remaking', 'scheduling', 'queued', 'done', 'error'];
  return ((fbpPipe && fbpPipe.items) || []).filter(it => it.page_id && WORK.includes(it.status))
    .map(it => ({
      it, slug: fbpSlugOfLink(it.link), rid: it.reel || '', st: fbpProdSt(it),
      day: it.cts || it.ts || 0, page_id: it.page_id,
      page_name: it.page_name || it.page || '(không tên)',
      audio: it.audio || 'B', clip: it.clip || 'grok_video_heavy',
      style: it.style || 'real', when_ts: it.when_ts || 0, post_id: it.post_id || '',
      n: it.n_scenes || 6,
    }));
}
const FBP_ST = { todo: ['wait', 'Chưa làm'], doing: ['run', 'Đang làm'],
  ready: ['sched', 'Chờ duyệt'], done: ['done', 'Xong'], err: ['err', 'Lỗi'] };
// 1 dòng video đã/đang sản xuất (dùng trong lưới theo ngày).
function fbpProdRow(s) {
  const [tg, lb0] = FBP_ST[s.st];
  const now = Date.now() / 1000;
  let lb = lb0, sub = '';
  if (s.st === 'done') {
    if (s.when_ts && s.when_ts > now) { lb = 'Đã lên lịch'; sub = fbpFmtTime(s.when_ts); }
    else if (s.post_id) { lb = 'Đã đăng'; sub = s.when_ts ? fbpFmtTime(s.when_ts) : ''; }
  } else if (s.st === 'doing' && s.it.step) sub = s.it.step;
  const canView = s.slug && s.rid && s.st === 'done';
  return `<tr>
    <td><span class="th-s">🎬</span> <b>${s.rid ? esc(s.rid) : '<span class="mut">—</span>'}</b>
      <div class="mut" style="font-size:11px">nguồn: ${esc(s.slug || '—')}</div></td>
    <td class="mut" style="font-size:11px">${esc(FBP_STYLE[s.style] || s.style)}</td>
    <td class="mut" style="font-size:11px">${esc(fbpClipLabel(s.clip))}</td>
    <td><span class="tag ${s.audio === 'A' ? 'a' : 'b'}">${s.audio === 'A' ? 'A' : 'B'}</span></td>
    <td class="mut" style="font-variant-numeric:tabular-nums">${fbpEstCredit(s.n, s.clip).toLocaleString()}</td>
    <td><span class="tag ${tg}">${lb}</span>${sub ? ` <span class="mut" style="font-size:11px">${esc(sub)}</span>` : ''}</td>
    <td style="white-space:nowrap">${canView
      ? `<a class="btn sm ghost" title="Xem video ĐÃ LÀM" href="/media/fb-remake/${esc(s.slug)}/${esc(s.rid)}-lamlai.mp4" target="_blank">▶ Xem</a>`
      : s.st === 'err' ? `<button class="btn sm" onclick="fbpItemRetry('${esc(s.it.id)}')">↻ Thử lại</button>` : ''}</td></tr>`;
}

// Nhãn ngày dd/mm + khoá nhóm theo NGÀY (local).
function fbpDayKey(ts) { const d = new Date(ts * 1000); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
function fbpDayLabel(ts) { const d = new Date(ts * 1000); const th = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'][d.getDay()]; return `${th} ${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`; }

// Tên page CHUẨN theo page_id (ưu tiên danh sách page hiện tại — tránh "2 page GocKyUc"
// do dữ liệu cũ ghi tên khác). Fallback tên trong item.
function fbpPageName(pid, fallback) {
  const p = (fbpPages.pages || []).find(x => x.id === pid);
  return (p && p.name) || fallback || pid || '(không tên)';
}

function fbpRemakeTab() {
  const q = (fbpRemakeSearch || '').toLowerCase();
  const all = fbpProducedRows();
  const flt = fbpRemakeFilter;
  let rows0 = all.filter(s => flt === 'all' ? true : s.st === flt);
  if (q) rows0 = rows0.filter(s => (`${fbpPageName(s.page_id, s.page_name)} ${s.slug} ${s.rid}`).toLowerCase().includes(q));

  // Nhóm theo PAGE_ID (KHÔNG theo tên — cùng page_id mà tên khác nhau vẫn là 1 page).
  const byPage = {};
  rows0.forEach(s => { (byPage[s.page_id] = byPage[s.page_id] || []).push(s); });
  const pids = Object.keys(byPage).sort((a, b) => byPage[b].length - byPage[a].length);

  const blocks = pids.map(pid => {
    const list = byPage[pid].slice().sort((a, b) => b.day - a.day);
    const pn = fbpPageName(pid, list[0].page_name);
    const nDone = list.filter(s => s.st === 'done').length;
    const nDoing = list.filter(s => s.st === 'doing').length;
    const nErr = list.filter(s => s.st === 'err').length;
    const open = fbpProdOpen.has(pid);
    // Đầu khối: bấm để gập/mở (mặc định gập cho gọn). Hiện số tóm tắt như các mục khác.
    const head = `<div class="prodpage-h" onclick="fbpProdToggle('${esc(pid)}')" style="cursor:pointer">
      <span class="caret">${open ? '▾' : '▸'}</span> 🏷 <b>${esc(pn)}</b>
      <span class="mut">· ${list.length} video</span>
      ${nDoing ? `<span class="tag run">${nDoing} đang làm</span>` : ''}
      ${nDone ? `<span class="tag done">${nDone} xong</span>` : ''}
      ${nErr ? `<span class="tag err">${nErr} lỗi</span>` : ''}</div>`;
    if (!open) return `<div class="prodpage">${head}</div>`;
    const days = {};
    list.forEach(s => { (days[fbpDayKey(s.day)] = days[fbpDayKey(s.day)] || []).push(s); });
    const dayRows = Object.keys(days).sort().reverse().map(dk => {
      const arr = days[dk];
      return `<tr class="day-sep"><td colspan="7">📅 ${fbpDayLabel(arr[0].day)} · <b>${arr.length}</b> video</td></tr>${arr.map(fbpProdRow).join('')}`;
    }).join('');
    return `<div class="prodpage">${head}
      <div class="tablewrap"><table><thead><tr>
        <th>Video (UID nguồn)</th><th>Kiểu ảnh</th><th>Kiểu video</th><th>Audio</th><th>Credit</th><th>Trạng thái</th><th></th>
      </tr></thead><tbody>${dayRows}</tbody></table></div></div>`;
  }).join('');

  const cnt = st => all.filter(s => s.st === st).length;
  const chip = (id, lb, n) => `<button class="btn sm ${flt === id ? 'primary' : 'ghost'}" onclick="fbpRemakeFilter='${id}';render()">${lb}${n != null ? ` ${n}` : ''}</button>`;
  const allOpen = pids.length && pids.every(p => fbpProdOpen.has(p));
  return `<div class="toolbar">
      <input type="text" class="txt" style="width:210px" placeholder="Tìm page / nguồn / UID…" value="${esc(fbpRemakeSearch)}" oninput="fbpRemakeSearch=this.value;render()">
      <span class="chips">${chip('all', 'Tất cả', all.length)}${chip('doing', 'Đang làm', cnt('doing'))}${chip('done', 'Xong', cnt('done'))}${chip('err', 'Lỗi', cnt('err'))}</span>
      <button class="btn sm ghost" onclick="${allOpen ? 'fbpProdOpen.clear()' : `fbpProdOpen=new Set(${JSON.stringify(pids)})`};render()">${allOpen ? '⊟ Gập hết' : '⊞ Mở hết'}</button></div>
    ${blocks || `<div class="mut" style="text-align:center;padding:24px">Chưa có video nào ĐÃ LÀM. Bấm <b>▶ Star</b> ở <b>Tổng quan page</b> để hệ tự tải nguồn + làm lại.</div>`}
    <div class="foot">Danh sách ĐÃ SẢN XUẤT theo <b>từng Page → theo ngày</b> (đồng bộ pipeline: auto + làm lại tay). Bấm tên page để mở/gập. Hiển thị ${rows0.length} / ${all.length} video.</div>`;
}
function fbpRemakeToggleVisible(on) {
  const q = (fbpRemakeSearch || '').toLowerCase();
  fbpRemakeRows().filter(s => s.st !== 'todo' && (fbpRemakeFilter === 'all' || s.st === fbpRemakeFilter)
    && (!q || (`${s.slug} ${s.rid} ${s.caption || ''}`).toLowerCase().includes(q)))
    .forEach(s => on ? fbpRemakeSel.add(`${s.slug}|${s.rid}`) : fbpRemakeSel.delete(`${s.slug}|${s.rid}`));
  render();
}

/* ── Tự động theo page: mapping {page ↔ link} ── */
function fbpAutoAddRow() {
  const pg = ((fbpPages.pages || []).find(p => p.can_post && p.allowed) || {});
  fbpAutoRows.push({ id: 'new' + Date.now() + Math.random().toString(36).slice(2, 6),
    page_id: pg.id || '', page_name: pg.name || '', link: '', audio: 'B', clip: 'veo_3_1', style: 'real', when_ts: 0, desc: '' });
  render();
}
function fbpAutoAddPerPage() {
  const pages = (fbpPages.pages || []).filter(p => p.can_post && p.allowed);
  if (!pages.length) return toast('Chưa có page được dùng (tab Page & Token).', 'err');
  pages.forEach(p => fbpAutoRows.push({ id: 'new' + Date.now() + Math.random().toString(36).slice(2, 6),
    page_id: p.id, page_name: p.name, link: '', audio: 'B', clip: 'veo_3_1', style: 'real', when_ts: 0, desc: '' }));
  render(); toast(`Đã thêm ${pages.length} dòng (mỗi page 1) — điền link nguồn cho từng dòng`, 'ok');
}
function fbpAutoEdit(id, field, val) {
  const r = fbpAutoRows.find(x => x.id === id); if (!r) return;
  if (field === 'page_id') { r.page_id = val; r.page_name = ((fbpPages.pages || []).find(p => p.id === val) || {}).name || ''; }
  else if (field === 'when') { r.when_ts = val ? Math.floor(new Date(val).getTime() / 1000) : 0; }
  else r[field] = val;
}
function fbpAutoDel(id) { fbpAutoRows = fbpAutoRows.filter(x => x.id !== id); render(); }
async function fbpAutoSave() {
  await act(() => api('/fb-post/automap', { method: 'POST', body: fbpAutoRows }), 'Đã lưu mapping.');
}
/* Backlog cũ→mới: xem trạng thái (đọc file) + build (cào qua Chrome). */
async function fbpBacklogLoad(id) {
  const r = fbpAutoRows.find(x => x.id === id);
  if (!r || !r.link) return toast('Nhập link nguồn trước.', 'err');
  try {
    const d = await api('/fb-post/backlog?link=' + encodeURIComponent(r.link));
    r._bl = { total: d.total, done: d.done, remain: d.remain, next: d.next, items: d.items || [] };
    render();
  } catch (e) { toast(e.message || 'Lỗi đọc backlog', 'err'); }
}
async function fbpBacklogBuild(id) {
  const r = fbpAutoRows.find(x => x.id === id);
  if (!r || !r.link) return toast('Nhập link nguồn trước.', 'err');
  const res = await act(() => api('/fb-post/backlog/build', { method: 'POST', body: { link: r.link } }),
    'Đang cào nguồn dựng backlog (xem Hàng đợi) — xong bấm 📋 để tải danh sách.');
  if (res) setTimeout(() => fbpBacklogLoad(id), 1500);
}
function fbpBacklogToggle(id) {
  const r = fbpAutoRows.find(x => x.id === id); if (!r) return;
  r._blOpen = !r._blOpen; render();
}
// Cào NHIỀU page 1 lúc: các page đã tick ở Tổng quan → xếp hàng đợi (chạy lần lượt).
async function fbpBacklogBuildBulk() {
  const all = (fbpFanpages && fbpFanpages.fanpages) || [];
  const chosen = all.filter(r => fbpFpSel.has(r.id));
  const withSrc = chosen.filter(r => r.source && r.source_slug);
  if (!withSrc.length) return toast('Các page đã chọn chưa gán link nguồn.', 'err');
  const links = withSrc.map(r => r.source);
  const noSrc = chosen.length - withSrc.length;
  const res = await act(() => api('/fb-post/backlog/build-bulk', { method: 'POST', body: { links } }),
    `Đang xếp ${links.length} nguồn vào hàng đợi cào (chạy lần lượt — xem Hàng đợi)…`);
  if (res && res.ok) {
    toast(`Đã xếp ${res.n} nguồn cào lần lượt${noSrc ? ` (bỏ ${noSrc} page chưa gán nguồn)` : ''}.`, 'ok');
  }
}

/* ── 🗂 DANH SÁCH NGUỒN — khâu trung gian cào→làm lại (docs/danh-sach-nguon-ke-hoach.md) ── */
let fbpSrcSlug = '';         // slug page đang xem
let fbpSrcData = null;       // {slug,count,analysis,reels,credit_per_reel}
let fbpSrcSel = new Set();   // rid đã tick
let fbpSrcClip = 'grok_video_heavy';
let fbpSrcStyle = '';        // '' = dùng kiểu ảnh AI gợi ý
let fbpSrcAudio = 'B';
const FBP_SRC_CLIPS = [['grok_video_heavy', 'Grok (1000)'], ['veo_3_1', 'VEO 3.1 (800)'], ['wan_2_2', 'Wan (200)']];

async function fbpSrcLoad(slug) {
  fbpSrcSlug = slug; fbpSrcData = null; fbpSrcSel.clear();
  if (!slug) return render();
  fbpSrcData = await api('/fb-post/source-list?slug=' + encodeURIComponent(slug)).catch(() => null);
  render();
}
async function fbpSrcAnalyze() {
  if (!fbpSrcSlug) return toast('Chọn page nguồn trước.', 'err');
  const r = await act(() => api('/fb-post/source-list/analyze', { method: 'POST', body: { slug: fbpSrcSlug } }),
    'Đang phân tích lô (AI xem vài mẫu đại diện)…');
  if (r && r.ok) { toast('Phân tích lô xong.', 'ok'); fbpSrcLoad(fbpSrcSlug); }
}
function fbpSrcSelToggle(rid, on) { on ? fbpSrcSel.add(rid) : fbpSrcSel.delete(rid); render(); }
function fbpSrcSelAll(on) {
  const rs = (fbpSrcData && fbpSrcData.reels) || [];
  if (on) rs.forEach(r => fbpSrcSel.add(r.id)); else fbpSrcSel.clear();
  render();
}
async function fbpSrcPush() {
  const rids = [...fbpSrcSel];
  if (!rids.length) return toast('Chưa tick reel nào.', 'err');
  const style = fbpSrcStyle || (fbpSrcData && fbpSrcData.analysis && fbpSrcData.analysis.kieu_anh) || 'real';
  const r = await act(() => api('/fb-post/source-list/push', {
    method: 'POST', body: { slug: fbpSrcSlug, rids, clip: fbpSrcClip, style, audio: fbpSrcAudio, n_scenes: 7 }
  }), `Đang đẩy ${rids.length} reel sang Xưởng…`);
  if (r && r.ok) {
    toast(`Đã đẩy ${r.enqueued} reel sang Xưởng${r.failed ? ` (${r.failed} chưa tải/lỗi)` : ''}. Xem tab Sản xuất / Hàng đợi.`, 'ok');
    fbpSrcSel.clear(); render();
  }
}
function fbpSourceListTab() {
  const srcPages = (fbpFanpages && fbpFanpages.fanpages || []).filter(p => p.source_slug);
  const picker = `<select class="txt" style="min-width:220px" onchange="fbpSrcLoad(this.value)">
    <option value="">— Chọn page nguồn (đã cào) —</option>
    ${srcPages.map(p => `<option value="${esc(p.source_slug)}" ${p.source_slug === fbpSrcSlug ? 'selected' : ''}>${esc(p.name)} (${esc(p.source_slug)})</option>`).join('')}</select>`;
  const bar = `<div class="fbrow" style="margin:6px 0 12px;gap:10px;align-items:center">
    ${picker}
    <button class="btn sm" ${fbpSrcSlug ? '' : 'disabled'} onclick="fbpSrcAnalyze()" title="AI xem vài mẫu → chốt dạng cả lô">🔍 Phân tích lô</button>
    <span class="mut" style="font-size:12px">Phân tích cấp LÔ (rẻ): AI xem vài mẫu → áp cả lô. Không cào lại — dùng reel đã cào.</span></div>`;

  if (!fbpSrcSlug) return `<div class="fbstat">Chọn 1 <b>page nguồn đã cào</b> để xem Danh Sách Nguồn → phân tích lô → đẩy sang Xưởng.</div>${bar}
    ${srcPages.length ? '' : '<div class="note">Chưa page nào có nguồn đã cào. Cào ở tab <b>Nguồn & Kho đệm</b> (nút ⬇ Cào tất cả) trước.</div>'}`;
  if (!fbpSrcData) return bar + skeleton(3);

  const a = fbpSrcData.analysis;
  const styleLabel = v => (FBP_STYLES.find(s => s[0] === v) || [v, v])[1];
  const anaCard = a ? `<div class="card" style="padding:12px;margin-bottom:12px">
    <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:center">
      <div><span class="mut">Dạng lô</span><br><b>${esc(a.dang)}</b> <span class="mut">· tin cậy ${a.do_tin_cay ?? '?'}%</span></div>
      <div><span class="mut">Chủ đề</span><br><b>${esc(a.chu_de || '—')}</b></div>
      <div><span class="mut">Kiểu ảnh gợi ý</span><br><b>${esc(styleLabel(a.kieu_anh))}</b></div>
      <div style="flex:1;min-width:200px"><span class="mut">Hướng dựng</span><br>${esc(a.huong || '')}</div>
    </div>
    <div class="mut" style="font-size:12px;margin-top:6px">${esc(a.dang_mo_ta || '')}</div>
    ${a.supported ? '' : '<div class="note" style="margin-top:8px">⚠️ Dạng này pipeline làm lại chưa hỗ trợ tốt — kiểm tay trước khi đẩy loạt.</div>'}
  </div>` : `<div class="note" style="margin-bottom:12px">Chưa phân tích lô này — bấm <b>🔍 Phân tích lô</b> để AI chốt dạng + kiểu ảnh + chủ đề.</div>`;

  // preset đẩy Xưởng
  const curStyle = fbpSrcStyle || (a && a.kieu_anh) || 'real';
  const preset = `<div class="fbrow" style="gap:12px;align-items:center;margin-bottom:10px;flex-wrap:wrap">
    <label class="mut">Kiểu ảnh <select class="txt" onchange="fbpSrcStyle=this.value;render()">
      ${FBP_STYLES.map(([v, l]) => `<option value="${v}" ${v === curStyle ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    <label class="mut">Model <select class="txt" onchange="fbpSrcClip=this.value;render()">
      ${FBP_SRC_CLIPS.map(([v, l]) => `<option value="${v}" ${v === fbpSrcClip ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    <label class="mut">Âm thanh <select class="txt" onchange="fbpSrcAudio=this.value;render()">
      <option value="B" ${fbpSrcAudio === 'B' ? 'selected' : ''}>Giữ tiếng gốc</option>
      <option value="A" ${fbpSrcAudio === 'A' ? 'selected' : ''}>Giọng + nhạc mới</option></select></label>
    <span class="mut" style="font-size:12px">Ước tính ~<b>${(fbpSrcData.credit_per_reel || 0).toLocaleString()}</b> credit/reel (7 cảnh)</span></div>`;

  const rows = fbpSrcData.reels || [];
  const nsel = fbpSrcSel.size;
  const totalCr = nsel * (fbpSrcData.credit_per_reel || 0);
  const bulk = nsel ? `<div class="fpbulk" style="margin:8px 0">
    <b>${nsel}</b> reel chọn · ước tính <b>${totalCr.toLocaleString()}</b> credit
    <button class="btn sm primary" onclick="fbpSrcPush()">⬆ Chuyển qua Xưởng (${nsel})</button>
    <button class="btn sm ghost" onclick="fbpSrcSel.clear();render()">Bỏ chọn</button></div>` : '';

  const allOn = rows.length && rows.every(r => fbpSrcSel.has(r.id));
  const body = rows.map(r => `<tr>
    <td style="text-align:center"><input type="checkbox" ${fbpSrcSel.has(r.id) ? 'checked' : ''} onchange="fbpSrcSelToggle('${r.id}',this.checked)"></td>
    <td>${r.thumb ? `<img src="${esc(r.thumb)}" style="width:44px;height:78px;object-fit:cover;border-radius:6px" loading="lazy">` : ''}</td>
    <td><a href="${esc(r.href || '#')}" target="_blank" class="mut" style="font-size:12px">${esc(r.id)}</a></td>
    <td><b>${r.view_text || (r.views != null ? r.views.toLocaleString() : '—')}</b></td>
    <td class="mut">${r.length ? Math.round(r.length) + 's' : '—'}</td>
    <td>${r.downloaded ? '<span class="tag done">đã tải</span>' : '<span class="tag wait">chưa tải</span>'}</td>
  </tr>`).join('');

  return bar + anaCard + preset + bulk + `<div class="card"><div class="tablewrap"><table class="fptbl">
    <thead><tr><th style="width:34px"><input type="checkbox" ${allOn ? 'checked' : ''} onchange="fbpSrcSelAll(this.checked)"></th>
    <th>Ảnh</th><th>Reel</th><th>Views</th><th>Dài</th><th>Trạng thái</th></tr></thead>
    <tbody>${body || `<tr><td colspan="6" class="mut" style="text-align:center;padding:20px">Chưa có reel — cào nguồn trước.</td></tr>`}</tbody>
  </table></div></div>`;
}
function fbpAutoTab() {
  const pages = (fbpPages.pages || []).filter(p => p.can_post && p.allowed);
  const pgSel = (rid) => `<select class="txt" style="width:100%" onchange="fbpAutoEdit('${rid.id}','page_id',this.value)">
    ${pages.map(p => `<option value="${p.id}" ${p.id === rid.page_id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select>`;
  const styleSel = r => `<select class="txt" onchange="fbpAutoEdit('${r.id}','style',this.value)">${FBP_STYLES.map(([v, l]) => `<option value="${v}" ${(r.style || 'real') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
  // "Kiểu video" — TẤT CẢ model i2v 79AI (nạp thật, có giá). Model đang chọn mà chưa có trong
  // danh sách (chưa nạp xong) vẫn giữ 1 option để không mất lựa chọn.
  const clipSel = r => {
    const cur = r.clip || 'grok_video_heavy';
    const list = fbpVideoModels.length ? fbpVideoModels : [{ model: cur, name: fbpClipLabel(cur), price: fbpVideoPrice(cur) }];
    const has = list.some(m => m.model === cur);
    const opts = (has ? list : [{ model: cur, name: fbpClipLabel(cur), price: fbpVideoPrice(cur) }, ...list])
      .map(m => `<option value="${esc(m.model)}" ${m.model === cur ? 'selected' : ''}>${esc(m.name)} (${(m.price || 0).toLocaleString()})</option>`).join('');
    return `<select class="txt" style="max-width:190px" onchange="fbpAutoEdit('${r.id}','clip',this.value)">${opts}</select>`;
  };
  const blList = r => {
    if (!r._blOpen || !r._bl) return '';
    const its = (r._bl.items || []);
    const cells = its.slice(0, 60).map(it => `<span class="blchip ${it.done ? 'done' : ''}" title="${it.done ? 'đã làm' : 'chưa làm'} · ${esc(it.view_text || '')}">${it.done ? '✓' : ''}${esc((it.id || '').slice(-5))}</span>`).join('');
    return `<tr class="blrow"><td colspan="6">
      <div class="mut" style="font-size:11px;margin-bottom:5px">Backlog cũ→mới (${its.length}) — ô sáng = chưa làm, ✓ = đã làm. Làm lần lượt từ TRÁI (cũ nhất):</div>
      <div class="blwrap">${cells}${its.length > 60 ? `<span class="mut" style="font-size:11px">+${its.length - 60} nữa…</span>` : ''}</div></td></tr>`;
  };
  const rows = fbpAutoRows.map(r => `<tr>
    <td style="min-width:150px">${pgSel(r)}</td>
    <td style="min-width:230px"><input type="text" class="txt" style="width:100%" placeholder="https://facebook.com/<page>/reels/ hoặc /reel/<id>" value="${esc(r.link)}" oninput="fbpAutoEdit('${r.id}','link',this.value)"></td>
    <td><select class="txt" onchange="fbpAutoEdit('${r.id}','audio',this.value)"><option value="B" ${r.audio === 'B' ? 'selected' : ''}>${FBP_AUDIO.B}</option><option value="A" ${r.audio === 'A' ? 'selected' : ''}>${FBP_AUDIO.A}</option></select></td>
    <td>${clipSel(r)}</td>
    <td>${styleSel(r)}</td>
    <td style="white-space:nowrap">
      <button class="btn sm ghost" title="Cào nguồn dựng backlog cũ→mới" onclick="fbpBacklogBuild('${r.id}')">⬇ DS</button>
      <button class="btn sm ghost" title="Xem/ẩn danh sách backlog" onclick="fbpBacklogLoad('${r.id}').then(()=>fbpBacklogToggle('${r.id}'))">📋</button>
      ${r._bl ? `<span class="tag ${r._bl.remain ? 'sched' : 'done'}" title="còn ${r._bl.remain} chưa làm / ${r._bl.total} tổng · kế tiếp cũ nhất ${r._bl.next || '—'}">${r._bl.done}/${r._bl.total} · còn ${r._bl.remain}</span>` : ''}
      <button class="btn sm ghost" onclick="fbpAutoDel('${r.id}')">✕</button></td></tr>${blList(r)}`).join('');
  return `<div class="fbstat">Chỉ GÁN <b>Page ↔ Link nguồn</b> (+ Audio/Clip/Kiểu ảnh) ở đây. Chạy bằng <b>▶ Star</b> ở tab <b>Tổng quan page</b> (tích page → Star). <b>Cách đăng</b> (đăng luôn / hẹn sau khi làm xong) chọn ở Tổng quan hoặc <b>Cài đặt</b>.</div>
    <div class="toolbar">
      <button class="btn" onclick="fbpAutoAddRow()">＋ Thêm dòng</button>
      <button class="btn ghost" onclick="fbpAutoAddPerPage()">＋ 1 dòng mỗi page</button>
      <button class="btn primary" onclick="fbpAutoSave()">💾 Lưu mapping</button>
    </div>
    <div class="tablewrap"><table><thead><tr><th>Page</th><th>Link nguồn</th><th>Audio</th><th>Kiểu video</th><th>Kiểu ảnh</th><th></th></tr></thead>
    <tbody>${rows || '<tr><td colspan="6" class="mut" style="text-align:center;padding:20px">Chưa có dòng nào — bấm "＋ Thêm dòng".</td></tr>'}</tbody></table></div>
    <div class="note" style="margin-top:12px">⚠️ Đây là nơi <b>GÁN nguồn ↔ page</b> — muốn chạy vào <b>Tổng quan page</b> tích page rồi <b>▶ Star</b> → hộp chọn <b>cách đăng</b> (đăng luôn / hẹn giờ) + <b>số bài</b> + <b>giãn cách phút</b>, xong bấm Bắt đầu. Làm <b>tuần tự</b> từng bài, bài sau bắt đầu sau khi bài trước đăng xong. <b>Link page nguồn</b> (vd <code>/tenpage/reels/</code>): bấm <b>⬇ DS</b> cào dựng <b>backlog cũ→mới</b>, <b>📋</b> xem — tự lấy reel <b>CŨ NHẤT chưa làm</b>. Link <code>/reel/&lt;id&gt;</code> = 1 video cố định. Audio: <b>B</b> giữ tiếng gốc · <b>A</b> giọng+nhạc mới. <b>Kiểu video</b>: ${fbpVideoModels.length ? `<b>${fbpVideoModels.length}</b> model i2v 79AI` : 'đang nạp model 79AI…'} (grok/veo/kling/hailuo… — số trong ngoặc là credit/clip). Kiểu ảnh: <b>${FBP_STYLES.length}</b> kiểu AI (Thật / Hoạt hình / Anime / Sơn dầu…). Đủ số bài là <b>dừng hẳn</b> — muốn chạy nữa bấm <b>▶ Làm tiếp</b>.</div>`;
}

function fbpCfgTab() {
  const s = fbpSummary || {};
  const ok = fbpPages && fbpPages.ok;
  return `<div class="toolbar" style="margin-bottom:12px"><span class="chips">
      <button class="btn sm ghost" onclick="fbpSetTab('pages')">🔑 Page &amp; Token (BM · whitelist)</button>
      <button class="btn sm ghost" onclick="fbpSetTab('acc')">🧑 Tài khoản Chrome</button>
    </span></div>
    <div class="panel" style="max-width:660px">
    <h3>Token Facebook (đăng bài)</h3>
    <div class="fbstat" style="margin:2px 0 10px">
      ${ok ? `🟢 Đang dùng token của <b>${esc(fbpPages.me)}</b> — <b>${s.postable}</b>/${s.pages} page đăng được.` : '🔴 Chưa có token hợp lệ.'}
    </div>
    <div class="field"><label class="mut">Dán token (System User hoặc Explorer, bắt đầu EAA…)</label><br>
      <textarea class="txt" style="width:100%;height:70px" placeholder="EAA…" oninput="fbpTokenInput=this.value">${esc(fbpTokenInput)}</textarea></div>
    <button class="btn primary" onclick="fbpSaveToken()">Lưu &amp; kiểm tra token</button>
    <button class="btn" style="margin-left:8px" onclick="fbpReloadPages()" title="Vừa thêm page vào BM? Bấm để nạp page mới (không cần dán lại token)">🔄 Nạp lại page (thêm page mới từ BM)</button>
    <div class="mut" style="margin-top:10px;font-size:12px">Lưu vào <code>keys.env</code> (gitignore), kiểm hợp lệ rồi hiện số page ngay. <b>Thêm page vào BM</b> → bấm <b>🔄 Nạp lại page</b> (page mới tự thêm vào whitelist, dùng được ngay).</div>
    <div class="mut" style="margin-top:8px;font-size:12px">⚠️ Token Explorer sống ~1-2h. Lâu dài dùng <b>System User token</b> (không hết hạn) — hoặc để app tự lấy bên dưới 👇.</div>
  </div>
  ${fbpGrabPanel()}
  ${fbpBmPanel()}
  ${fbpViralPanel()}
  ${fbpDripPanel()}
  ${fbpGovPanel()}
  ${fbpAutopilotPanel()}`;
}
function fbpViralPanel() {
  const cur = fbpViralInput != null ? fbpViralInput : ((fbpInsights || {}).viral_views || 100000);
  return `<div class="panel" style="max-width:660px;margin-top:16px">
    <h3>🔥 Ngưỡng "viral"</h3>
    <div class="mut" style="font-size:12.5px;margin-bottom:10px">Bài đạt ≥ số views này = đánh dấu <b>viral</b> (🔥) ở Tổng quan page. Số liệu lấy từ Graph API khi bấm <b>Đồng bộ số liệu</b>.</div>
    <div class="fbrow" style="gap:8px;align-items:center">
      <input type="number" class="txt" style="width:160px" min="1000" step="1000" value="${cur}" oninput="fbpViralInput=parseInt(this.value)||0">
      <span class="mut">views</span>
      <button class="btn primary" onclick="fbpSaveViral()">Lưu ngưỡng</button>
    </div>
  </div>`;
}
async function fbpSaveViral() {
  const v = fbpViralInput != null ? fbpViralInput : ((fbpInsights || {}).viral_views || 100000);
  if (!v || v < 1000) return toast('Ngưỡng tối thiểu 1000 views.', 'err');
  await act(async () => {
    await api('/config', { method: 'POST', body: { viral_views: v } });
    fbpInsights = await api('/fb-post/insights').catch(() => fbpInsights);
    fbpViralInput = null;
    render();
  }, 'Đã lưu ngưỡng viral.');
}

/* ── Lấy System User token (không hết hạn) BÁN TỰ ĐỘNG qua Chrome đã đăng nhập ──
   ĐO THẬT: token nhúng sẵn trong trang Meta là first-party → Graph công khai từ chối,
   KHÔNG cào-rồi-đúc được. Nên: app mở đúng trang → bạn bấm Generate (OAuth phải người
   thật) → app ĐỌC token từ ô rồi kiểm + lưu. */
function fbpGrabPanel() {
  const g = fbpGrab;
  return `<div class="panel" style="max-width:660px;margin-top:16px">
    <h3>🤖 Lấy token qua trình duyệt <span class="mut">System User — không hết hạn</span></h3>
    <div class="mut" style="font-size:12.5px;line-height:1.75;margin-bottom:10px">
      3 bước — app lo 2 đầu, bạn chỉ bấm Generate:
      <div style="margin-top:6px">
        <b>1.</b> Bấm <b>Mở trang tạo token</b> → Chrome quản lý (đã đăng nhập) mở trang System Users.<br>
        <b>2.</b> Trong Chrome: chọn/ tạo <b>System User</b> → <b>Generate new token</b> → chọn <b>App</b> → tick <code>pages_manage_posts</code>, <code>pages_show_list</code> → Generate.<br>
        <b>3.</b> Token hiện trên màn hình → quay lại đây bấm <b>Đọc token từ trình duyệt</b> (app tự kiểm + lưu).
      </div>
    </div>
    <div class="field"><label class="mut">Đặt tên (hiện ở danh sách BM)</label>
      <input type="text" class="txt" style="width:220px;margin-left:8px" placeholder="vd: SysUser-chính" value="${esc(g.sel.name)}" oninput="fbpGrab.sel.name=this.value"></div>
    <div class="fbrow" style="gap:8px;margin-top:8px">
      <button class="btn" onclick="fbpGrabOpen()">① Mở trang tạo token</button>
      <button class="btn primary ${g.busy ? '' : ''}" ${g.busy ? 'disabled' : ''} onclick="fbpGrabRead()">${g.busy ? '⏳ Đang đọc…' : '② Đọc token từ trình duyệt'}</button>
    </div>
    <div class="mut" style="margin-top:10px;font-size:12px">⚠️ Vì sao không hoàn toàn tự động: token nhúng sẵn trong trang Meta bị Graph công khai chặn (đã đo). Chỉ token do bạn tự Generate mới dùng được — nên cần đúng 1 cú bấm Generate của bạn. Dùng chung cửa sổ Chrome với tab <b>Tải video FB</b> (đăng nhập Facebook ở đó 1 lần — KHÁC hồ sơ ở tab Tài khoản).</div>
  </div>`;
}
async function fbpGrabOpen() {
  const r = await act(() => api('/fb-post/token/open-page', { method: 'POST', body: {} }),
    'Đã mở trang tạo token trong Chrome quản lý.');
  if (r) toast(r.logged_in ? 'Trang đã mở — bấm Generate token trong Chrome' : '⚠️ Chrome chưa đăng nhập — đăng nhập Facebook trong cửa sổ đó trước', r.logged_in ? 'ok' : 'err');
}
async function fbpGrabRead() {
  fbpGrab.busy = true; render();
  try {
    const r = await api('/fb-post/token/read-browser', { method: 'POST', body: { name: fbpGrab.sel.name || 'System User' } });
    toast(`🔑 ${r.me} · ${r.count} page — token không hết hạn, đã lưu`, 'ok');
    act(loadFbPost);
  } catch (e) { toast(e.message || 'Đọc token lỗi', 'err'); }
  fbpGrab.busy = false; render();
}

function fbpBmPanel() {
  const rows = fbpTokens.map(t => `<tr><td><span class="th-s">🏢</span> ${esc(t.name)}</td>
    <td><button class="btn sm ghost" onclick="fbpDelBm('${esc(t.name)}')">✕ gỡ</button></td></tr>`).join('');
  return `<div class="panel" style="max-width:660px;margin-top:16px">
    <h3>🏢 Nhiều Business Manager <span class="mut">chia rủi ro — 1 sự cố không chết chùm</span></h3>
    <div class="tablewrap" style="border:none;margin-bottom:10px"><table><thead><tr><th>BM / Tài khoản</th><th></th></tr></thead>
      <tbody>${rows || '<tr><td colspan="2" class="mut">Chưa có — token "chính" tự migrate khi bạn dán ở trên.</td></tr>'}</tbody></table></div>
    <div class="fbrow">
      <input type="text" class="txt" style="width:150px" placeholder="Tên BM (vd BM-2)" value="${esc(fbpBmNew.name)}" oninput="fbpBmNew.name=this.value">
      <input type="text" class="txt" style="flex:1" placeholder="Token System User của BM đó (EAA…)" value="${esc(fbpBmNew.token)}" oninput="fbpBmNew.token=this.value">
      <button class="btn" onclick="fbpAddBm()">＋ Thêm BM</button>
    </div>
    <div class="mut" style="margin-top:8px;font-size:12px">Mỗi BM 1 token riêng → page gộp chung ở mọi tab. Hàng trăm page nên chia nhiều BM.</div>
  </div>`;
}
async function fbpAddBm() {
  if (!fbpBmNew.token) return toast('Dán token BM.', 'err');
  const r = await act(() => api('/fb-post/tokens', { method: 'POST', body: { name: fbpBmNew.name || 'BM', token: fbpBmNew.token.trim() } }), null);
  if (r) { fbpBmNew = { name: '', token: '' }; toast(`Đã thêm ${r.name} · ${r.count} page`, 'ok'); act(loadFbPost); }
}
async function fbpDelBm(name) {
  if (!confirm(`Gỡ BM "${name}"? (page của BM này biến khỏi danh sách)`)) return;
  await act(() => api('/fb-post/tokens/' + encodeURIComponent(name), { method: 'DELETE' }), 'Đã gỡ BM.');
  act(loadFbPost);
}

function fbpAutopilotPanel() {
  const a = fbpAuto || { enabled: false, interval_min: 60 };
  return `<div class="panel" style="max-width:660px;margin-top:16px">
    <h3>🔁 Autopilot (cron) <span class="mut">tự lặp lại theo chu kỳ</span></h3>
    <div class="mut" style="font-size:12.5px;margin-bottom:10px">Bật/tắt chạy giờ gộp ở <b>Tổng quan page</b> (tích page → <b>▶ Start</b> / <b>⏹ Stop</b>). Ô dưới chỉ chỉnh <b>chu kỳ quét</b> — mỗi chu kỳ hệ tự bù bài cho các page đang Start tới đủ nhịp/ngày.</div>
    <label class="fbchk" style="margin-bottom:10px"><input type="checkbox" ${a.enabled ? 'checked' : ''} onchange="fbpAutoCfgEdit('enabled',this.checked)"> Bật vòng lặp cron (Start ở Tổng quan tự bật ô này)</label>
    <div class="field"><label class="mut">Chu kỳ quét (phút)</label><br>
      <input type="number" class="txt" style="width:110px" value="${a.interval_min ?? 60}" onchange="fbpAutoCfgEdit('interval_min',+this.value)"></div>
    <button class="btn primary" onclick="fbpSaveAutopilot()">Lưu autopilot</button>
    <div class="mut" style="margin-top:10px;font-size:12px">Mỗi chu kỳ: nếu bộ hãm CHO PHÉP → đẩy job cho các dòng đã bật 🔁 (trong hạn mức/ngày). Chỉ chạy khi app đang bật. Mặc định TẮT cho an toàn.</div>
  </div>`;
}
function fbpAutoCfgEdit(k, v) { if (!fbpAuto) fbpAuto = {}; fbpAuto[k] = v; }
async function fbpSaveAutopilot() {
  await act(() => api('/fb-post/autopilot', { method: 'POST', body: fbpAuto || {} }), 'Đã lưu autopilot.');
  act(loadFbPost);
}

/* CÁCH ĐĂNG mặc định (dùng khi bấm ▶ Star — vẫn chỉnh lại được trong hộp Star).
   Đăng luôn / Lên lịch (giờ cụ thể) + số bài + giãn cách phút. */
function fbpDripPanel() {
  const d = fbpDrip || {};
  const mode = d.post_mode || 'now';
  const opt = (m, lb, sub) => `<label class="fbchk" style="display:block;margin-bottom:8px">
    <input type="radio" name="fbpm" ${mode === m ? 'checked' : ''} onchange="fbpDripEdit('post_mode','${m}');render()">
    <b>${lb}</b> <span class="mut" style="font-size:12px">— ${sub}</span></label>`;
  return `<div class="panel" style="max-width:660px;margin-top:16px">
    <h3>🕒 Cách đăng mặc định <span class="mut">áp khi bấm ▶ Star (chỉnh lại được trong hộp Star)</span></h3>
    ${opt('now', '⚡ Đăng luôn', 'video đầu làm xong là đăng ngay; bài sau cách nhau bên dưới')}
    ${opt('schedule', '🗓 Lên lịch', 'đăng vào giờ cụ thể')}
    ${mode === 'schedule' ? `<div class="fbrow" style="gap:12px;margin:6px 0 4px 24px">
      <div class="field"><label class="mut">Giờ đăng bài đầu</label><br>
        <input type="time" class="txt" value="${esc(d.post_hhmm || '08:00')}" onchange="fbpDripEdit('post_hhmm',this.value)"></div>
      <div class="field"><label class="mut">Bắt đầu từ</label><br>
        <select class="txt" onchange="fbpDripEdit('post_day_offset',+this.value)">${[[0, 'Hôm nay'], [1, 'Ngày mai'], [2, '+2 ngày'], [3, '+3 ngày']].map(([v, l]) => `<option value="${v}" ${(+(d.post_day_offset ?? 1)) === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    </div>` : ''}
    <div class="fbrow" style="gap:12px;margin-top:10px">
      <div class="field"><label class="mut">Số bài mỗi lần Star</label><br>
        <input type="number" class="txt" style="width:90px" min="1" value="${d.run_target || 1}" onchange="fbpDripEdit('run_target',Math.max(1,+this.value||1))"></div>
      <div class="field"><label class="mut">Giãn cách mỗi bài (phút)</label><br>
        <input type="number" class="txt" style="width:100px" min="0" value="${d.gap_min ?? 60}" onchange="fbpDripEdit('gap_min',Math.max(0,+this.value||0))"></div>
    </div>
    <div class="mut" style="font-size:12px;margin-top:8px">Làm tuần tự: bài sau chỉ bắt đầu sau khi bài trước ĐĂNG xong; giờ đăng bài sau cách bài trước đúng số phút trên. (FB cần ≥10 phút với bài hẹn giờ.)</div>
    <button class="btn primary" style="margin-top:12px" onclick="fbpSaveDrip()">Lưu mặc định</button>
  </div>`;
}
function fbpDripEdit(k, v) {
  if (!fbpDrip) fbpDrip = { post_mode: 'now', post_hhmm: '08:00', post_day_offset: 1, run_target: 1, gap_min: 60 };
  fbpDrip[k] = v;
}
async function fbpDripPersist() {
  const d = fbpDrip || {};
  const body = {
    post_mode: d.post_mode || 'now', post_hhmm: d.post_hhmm || '08:00', post_day_offset: d.post_day_offset ?? 1,
    run_target: d.run_target || 1, gap_min: d.gap_min ?? 60,
  };
  fbpDrip = await api('/fb-post/drip', { method: 'POST', body });
  return fbpDrip;
}
async function fbpSaveDrip() { await act(fbpDripPersist, 'Đã lưu cách đăng mặc định.'); }

function fbpGovPanel() {
  const g = (fbpGov && fbpGov.config) || {};
  return `<div class="panel" style="max-width:660px;margin-top:16px">
    <h3>🛡️ Bộ hãm (Governor) <span class="mut">chống cháy credit khi auto</span></h3>
    <label class="fbchk" style="margin-bottom:10px"><input type="checkbox" ${g.enabled ? 'checked' : ''} onchange="fbpGovEdit('enabled',this.checked)"> Bật bộ hãm (khuyên luôn bật)</label>
    <div class="field"><label class="mut">Sàn credit — dưới mức này thì DỪNG làm video</label><br>
      <input type="number" class="txt" style="width:160px" value="${g.floor_credit ?? 8000}" onchange="fbpGovEdit('floor_credit',+this.value)"></div>
    <div class="field"><label class="mut">Trần video làm / ngày (toàn hệ)</label><br>
      <input type="number" class="txt" style="width:100px" value="${g.video_per_day ?? 2}" onchange="fbpGovEdit('video_per_day',+this.value)"></div>
    <div class="field"><label class="mut">Trần bài / page / ngày</label><br>
      <input type="number" class="txt" style="width:100px" value="${g.post_per_page_day ?? 2}" onchange="fbpGovEdit('post_per_page_day',+this.value)"></div>
    <button class="btn primary" onclick="fbpSaveGov()">Lưu bộ hãm</button>
    <div class="mut" style="margin-top:10px;font-size:12px">Auto sẽ DỪNG làm khi credit dưới sàn hoặc đủ trần/ngày — dù full-auto.</div>
  </div>`;
}
function fbpGovEdit(k, v) { if (!fbpGov) fbpGov = { config: {} }; fbpGov.config[k] = v; }
async function fbpSaveGov() {
  const c = (fbpGov && fbpGov.config) || {};
  await act(() => api('/fb-post/governor', { method: 'POST', body: c }), 'Đã lưu bộ hãm.');
  act(loadFbPost);
}

/* ══════════ TAI VIDEO/REEL FACEBOOK ══════════ */
let fbSess = { alive: false, logged_in: false, targets: 0 };
let fbUrl = '';
let fbPages = [];          // [{slug,count,downloaded,scraped_at}]
let fbSlug = '';           // page dang xem
let fbIndex = null;        // {slug, reels:[...], count, downloaded}
let fbSel = new Set();     // reel id da tick
let fbFilter = 'all';      // all | listed | downloaded
let fbMinViews = 0;        // loc view toi thieu
let fbQuality = 'best';    // best | 720

async function loadFbVideo() {
  fbSess = await api('/fb/session').catch(() => ({ alive: false, logged_in: false, targets: 0 }));
  fbPages = (await api('/fb/pages').catch(() => ({ pages: [] }))).pages || [];
  if (!fbSlug && fbPages.length) fbSlug = fbPages[0].slug;
  if (fbSlug) fbIndex = await api('/fb/index?slug=' + encodeURIComponent(fbSlug)).catch(() => null);
  else fbIndex = null;
  if (fbIndex) {
    const ids = new Set(fbIndex.reels.map(r => r.id));
    fbSel = new Set([...fbSel].filter(id => ids.has(id)));
  }
  render();
}

function fbFmtViews(r) {
  if (r.view_text) return r.view_text;
  const v = r.views || 0;
  if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M';
  if (v >= 1e3) return (v / 1e3).toFixed(0) + 'K';
  return String(v);
}
function fbFiltered() {
  let rows = (fbIndex && fbIndex.reels) || [];
  if (fbFilter === 'listed') rows = rows.filter(r => !r.downloaded);
  else if (fbFilter === 'downloaded') rows = rows.filter(r => r.downloaded);
  if (fbMinViews > 0) rows = rows.filter(r => (r.views || 0) >= fbMinViews);
  return rows;
}

async function fbOpenSession() {
  const st = await act(() => api('/fb/session', { method: 'POST' }),
    'Đã mở cửa sổ Chrome. Đăng nhập Facebook trong cửa sổ đó rồi bấm "Kiểm tra đăng nhập".');
  if (st) { fbSess = { alive: true, logged_in: st.logged_in, targets: st.targets }; render(); }
}
async function fbCheckSession() { await act(loadFbVideo); }
async function fbDoList() {
  const url = (fbUrl || '').trim();
  if (!url) return toast('Dán link page trước.', 'err');
  const r = await act(() => api('/fb/list', { method: 'POST', body: { url } }),
    'Đang liệt kê reel… (xem tiến độ ở Hàng đợi). Bấm "Làm mới" khi xong.');
  if (r) { fbSlug = r.slug; setTimeout(() => { if (S.page === 'fbvideo') act(loadFbVideo); }, 8000); }
}
async function fbDownloadSel() {
  const ids = [...fbSel];
  if (!ids.length) return toast('Chưa chọn reel nào.', 'err');
  const r = await act(() => api('/fb/download', { method: 'POST', body: { slug: fbSlug, ids, quality: fbQuality } }),
    `Đang tải ${ids.length} reel… (xem Hàng đợi). Bấm "Làm mới" khi xong.`);
  if (r) setTimeout(() => { if (S.page === 'fbvideo') act(loadFbVideo); }, 10000);
}
function fbToggle(id, on) { on ? fbSel.add(id) : fbSel.delete(id); render(); }
function fbToggleAll(on) {
  fbFiltered().forEach(r => on ? fbSel.add(r.id) : fbSel.delete(r.id));
  render();
}
function fbSetSlug(s) { fbSlug = s; fbSel = new Set(); fbIndex = null; act(loadFbVideo); }

function pgFbVideo() {
  const s = fbSess;
  const head = `<div class="head"><h1>Tải video FB</h1>
    <span class="sub">tải reel về · sửa nội dung · đăng lại (bài mới)</span>
    <div class="right"><button class="btn ghost" onclick="fbCheckSession()">↻ Làm mới</button></div></div>`;

  const sess = `<div class="fbbar">
    <b>Cửa sổ Chrome quản lý:</b>
    ${s.alive ? (s.logged_in ? '<span class="tag done">Đã đăng nhập Facebook</span>'
      : '<span class="tag draft">Đang mở — chưa đăng nhập</span>')
      : '<span class="tag err">Chưa mở</span>'}
    <button class="btn" onclick="fbOpenSession()">Mở Chrome &amp; đăng nhập</button>
    <button class="btn ghost" onclick="fbCheckSession()">Kiểm tra đăng nhập</button>
    <span class="mut" style="flex-basis:100%;margin-top:4px">Mở cửa sổ Chrome riêng, tự đăng nhập Facebook bằng tay (cookie được giữ — lần sau khỏi đăng nhập lại). Tool không đụng mật khẩu.</span>
  </div>`;

  const lister = `<div class="fbrow">
    <input id="fb-url" type="text" class="txt" style="flex:1" placeholder="Dán link page, vd https://www.facebook.com/tuoitho89x/reels/"
      value="${esc(fbUrl)}" oninput="fbUrl=this.value">
    <button class="btn" ${s.logged_in ? '' : 'disabled title="Đăng nhập trước"'} onclick="fbDoList()">Liệt kê reel</button>
  </div>`;

  let pagePick = '';
  if (fbPages.length) {
    pagePick = `<div class="fbrow" style="margin-top:10px"><span class="mut">Page:</span> ` + fbPages.map(p =>
      `<button class="avchip ${p.slug === fbSlug ? 'on' : ''}" onclick="fbSetSlug('${esc(p.slug)}')">${esc(p.slug)} (${p.downloaded}/${p.count})</button>`
    ).join('') + `</div>`;
  }

  if (!fbIndex) {
    return `${head}<div class="wrap">${sess}${lister}${pagePick}
      ${empty('⬇', 'Chưa có page nào', 'Đăng nhập → dán link page → Liệt kê reel.')}</div>`;
  }

  const rows = fbFiltered();
  const allSel = rows.length && rows.every(r => fbSel.has(r.id));
  const bulk = `<div class="fbrow" style="margin:12px 0">
    <label class="fbchk"><input type="checkbox" ${allSel ? 'checked' : ''} onchange="fbToggleAll(this.checked)"> Chọn tất cả (${rows.length})</label>
    <span class="fbchips">
      ${['all:Tất cả', 'listed:Chưa tải', 'downloaded:Đã tải'].map(x => {
        const [k, lb] = x.split(':');
        return `<button class="avchip ${fbFilter === k ? 'on' : ''}" onclick="fbFilter='${k}';render()">${lb}</button>`;
      }).join('')}
    </span>
    <label class="mut">View ≥ <input class="txt" style="width:90px;display:inline-block" type="number" value="${fbMinViews}" oninput="fbMinViews=+this.value||0;render()"></label>
    <span style="flex:1"></span>
    <label class="mut">Chất lượng
      <select class="txt" style="display:inline-block;width:auto" onchange="fbQuality=this.value">
        <option value="best" ${fbQuality === 'best' ? 'selected' : ''}>Nét nhất</option>
        <option value="720" ${fbQuality === '720' ? 'selected' : ''}>720p (nhẹ)</option>
      </select></label>
    <button class="btn" ${fbSel.size ? '' : 'disabled'} onclick="fbDownloadSel()">Tải ${fbSel.size || ''} reel đã chọn</button>
  </div>`;

  const body = rows.map(r => {
    const thumb = r.downloaded ? `/media/fb/${fbIndex.slug}/${r.id}/thumb`
      : (r.thumb || '');
    const st = r.downloaded ? '<span class="tag done">Đã tải</span>'
      : '<span class="tag draft">Chưa tải</span>';
    const actions = r.downloaded
      ? `<a class="btn ghost sm" href="/media/fb/${fbIndex.slug}/${r.id}/video" target="_blank">▶ Xem</a>`
        + (r.caption ? ` <button class="btn ghost sm" onclick="copy(fbCap('${r.id}'),'caption')">Caption</button>` : '')
      : `<a class="btn ghost sm" href="${esc(r.href)}" target="_blank">Mở FB</a>`;
    return `<tr>
      <td><input type="checkbox" ${fbSel.has(r.id) ? 'checked' : ''} onchange="fbToggle('${r.id}',this.checked)"></td>
      <td>${thumb ? `<img class="fbthumb" src="${esc(thumb)}" loading="lazy" referrerpolicy="no-referrer">` : ''}</td>
      <td><b>${fbFmtViews(r)}</b> view</td>
      <td>${st}</td>
      <td>${actions}</td>
    </tr>`;
  }).join('');

  return `${head}<div class="wrap">${sess}${lister}${pagePick}
    <div class="fbstat">
      <span><b>${fbIndex.count}</b> reel</span>
      <span class="mut">· đã tải <b>${fbIndex.downloaded}</b></span>
      <span class="mut">· đang hiện <b>${rows.length}</b></span>
    </div>
    ${bulk}
    <div class="tablewrap"><table>
      <thead><tr><th></th><th>Ảnh</th><th>View</th><th>Trạng thái</th><th></th></tr></thead>
      <tbody>${body}</tbody>
    </table></div></div>`;
}
// Lay caption tu index (tranh nhung chuoi dai vao HTML inline)
function fbCap(id) {
  const r = (fbIndex && fbIndex.reels || []).find(x => x.id === id);
  return (r && r.caption) || '';
}

const PAGES = ['intake','board','library','images','aivideo','fbvideo','fbpost','voices','voice','settings'];
document.addEventListener('keydown', e => {
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
  const k = e.key.toLowerCase();
  if (k >= '1' && k <= '9') return go(PAGES[+k - 1]);
  if (k === 'r') { const l = loaders[S.page]; if (l) act(l); return; }
  if (k === 'u' && S.page === 'intake') { $('#file-in')?.click(); return; }
  if (k === 'escape') {
    if (S.page === 'episode') return go('board');
    if (selEp.size || selIntake.size) { selEp.clear(); selIntake.clear(); render(); }
    return;
  }
  if (e.code === 'Space' && S.page === 'episode') {
    const a = $('#ep-audio');
    if (a) { e.preventDefault(); a.paused ? a.play() : a.pause(); }
  }
});

$$('.nav-item').forEach(el => el.addEventListener('click', () => go(el.dataset.page)));
(async () => {
  try { appConfig = { ...appConfig, ...(await api('/config')) }; } catch {}
  applyNavConfig();
  go(appConfig.advanced_mode ? 'intake' : 'fbpost');   // advanced OFF -> Tong quan page
  checkOnboarding();                                    // chan neu thieu key bat buoc
  loadBalance();   // nap so du + QUOTA GOI + version cho MOI trang landing (khong chi 'board')
})();
initQueue();
setInterval(() => {
  if (!S.jobs.current) api('/balance').then(b => { S.balance = b; paintQuota(); }).catch(() => {});
  loadSubQuota();   // lam moi quota goi (video/anh con lai) dinh ky
}, 120000);

// TIẾN TRÌNH sống: khi đang xem "Tổng quan page" và có page ĐANG SẢN XUẤT → tự nạp lại
// fanpages + pipeline (chỉ đọc file, KHÔNG gọi Graph) để cột TIẾN TRÌNH chạy "Đang tạo ảnh
// 3/7"... như log hàng đợi. Bỏ qua khi đang gõ ô nhập (khỏi giật/mất focus).
setInterval(async () => {
  if (S.page !== 'fbpost' || fbpTab !== 'fanpage') return;
  const rows = (fbpFanpages && fbpFanpages.fanpages) || [];
  const pipeBusy = ((fbpPipe && fbpPipe.items) || [])
    .some(it => ['queued', 'downloading', 'remaking', 'scheduling'].includes(it.status));
  if (!rows.some(r => r.st === 'producing') && !pipeBusy) return;
  const ae = document.activeElement;
  if (ae && ['INPUT', 'TEXTAREA', 'SELECT'].includes(ae.tagName)) return;
  try {
    const [fp, pp] = await Promise.all([api('/fb-post/fanpages'), api('/fb-post/pipeline')]);
    if (fp) fbpFanpages = fp;
    if (pp) fbpPipe = pp;
    render();
  } catch {}
}, 9000);
