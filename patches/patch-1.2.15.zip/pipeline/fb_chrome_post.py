# -*- coding: utf-8 -*-
"""
DANG REEL BANG CHROME (CDP) — thay cho Graph API token.

Vi sao co: token FB hay bi Meta khoa ("API access blocked" code 200). Duong Chrome
dang NHU NGUOI THAT bang chinh phien Chrome da dang nhap -> khong phu thuoc token.
Bonus: composer co o TIEU DE + o THE ma Graph API KHONG co.

TAT CA ky thuat duoi day DO THAT trong POC 2026-07-25 (reel_id 1571663527918104,
verify Graph API 200). Xem docs/hook-chu-va-dang-bang-chrome.md.

LUONG (composer Business Suite, 3 buoc Tao -> Chinh sua -> Chia se):
  1. mo tab  business.facebook.com/latest/reels_composer?asset_id=<page_id>
  2. hook HTMLInputElement.prototype.click  (chan hop thoai file cua Windows)
  3. click "Them video" -> FB goi input.click() -> ta giu duoc node input
  4. DOM.setFileInputFiles(node, mp4)  -> cho upload 100%
  5. tieu de  : NATIVE SETTER + input/change event   (o <input> React)
  6. mo ta+tag: Input.insertText                     (o div[role=textbox])
  7. the      : Input.insertText + Enter  -> moi the thanh 1 chip
  8. "Tiep" -> "Tiep" -> chon "Chi su dung am thanh goc" -> "Chia se ngay"
  9. nut "Chia se" o FOOTER: PHAI dispatchMouseEvent (element.click() KHONG an)

BA BAY (dung sua lai cho "gon" keo hong):
  - `element.click()` khong bam duoc nut submit cuoi -> Input.dispatchMouseEvent.
  - Text trung nhau: "Chia se" khop CA tab breadcrumb LAN nut footer -> loc theo
    kich thuoc + lay cai `top` LON NHAT.
  - KHONG bam "Quay lai": React reset sach o mo ta.
"""
import json
import os
import time

import fb_session as S

COMPOSER = "https://business.facebook.com/latest/reels_composer?asset_id=%s"

UPLOAD_WAIT = int(os.environ.get("CS_CHROME_UPLOAD_WAIT", "600"))   # cho upload (giay)
STEP_WAIT = float(os.environ.get("CS_CHROME_STEP_WAIT", "6"))       # cho doi buoc


# ─────────────────────────── JS dung chung ───────────────────────────
_HOOK = """
(() => {
  if (window.__cs_hooked) return 'hooked';
  window.__cs_hooked = 1; window.__cs_grabbed = null;
  const orig = HTMLInputElement.prototype.click;
  HTMLInputElement.prototype.click = function () {
    if (this.type === 'file') { window.__cs_grabbed = this; return; }   // chan native dialog
    return orig.apply(this, arguments);
  };
  return 'ok';
})()
"""

# Click theo TEXT. `bottom=1` -> lay phan tu THAP NHAT tren man hinh (nut footer,
# tranh trung ten voi tab breadcrumb o dau trang).
_CLICK_TEXT = """
(() => {
  const want = %s, bottom = %s;
  let cands = [...document.querySelectorAll('div[role=button],button,span')]
    .filter(e => want.includes((e.innerText || '').trim()));
  if (bottom) cands = cands.filter(e => { const r = e.getBoundingClientRect();
                                          return r.width > 40 && r.height > 20; });
  if (!cands.length) return 'NOTFOUND';
  cands = cands.map(e => ({e, r: e.getBoundingClientRect()}));
  cands.sort((a, b) => bottom ? b.r.top - a.r.top : a.r.top - b.r.top);
  const el = cands[0].e.closest('div[role=button],button') || cands[0].e;
  if (el.getAttribute('aria-disabled') === 'true') return 'DISABLED';
  el.click();
  return 'ok';
})()
"""

# Toa do TAM cua element tim theo text (doc TU DOM, khong hardcode) -> de dispatch chuot that.
_RECT_TEXT = """
(() => {
  let c = [...document.querySelectorAll('div[role=button],button')]
    .filter(e => (e.innerText || '').trim() === %s)
    .map(e => ({e, r: e.getBoundingClientRect()}))
    .filter(x => x.r.width > 40 && x.r.height > 20)
    .sort((a, b) => b.r.top - a.r.top);
  if (!c.length) return null;
  c[0].e.scrollIntoView({block: 'center'});
  const r = c[0].e.getBoundingClientRect();
  return JSON.stringify({x: r.left + r.width / 2, y: r.top + r.height / 2});
})()
"""

# O <input> React: native setter + input/change (Input.insertText KHONG an - da do).
_SET_INPUT = """
(() => {
  const e = [...document.querySelectorAll('input')]
    .find(x => ((x.getAttribute('aria-label') || '') + (x.placeholder || '')).includes(%s));
  if (!e) return 'NOTFOUND';
  const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  e.focus(); set.call(e, %s);
  e.dispatchEvent(new Event('input', {bubbles: true}));
  e.dispatchEvent(new Event('change', {bubbles: true}));
  return e.value;
})()
"""

_FOCUS = """
(() => {
  const e = [...document.querySelectorAll(%s)]
    .find(x => ((x.getAttribute('aria-label') || '') + (x.placeholder || '')).includes(%s));
  if (!e) return 'NOTFOUND';
  e.focus(); e.click(); return 'ok';
})()
"""

# Chon radio theo CAU MO TA (vd "Chi su dung am thanh goc").
_PICK_RADIO = """
(() => {
  for (const r of document.querySelectorAll('div[role=radio],input[type=radio]')) {
    let p = r, hit = false;
    for (let i = 0; i < 6 && p; i++, p = p.parentElement) {
      const s = (p.innerText || '').trim();
      if (s.includes(%s)) { hit = true; break; }
      if (s.length > 200) break;
    }
    if (hit) { (r.closest('div[role=radio]') || r).click(); return 'ok'; }
  }
  return 'NOTFOUND';
})()
"""

_UPLOAD_PCT = """
(() => {
  const t = document.body.innerText;
  const m = t.match(/(\\d{1,3})\\s*%/);
  return JSON.stringify({pct: m ? +m[1] : -1, safe: t.includes('an toàn để đăng')});
})()
"""


def _log(msg):
    print("[chrome-post] %s" % msg, flush=True)


def _tab_for(port, url):
    """Mo tab moi toi url, tra ve target."""
    import urllib.request
    req = urllib.request.Request("http://127.0.0.1:%d/json/new?%s" % (port, url), method="PUT")
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def _close_tab(port, tid):
    import urllib.request
    try:
        urllib.request.urlopen("http://127.0.0.1:%d/json/close/%s" % (port, tid), timeout=8)
    except Exception:
        pass


def _real_click(c, x, y):
    """Click CHUOT THAT (nut submit cuoi KHONG nhan element.click())."""
    c.send("Input.dispatchMouseEvent", {"type": "mouseMoved", "x": x, "y": y})
    time.sleep(0.1)
    for typ in ("mousePressed", "mouseReleased"):
        c.send("Input.dispatchMouseEvent", {"type": typ, "x": x, "y": y,
                                            "button": "left", "clickCount": 1})
        time.sleep(0.1)


def _wait_text(c, words, timeout=90):
    """Cho toi khi trang HIEN 1 trong cac cum tu (composer render xong).

    KHONG duoc cho theo do dai innerText: sidebar Business Suite da co san vai tram ky tu
    nen dieu kien do thoa SOM khi composer con dang quay vong -> tim nut khong thay (da do that).
    """
    js = ("(() => { const t = document.body.innerText; return %s.some(w => t.includes(w)) ? 1 : 0; })()"
          % json.dumps(list(words)))
    end = time.time() + timeout
    while time.time() < end:
        try:
            if c.eval(js):
                return True
        except Exception:
            pass
        time.sleep(2)
    return False


def _enter(c):
    for typ in ("keyDown", "keyUp"):
        c.send("Input.dispatchKeyEvent", {"type": typ, "key": "Enter", "code": "Enter",
                                          "windowsVirtualKeyCode": 13})
    time.sleep(0.6)


class ChromePostError(RuntimeError):
    """Loi doc duoc de ghi thang vao pipeline item."""


def post_reel(page_id: str, video: str, caption: str = "", title: str = "",
              tags=None, port: int = S.DEFAULT_PORT, audio_mode: str = "original_only",
              shot_dir: str = "", keep_tab: bool = False) -> dict:
    """Dang 1 reel len page bang Chrome. Tra {ok, page_id, video, seconds}.

    audio_mode: 'original_only' (mac dinh, "Chi su dung am thanh goc")
              | 'remix' (cho remix)  | 'none' (khong cho phep)
    shot_dir  : co thi chup man hinh khi LOI (bang chung, theo rule #1).
    Nem ChromePostError voi ly do DOC DUOC neu that bai.
    """
    if not os.path.isfile(video):
        raise ChromePostError("Khong thay file video: %s" % video)
    if not S.is_alive(port):
        raise ChromePostError("Chrome chua mo (cong CDP %d). Mo phien Chrome truoc." % port)
    if not S.logged_in(port):
        raise ChromePostError("Chrome chua dang nhap Facebook (thieu cookie c_user).")

    tags = [t for t in (tags or []) if str(t).strip()]
    t0 = time.time()
    tab = _tab_for(port, COMPOSER % page_id)
    c = S.CDP(tab["webSocketDebuggerUrl"])

    def shot(name):
        if not shot_dir:
            return ""
        try:
            import base64
            os.makedirs(shot_dir, exist_ok=True)
            r = c.send("Page.captureScreenshot", {"format": "png"}, timeout=60)
            p = os.path.join(shot_dir, "%s_%s.png" % (page_id, name))
            open(p, "wb").write(base64.b64decode(r["data"]))
            return p
        except Exception:
            return ""

    def fail(msg, step):
        p = shot("loi_" + step)
        _close_tab(port, tab["id"]) if not keep_tab else None
        raise ChromePostError("%s (buoc: %s)%s" % (msg, step, (" · anh: %s" % p) if p else ""))

    try:
        c.send("DOM.enable"); c.send("Runtime.enable"); c.send("Page.enable")
        if not _wait_text(c, ["Thêm video", "File phương tiện"], timeout=120):
            fail("Composer Reels khong render sau 120s (mang cham / FB doi giao dien?)", "mo_composer")

        # ── 1. nap video ──
        c.eval(_HOOK)
        if c.eval(_CLICK_TEXT % (json.dumps(["Thêm video"]), "0")) != "ok":
            fail("Khong thay nut 'Them video' (composer doi giao dien?)", "them_video")
        grabbed = False
        for _ in range(15):
            time.sleep(1)
            if c.eval("window.__cs_grabbed ? 1 : 0"):
                grabbed = True
                break
        if not grabbed:
            fail("Khong bat duoc o chon file (hook input.click that bai)", "hook_input")
        r = c.send("Runtime.evaluate", {"expression": "window.__cs_grabbed", "returnByValue": False})
        c.send("DOM.setFileInputFiles", {"objectId": r["result"]["objectId"], "files": [video]})
        _log("da nap %s" % os.path.basename(video))

        # cho upload xong. LUU Y: input.files doc ra 0 du upload THAT thanh cong ->
        # bam vao % tien do / cau "an toan de dang", KHONG bam vao input.files.
        end = time.time() + UPLOAD_WAIT
        ok_up = False
        while time.time() < end:
            time.sleep(3)
            try:
                d = json.loads(c.eval(_UPLOAD_PCT) or "{}")
            except Exception:
                d = {}
            if d.get("safe") or d.get("pct") == 100:
                ok_up = True
                break
        if not ok_up:
            fail("Upload video khong xong sau %ds" % UPLOAD_WAIT, "upload")
        _log("upload xong (%.0fs)" % (time.time() - t0))

        # ── 2. tieu de / mo ta / the (dien MOT LUOT, KHONG quay lai buoc) ──
        if title:
            v = c.eval(_SET_INPUT % (json.dumps("tiêu đề"), json.dumps(title)))
            if v == "NOTFOUND":
                _log("canh bao: khong thay o Tieu de, bo qua")
        if caption:
            if c.eval(_FOCUS % (json.dumps("div[role=textbox],textarea"),
                                json.dumps("văn bản"))) == "NOTFOUND":
                fail("Khong thay o Mo ta", "mo_ta")
            c.send("Input.insertText", {"text": caption})
            time.sleep(1)
        if tags:
            if c.eval(_FOCUS % (json.dumps("input,div[role=textbox]"),
                                json.dumps("từ khóa"))) == "ok":
                for tg in tags[:10]:
                    c.send("Input.insertText", {"text": str(tg).lstrip("#")})
                    time.sleep(0.5)
                    _enter(c)
            else:
                _log("canh bao: khong thay o The, bo qua")

        # ── 3. Tiep -> Tiep ──
        for i in (1, 2):
            if c.eval(_CLICK_TEXT % (json.dumps(["Tiếp"]), "1")) != "ok":
                _log("canh bao: khong bam duoc 'Tiep' lan %d (co the da o buoc sau)" % i)
            time.sleep(STEP_WAIT)

        # ── 4. am thanh goc + dang ngay ──
        want = {"original_only": "Chỉ sử dụng âm thanh gốc",
                "remix": "Cho phép remix và sử dụng âm thanh gốc",
                "none": "Không cho phép remix hoặc sử dụng âm thanh gốc"}.get(
                    audio_mode, "Chỉ sử dụng âm thanh gốc")
        if c.eval(_PICK_RADIO % json.dumps(want)) != "ok":
            _log("canh bao: khong chon duoc '%s' (giu mac dinh FB)" % want)
        time.sleep(1.5)
        c.eval(_CLICK_TEXT % (json.dumps(["Chia sẻ ngay"]), "0"))
        time.sleep(1.5)

        # ── 5. nut "Chia se" FOOTER: PHAI chuot that ──
        raw = c.eval(_RECT_TEXT % json.dumps("Chia sẻ"))
        if not raw:
            fail("Khong thay nut 'Chia se' o footer", "nut_chia_se")
        pt = json.loads(raw)
        _real_click(c, pt["x"], pt["y"])
        _log("da bam Chia se, cho FB xu ly...")

        # DO THAT: FB ket thuc theo 2 KIEU khac nhau (tuy luc) — phai chap nhan CA HAI:
        #   (a) chuyen trang sang Lich noi dung (roi composer)
        #   (b) O LAI composer nhung hien hop "Dang xu ly thuoc phim ... he thong se dang"
        #       + nut "Xong"  -> BAI DA GUI THANH CONG (da verify Graph: reel 890127297020837).
        # Chi cho (a) la bao FAIL oan tren bai DA DANG -> se dang lai lan 2 = TRUNG BAI.
        done = False
        for _ in range(24):
            time.sleep(5)
            if "reels_composer" not in (c.eval("location.href") or ""):
                done = True
                break
            if c.eval("(() => { const t = document.body.innerText; "
                      "return t.includes('Đang xử lý thước phim') || "
                      "t.includes('hệ thống sẽ đăng thước phim') ? 1 : 0; })()"):
                done = True
                c.eval(_CLICK_TEXT % (json.dumps(["Xong"]), "0"))     # dong hop thoai
                break
        if not done:
            fail("Bam 'Chia se' nhung khong thay dau hieu da gui sau 120s", "cho_dang")
        _log("DANG XONG (%.0fs)" % (time.time() - t0))
        return {"ok": True, "page_id": page_id, "video": video,
                "seconds": round(time.time() - t0, 1)}
    finally:
        try:
            c.close()
        except Exception:
            pass
        if not keep_tab:
            _close_tab(port, tab["id"])


POST_COMPOSER = "https://business.facebook.com/latest/composer?asset_id=%s"


def post_photo(page_id: str, image: str, caption: str = "", port: int = S.DEFAULT_PORT,
               shot_dir: str = "", keep_tab: bool = False) -> dict:
    """Dang 1 BAI VIET ANH len page bang Chrome (composer bai viet, KHONG phai Reels).

    Cung ky thuat voi post_reel: hook input.click -> setFileInputFiles -> insertText caption
    -> nut "Dang" o FOOTER bang chuot that.
    """
    if not os.path.isfile(image):
        raise ChromePostError("Khong thay file anh: %s" % image)
    if not S.is_alive(port):
        raise ChromePostError("Chrome chua mo (cong CDP %d)." % port)
    if not S.logged_in(port):
        raise ChromePostError("Chrome chua dang nhap Facebook.")

    t0 = time.time()
    tab = _tab_for(port, POST_COMPOSER % page_id)
    c = S.CDP(tab["webSocketDebuggerUrl"])

    def shot(name):
        if not shot_dir:
            return ""
        try:
            import base64
            os.makedirs(shot_dir, exist_ok=True)
            r = c.send("Page.captureScreenshot", {"format": "png"}, timeout=60)
            p = os.path.join(shot_dir, "%s_%s.png" % (page_id, name))
            open(p, "wb").write(base64.b64decode(r["data"]))
            return p
        except Exception:
            return ""

    def fail(msg, step):
        p = shot("loi_photo_" + step)
        if not keep_tab:
            _close_tab(port, tab["id"])
        raise ChromePostError("%s (buoc: %s)%s" % (msg, step, (" · anh: %s" % p) if p else ""))

    try:
        c.send("DOM.enable"); c.send("Runtime.enable"); c.send("Page.enable")
        if not _wait_text(c, ["Thêm ảnh/video", "Thêm ảnh", "File phương tiện"], timeout=120):
            fail("Composer bai viet khong render sau 120s", "mo_composer")

        c.eval(_HOOK)
        if c.eval(_CLICK_TEXT % (json.dumps(["Thêm ảnh/video", "Thêm ảnh"]), "0")) != "ok":
            fail("Khong thay nut 'Them anh/video'", "them_anh")
        grabbed = False
        for _ in range(15):
            time.sleep(1)
            if c.eval("window.__cs_grabbed ? 1 : 0"):
                grabbed = True
                break
        if not grabbed:
            fail("Khong bat duoc o chon file anh", "hook_input")
        r = c.send("Runtime.evaluate", {"expression": "window.__cs_grabbed", "returnByValue": False})
        c.send("DOM.setFileInputFiles", {"objectId": r["result"]["objectId"], "files": [image]})
        _log("da nap anh %s" % os.path.basename(image))
        time.sleep(6)

        if caption:
            # O soan cua composer BAI VIET khong chac co role=textbox / aria-label 'văn bản'
            # (da do that) -> thu lan luot nhieu kieu selector, lay o TO nhat con nhin thay.
            picked = c.eval(r"""
            (() => {
              const sels = ['div[role=textbox]', '[contenteditable="true"]', 'textarea'];
              let best = null, area = 0;
              for (const s of sels) {
                for (const e of document.querySelectorAll(s)) {
                  const r = e.getBoundingClientRect();
                  if (r.width < 80 || r.height < 20) continue;      // bo o an / o ti hon
                  const a = r.width * r.height;
                  if (a > area) { area = a; best = e; }
                }
                if (best) break;                                    // uu tien selector dung truoc
              }
              if (!best) return 'NOTFOUND';
              best.focus(); best.click();
              return best.tagName + '/' + (best.getAttribute('role') || 'editable');
            })()
            """)
            if picked == "NOTFOUND":
                fail("Khong thay o soan noi dung", "o_soan")
            _log("o soan: %s" % picked)
            c.send("Input.insertText", {"text": caption})
            time.sleep(1.5)

        raw = c.eval(_RECT_TEXT % json.dumps("Đăng"))
        if not raw:
            fail("Khong thay nut 'Dang' o footer", "nut_dang")
        pt = json.loads(raw)
        _real_click(c, pt["x"], pt["y"])
        _log("da bam Dang, cho FB xu ly...")

        # DO THAT: dang xong FB hien hop "Đã đăng bài viết của bạn" + moi TAO QUANG CAO
        # (khong chuyen trang) -> phai nhan chuoi nay, roi bam "Để sau" de dong hop.
        done = False
        for _ in range(20):
            time.sleep(5)
            if "composer" not in (c.eval("location.href") or ""):
                done = True
                break
            if c.eval("(() => { const t = document.body.innerText; "
                      "return (t.includes('Đã đăng bài viết') || t.includes('Đang xử lý') || "
                      "t.includes('đã được đăng')) ? 1 : 0; })()"):
                done = True
                c.eval(_CLICK_TEXT % (json.dumps(["Để sau"]), "0"))   # KHONG tao quang cao
                break
        if not done:
            fail("Bam 'Dang' nhung khong thay dau hieu da gui sau 100s", "cho_dang")
        _log("DANG ANH XONG (%.0fs)" % (time.time() - t0))
        return {"ok": True, "page_id": page_id, "image": image,
                "seconds": round(time.time() - t0, 1)}
    finally:
        try:
            c.close()
        except Exception:
            pass
        if not keep_tab:
            _close_tab(port, tab["id"])


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Dang 1 reel len page bang Chrome (CDP).")
    ap.add_argument("--page-id", required=True)
    ap.add_argument("--video", required=True)
    ap.add_argument("--caption", default="")
    ap.add_argument("--title", default="")
    ap.add_argument("--tags", default="", help="cach nhau bang dau phay")
    ap.add_argument("--audio", default="original_only",
                    choices=["original_only", "remix", "none"])
    ap.add_argument("--shot-dir", default="")
    a = ap.parse_args()
    out = post_reel(a.page_id, a.video, a.caption, a.title,
                    [t.strip() for t in a.tags.split(",") if t.strip()],
                    audio_mode=a.audio, shot_dir=a.shot_dir)
    print(json.dumps(out, ensure_ascii=False))
