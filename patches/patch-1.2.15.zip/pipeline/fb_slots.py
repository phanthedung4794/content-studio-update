# -*- coding: utf-8 -*-
"""
SLOT ALLOCATOR — tinh GIO DANG khi chay NHIEU PAGE SONG SONG.

Cong thuc (nguoi dung chot 2026-07-25):

    gio_dang(page, bai thu k) = anchor + rank(page) * gap_page + k * gap_post

  anchor    = moc bat dau (vd 6h sang hom nay)
  rank(page)= thu tu page DO lam xong BAI DAU (ai xong truoc lay so nho) - first-come-first-serve
  gap_page  = gian cach giua cac PAGE (vd 15')
  gap_post  = gian cach giua cac BAI cua CUNG 1 page (vd 300')

VD 10 page, anchor 6:00, gap_page 15', gap_post 300':
  page xong dau  -> 6:00 (luot 1), 11:00 (luot 2)
  page xong thu 2 -> 6:15 (luot 1), 11:15 (luot 2)
  ...
  page thu 10     -> 8:15 (luot 1), 13:15 (luot 2)

LO TOAN phai chan: neu n_page * gap_page > gap_post thi luot 2 cua page dau CHONG len
luot 1 cua page cuoi -> `check_conflict()` bao ra de UI canh bao.

Rank luu ben file (facebook/_slot_rank.json) de restart khong mat thu tu.
Khac `_compute_slot` cu (server.py): cu tinh theo SO BAI DA LAM cua rieng 1 page,
khong biet cac page khac -> nhieu page xong cung luc thi trung gio.
"""
import json
import os
import time
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.environ.get("CS_FB_ROOT") or os.path.join(ROOT, "facebook")
STORE = os.path.join(FB_ROOT, "_slot_rank.json")

MIN_LEAD = 660          # FB doi gio hen >= 10' tuong lai (dung chung voi fb_publish)


# ─────────────────────────── kho rank (ben file) ───────────────────────────
def _load() -> dict:
    try:
        with open(STORE, encoding="utf-8-sig") as f:      # utf-8-sig: file co BOM van doc duoc
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d: dict) -> None:
    os.makedirs(FB_ROOT, exist_ok=True)
    tmp = STORE + ".%d.tmp" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    for _ in range(12):                                    # Windows hay chan os.replace
        try:
            os.replace(tmp, STORE)
            return
        except OSError:
            time.sleep(0.15)
    with open(STORE, "w", encoding="utf-8") as f:          # fallback: ghi thang
        json.dump(d, f, ensure_ascii=False, indent=1)


def reset(run_id: str = "") -> None:
    """Xoa bang rank (goi khi bat dau LUOT MOI = bam Star)."""
    _save({"run_id": run_id or str(int(time.time())), "ranks": {}})


def rank_of(page_id: str, run_id: str = "") -> int:
    """Cap rank cho page theo THU TU GOI DAU TIEN (first-come-first-serve).

    Page da co rank -> tra lai rank cu (goi bao nhieu lan cung the).
    run_id doi (luot Star moi) -> bang rank tu reset.
    Lan cap DAU TIEN cua luot cung ghi `t0` = thoi diem page DAU TIEN lam xong video
    (dung lam MOC NEO cho che do "dang luon").
    """
    d = _load()
    if run_id and d.get("run_id") != run_id:
        d = {"run_id": run_id, "ranks": {}}
    ranks = d.setdefault("ranks", {})
    if page_id in ranks:
        return int(ranks[page_id])
    if not ranks:                                          # page DAU TIEN cua luot
        d["t0"] = int(time.time())
    ranks[page_id] = len(ranks)                            # 0,1,2... theo thu tu xong
    d.setdefault("run_id", run_id or str(int(time.time())))
    _save(d)
    return int(ranks[page_id])


def run_t0(run_id: str = "") -> int:
    """Thoi diem page DAU TIEN cua luot lam xong video (moc neo che do 'dang luon').

    Chua co (chua page nao xong) -> tra now.
    """
    d = _load()
    if run_id and d.get("run_id") != run_id:
        return int(time.time())
    return int(d.get("t0") or time.time())


# ─────────────────────────── tinh gio ───────────────────────────
def anchor_ts(hhmm: str = "06:00", day_offset: int = 0, now: int = 0) -> int:
    """Moc bat dau: hh:mm cua ngay (hom nay + day_offset)."""
    now = int(now or time.time())
    try:
        hh, mm = [int(x) for x in str(hhmm).split(":")[:2]]
    except Exception:
        hh, mm = 6, 0
    base = datetime.fromtimestamp(now) + timedelta(days=max(0, int(day_offset or 0)))
    return int(base.replace(hour=hh, minute=mm, second=0, microsecond=0).timestamp())


def slot_for(anchor: int, rank: int, k: int, gap_page_min: int, gap_post_min: int,
             now: int = 0, min_lead: int = None) -> int:
    """Gio dang (unix) cua BAI THU k (0-based) cua page co `rank` (0-based).

    min_lead: khoang cach toi thieu so voi bay gio.
      - None (mac dinh) -> MIN_LEAD (660s): dung khi HEN LICH qua Graph API (FB tu choi
        gio hen qua gan).
      - 0 -> khong day: dung cho CHROME "dang luon" (page dau xong la dang NGAY, khong
        co ly do doi 11 phut vi Chrome bam nut truc tiep chu khong hen lich FB).
    """
    now = int(now or time.time())
    lead = MIN_LEAD if min_lead is None else max(0, int(min_lead))
    ts = int(anchor) + int(rank) * max(0, int(gap_page_min)) * 60 \
                     + int(k) * max(0, int(gap_post_min)) * 60
    if ts < now + lead:
        ts = now + lead
    return ts


def check_conflict(n_pages: int, gap_page_min: int, gap_post_min: int) -> str:
    """'' neu OK. Nguoc lai tra CANH BAO doc duoc (luot 2 chong luot 1 cua page cuoi).

    Dieu kien an toan: (n_pages - 1) * gap_page < gap_post.
    """
    n = max(1, int(n_pages))
    gp, gb = max(0, int(gap_page_min)), max(0, int(gap_post_min))
    need = (n - 1) * gp
    if gb and need >= gb:
        return ("%d page × %d phút = %d phút > giãn cách mỗi bài %d phút → bài lượt 2 của page "
                "đầu sẽ đè lên lượt 1 của page cuối. Tăng giãn cách mỗi bài lên ≥ %d phút "
                "(hoặc giảm giãn cách page)." % (n, gp, need, gb, need + 1))
    return ""


def plan_preview(n_pages: int, n_posts: int, hhmm: str, day_offset: int,
                 gap_page_min: int, gap_post_min: int, now: int = 0,
                 mode: str = "schedule") -> list:
    """Bang gio DU KIEN (de hien cho nguoi dung xem truoc). [{page_i, post_k, ts}]

    mode='now'      -> neo vao BAY GIO (page xong dau tien dang ngay).
    mode='schedule' -> neo vao hh:mm cua ngay (hom nay + day_offset).
    """
    now = int(now or time.time())
    a = now if mode == "now" else anchor_ts(hhmm, day_offset, now)
    out = []
    for i in range(max(1, int(n_pages))):
        for k in range(max(1, int(n_posts))):
            out.append({"page_i": i, "post_k": k,
                        "ts": slot_for(a, i, k, gap_page_min, gap_post_min, now, min_lead=0)})
    out.sort(key=lambda x: x["ts"])
    return out


if __name__ == "__main__":                                 # kiem THAT bang so
    import io
    import sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    now = int(datetime(2026, 7, 25, 5, 0, 0).timestamp())  # 05:00 hom nay
    a = anchor_ts("06:00", 0, now)
    print("anchor:", datetime.fromtimestamp(a).strftime("%d/%m %H:%M"))
    for i in range(3):
        for k in range(2):
            ts = slot_for(a, i, k, 15, 300, now)
            print("  page#%d bai#%d -> %s" % (i, k, datetime.fromtimestamp(ts).strftime("%d/%m %H:%M")))
    print("conflict 10 page:", check_conflict(10, 15, 300) or "OK")
    print("conflict 30 page:", check_conflict(30, 15, 300) or "OK")
