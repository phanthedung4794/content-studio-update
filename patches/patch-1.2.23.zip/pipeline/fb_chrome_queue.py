# -*- coding: utf-8 -*-
"""
KHO CHO + WATCHDOG cho duong dang bang CHROME.

Video lam xong KHONG dang ngay: xep vao kho cho kem GIO HEN (tinh bang fb_slots).
Watchdog tick moi 60s, den gio thi mo Chrome dang.

VI SAO CAN MUTEX: chi co 1 Chrome. N page chay song song, xong cung luc -> neu bang
nao cung mo composer thi tranh nhau 1 trinh duyet. Watchdog xu ly TUAN TU trong 1
luong duy nhat -> khong bao gio 2 bai dang cung luc.

CHINH SACH TRE (may tat qua gio hen):
  tre <= LATE_OK (mac dinh 2h)  -> DANG BU NGAY khi may bat lai
  tre >  LATE_OK               -> DOI sang gio hen ke tiep + ghi ro ly do (khong im lang bo)

Kho: facebook/_chrome_queue.json  (co lock-file, nhieu tien trinh ghi khong mat update
     — bai hoc pipeline-clobber 2026-07-24)
"""
import json
import os
import re
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.environ.get("CS_FB_ROOT") or os.path.join(ROOT, "facebook")
STORE = os.path.join(FB_ROOT, "_chrome_queue.json")
LOCK = STORE + ".lock"
SHOTS = os.path.join(FB_ROOT, "_chrome_shots")

LATE_OK = int(os.environ.get("CS_CHROME_LATE_OK", str(2 * 3600)))    # tre <=2h thi dang bu
# Nhip watchdog. 15s (truoc 60s): che do "Dang luon" phai dang gan nhu NGAY khi video xong
# — cho toi 1 phut thi nguoi dung thay bai nam trong lich, tuong tool khong dang luon.
TICK = int(os.environ.get("CS_CHROME_TICK", "15"))                   # nhip watchdog (giay)
# Khoang cach TOI THIEU giua bai cua HAI PAGE khac nhau. Chi co 1 Chrome nen hai page
# dang cung luc la xung dot -> bai vao sau bi lui lai.
# 5 PHUT chu khong phai 1 (nguoi dung chot 2026-07-27): 1 phut khong du khi mang nghen
# hoac co sai so — bai truoc chua dang xong thi bai sau da toi gio.
# LUU Y: day chi la muc lui DU PHONG. Bai sau KHONG phai cho du 5 phut — xem `due()`:
# page truoc vua xong (hoac LOI) la page sau duoc dang ngay o nhip ke tiep.
MIN_SPACING = int(os.environ.get("CS_CHROME_MIN_SPACING", "300"))    # giay

_run_lock = threading.Lock()        # MUTEX: chi 1 bai dang bang Chrome tai 1 thoi diem
_thread = None
_stop = threading.Event()
_wake = threading.Event()          # đánh thức watchdog giữa nhịp (xem kick())


def kick() -> None:
    """Thức watchdog NGAY (gọi khi vừa có bài đến hạn) — khỏi chờ hết nhịp."""
    _wake.set()


# ─────────────────────────── kho (lock-file) ───────────────────────────
def _with_lock(fn, tries: int = 60):
    """Chay fn() khi giu lock-file (chong 2 tien trinh doc-sua-ghi de len nhau)."""
    os.makedirs(FB_ROOT, exist_ok=True)
    for _ in range(tries):
        try:
            fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_RDWR)
            try:
                return fn()
            finally:
                os.close(fd)
                try:
                    os.remove(LOCK)
                except OSError:
                    pass
        except FileExistsError:
            time.sleep(0.1)
    return fn()                      # ket lock qua lau -> cu chay (tha sai con hon treo)


def _say(msg: str) -> None:
    """In nhat ky AN TOAN — khong bao gio nem loi.

    Vi sao: stdout cua may chu duoc chuyen huong ra file => encoding theo locale (cp1252),
    ma o day co in TEN PAGE va TEN NHOM tieng Viet. Do that: print('HỒI ỨC') ra file nem
    UnicodeEncodeError. Neu de no nem thi (a) add() hong -> bai khong vao kho cho,
    (b) vong watchdog thoat han -> KHONG BAI NAO dang duoc nua.
    """
    try:
        print("[chrome-queue] %s" % msg, flush=True)
    except Exception:
        try:
            print("[chrome-queue] %s"
                  % str(msg).encode("ascii", "replace").decode("ascii"), flush=True)
        except Exception:
            pass


def _load() -> list:
    try:
        with open(STORE, encoding="utf-8-sig") as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except Exception:
        return []


def _save(items: list) -> None:
    os.makedirs(FB_ROOT, exist_ok=True)
    tmp = STORE + ".%d.tmp" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=1)
    for _ in range(12):
        try:
            os.replace(tmp, STORE)
            return
        except OSError:
            time.sleep(0.15)
    with open(STORE, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=1)


def add(page_id: str, page_name: str, video: str, when_ts: int, caption: str = "",
        title: str = "", tags=None, item_id: str = "", audio_mode: str = "original_only",
        kind: str = "reel", gap_page_min: int = 15) -> dict:
    """Xep 1 bai vao kho cho dang bang Chrome. Tra ve item.

    kind='reel'  -> `video` la file mp4 (composer Reels)
    kind='photo' -> `video` la file anh (composer bai viet anh)

    `gap_page_min` KHONG dung de tinh chot chan duoi day (chi `respace()` dung): khoang
    day khi trung la MIN_SPACING co dinh — nguoi dung chot 5 phut ("k can 1 phut, nhieu
    khi nghen mang hoac sai so"). Cai gian cach page nho hon 5 phut thi chot chan van
    noi rong ra 5 phut, vi mot bai reel co the cho toi 180s -> gian 2 phut la hai bai
    that su dam nhau. UI canh bao truoc khi bam Star de khong bi bat ngo.

    CHOT CHAN CUOI: gio da co bai cua PAGE KHAC giu -> day sang nhip ke tiep. Du khau
    tinh gio co sai (moc cu, rank trung...) thi kho cho VAN khong bao gio co 2 page cung
    mot gio -> khong con canh "dang lien tuc".
    """
    it = {"id": "cq_%d_%s" % (int(time.time() * 1000), page_id[-6:]),
          "page_id": page_id, "page_name": page_name or page_id,
          "kind": kind, "video": video, "when_ts": int(when_ts),
          "caption": caption, "title": title, "tags": list(tags or []),
          "audio_mode": audio_mode,
          "pipeline_id": item_id,              # de cap nhat nguoc ve tab San xuat
          "status": "waiting",                 # waiting | posting | done | error
          "step": "chờ tới giờ đăng", "error": "", "cts": int(time.time())}

    def _do():
        items = _load()
        # CHOT CHAN XUNG DOT CHROME (nguoi dung chot 2026-07-27): chi co MOT Chrome, hai
        # bai dang cung luc la xung dot. Luat:
        #   - hai bai den tu HAI LUONG XEP LICH KHAC NHAU phai cach it nhat MIN_SPACING
        #   - trung thi bai VAO KHO SAU bi day ra sau -> ai len lich truoc dang truoc
        #   - chi day DU MIN_SPACING moi lan, khong day xa: lich da tinh o fb_slots van giu
        #     nguyen y dinh, day chi de khong dam nhau. Bai sau den gio trong luc bai truoc
        #     dang dang thi mutex trong post_one cho no CHO tu nhien.
        # Xung dot xet theo CUA SO chu khong theo giay chinh xac — do that: hai luot Star
        # co moc neo khac nhau ra gio lech 7 giay, khop bang "==" thi lot chot chan.
        #
        # "LUONG XEP LICH" = (page_id, kind) chu KHONG phai page_id. LOI THAT (do
        # 2026-07-28, tools/probe/t_hai_luong_lich.py): Star CA video LAN anh o che do LEN
        # LICH thi hai luong doc CUNG anchor tu tab Chrome nhung giu HAI bang rank rieng ->
        # cung mot page nhan rank 0 o ca hai bang -> video va anh ra DUNG CUNG MOT GIAY
        # (do duoc: cach nhau 0s). Loc cu chi so sanh page_id nen khong he thay.
        # Nguoc lai, hai bai CUNG page CUNG luong da duoc gian bang gap_bai nguoi dung cai
        # -> khong duoc dung vao, neu khong se pha cai ho vua chon.
        mine = (page_id, kind)
        busy = [(int(x.get("when_ts") or 0), str(x.get("page_id")), str(x.get("kind") or "reel"))
                for x in items if x.get("status") in ("waiting", "posting")]
        ts = int(it["when_ts"])
        for _ in range(500):                  # co tran -> khong bao gio lap vo han
            clash = [b for b in busy
                     if (b[1], b[2]) != mine and abs(b[0] - ts) < MIN_SPACING]
            if not clash:
                break
            ts = max(b[0] for b in clash) + MIN_SPACING
        if ts != int(it["when_ts"]):
            _say("%s: %s da co bai khac giu cho -> doi %s"
                 % (it["page_name"], time.strftime("%H:%M", time.localtime(it["when_ts"])),
                    time.strftime("%H:%M", time.localtime(ts))))
            it["when_ts"] = ts
        items.append(it)
        _save(items)
        return it
    return _with_lock(_do)


def update(item_id: str, **kw) -> None:
    def _do():
        items = _load()
        for x in items:
            if x.get("id") == item_id:
                x.update(kw)
                break
        _save(items)
    _with_lock(_do)


def delete(ids) -> int:
    ids = set(ids or [])

    def _do():
        items = _load()
        keep = [x for x in items if x.get("id") not in ids]
        n = len(items) - len(keep)
        _save(keep)
        return n
    return _with_lock(_do)


def all_items() -> list:
    return _load()


def due(now: int = 0) -> list:
    """Cac item DEN GIO can dang (cu nhat truoc).

    Cung gio (du lieu cu xep truoc khi co chot chan MIN_SPACING) -> AI LEN LICH TRUOC
    DANG TRUOC: sap thu hai theo `cts` (luc bai duoc xep vao kho).
    """
    now = int(now or time.time())
    return sorted([x for x in _load()
                   if x.get("status") == "waiting" and int(x.get("when_ts") or 0) <= now],
                  key=lambda x: (int(x.get("when_ts") or 0), int(x.get("cts") or 0)))


def respace(gap_page_min: int = 15, dry: bool = True) -> dict:
    """Gian lai cac bai CHUA DANG bi TRUNG GIO (moi page mot gio rieng).

    Vi sao can: truoc day N job song song cung gianh rank 0 (thieu khoa) -> 2 page cung
    gio. Da va o fb_slots, nhung bai LO XEP roi van nam trong kho -> ham nay don not.
    Bai cua CUNG page giu nguyen khoang cach rieng; chi day bai cua page KHAC khi trung.
    dry=True -> chi xem truoc.
    """
    gap = max(1, int(gap_page_min)) * 60
    items = sorted([x for x in _load() if x.get("status") == "waiting"],
                   key=lambda x: (int(x.get("when_ts") or 0), str(x.get("page_id"))))
    taken, moves = {}, []
    for it in items:
        ts = int(it.get("when_ts") or 0)
        while ts in taken and taken[ts] != it.get("page_id"):
            ts += gap                       # gio nay page khac giu roi -> lui 1 nhip
        taken[ts] = it.get("page_id")
        if ts != int(it.get("when_ts") or 0):
            moves.append({"id": it["id"], "page_name": it.get("page_name", ""),
                          "from": int(it.get("when_ts") or 0), "to": ts})
    if not dry:
        for m in moves:
            update(m["id"], when_ts=m["to"],
                   step="đã giãn giờ (trùng với page khác)")
    return {"checked": len(items), "moved": len(moves), "moves": moves[:40], "dry": dry}


def _caption_with_tags(caption: str, tags) -> str:
    """Ghep hashtag vao cuoi tus (cho BAI ANH — khong co o 'The' rieng nhu Reels).

    Luon co #xuhuong #viral (giong duong video, xem fb_publish.ensure_trend_tags),
    khong nhan doi the da co san trong tus.
    """
    cap = (caption or "").rstrip()
    have = {t.lower().lstrip("#") for t in re.findall(r"#(\w+)", cap)}
    out = []
    for t in list(tags or []) + ["xuhuong", "viral"]:
        t = str(t).lstrip("#").strip()
        if t and t.lower() not in have:
            have.add(t.lower())
            out.append("#" + t)
    return (cap + "\n\n" + " ".join(out)).strip() if out else cap


# ─────────────────────────── dang 1 item ───────────────────────────
# Cac buoc loi xay ra TRUOC khi upload video/anh -> chua gui gi len Facebook -> thu lai
# AN TOAN TUYET DOI (khong the dang trung). DO THAT 28/07: bai luc 00:48 loi
# "Composer Reels khong render sau 120s", bai ke tiep luc 00:54 tren CUNG page CHAY BINH
# THUONG -> loi tam thoi, chi can thu lai. Graph xac minh bai loi KHONG he len.
_SAFE_RETRY = ("buoc: mo_composer", "buoc: them_video", "buoc: o_soan")


def post_one(it: dict, on_done=None) -> dict:
    """Dang 1 item bang Chrome. GIU MUTEX -> khong bao gio 2 bai cung luc.

    Thu lai TRONG cung mot lan giu khoa (vong for), KHONG goi de quy: `_run_lock` la
    threading.Lock thuong — khong reentrant — nen goi lai post_one o trong `with` la
    TU KHOA CHINH MINH, treo vinh vien ca viec dang.
    """
    import fb_chrome_post
    with _run_lock:
      for attempt in (0, 1):
        update(it["id"], status="posting", step="đang mở Chrome đăng", error="")
        try:
            if (it.get("kind") or "reel") == "photo":
                # BAI VIET ANH khong co o "The" rieng nhu Reels -> hashtag phai nam
                # TRONG noi dung, neu khong bai anh se KHONG co hashtag nao (khac video).
                r = fb_chrome_post.post_photo(
                    it["page_id"], it["video"],
                    caption=_caption_with_tags(it.get("caption") or "", it.get("tags") or []),
                    shot_dir=SHOTS, share_groups=bool(it.get("share_groups", True)))
            else:
                r = fb_chrome_post.post_reel(
                    it["page_id"], it["video"], caption=it.get("caption") or "",
                    title=it.get("title") or "", tags=it.get("tags") or [],
                    audio_mode=it.get("audio_mode") or "original_only", shot_dir=SHOTS,
                    share_groups=bool(it.get("share_groups", True)))
            gl = r.get("groups") or []
            # CA reel LAN bai viet anh deu co muc chia se nhom (giao dien khac nhau nhung
            # cung gioi han 3 nhom/bai). Page khong co nhom van la DANG THANH CONG — chi
            # ghi ro ly do cho biet, khong phai loi.
            if gl:
                step = ("đã đăng bằng Chrome · %d nhóm: %s"
                        % (len(gl), ", ".join(g.get("name", "") for g in gl)))
            else:
                step = "đã đăng bằng Chrome · không kèm nhóm (%s)" % (
                    (r.get("groups_why") or "page chưa tham gia nhóm nào")[:80])
            update(it["id"], status="done", step=step[:300], error="",
                   posted_ts=int(time.time()),   # gio dang THAT, de doi chieu voi gio hen
                   groups=[{"id": g.get("id"), "name": g.get("name")} for g in gl])
            if on_done:
                try:
                    on_done(it, None)
                except Exception:
                    pass
            return {"ok": True, "id": it["id"], **r}
        except Exception as exc:
            msg = "%s: %s" % (type(exc).__name__, exc)
            # Loi TRUOC khi upload -> chua gui gi -> thu lai 1 lan (khong the trung bai).
            if attempt == 0 and any(k in msg for k in _SAFE_RETRY):
                _say("%s: %s -> thu lai 1 lan (chua gui gi len FB nen an toan)"
                     % (it.get("page_name"), msg[:110]))
                update(it["id"], status="posting",
                       step="lỗi tạm khi mở composer → đang thử lại", error="")
                time.sleep(20)
                continue
            update(it["id"], status="error", step="lỗi đăng bằng Chrome", error=msg[:400])
            if on_done:
                try:
                    on_done(it, msg)
                except Exception:
                    pass
            return {"ok": False, "id": it["id"], "error": msg}


def _handle_late(it: dict, now: int) -> bool:
    """Xu ly item TRE. True = cu dang bu ngay; False = da doi lich, bo qua luot nay."""
    late = now - int(it.get("when_ts") or 0)
    if late <= LATE_OK:
        return True
    # Tre qua lau (may tat) -> DOI sang mai cung gio, ghi ro (khong im lang bo bai)
    new_ts = int(it["when_ts"]) + 86400 * max(1, (late // 86400) + 1)
    update(it["id"], when_ts=new_ts,
           step="trễ %.1f giờ (máy tắt) → dời sang %s"
                % (late / 3600.0, time.strftime("%H:%M %d/%m", time.localtime(new_ts))))
    return False


def tick(now: int = 0, on_done=None) -> dict:
    """1 nhip watchdog: dang MOI item den gio, TUAN TU. Tra thong ke."""
    now = int(now or time.time())
    posted, failed, moved = 0, 0, 0
    for it in due(now):
        if _stop.is_set():
            break
        if not _handle_late(it, now):
            moved += 1
            continue
        r = post_one(it, on_done=on_done)
        if r.get("ok"):
            posted += 1
        else:
            failed += 1
    return {"posted": posted, "failed": failed, "moved": moved}


# ─────────────────────────── watchdog ───────────────────────────
def start(on_done=None) -> bool:
    """Bat vong nen. Goi 1 lan luc server khoi dong."""
    global _thread
    if _thread and _thread.is_alive():
        return False
    _stop.clear()

    def _loop():
        while not _stop.is_set():
            try:
                st = tick(on_done=on_done)
                if st["posted"] or st["failed"] or st["moved"]:
                    _say("%s" % st)
            except Exception as exc:
                # PHAI dung _say: exc thuong chua ten nhom/ten page tieng Viet — print()
                # tho se nem ngay TAI DAY, thoat han vong while = watchdog chet lang.
                _say("loi vong nen: %s" % exc)
            # Ngu toi nhip sau, NHUNG ai do goi kick() (vd vua xep 1 bai den han o che do
            # "Dang luon") thi thuc day ngay -> khong phai cho het nhip.
            _wake.wait(TICK)
            _wake.clear()

    _thread = threading.Thread(target=_loop, name="chrome-queue", daemon=True)
    _thread.start()
    return True


def stop() -> None:
    _stop.set()


def alive() -> bool:
    return bool(_thread and _thread.is_alive())


if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"
    if cmd == "list":
        for x in all_items():
            print("%-22s %-16s %-9s %s | %s" % (
                x["id"], x.get("page_name", "")[:16], x.get("status"),
                time.strftime("%H:%M %d/%m", time.localtime(x.get("when_ts") or 0)),
                (x.get("error") or x.get("step") or "")[:50]))
    elif cmd == "tick":
        print(json.dumps(tick(), ensure_ascii=False))
