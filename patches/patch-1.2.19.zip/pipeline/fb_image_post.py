# -*- coding: utf-8 -*-
"""
BAI DANG ANH (khong phai video): Gemini phan tich -> y tuong tranh + CHU tren anh + tus
-> 79AI ve tranh -> PIL ghi chu -> xep KHO CHO dang theo lich (giong video).

Vi sao tach khoi image_post.py: image_post lo phan VE + GHEP THE (thuan PIL/79AI, dung
chung cho tab "Tao anh" thu cong). Module nay lo phan NOI DUNG (Gemini) + DUONG DANG
(kho cho + lich), tai dung image_post chu KHONG chep lai.

QUY TAC CUNG #3: 79AI KHONG ve duoc chu tieng Viet -> chu do PIL ghi len (image_post.compose_card).

Gemini tra 1 JSON:
  {idea, text, caption, tags[]}
    idea    : mo ta tranh (TIENG ANH — 79AI hieu tot hon), KHONG chua chu/text
    text    : CHU ghi len anh (tieng Viet co dau, manh, danh vao cam xuc)
    caption : tus dang kem bai
    tags    : the/hashtag
"""
import json
import os
import re
import tempfile
import time

import fb_remake                     # dung chung gemini_generate + _first_json (DRY)
import image_post

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.environ.get("CS_FB_ROOT") or os.path.join(ROOT, "facebook")
OUT_DIR = os.path.join(FB_ROOT, "_image_posts")

# Model ve mac dinh: khop pipeline video (banana_pro vip 1k = 600cr, nhanh + on dinh nhat
# theo phep do 2026-07-24). Doi bang env neu can.
# Bao tien trinh SONG (giong fb_remake.set_progress): server gan callback ghi vao
# fb_pipeline -> cot Trang thai o man hinh chinh chay chu nhu duong video.
_PROG = None


def set_progress(cb):
    global _PROG
    _PROG = cb


def _prog(msg):
    print("[img] %s" % msg, flush=True)
    if _PROG:
        try:
            _PROG(msg)
        except Exception:
            pass


MODEL = os.environ.get("CS_IMGPOST_MODEL", "google_image_gen_banana_pro")
MODE = os.environ.get("CS_IMGPOST_MODE", "vip")
RES = os.environ.get("CS_IMGPOST_RES", "1k")

_PROMPT = (
    "Ban la chuyen gia lam BAI DANG ANH viral cho fanpage Facebook tieng Viet "
    "(hoai niem / tam su / ngam doi / doi song que).\n"
    "Chu de / noi dung nguon:\n\"\"\"%s\"\"\"\n\n"
    "Tao 1 bai dang ANH. Tra ve DUNG 1 JSON (khong markdown, khong giai thich):\n"
    '{"idea": "...", "text": "...", "caption": "...", "tags": ["...", "..."]}\n'
    "- idea: mo ta buc tranh bang TIENG ANH cho AI ve (bo cuc, nhan vat, boi canh, anh sang, "
    "cam xuc). Canh doi thuong Viet Nam, GIAU CAM XUC, de dong cam. TUYET DOI khong yeu cau "
    "ve chu/text/watermark trong tranh.\n"
    "- text: CHU se ghi len anh. 1-2 cau NGAN (toi da 20 tu), tieng Viet CO DAU DAY DU, danh "
    "THANG vao cam xuc nguoi doc (cham ky uc / xot xa / thuc tinh). Viet nhu loi tam su that "
    "long, KHONG sao rong. VD dung: \"Cha mẹ già rồi, còn về được mấy lần nữa?\"\n"
    "- caption: tus dang kem, 2-4 dong, dong dau la cau HOOK manh, tieng Viet CO DAU, toi da "
    "2-3 emoji, KHONG nhac ten kenh/link/keu goi follow, KHONG kem hashtag.\n"
    "- tags: 4-6 tu khoa KHONG dau '#', khong dau tieng Viet, khong khoang trang.\n"
    "Chi tra JSON.")


# ---------------------------------------------------------------- CHU DE (Gemini tu nghi)
# So chu de gan day GIU LAI de dua vao prompt "dung lap" -> page chay lau van khong ra
# lai cung mot chuyen. Giu it thoi: prompt dai qua thi Gemini bat dau lo di.
TOPIC_STORE = os.path.join(FB_ROOT, "_image_topics.json")
TOPIC_KEEP = 40

_TOPIC_PROMPT = (
    "Ban la nguoi lam noi dung viral cho fanpage Facebook tieng Viet.\n"
    "FANPAGE: \"%s\"\n"
    "CHU DE KENH: %s\n\n"
    "VIDEO DANG CHAY TREN KENH NAY (view — noi dung):\n%s\n\n"
    "Lay CHU DE TU CHINH CAC VIDEO TREN — moi chu de bai anh phai bat nguon tu MOT video "
    "cu the o tren (uu tien video view cao), giu nguyen cau chuyen / boi canh / cam xuc cua "
    "no, chi ke lai gon thanh MOT KHOANH KHAC dung yen de ve thanh 1 buc anh. "
    "TUYET DOI khong bia chu de nam ngoai danh sach tren.\n"
    "Tra %d chu de. Moi chu de phai:\n"
    "- Cham DUNG noi dau / ky uc / dieu nguoi doc dang nghi ma khong noi ra "
    "(cha me gia, con xa que, tinh nghia vo chong, ban cu, cai ngheo ngay xua...).\n"
    "- CU THE (mot canh, mot khoanh khac, mot chi tiet), KHONG chung chung kieu "
    "\"noi ve tinh cam gia dinh\".\n"
    "- Du manh de nguoi luot phai dung lai va muon binh luan.\n"
    "- KHAC HAN nhau va KHAC danh sach da dung ben duoi.\n\n"
    "DA DUNG (tuyet doi khong lap lai y nay):\n%s\n\n"
    "Tra ve DUNG 1 JSON (khong markdown, khong giai thich):\n"
    '{"topics": ["...", "..."]}\n'
    "Moi topic 1-2 cau tieng Viet CO DAU DAY DU. Chi tra JSON.")


def page_video_digest(slug, limit=8):
    """Lay NOI DUNG VIDEO THAT cua page nguon (caption + view) de Gemini nghi chu de.

    Nguon: `facebook/<slug>/downloads/*/meta.json` (reel da tai — co caption day du + view),
    bo sung tu `index.json` neu co caption. Sap theo VIEW giam dan -> Gemini hoc tu bai
    CHAY TOT nhat chu khong phai bai ngau nhien. Khong co gi -> tra [] (nguoi goi tu lo).
    """
    if not slug:
        return []
    rows = []
    dl = os.path.join(FB_ROOT, slug, "downloads")
    if os.path.isdir(dl):
        for d in os.listdir(dl):
            try:
                with open(os.path.join(dl, d, "meta.json"), encoding="utf-8-sig") as f:
                    m = json.load(f) or {}
            except Exception:
                continue
            cap = (m.get("caption") or "").strip()
            if cap:
                rows.append((int(float(m.get("views") or 0)), cap))
    try:
        with open(os.path.join(FB_ROOT, slug, "index.json"), encoding="utf-8-sig") as f:
            reels = (json.load(f) or {}).get("reels") or {}
        for r in (reels.values() if isinstance(reels, dict) else reels):
            cap = ((r or {}).get("caption") or "").strip()
            if cap:
                rows.append((int((r.get("views") or 0)), cap))
    except Exception:
        pass
    seen, out = set(), []
    for v, cap in sorted(rows, key=lambda x: -x[0]):
        cap = re.sub(r"https?://\S+", "", cap)                 # bo link Shopee/rut gon
        cap = re.sub(r"#\S+", "", cap)                         # bo hashtag quang ba kenh
        cap = " ".join(cap.split())[:220]
        k = cap[:60].lower()
        if cap and k not in seen:
            seen.add(k)
            out.append("- %s view: %s" % (v or "?", cap))
        if len(out) >= limit:
            break
    return out


def _topic_log(page_id=""):
    d = {}
    try:
        with open(TOPIC_STORE, encoding="utf-8-sig") as f:
            d = json.load(f) or {}
    except Exception:
        d = {}
    return d.get(page_id, []) if page_id else d


def _topic_remember(page_id, topics):
    """Ghi so chu de. N job ve anh chay SONG SONG cung ghi 1 file -> tren Windows
    os.replace bi chan (WinError 5 Access is denied) khi file dang bi tien trinh khac
    mo -> job LOI oan du anh da ve xong. Nen: khoa bang lock-file + retry + cuoi cung
    ghi thang; that bai han thi BO QUA (so chu de chi de tranh trung, mat 1 dong khong
    duoc phep giet ca job)."""
    os.makedirs(os.path.dirname(TOPIC_STORE) or ".", exist_ok=True)
    lock = TOPIC_STORE + ".lock"
    fd = None
    for _ in range(60):                       # doi toi da ~6s de gianh khoa
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_RDWR)
            break
        except FileExistsError:
            try:                              # khoa mo coi (tien trinh chet) -> don
                if time.time() - os.path.getmtime(lock) > 30:
                    os.unlink(lock)
            except OSError:
                pass
            time.sleep(0.1)
    try:
        d = _topic_log()                      # doc SAU khi co khoa -> khong mat update
        cur = list(d.get(page_id) or [])
        cur.extend([t for t in topics if t])
        d[page_id] = cur[-TOPIC_KEEP:]
        body = json.dumps(d, ensure_ascii=False, indent=1)
        tmp = TOPIC_STORE + ".%d.tmp" % os.getpid()
        for i in range(12):
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    f.write(body)
                os.replace(tmp, TOPIC_STORE)
                return
            except PermissionError:
                time.sleep(0.25)
        try:                                  # luoi cuoi: ghi thang (khong dung replace)
            with open(TOPIC_STORE, "w", encoding="utf-8") as f:
                f.write(body)
        except OSError as exc:
            print("[img-topic] khong ghi duoc so chu de (%s) — bo qua" % str(exc)[:80],
                  flush=True)
    finally:
        if fd is not None:
            os.close(fd)
            try:
                os.unlink(lock)
            except OSError:
                pass


def topics_for_page(page_id, page_name, theme="", n=1, timeout=90, remember=True, slug=""):
    """Gemini tu nghi n CHU DE bai anh DUA THEO VIDEO THAT cua page (khong lap chu de cu).

    slug = page nguon dang cao -> lay caption cac reel dang chay (page_video_digest) lam
    goc. Khong co video nao thi moi rot ve ten page + chu de kenh.

    Tra list chu de (tieng Viet). Gemini loi / thieu key -> tra [] (nguoi goi tu lo
    fallback) — KHONG nem de mot page hong khong keo sap ca luot.
    """
    n = max(1, int(n))
    vids = page_video_digest(slug) if slug else []
    vtxt = "\n".join(vids) if vids else "- (chua tai video nao — bam theo chu de kenh)"
    used = list(_topic_log(page_id))
    out, seen = [], {t.strip().lower() for t in used}
    # 2 lươt: loc trung xong con thieu thi xin them (chu de vua sinh cung vao danh sach
    # "da dung" cua luot sau -> khong bao gio tra 2 chu de giong nhau trong cung 1 me).
    for _ in range(2):
        if len(out) >= n:
            break
        avoid = "\n".join("- %s" % t for t in (used + out)[-24:]) or "- (chua co)"
        try:
            txt = fb_remake.gemini_generate(
                [{"text": _TOPIC_PROMPT % (page_name or page_id,
                                           theme or "(chua phan tich — tu suy tu video ben duoi)",
                                           vtxt, n - len(out), avoid)}],
                gen_config={"temperature": 1.0}, timeout=timeout)
            got = fb_remake._first_json(txt).get("topics") or []
        except Exception as exc:
            print("[img-topic] Gemini loi (%s)" % str(exc)[:90], flush=True)
            break
        for t in got:
            s = str(t).strip()
            if s and s.lower() not in seen:
                seen.add(s.lower())
                out.append(s)
    out = out[:n]
    if out and remember:
        _topic_remember(page_id, out)
    return out


def content_pack(source_text, timeout=90):
    """Gemini -> {idea, text, caption, tags}. Loi/thieu key -> fallback an toan (khong nem)."""
    base = (source_text or "").strip()
    fb = {"idea": "", "text": "", "caption": base, "tags": ["xuhuong", "viral"]}
    if not base:
        return fb
    try:
        txt = fb_remake.gemini_generate([{"text": _PROMPT % base[:1500]}],
                                        gen_config={"temperature": 0.9}, timeout=timeout)
        d = fb_remake._first_json(txt)
        tags = [re.sub(r"[^0-9a-zA-Z_]", "", str(t).lstrip("#"))[:24] for t in (d.get("tags") or [])]
        tags = [t for t in tags if t][:6]
        for must in ("xuhuong", "viral"):
            if must not in [t.lower() for t in tags]:
                tags.append(must)
        return {"idea": (d.get("idea") or "").strip(),
                "text": (d.get("text") or "").strip()[:160],
                "caption": (d.get("caption") or base).strip(),
                "tags": tags}
    except Exception as exc:
        print("[img-pack] Gemini loi (%s) -> fallback" % str(exc)[:90], flush=True)
        return fb


# LECH KEY GIUA 2 MODULE (do that 2026-07-25): fb_remake dung 'real'/'cartoon',
# image_post dung 'anh_that'/'hoat_hinh'. Truyen thang 'real' -> build_prompt khong khop
# -> AM THAM roi ve mac dinh hoat hinh (chon "anh that" ma ra hoat hinh). Anh xa o day.
_STYLE_MAP = {"real": "anh_that", "cartoon": "hoat_hinh"}


def map_style(style):
    """Doi key kieu anh cua fb_remake -> key cua image_post. Khong biet -> giu nguyen."""
    s = (style or "").strip()
    s = _STYLE_MAP.get(s, s)
    return s if s in image_post.STYLES else image_post.DEFAULT_STYLE


def make_image(idea, text, style="real", ratio_key="facebook_post", out_dir="",
               model=MODEL, mode=MODE, resolution=RES):
    """79AI ve tranh theo `idea` -> PIL ghi `text` len -> tra duong dan anh.

    text rong -> anh KHONG chu (phu kin khung).
    """
    from gommo_client import GommoClient, download
    if not (idea or "").strip():
        raise ValueError("Thieu y tuong tranh (idea).")
    style = map_style(style)
    out_dir = out_dir or OUT_DIR
    os.makedirs(out_dir, exist_ok=True)
    client = GommoClient()
    # ti le tranh: co chu -> khop dai tranh (~70% duoi); khong chu -> phu kin
    ratios = []
    try:
        row = next((m for m in client.image_models() if m.get("model") == model), None)
        ratios = [o["value"] for o in (row or {}).get("ratios", [])]
    except Exception:
        ratios = []
    illo_ratio = image_post.pick_illustration_ratio(ratios or ["9:16", "1:1", "16:9"],
                                                    ratio_key, full=not text)
    prompt = image_post.build_prompt(idea, style)
    res = client.create_image(model=model, prompt=prompt, ratio=illo_ratio,
                             mode=mode or None, resolution=resolution or None)
    if res.get("error"):
        raise RuntimeError("79AI tu choi: %s" % (res.get("message") or res))
    info = res.get("imageInfo") or res.get("data") or res
    idb = info.get("id_base") or res.get("id_base")
    if not idb:
        raise RuntimeError("Khong lay duoc ma anh tu 79AI: %s" % res)
    done = client.wait_for_image(idb)
    out = os.path.join(out_dir, "imgpost_%d.png" % int(time.time() * 1000))
    with tempfile.TemporaryDirectory() as td:
        raw = os.path.join(td, "illo.png")
        download(done["url"], raw)
        if text:
            image_post.compose_card(raw, text, out, ratio_key)
        else:
            image_post.compose_plain(raw, out, ratio_key)
    return out


def build(source_text, style="real", ratio_key="facebook_post", out_dir=""):
    """1 phat: Gemini -> noi dung -> ve anh. Tra {image, text, caption, tags, idea}."""
    p = content_pack(source_text)
    if not p.get("idea"):
        raise RuntimeError("Gemini khong tra duoc y tuong tranh (thieu GEMINI_API_KEY?)")
    img = make_image(p["idea"], p["text"], style=style, ratio_key=ratio_key, out_dir=out_dir)
    return {"image": img, **p}


def _mode_for(model: str) -> str:
    """3.0-omni KHONG co tham so mode (giong fb_remake._gen_one_image) — model khac giu 'vip'."""
    return None if (model or MODEL) == "3.0-omni" else MODE


def run_for_page(page_id, page_name, source_text="", when_ts=0, style="real",
                 ratio_key="facebook_post", rank=None, slot_k=0,
                 gap_page_min=15, gap_post_min=300, anchor=0, mode="now", theme="", slug="",
                 run_id="", img_model=None):
    """Tao 1 BAI DANG ANH cho page roi XEP KHO CHO (dang bang Chrome theo lich).

    source_text RONG -> Gemini TU NGHI chu de hop voi page (theme = chu de kenh do
    Gemini phan tich nguon dien san), tranh trung chu de da dung cho page do.

    Gio dang tinh y het duong video (fb_slots): anchor + rank*gap_page + k*gap_bai
    -> bai anh va bai video dung CHUNG mot quy tac lich, khong lech nhau.
    """
    import fb_chrome_queue
    import fb_slots
    src = (source_text or "").strip()
    if not src:
        _prog("Đang nghĩ chủ đề theo video của page")
        got = topics_for_page(page_id, page_name, theme, 1, slug=slug)
        if not got:
            raise RuntimeError("Gemini khong nghi duoc chu de cho page nay (thieu GEMINI_API_KEY?)")
        src = got[0]
        print("[img-topic] %s → %s" % (page_name or page_id, src[:90]), flush=True)
    _prog("Đang viết chữ trên ảnh + tus (Gemini)")
    p = content_pack(src)
    if not p.get("idea"):
        raise RuntimeError("Gemini khong tra duoc y tuong tranh (thieu GEMINI_API_KEY?)")
    _prog("Đang vẽ tranh bằng 79AI")
    img = make_image(p["idea"], p["text"], style=style, ratio_key=ratio_key,
                     model=img_model or MODEL, mode=_mode_for(img_model))
    r = {"image": img, **p, "topic": src}
    if not when_ts:
        # run_id = 1 luot bam Star. Thieu no -> dung lai BANG RANK CU -> page vua xong
        # lai mang rank cu -> "dang luon" ma bi day them rank*gap_page phut.
        rk = fb_slots.rank_of(page_id, run_id) if rank is None else int(rank)
        a = fb_slots.run_t0(run_id) if mode == "now" else int(anchor or 0)
        when_ts = fb_slots.slot_for(a, rk, slot_k, gap_page_min, gap_post_min, min_lead=0)
    it = fb_chrome_queue.add(page_id, page_name, r["image"], int(when_ts),
                             caption=r["caption"], title="", tags=r["tags"], kind="photo",
                             gap_page_min=gap_page_min)
    return {**r, "queue_id": it["id"], "when_ts": int(when_ts)}


if __name__ == "__main__":
    import argparse
    import io
    import sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    ap = argparse.ArgumentParser(description="Tao bai dang ANH tu chu de (Gemini + 79AI + PIL).")
    ap.add_argument("--source", default="", help="chu de / noi dung nguon (RONG = Gemini tu nghi)")
    ap.add_argument("--theme", default="", help="chu de kenh (giup Gemini nghi dung gu page)")
    ap.add_argument("--slug", default="", help="page NGUON da cao (lay caption video that lam goc)")
    ap.add_argument("--topics-only", type=int, default=0,
                    help="chi in N chu de Gemini nghi cho page (0 credit, khong ve)")
    ap.add_argument("--style", default="real")
    ap.add_argument("--img-model", default="", help="model VE ANH nguoi dung chon, '' = mac dinh")
    ap.add_argument("--ratio", default="facebook_post")
    ap.add_argument("--pack-only", action="store_true", help="chi sinh noi dung, KHONG ve (0 credit)")
    # Che do CHO PAGE: ve xong xep thang KHO CHO (dang bang Chrome theo lich)
    ap.add_argument("--page-id", default="")
    ap.add_argument("--page-name", default="")
    ap.add_argument("--n", type=int, default=1)             # so bai anh cho page nay
    ap.add_argument("--slot-gap-page", type=int, default=15)
    ap.add_argument("--slot-gap-post", type=int, default=300)
    ap.add_argument("--slot-anchor", type=int, default=0)
    ap.add_argument("--chrome-mode", default="now", choices=["now", "schedule"])
    ap.add_argument("--slot-run-id", default="", help="1 luot Star = 1 run-id (rank reset)")
    ap.add_argument("--item-id", default="", help="ghi trang thai vao fb_pipeline (theo doi tren tool)")
    a = ap.parse_args()
    if a.topics_only:
        print(json.dumps(topics_for_page(a.page_id or "cli", a.page_name, a.theme,
                                         a.topics_only, remember=bool(a.page_id),
                                         slug=a.slug), ensure_ascii=False, indent=1))
    elif a.pack_only:
        print(json.dumps(content_pack(a.source), ensure_ascii=False, indent=1))
    elif a.page_id:
        # --item-id: bao trang thai SONG vao fb_pipeline -> man hinh chinh theo doi duoc
        # y het duong video (queued -> dang lam -> done/error), khong phai cho im lim.
        pipe = None
        if a.item_id:
            import fb_pipeline as pipe

            def _st(msg, status="remaking"):
                try:
                    pipe.update(a.item_id, step=msg, status=status)
                except Exception:
                    pass
            set_progress(lambda m: _st("%s (%d/%d)" % (m, _k[0] + 1, max(1, a.n))))
        _k = [0]
        out = []
        try:
            for k in range(max(1, a.n)):
                _k[0] = k
                r = run_for_page(a.page_id, a.page_name, a.source, style=a.style,
                                 ratio_key=a.ratio, slot_k=k, gap_page_min=a.slot_gap_page,
                                 gap_post_min=a.slot_gap_post, anchor=a.slot_anchor,
                                 mode=a.chrome_mode, theme=a.theme, slug=a.slug,
                                 run_id=a.slot_run_id, img_model=(a.img_model or None))
                print("→ bài ảnh %d/%d → %s | %s" % (
                    k + 1, a.n, time.strftime("%H:%M %d/%m", time.localtime(r["when_ts"])),
                    r["text"][:60]), flush=True)
                out.append({"when_ts": r["when_ts"], "text": r["text"]})
                if pipe:
                    pipe.update(a.item_id, when_ts=int(r["when_ts"]), desc=r["text"][:120],
                                step="đã xếp kho chờ %d/%d — %s" % (
                                    k + 1, max(1, a.n),
                                    time.strftime("%H:%M %d/%m", time.localtime(r["when_ts"]))))
        except Exception as exc:
            if pipe:
                pipe.update(a.item_id, status="error", step="lỗi tạo bài ảnh",
                            error=str(exc)[:300])
            raise
        if pipe:
            pipe.update(a.item_id, status="done",
                        step="✅ %d bài ảnh chờ Chrome đăng" % len(out))
        print("KETQUA:", json.dumps({"ok": True, "posts": out}, ensure_ascii=False))
    else:
        print(json.dumps(build(a.source, a.style, a.ratio), ensure_ascii=False, indent=1))
