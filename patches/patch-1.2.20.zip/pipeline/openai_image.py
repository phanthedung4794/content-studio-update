"""Ve anh bang OpenAI gpt-image-2 — CHI dung cho tab "Tao anh" (noi dung don le, dong bo).

KHONG dung trong pipeline dang hang loat FB (fb_auto/fb_image_post van 79AI-only —
kien truc resume/.task/retry cua 79AI la BAT DONG BO, khac han goi dong bo cua OpenAI;
tron 2 co che vao 1 rui ro cho he thong dang chay that). Xem CLAUDE.md rule
"sua song song 4 duong" — day la PROVIDER THEM cho 1 tool don, khong phai 4 duong do.
"""
import base64
import json
import os
import urllib.error
import urllib.request

API_URL = "https://api.openai.com/v1/images/generations"

# Ti le (ten dung chung voi 79AI: "9:16","1:1"...) -> size CO DINH OpenAI ho tro (chi 3
# kich thuoc). "9:16"/"16:9" (video doc/ngang) khong co size rieng -> alias ve 2:3/3:2
# gan nhat (anh se duoc crop lai o buoc dung video/ghep the nao cung khong sao).
SIZES = {"1:1": "1024x1024", "2:3": "1024x1536", "3:2": "1536x1024",
         "9:16": "1024x1536", "16:9": "1536x1024"}

# Gia USD/anh do THAT tu developers.openai.com/api/docs/pricing (2026-07-26, size 1024x1024).
_PRICE_USD = {"low": 0.011, "medium": 0.042, "high": 0.167}
USD_VND = 26000   # ty gia tham khao co dinh — chi de UI hien chi phi uoc tinh (~doi VND)


def price_vnd(quality: str) -> int:
    return round(_PRICE_USD.get(quality, _PRICE_USD["low"]) * USD_VND)


def _key() -> str:
    k = os.environ.get("OPENAI_API_KEY", "")
    if not k:
        raise RuntimeError("Thiếu OPENAI_API_KEY (điền ở Cài đặt → Quản lý key).")
    return k


def generate(prompt: str, ratio: str = "1:1", quality: str = "low") -> bytes:
    """Goi OpenAI images/generations (dong bo, 1 lan) -> tra ve BYTES PNG."""
    size = SIZES.get(ratio, "1024x1024")
    q = quality if quality in _PRICE_USD else "low"
    body = json.dumps({"model": "gpt-image-2", "prompt": prompt, "size": size,
                        "quality": q, "n": 1}).encode("utf-8")
    req = urllib.request.Request(
        API_URL, data=body,
        headers={"Authorization": f"Bearer {_key()}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"OpenAI từ chối: {e.read().decode()[:300]}")
    item = (data.get("data") or [{}])[0]
    b64 = item.get("b64_json")
    if not b64:
        raise RuntimeError(f"OpenAI không trả ảnh: {str(data)[:300]}")
    return base64.b64decode(b64)
