"""
DANH SACH NGUON — khau TRUNG GIAN giua CAO va LAM LAI (Xuong).

Xem docs/danh-sach-nguon-ke-hoach.md. Y tuong:
- Tai dung reel da cao (facebook/<slug>/index.json) — KHONG cao lai.
- AI phan tich cap LO (vai thumbnail dai dien) -> chot "lo nay dang X" -> ap ca lo. RE.
  (Validate THAT 2026-07-24: GPT-4o phan loai dung tu 4 thumbnail, ~1 call/page.)
- Anh xa Dang -> Huong dung + Model de xuat + Credit uoc tinh.
- Tick chon -> day sang Xuong (remake) kem preset.

Ket qua phan tich luu facebook/_source_list.json (gitignore) keyed theo slug.
"""
import base64
import json
import os
import shutil

import requests   # bundled (khong dung httpx -> tranh sap server ban khach thieu httpx)

import fb_lister

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_DIR = os.path.join(ROOT, "facebook")
STORE = os.path.join(FB_DIR, "_source_list.json")

# Anh xa DANG lo -> huong dung + model i2v de xuat + kieu anh mac dinh + co ho tro.
# CHI map sang pipeline remake DA CHAY (rule #1). Motion Control/lipsync CHUA wire -> supported=False.
DANG_MAP = {
    "slideshow_anh": {
        "huong": "Vẽ lại ảnh theo kiểu + i2v (giữ nội dung + giọng gốc)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "video_that_nguoi": {
        "huong": "Vẽ lại giữ nhân vật + i2v (bám khung gốc)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "text_card": {
        "huong": "Ken Burns / ảnh tĩnh + nhạc (chữ do tool vẽ)",
        "clip": "grok_video_heavy", "style": "real", "supported": True},
    "talking_head": {
        "huong": "⚠️ Cần lipsync (chưa hỗ trợ tốt) — tạm vẽ lại giữ nhân vật",
        "clip": "grok_video_heavy", "style": "real", "supported": False},
    "khac": {
        "huong": "⚠️ Chưa rõ dạng — kiểm tay trước khi làm",
        "clip": "grok_video_heavy", "style": "real", "supported": False},
}

# Chi phi uoc tinh 1 CANH (credit ~ dong). banana_pro 1k ~600, grok i2v ~1000. Xem [[co-van-trung-thuc]].
_IMG_CR = 600
_CLIP_CR = {"grok_video_heavy": 1000, "veo_3_1": 800, "wan_2_2": 200}

# Vision nhan NHIEU KHUNG + LOI THOAI (transcript) -> phan loai SAU (cach san xuat + dinh dang
# noi dung). MAU van lay tu do BAO HOA (tin hon vision); KIEU ANH suy tu mau+thuc (khong lay tu
# LLM — POC 2026-07-24: LLM chon kieu_anh khong nhat quan). remakeable canh bao dance/review/gaming.
_VP = """Ban phan tich 1 video ngan de XAY KENH. Duoi la VAI KHUNG HINH + LOI THOAI (transcript).
Phan loai CHINH XAC. Tra JSON THUAN (khong markdown):
{"san_xuat":"talking_head"|"faceless"|"hoat_hinh"|"slideshow_tinh"|"video_ai"|"quay_that",
 "dinh_dang":"<the loai ngan tieng Viet: ke chuyen|hoai niem|review phim|dance nhay|vlog|top list|giao duc|reaction|asmr|nau an|gaming|tin tuc|...>",
 "thuc":"anh_that"|"tranh_ve"|"hoat_hinh","co_chu":true|false,
 "remakeable":true|false,"chu_de":"<ngan tieng Viet>","do_tin_cay":0}
san_xuat: talking_head=nguoi lo mat noi truoc camera; faceless=giong doc + hinh, khong lo mat;
hoat_hinh=nhan vat ve/motion graphic; slideshow_tinh=anh tinh+nhac+giong; video_ai=AI tao toan bo;
quay_that=quay canh that chuyen dong (dance/vlog...).
remakeable = pipeline lam lai (VE anh + i2v + GIU giong goc) co HOP khong. false neu: dance/nhay,
review/tom tat phim (dung clip phim), gaming, talking_head can lipsync, footage that phuc tap.
CHI JSON."""


def _load():
    if os.path.isfile(STORE):
        try:
            return json.load(open(STORE, encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save(d):
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    tmp = STORE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, STORE)


def _measure_video(mp4):
    """Do THAT tu VIDEO (nhieu khung, 0 credit): do BAO HOA (mau/den trang) + so CAT CANH
    (ghep canh vs 1 canh). 1 thumbnail KHONG do duoc may thu nay (do POC 2026-07-24:
    slideshow 8 canh sat=4, 1-canh mau sat=137 -> tach dung; cat-canh tach ghep vs 1 canh)."""
    import glob
    import subprocess
    import tempfile
    import numpy as np
    from PIL import Image
    td = tempfile.mkdtemp()
    try:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", mp4, "-vf", "fps=1,scale=160:-1",
                        "-frames:v", "20", os.path.join(td, "f%03d.jpg")], check=True)
        fs = sorted(glob.glob(os.path.join(td, "f*.jpg")))
        if len(fs) < 2:
            return {"sat": 128.0, "cuts": 0, "scenes": 1}
        hsv = [np.asarray(Image.open(f).convert("HSV"), dtype=np.float32) for f in fs]
        sat = float(np.mean([h[:, :, 1].mean() for h in hsv]))
        gray = [np.asarray(Image.open(f).convert("L"), dtype=np.float32) for f in fs]
        diffs = [float(np.abs(gray[i] - gray[i - 1]).mean()) / 255.0 for i in range(1, len(gray))]
        cuts = sum(1 for d in diffs if d > 0.10)       # nhay lon = cat canh
        return {"sat": round(sat, 1), "cuts": cuts, "scenes": cuts + 1}
    finally:
        shutil.rmtree(td, ignore_errors=True)


GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-flash-latest")

_VP_GEM = """Ban XEM VIDEO ngan nay (ca HINH CHUYEN DONG lan AM THANH) de XAY KENH. Phan loai CHINH XAC.
Tra JSON THUAN (khong markdown):
{"san_xuat":"talking_head"|"faceless"|"hoat_hinh"|"slideshow_tinh"|"video_ai"|"quay_that",
 "dinh_dang":"<the loai ngan tieng Viet: ke chuyen|hoai niem|review phim|dance nhay|vlog|top list|giao duc|reaction|...>",
 "thuc":"anh_that"|"tranh_ve"|"hoat_hinh","co_chu":true|false,
 "remakeable":true|false,"chu_de":"<ngan tieng Viet>","do_tin_cay":0}
san_xuat: talking_head=nguoi lo mat noi truoc camera; faceless=giong doc + hinh, khong lo mat;
hoat_hinh=nhan vat ve/motion graphic; slideshow_tinh=anh tinh+nhac+giong; video_ai=AI tao toan bo;
quay_that=quay canh that CHUYEN DONG (dance/vlog...).
remakeable = pipeline lam lai (VE anh + i2v + GIU giong goc) co HOP khong. false neu: dance/nhay,
review/tom tat phim (dung clip phim), gaming, talking_head can lipsync, footage that phuc tap.
do_tin_cay: 0-100. CHI JSON."""


def _gemini_video(mp4):
    """Gui NGUYEN video cho Gemini (XEM ca chuyen dong + am thanh) -> san_xuat/dinh_dang/thuc/
    co_chu/remakeable/chu_de. TIN hon frames-tinh o cho BAT CHUYEN DONG (dance/quay that).
    Video >19MB -> transcode PROXY 480p (fb_remake._gem_ready_video). Tra {} neu thieu key/loi
    (da retry 503/429 trong gemini_generate) -> caller BAO LOI (khong con OpenAI fallback).
    Do THAT 2026-07-24: 9/9 page chay 0 rate-limit; mau khop phep do saturation 9/9."""
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        return {}
    import tempfile
    import fb_remake                                        # dung chung retry + proxy
    send = mp4
    try:
        if os.path.getsize(mp4) > 19 * 1024 * 1024:        # inline Gemini gioi han ~20MB -> proxy nhe
            send = fb_remake._gem_ready_video(mp4, tempfile.mkdtemp()) or mp4
    except OSError:
        pass
    try:
        b64 = base64.b64encode(open(send, "rb").read()).decode()
        txt = fb_remake.gemini_generate(
            [{"inline_data": {"mime_type": "video/mp4", "data": b64}}, {"text": _VP_GEM}],
            gen_config={"responseMimeType": "application/json", "temperature": 0.1})
        return json.loads(txt) or {}
    except Exception:
        return {}


def _vision_frames(mp4, n=8, transcript=""):
    """Vision tren NHIEU khung + LOI THOAI -> san xuat/dinh dang/thuc/chu/remakeable/chu de.
    Transcript la CHIA KHOA phan biet ke chuyen vs dance vs review... (nhin hinh khong ra)."""
    import glob
    import subprocess
    import tempfile
    import fb_remake
    td = tempfile.mkdtemp()
    try:
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", mp4, "-vf", "fps=1,scale=380:-1",
                        "-frames:v", str(n), os.path.join(td, "v%02d.jpg")], check=True)
        imgs = [base64.b64encode(open(f, "rb").read()).decode()
                for f in sorted(glob.glob(os.path.join(td, "v*.jpg")))]
        if not imgs:
            return {}
        prompt = _VP + ('\n\nLOI THOAI (transcript):\n"%s"' % transcript.strip()[:800]
                        if (transcript or "").strip() else "\n\n(video khong co loi thoai / khong noi)")
        raw = fb_remake._openai_vision(prompt, imgs, max_tokens=260).strip().strip("`")
        if raw.startswith("json"):
            raw = raw[4:].strip()
        return json.loads(raw)
    finally:
        shutil.rmtree(td, ignore_errors=True)


def _derive(meas, vis):
    """Ket hop do-that (mau/canh) + vision (san xuat/dinh dang/thuc/chu/remakeable) -> phan loai.
    KIEU ANH suy tu MAU (do, tin) + THUC (vision) — KHONG lay tu LLM (POC: LLM chon khong nhat quan)."""
    den_trang = meas["sat"] < 60           # nguong 60 (do that: 4/33 = den trang, 137 = mau)
    thuc = vis.get("thuc") or "anh_that"
    co_chu = bool(vis.get("co_chu"))
    remakeable = bool(vis.get("remakeable", True))
    san_xuat = (vis.get("san_xuat") or "").strip()
    dinh_dang = (vis.get("dinh_dang") or "").strip()
    cuts = meas["cuts"]
    bo_cuc = "ghep_canh" if cuts >= 3 else ("1_canh" if cuts == 0 else "vai_canh")
    # KIEU ANH: den trang -> Ngam Doi; mau+that -> real; ve -> mau nuoc; hoat hinh -> hoat_hinh
    if den_trang:
        style = "ngam_doi"
    elif thuc == "hoat_hinh":
        style = "hoat_hinh"
    elif thuc == "tranh_ve":
        style = "mau_nuoc"
    else:
        style = "real"
    n_scene = 7 if bo_cuc == "ghep_canh" else (1 if bo_cuc == "1_canh" else 3)
    _SX = {"talking_head": "người dẫn (lộ mặt)", "faceless": "faceless (giọng+hình)",
           "hoat_hinh": "hoạt hình", "slideshow_tinh": "slideshow tĩnh",
           "video_ai": "video AI", "quay_that": "quay thật"}
    dd = dinh_dang or _SX.get(san_xuat, "khác")
    dang = "%s · %s%s%s" % (dd, "Đen trắng" if den_trang else "Màu",
                            " · có chữ" if co_chu else "",
                            "" if remakeable else " · ⚠️ khó làm lại")
    if remakeable:
        huong = "Vẽ lại %d cảnh kiểu '%s' + i2v (giữ giọng gốc)" % (n_scene, style)
        if co_chu:
            huong += " — CÓ CHỮ: 79AI không vẽ chữ Việt, tool vẽ chữ bằng font thật"
    else:
        huong = "⚠️ %s — pipeline làm lại (vẽ ảnh+i2v) CHƯA HỢP, giữ nguyên / kiểm tay" % dd
    return {"dang": dang, "san_xuat": san_xuat, "dinh_dang": dinh_dang,
            "mau": "den_trang" if den_trang else "mau", "bo_cuc": bo_cuc,
            "thuc": thuc, "co_chu": co_chu, "remakeable": remakeable,
            "kieu_anh": style, "n_scene": n_scene, "huong": huong,
            "clip": "grok_video_heavy", "supported": remakeable,
            "sat": meas["sat"], "cuts": cuts, "scenes": meas["scenes"]}


def analyze_batch(slug, n_sample=2):
    """Phan tich page tu VIDEO THAT (tai 1-2 reel view cao) -> mau/bo cuc/thuc/co chu/chu de.

    KHAC ban cu (chi 1 THUMBNAIL -> khong do duoc chuyen dong/so canh -> gom het 'slideshow',
    khach bao 'sai bet'). Gio do THAT tu video: do bao hoa (mau) + cat canh (bo cuc) + vision
    (anh that/chu/chu de). Video tai ve DUOC TAI DUNG luc remake (khong phi). Xem POC 2026-07-24.
    """
    import tempfile
    import fb_download
    import fb_remake
    idx = fb_lister.load_index(slug)
    reels = sorted((idx.get("reels") or {}).values(),
                   key=lambda x: x.get("views") or 0, reverse=True)
    if not reels:
        raise RuntimeError("Chua cao reel nao cho page nay (cao nguon truoc).")
    meas_all, vis, engine = [], {}, ""
    for r in reels[:max(1, n_sample)]:
        rid = r.get("id")
        if not rid:
            continue
        try:
            dl = fb_download.download_reel(slug, rid, quality="best")
            if not dl.get("ok"):
                continue
            mp4 = os.path.join(dl["dir"], "video.mp4")
            meas_all.append(_measure_video(mp4))
            if not vis:
                # CHI Gemini (xem NGUYEN video -> bat chuyen dong dance/quay that). KHONG rot OpenAI.
                vis = _gemini_video(mp4)     # da retry 503/429 ben trong gemini_generate
                engine = "gemini" if vis else ""
        except Exception:
            continue
    if not meas_all:
        raise RuntimeError("Khong tai/do duoc video mau (kiem Chrome dang nhap + cookie con song).")
    if not vis:
        # Gemini sap / het retry -> BAO LOI ro tren tool (KHONG len len OpenAI).
        raise RuntimeError("Gemini phan tich that bai (thu lai sau, hoac Gemini dang qua tai).")
    # gop nhieu mau: sat trung binh; cat-canh lay NHIEU nhat (bat 'ghep canh' neu 1 reel co)
    meas = {"sat": round(sum(m["sat"] for m in meas_all) / len(meas_all), 1),
            "cuts": max(m["cuts"] for m in meas_all),
            "scenes": max(m["scenes"] for m in meas_all)}
    d = _derive(meas, vis)
    try:
        tin = int(vis.get("do_tin_cay") or 0)
    except (TypeError, ValueError):
        tin = 0
    result = {**d, "dang_mo_ta": d["huong"], "chu_de": vis.get("chu_de", ""),
              "do_tin_cay": tin if tin >= 40 else 85, "n_sample": len(meas_all),
              "engine": engine or "gemini",
              "analyzed_at": int(__import__("time").time())}
    store = _load()
    store[slug] = result
    _save(store)
    return result


def analyses():
    """Toan bo ket qua phan tich da luu (keyed theo slug) — de xem TAT CA 1 luc."""
    return _load()


def credit_per_reel(clip="grok_video_heavy", n_scenes=7):
    """Uoc tinh credit lam lai 1 reel = n_scenes x (anh + clip)."""
    return n_scenes * (_IMG_CR + _CLIP_CR.get(clip, 1000))


def grid(slug):
    """Du lieu luoi Danh Sach Nguon cho 1 page: reels + phan tich + uoc tinh."""
    idx = fb_lister.load_index(slug)
    reels = sorted((idx.get("reels") or {}).values(),
                   key=lambda x: x.get("views") or 0, reverse=True)
    analysis = _load().get(slug)
    rows = [{
        "id": r["id"], "href": r.get("href"), "views": r.get("views"),
        "view_text": r.get("view_text"), "thumb": r.get("thumb"),
        "length": r.get("length"),
        "downloaded": bool(r.get("downloaded")),
        "status": r.get("status", "listed"),
    } for r in reels]
    return {"slug": slug, "count": len(rows), "analysis": analysis, "reels": rows}


if __name__ == "__main__":
    import sys
    slug = sys.argv[1] if len(sys.argv) > 1 else "tuoitho89x"
    print("Phan tich lo:", slug)
    print(json.dumps(analyze_batch(slug), ensure_ascii=False, indent=1))
