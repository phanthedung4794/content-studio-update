# -*- coding: utf-8 -*-
"""
Orchestration 1 dong mapping: LINK nguon -> tai -> lam lai -> len lich dang len PAGE.
Dung boi tab "Tu dong theo page". Moi dong chay 1 job (qua hang doi).

CHUA NGHIEM THU THAT (ton credit + chan dang) -> debug lan dau cung nguoi dung.
"""
import argparse
import json
import os
import re
import time

import fb_download
import fb_governor
import fb_graph
import fb_pipeline
import fb_publish
import fb_remake
import fb_watch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FB_ROOT = os.path.join(ROOT, "facebook")


def _reel_id(link: str) -> str:
    m = re.search(r"/reel/(\d+)", link) or re.search(r"/videos/(\d+)", link) \
        or re.search(r"[?&]v=(\d+)", link)
    return m.group(1) if m else ""


def _slug(link: str) -> str:
    # profile.php?id=<so> -> id<so> (KHOP fb_lister.page_slug + automap; truoc tra "auto" ->
    # 5 page so DON CHUNG facebook/auto/remake/ + frontend khong tim ra video -> mat nut Xem).
    mid = re.search(r"profile\.php\?id=(\d+)", link)
    if mid:
        return "id" + mid.group(1)
    m = re.search(r"facebook\.com/([^/?#]+)", link)
    s = m.group(1) if m else "auto"
    return "auto" if s in ("reel", "watch", "profile.php") else s


def run_row(page_id, link, audio_mode="B", clip_model="veo_3_1",
            desc="", n_scenes=6, item_id=None, style="real",
            post_mode="schedule", lanes=None, order="oldest", reel_id="",
            img_model=None,
            # ── ĐƯỜNG CHROME (transport='chrome'): không đăng bằng token, xếp KHO CHỜ ──
            transport="token", title="", tags=None, page_name="",
            slot_run_id="", slot_k=0, slot_gap_page=15, slot_gap_post=300,
            slot_anchor=0, chrome_mode="schedule",
            hook="on", hook_fit="cover"):     # hook: on (suot video) | head (3s dau) | off
    def _st(step, status, **kw):
        if item_id:
            fb_pipeline.update(item_id, step=step, status=status, **kw)

    def _fail(res):
        _st(res.get("step", "?"), "error",
            error=str(res.get("reason") or res.get("error"))[:200])
        return res

    # Link NGUON (page) -> tu lay reel MOI ke tiep; link co dinh -> lay dung reel do.
    is_src = fb_watch.is_source(link)
    if reel_id:
        # RETRY/RESUME: nham DUNG reel cu (item da luu) -> CUNG work dir -> resume (giu clip/anh
        # da lam). Truoc day retry truyen link nguon -> next_pick CHON LAI reel -> work dir khac
        # -> lam lai tu dau. Giu link nguon de _slug() ra dung slug page (khop work dir cu).
        rid = reel_id
    elif is_src:
        rid = fb_watch.next_pick(link, order=order)   # 'oldest' (cũ nhất) | 'random' (ngẫu nhiên)
        if not rid:
            return _fail({"ok": False, "step": "watch", "reason": "Hết video chưa làm ở nguồn."})
    else:
        rid = _reel_id(link)
        if not rid:
            return _fail({"ok": False, "step": "watch", "error": "Link không có reel id."})
    slug = _slug(link)
    _st("Đang tải video nguồn", "downloading", reel=rid)

    # 1) TAI
    print("→ tải reel %s ..." % rid, flush=True)
    dl = fb_download.download_reel(slug, rid, quality="best")
    if not dl.get("ok"):
        return _fail({"ok": False, "step": "download", "error": dl})
    src = os.path.join(dl["dir"], "video.mp4")

    # 2) LAM LAI — qua GOVERNOR truoc (chan chay credit)
    out = os.path.join(FB_ROOT, slug, "remake", "%s-lamlai.mp4" % rid)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    already = os.path.isfile(out) and os.path.getsize(out) > 1000
    if not already:
        # uoc luong credit: kenburns 0 (khong goi 79) | grok ~11k | veo ~7.2k | wan re hon
        if clip_model == "kenburns":
            est = 0
        else:
            est = 3600 if clip_model == "wan_2_2" else (11000 if clip_model == "grok_video_heavy" else 7200)
        # kenburns local (0 quota/credit) -> free; veo_3_1/grok trong goi + con quota -> 0 credit
        plan_free = clip_model == "kenburns" or (
            clip_model in ("veo_3_1", "grok_video_heavy") and fb_governor.sub_active())
        g = fb_governor.can_produce(est, plan_free=plan_free)
        if not g["ok"]:
            return _fail({"ok": False, "step": "governor", "reason": g["reason"]})
    _st("Đang chuẩn bị dựng lại", "remaking")
    # Day tien trinh CHI TIET cua fb_remake (chep loi / tao anh 3/7 / tao video / ghep) len
    # step cua item -> UI hien THONG MINH thay vi 'download' co dinh. Chi khi co item_id.
    if item_id:
        fb_remake.set_progress(lambda m: _st(m, "remaking"))
    print("→ làm lại (mode %s, %s) ..." % (audio_mode, clip_model), flush=True)
    try:
        rm = fb_remake.remake(src, out, n_scenes=n_scenes, clip_model=clip_model,
                              audio_mode=audio_mode, style=style, lanes=lanes, img_model=img_model)
    except Exception as e:
        # remake NEM loi (rate-limit het luot, ffmpeg, ...) -> danh dau item LOI (co nut thu lai)
        # thay vi de exception lam sap subprocess -> item KET "remaking" mai (treo). Xem _fail.
        return _fail({"ok": False, "step": "remake", "error": ("remake loi: " + str(e))[:200]})
    finally:
        fb_remake.set_progress(None)
    if not rm.get("ok"):
        return _fail({"ok": False, "step": "remake", "error": rm})
    if not (already or rm.get("skipped")):
        fb_governor.record_produced()

    # 3) LEN LICH DANG
    # ĐƯỜNG CHROME KHÔNG ĐỤNG TOKEN — không lấy page_token, không gọi Graph API. Mọi thao
    # tác đăng đi qua trình duyệt thật (fb_chrome_post). Token hỏng/bị Meta khoá vẫn đăng được.
    tok = ""
    if transport != "chrome":
        tok = fb_graph.page_token(page_id)
        if not tok:
            return _fail({"ok": False, "step": "publish", "error": "không có page token (refresh)"})
    # GÓI ĐĂNG BÀI: 1 call Gemini -> hook (chữ trên video) + title (ô Tiêu đề) + caption (tus)
    # + tags (ô Thẻ). Gọi 1 lần rẻ hơn 4 lần VÀ giữ giọng nhất quán giữa hook với tus.
    hook_text = ""
    if not desc:
        cap = os.path.join(dl["dir"], "caption.txt")
        if os.path.isfile(cap):
            raw = open(cap, encoding="utf-8").read()
            # Lọc link Shopee + hashtag/dòng quảng bá kênh nguồn trước khi đưa Gemini.
            cleaned = fb_publish.clean_caption(raw, add_tags=False)
            try:
                pack = fb_remake.content_pack(cleaned)
            except Exception:
                pack = {"hook": "", "title": "", "caption": cleaned, "tags": []}
            desc = pack.get("caption") or fb_publish.clean_caption(raw)
            hook_text = pack.get("hook") or ""
            if not title:
                title = pack.get("title") or ""
            if not tags:
                tags = pack.get("tags") or []
        else:
            desc = ""
    # LUÔN đảm bảo caption có #xuhuong + #viral (Gemini viết lại có thể KHÔNG kèm; dedup nếu đã có).
    desc = fb_publish.ensure_trend_tags(desc)

    # HOOK CHỮ trên đầu video (giữ chân 3 giây đầu). Lỗi vẽ -> GIỮ video gốc, KHÔNG chặn
    # luồng (video đã tốn credit rồi, không được để mất vì khâu trang trí).
    if hook in ("on", "head") and hook_text:
        try:
            import hook_overlay
            hooked = out.replace("-lamlai.mp4", "-hook.mp4")
            _st("Đang gắn chữ hook lên video", "remaking")
            if hook == "head":       # chữ CHỈ 3 giây đầu, sau đó video full khung
                hook_overlay.apply_hook_head(out, hooked, hook_text, seconds=3, fit=hook_fit)
            else:                     # chữ hiện SUỐT video
                hook_overlay.apply_hook(out, hooked, hook_text, fit=hook_fit)
            if os.path.isfile(hooked) and os.path.getsize(hooked) > 1000:
                out = hooked
                print("→ đã gắn hook: %s" % hook_text.replace("\n", " / "), flush=True)
        except Exception as exc:
            print("→ hook lỗi (%s) → giữ video không hook" % str(exc)[:120], flush=True)
    # ── ĐƯỜNG CHROME: KHÔNG đụng token, KHÔNG gọi Graph API (kể cả check lịch trùng).
    # Xếp vào KHO CHỜ + giờ tính theo THỨ TỰ PAGE LÀM XONG
    # (fb_slots: anchor + rank*gap_page + k*gap_bài). Watchdog đến giờ mở Chrome đăng.
    # rank cấp Ở ĐÂY (lúc video vừa xong) mới đúng "page nào xong trước lấy mốc sớm nhất"
    # — cấp lúc xếp job thì sai vì mọi job xếp cùng một lúc.
    if transport == "chrome":
        import fb_chrome_queue
        import fb_slots
        rank = fb_slots.rank_of(page_id, slot_run_id)     # thứ tự page LÀM XONG (0-based)
        if chrome_mode == "now":
            # ĐĂNG LUÔN: neo vào lúc page ĐẦU TIÊN làm xong → page đó đăng NGAY (rank 0,
            # bài 0 → t0 ≈ bây giờ), page xong sau cách nhau gap_page (≥15'), bài thứ 2
            # của mỗi page cách gap_bài. min_lead=0 vì Chrome bấm nút trực tiếp, không
            # phải hẹn lịch FB nên không cần đệm 11 phút.
            anchor = fb_slots.run_t0(slot_run_id)
        else:
            # LÊN LỊCH: neo vào giờ hẹn (vd 6h sáng) — làm hết video xong rồi chờ tới giờ.
            anchor = int(slot_anchor or 0)
        c_when = fb_slots.slot_for(anchor, rank, slot_k, slot_gap_page, slot_gap_post,
                                   min_lead=0)
        it = fb_chrome_queue.add(page_id, page_name, out, c_when, caption=desc,
                                 title=title, tags=tags or [], item_id=item_id or "",
                                 gap_page_min=slot_gap_page)
        hhmm = time.strftime("%H:%M %d/%m", time.localtime(c_when))
        print("→ xếp kho chờ Chrome (%s): page thứ %d, bài %d → %s"
              % (chrome_mode, rank + 1, slot_k + 1, hhmm), flush=True)
        if is_src:
            fb_watch.mark(slug, rid)
        # status='done' (KHÔNG phải 'scheduling') để item không bị dọn orphan khi restart
        # server — bài chờ Chrome có thể nằm nhiều giờ. Watchdog sẽ cập nhật lại khi đăng.
        _st("⏳ chờ Chrome đăng lúc %s" % hhmm, "done", page_id=page_id,
            when_ts=int(c_when), chrome_id=it["id"])
        return {"ok": True, "reel": rid, "out": out, "chrome_id": it["id"],
                "when_ts": int(c_when)}

    # GIỜ ĐĂNG (đường TOKEN) — tính bằng fb_slots, GIỐNG HỆT đường Chrome (rank = thứ tự PAGE
    # LÀM XONG, cấp Ở ĐÂY vì lúc xếp job KHÔNG biết page nào xong trước). Vòng 1 (slot_k=0)
    # giãn theo PAGE (rank*gap_page); vòng 2+ giãn theo BÀI TRƯỚC của CHÍNH page đó (gap_post,
    # KHÔNG phụ thuộc page khác — đúng công thức slot_for, xem fb_slots.py).
    import fb_slots
    rank = fb_slots.rank_of(page_id, slot_run_id)
    if post_mode != "schedule" and slot_k == 0 and rank == 0:
        # ĐĂNG LUÔN, bài ĐẦU của page ĐẦU TIÊN cả lượt (rank 0 — page xong trước tất cả):
        # đăng NGAY, không có mốc nào để giãn từ. Page rank>0 (xong SAU) vẫn phải giãn
        # rank*gap_page tính từ mốc page rank 0 — KHÔNG được bỏ qua slot_for như trước
        # (bug review bắt được: mọi page đều rơi vào nhánh này → mất hẳn giãn cách vòng 1).
        pub_when = None
        print("→ đăng luôn ...", flush=True)
    else:
        anchor = fb_slots.run_t0(slot_run_id) if post_mode != "schedule" else int(slot_anchor or 0)
        # min_lead mặc định (660s) của slot_for đảm bảo target LUÔN >= now+660 — nhánh
        # "lịch đã qua" bên dưới vì vậy không bao giờ chạy tới trong điều kiện bình thường;
        # giữ lại làm lưới an toàn phòng khi slot_for đổi mặc định min_lead sau này.
        target = fb_slots.slot_for(anchor, rank, slot_k, slot_gap_page, slot_gap_post)
        if target > int(time.time()) + 540:
            # CHECK LICH FB TRUOC: tranh TRUNG GIO voi bai da len lich -> day sang slot trong ke tiep
            # (vd dang co 6h/10h/13h -> bai moi len 16h). Loi Graph -> giu nguyen gio da tinh.
            pub_when = fb_publish.next_free_slot(page_id, tok, target, gap_hours=3)
            if pub_when != target:
                _st("Giờ %s trùng lịch → dời sang %s" % (
                    time.strftime("%H:%M", time.localtime(target)),
                    time.strftime("%H:%M %d/%m", time.localtime(pub_when))), "scheduling")
            print("→ lên lịch %s ..." % time.strftime("%H:%M %d/%m", time.localtime(pub_when)), flush=True)
        else:
            pub_when = None
            print("→ (lịch đã qua) đăng luôn ...", flush=True)
    _st("Đang đăng lên trang" if pub_when is None else "Đang lên lịch đăng", "scheduling")
    pub = fb_publish.publish_reel(page_id, tok, out, desc, pub_when)
    if not pub.get("ok"):
        return _fail({"ok": False, "step": "publish", "error": pub})
    if is_src:
        fb_watch.mark(slug, rid)          # ghi so da xu ly -> lan sau khong lam lai
    _st("done", "done", post_id=str(pub.get("post_id") or ""),
        video_id=str(pub.get("video_id") or ""), page_id=page_id, when_ts=int(pub_when or 0))
    return {"ok": True, "reel": rid, "out": out,
            "post_id": pub.get("post_id"), "when_ts": int(pub_when or 0)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--page-id", required=True)
    ap.add_argument("--link", required=True)
    ap.add_argument("--audio", default="B")
    ap.add_argument("--clip", default="veo_3_1")
    ap.add_argument("--desc-file", default="")
    ap.add_argument("--scenes", type=int, default=6)
    ap.add_argument("--style", default="real")   # real (giong that) | cartoon (hoat hinh)
    ap.add_argument("--img-model", default="")   # model VE ANH nguoi dung chon, '' = mac dinh
    ap.add_argument("--post-mode", default="schedule")   # now | schedule
    ap.add_argument("--lanes", type=int, default=1)      # i2v song song TRONG 1 page (mac dinh 1)
    ap.add_argument("--order", default="oldest")         # oldest (cu nhat) | random (ngau nhien)
    ap.add_argument("--reel-id", default="")             # RETRY/RESUME: nham dung reel cu (resume)
    ap.add_argument("--item-id", default=None)
    # ── duong CHROME ──
    ap.add_argument("--transport", default="token", choices=["token", "chrome"])
    ap.add_argument("--title", default="")               # o TIEU DE (chi Chrome co)
    ap.add_argument("--tags", default="")                # o THE, cach nhau dau phay
    ap.add_argument("--page-name", default="")
    ap.add_argument("--chrome-mode", default="schedule", choices=["now", "schedule"])
    ap.add_argument("--slot-run-id", default="")         # 1 luot Star = 1 run-id (rank reset)
    ap.add_argument("--slot-k", type=int, default=0)     # bai thu may cua page (0-based)
    ap.add_argument("--slot-gap-page", type=int, default=15)
    ap.add_argument("--slot-gap-post", type=int, default=300)
    ap.add_argument("--slot-anchor", type=int, default=0)   # moc neo (che do len lich)
    # ── HOOK CHU tren dau video ──
    ap.add_argument("--hook", default="on", choices=["on", "head", "off"])
    ap.add_argument("--hook-fit", default="cover", choices=["cover", "contain"])
    a = ap.parse_args()
    desc = ""
    if a.desc_file and os.path.isfile(a.desc_file):
        desc = open(a.desc_file, encoding="utf-8").read().strip()
    try:
        res = run_row(a.page_id, a.link, a.audio, a.clip, desc, a.scenes,
                      item_id=a.item_id, style=a.style, post_mode=a.post_mode, lanes=a.lanes,
                      order=a.order, reel_id=a.reel_id, img_model=(a.img_model or None),
                      transport=a.transport, title=a.title, page_name=a.page_name,
                      tags=[t.strip() for t in a.tags.split(",") if t.strip()],
                      chrome_mode=a.chrome_mode, slot_run_id=a.slot_run_id, slot_k=a.slot_k,
                      slot_gap_page=a.slot_gap_page, slot_gap_post=a.slot_gap_post,
                      slot_anchor=a.slot_anchor, hook=a.hook, hook_fit=a.hook_fit)
    except Exception as e:
        # LUOI CUOI: bat ky loi ngoai y muon -> item KHONG bao gio ket "remaking" (treo).
        if a.item_id:
            try:
                fb_pipeline.update(a.item_id, status="error", step=("lỗi: " + str(e))[:120])
            except Exception:
                pass
        res = {"ok": False, "error": str(e)[:200]}
    print("KETQUA:", json.dumps(res, ensure_ascii=False), flush=True)
