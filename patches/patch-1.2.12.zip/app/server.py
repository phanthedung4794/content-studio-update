"""Content Studio web server: JSON intake, approved Voice Lab, and production queue."""
import asyncio
import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "pipeline"))


def _load_keys() -> None:
    """Nap API key tu keys.env neu co (ban phat hanh).

    May cua nguoi phat trien nap key tu bien moi truong. May nguoi dung cuoi
    khong co gi ca -> doc tu file di kem. Bien moi truong co san thi UU TIEN,
    khong de file de len.
    """
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path = os.path.join(root, "keys.env")
    if not os.path.isfile(path):
        return
    try:
        with open(path, encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                k, v = k.strip(), v.strip()
                if k and v and not os.environ.get(k):
                    os.environ[k] = v
    except OSError:
        pass


_load_keys()

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import channels
import episode as ep_lib
import fb_download
import fb_drip
import fb_governor
import fb_graph
import fb_insights
import fb_lister
import fb_pipeline
import fb_profiles
import fb_publish
import fb_session
import fb_source_list
import fb_token_grab
import fb_watch
import image_post
import intake
import jobs
import voice_lab
import voice_profiles
from jobs import queue

APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(APP_DIR, "static")
app = FastAPI(title="Meteor Auto")


def _on_auto_job_end(job):
    """Job auto-fb XONG (done) → chạy NGAY 1 vòng cycle để đẩy bài kế cho page đó
    (không chờ cron 30'). Nhờ vậy: xong video 1 (đã hẹn đăng) là bắt tay làm video 2 liền,
    đúng số bài đã cài. Job LỖI thì để cron 30' hồi (tránh vòng lặp retry đốt credit).
    Chạy trong thread (push/đọc file là blocking, KHÔNG chạy thẳng trên event loop)."""
    try:
        if getattr(job, "kind", "") == "auto-fb" and getattr(job, "status", "") == jobs.DONE:
            threading.Thread(target=_run_cycle_guarded, daemon=True).start()
    except Exception as exc:
        print(f"[autopilot] _on_auto_job_end loi: {exc}", flush=True)


@app.on_event("startup")
async def _bind_loop():
    queue.bind_loop(asyncio.get_running_loop())
    # Ap so video chay SONG SONG tu Cai dat (mac dinh 5). Khach goi Starter dong thoi 12
    # -> chay nhieu page 1 luc thay vi ket o 3. Loi cau hinh -> giu mac dinh, KHONG sap.
    try:
        queue.set_max_concurrent(int(_app_config().get("max_jobs", 5)))
    except Exception:
        pass
    queue._on_end = _on_auto_job_end             # nối bài tiếp theo NGAY khi job auto xong
    try:
        _cleanup_orphan_pipeline()               # dọn item kẹt "remaking"/... từ lần chạy cũ
    except Exception as exc:
        print(f"[pipeline] don orphan loi: {exc}", flush=True)
    asyncio.create_task(_autopilot_loop())       # vòng autopilot (mặc định TẮT)


def root() -> str:
    return channels.active_path()


def P(*parts) -> str:
    return os.path.join(root(), *parts)


def read_json(path: str, default=None):
    if not os.path.exists(path):
        return default
    try:
        # utf-8-sig: doc duoc CA file co BOM (Notepad Windows hay them) lan khong BOM.
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        # File hong / BOM la -> tra default, KHONG lam sap endpoint (vd Dong bo so lieu).
        return default


def channel_cfg() -> dict:
    import yaml
    path = P("content", "channel.yaml")
    if not os.path.exists(path):
        return {}
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def episodes() -> list[str]:
    return ep_lib.all_episodes(root())


def episode_info(ep: str) -> dict:
    script = ep_lib.load_script(ep, root())
    needed = ep_lib.images_needed(script)
    done = ep_lib.images_done(ep, root())
    timing = read_json(P("voice", ep, "timing.json"), {})
    return {
        "episode": ep,
        "title": script.get("title", ep),
        "pillar": script.get("pillar", ""),
        "tone": script.get("tone", ""),
        "stage": ep_lib.API_NAME[ep_lib.stage(ep, script, root())],
        "beats": len(script.get("beats", [])),
        "images_needed": needed,
        "scenes_done": min(done, needed) if needed else done,
        "has_video": os.path.isfile(ep_lib.video_path(ep, root())),
        "has_voice": os.path.isfile(ep_lib.timing_path(ep, root())),
        "voice_profile_id": script.get("voice_profile_id"),
        "eleven_voice_id": script.get("eleven_voice_id"),
        "chars": episode_chars(script),
        # Engine da dung THAT (tu timing.json) — chi co sau khi da doc loi.
        "voice_engine": timing.get("engine"),
        # Lua chon giong RIENG cua tap (dat tren luoi). None = theo kenh.
        "voice_pick": script.get("voice_pick"),
        # Engine SE dung neu san xuat bay gio: lua chon rieng -> engine kenh.
        # Luoi hien dung giong se doc; doi kenh la doi that.
        "planned_engine": (script.get("voice_pick") or {}).get("engine") or channel_engine(),
        "timing_source": timing.get("timing_source"),
    }


def require_episode(ep: str) -> dict:
    try:
        ep_lib.validate_episode_id(ep)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    script = ep_lib.load_script(ep, root())
    if not script:
        raise HTTPException(404, "Khong tim thay tap")
    return script


def require_profile(profile_id: str | None = None, script: dict | None = None) -> str:
    profile_id = profile_id or (script or {}).get("voice_profile_id")
    try:
        profile, _ = voice_profiles.resolve(profile_id, root())
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return profile["id"]


# ══════════════════════════════════════════════════════════════════
#  GIONG DOC — MOT noi duy nhat quyet dinh dung engine nao
#
#  Thu tu uu tien:  tham so cua lenh  ->  snapshot trong kich ban  ->  channel.yaml
#
#  VI SAO SNAPSHOT: doi giong mac dinh cua kenh KHONG duoc lam doi giong cac tap
#  da lam roi. Moi tap nho engine + giong cua no ngay luc nhap.
# ══════════════════════════════════════════════════════════════════
ENGINES = ("omnivoice", "eleven")

_omni = {"checked": False, "ok": False}


def omnivoice_installed() -> bool:
    """OmniVoice (9 GB) khong di kem ban phat hanh — kiem xem da cai chua.

    Kiem MOT LAN roi nho: import torch mat gan mot giay.
    """
    if not _omni["checked"]:
        import importlib.util
        _omni["ok"] = all(importlib.util.find_spec(m) is not None
                          for m in ("torch", "omnivoice"))
        _omni["checked"] = True
    return _omni["ok"]


def channel_engine() -> str:
    engine = (channel_cfg().get("voice", {}) or {}).get("engine", "omnivoice")
    return engine if engine in ENGINES else "omnivoice"


def channel_eleven_voice() -> str:
    return (channel_cfg().get("voice", {}) or {}).get("eleven_voice_id") or ""


def narrate_command(ep: str, script: dict, engine: str | None = None,
                    profile_id: str | None = None,
                    eleven_voice: str | None = None) -> tuple:
    """Dung lenh doc loi. Tra ve (engine, cmd). Fail som neu thieu dieu kien —
    khong de nguoi dung xep viec roi vai phut sau moi biet la khong chay duoc."""
    # Thu tu: chon tay (modal) -> LUA CHON RIENG CUA TAP (voice_pick) -> ENGINE KENH.
    #
    # voice_pick: nguoi dung CHU DONG chon giong cho tap nay o luoi Xuong san xuat.
    # KHAC voi snapshot tu dong luc nhap (script['engine']/'eleven_voice_id') — cai
    # do da gay bug: tap nhap luc kenh con OmniVoice bi khoa OmniVoice mai. Gio
    # snapshot nhap KHONG con quyet dinh gi; chi lua chon co chu dich moi tinh.
    pick = script.get("voice_pick") or {}
    engine = engine or pick.get("engine") or channel_engine()
    if engine not in ENGINES:
        raise HTTPException(400, f"Engine khong hop le: {engine}")

    if engine == "omnivoice":
        if not omnivoice_installed():
            raise HTTPException(400,
                "Chưa cài OmniVoice. Bấm đúp file cai-giong-mien-phi.bat để cài "
                "(tải 9 GB), hoặc chuyển sang ElevenLabs ở Voice Lab.")
        pid = require_profile(profile_id or pick.get("profile_id"), script)
        return engine, ["pipeline/omnivoice_tts.py", "--episode", ep, "--profile", pid]

    voice = eleven_voice or pick.get("eleven_voice") or channel_eleven_voice()
    if not voice:
        raise HTTPException(400,
            "Chưa chọn giọng ElevenLabs. Vào Voice Lab → chọn giọng → Đặt làm giọng video.")
    if not os.environ.get("ELEVENLABS_API_KEY", "").strip():
        raise HTTPException(400,
            "Thiếu ELEVENLABS_API_KEY. Nạp key rồi khởi động lại phần mềm.")
    return engine, ["pipeline/narrate.py", "--episode", ep, "--voice", voice]


def episode_chars(script: dict) -> int:
    """So ky tu se doc — dung de bao truoc chi phi ElevenLabs."""
    return sum(len((b.get("voice") or "").strip()) for b in script.get("beats", []))


def push(kind: str, label: str, cmd: list, episode: str | None = None,
         chain: str | None = None, step: str = "") -> dict:
    return queue.add(kind, label, cmd, root(), episode, chain, step).to_dict()


def push(kind: str, label: str, cmd: list, episode: str | None = None,
         chain: str | None = None, step: str = "") -> dict:
    return queue.add(kind, label, cmd, root(), episode, chain, step).to_dict()


def push_chain(steps: list, episode: str | None = None) -> dict:
    chain = uuid.uuid4().hex[:8]
    return {
        "chain": chain,
        "jobs": [push(kind, label, cmd, episode, chain, f"{i}/{len(steps)}")
                 for i, (kind, label, cmd) in enumerate(steps, 1)],
    }


# Channels
@app.get("/api/channels")
def api_channels():
    return {"channels": channels.list_channels(), "active": channels.active()}


class ChannelNew(BaseModel):
    id: str
    name: str


@app.post("/api/channels")
def api_channel_create(body: ChannelNew):
    try:
        return channels.create(body.id, body.name)
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/channels/{cid}/switch")
def api_channel_switch(cid: str):
    try:
        return channels.switch(cid)
    except ValueError as exc:
        raise HTTPException(404, str(exc))


@app.delete("/api/channels/{cid}")
def api_channel_delete(cid: str, delete_files: bool = False):
    try:
        channels.remove(cid, delete_files)
        return {"ok": True}
    except ValueError as exc:
        raise HTTPException(400, str(exc))


# ══════════════════════════════════════════════════════════════════
#  APP CONFIG — cau hinh TOAN CUC (khong theo kenh): che do nang cao +
#  edition. GOI GON 4.0: an cac module cu (intake/aivideo/...) o tang UI.
#  Luu content/app_config.json canh channel.yaml, o ROOT (repo goc).
# ══════════════════════════════════════════════════════════════════
APP_CONFIG_PATH = os.path.join(channels.ROOT, "content", "app_config.json")
APP_CONFIG_DEFAULT = {"advanced_mode": False, "edition": "internal",
                      "viral_views": 100000, "max_jobs": 5}


def _app_config() -> dict:
    cfg = dict(APP_CONFIG_DEFAULT)
    data = read_json(APP_CONFIG_PATH, {})
    if isinstance(data, dict):
        cfg.update({k: data[k] for k in APP_CONFIG_DEFAULT if k in data})
    return cfg


def _save_app_config(cfg: dict) -> None:
    os.makedirs(os.path.dirname(APP_CONFIG_PATH), exist_ok=True)
    tmp = APP_CONFIG_PATH + f".tmp{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, APP_CONFIG_PATH)


@app.get("/api/config")
def api_config_get():
    return _app_config()


class AppConfigPatch(BaseModel):
    advanced_mode: bool | None = None
    edition: str | None = None
    viral_views: int | None = None
    max_jobs: int | None = None


@app.post("/api/config")
def api_config_set(body: AppConfigPatch):
    cfg = _app_config()
    if body.advanced_mode is not None:
        cfg["advanced_mode"] = bool(body.advanced_mode)
    if body.edition is not None and body.edition in ("internal", "customer"):
        cfg["edition"] = body.edition
    if body.viral_views is not None and body.viral_views > 0:
        cfg["viral_views"] = int(body.viral_views)
    if body.max_jobs is not None:
        # Clamp 1..12 + AP NGAY vao hang doi (khong can restart) -> luu gia tri da clamp.
        cfg["max_jobs"] = queue.set_max_concurrent(body.max_jobs)
    _save_app_config(cfg)
    return cfg


# ══════════════════════════════════════════════════════════════════
#  MUC LUC VIDEO — moi tap cua MOI kenh, nhom theo ngay
#
#  Khac /api/episodes (chi kenh dang mo). Muc luc tra loi cau hoi khac:
#  "tuan nay ra duoc bao nhieu video, o nhung kenh nao?"
#
#  CHI DOC. Khong sua gi cua episode.py hay channels.py.
# ══════════════════════════════════════════════════════════════════
@app.get("/api/library")
def api_library(channel: str = "", days: int = 0):
    import library
    return library.collect(channel, days)


def _channel_root(cid: str) -> str:
    """Thu muc goc cua MOT kenh cu the (khong phai kenh dang mo).

    Muc luc hien video cua moi kenh -> phai phuc vu file tu kenh khac
    kenh dang mo. Chi cho phep ID co trong so dang ky — khong nhan duong dan.
    """
    for ch in channels.list_channels():
        if ch["id"] == cid:
            return ch["path"]
    raise HTTPException(404, "Không có kênh này")


@app.get("/media/ch/{cid}/video/{ep}")
def media_ch_video(cid: str, ep: str):
    try:
        path = ep_lib.video_path(ep, _channel_root(cid))
    except ValueError:
        raise HTTPException(404)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="video/mp4")


@app.get("/media/ch/{cid}/scene/{ep}/{index}")
def media_ch_scene(cid: str, ep: str, index: int):
    try:
        path = ep_lib.scene_path(ep, index, _channel_root(cid))
    except ValueError:
        raise HTTPException(404)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, headers={"Cache-Control": "max-age=300"})


@app.get("/media/ch/{cid}/srt/{ep}")
def media_ch_srt(cid: str, ep: str):
    try:
        ep_lib.validate_episode_id(ep)
    except ValueError:
        raise HTTPException(404)
    path = os.path.join(_channel_root(cid), "publish", ep, f"{ep}.srt")
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="text/plain", filename=f"{ep}.srt")


# ══════════════════════════════════════════════════════════════════
#  SO DU
#
#  Goi TRONG TIEN TRINH, hai API SONG SONG (balance.fetch).
#  Truoc day spawn subprocess -> 3.4 giay: 1 giay khoi dong Python +
#  2 loi goi API tuan tu. Da do that.
#
#  Cache 2 phut. Loi mang -> tra so CU con hon tra 0 (bao dong gia "het tien").
# ══════════════════════════════════════════════════════════════════
_balance = {"data": None, "at": 0.0}
_BALANCE_TTL = 120


def fetch_balance(force: bool = False) -> dict:
    now = time.time()
    if not force and _balance["data"] and now - _balance["at"] < _BALANCE_TTL:
        return _balance["data"]
    try:
        import balance
        credits, chars = balance.fetch()
        data = {"credits": credits, "chars": chars, "ok": True}
        _balance.update(data=data, at=now)
        return data
    except Exception:
        return _balance["data"] or {"credits": 0, "chars": 0, "ok": False}


@app.get("/api/balance")
def api_balance(refresh: bool = False):
    cfg = channel_cfg().get("budget", {})
    bal = fetch_balance(force=refresh)
    return {
        **bal,
        "warn_below_credits": cfg.get("warn_below_credits", 10000),
        "warn_below_chars": cfg.get("warn_below_chars", 10000),
        "credits_per_image": cfg.get("credits_per_image", 600),
        "low_credits": bal["credits"] < cfg.get("warn_below_credits", 10000),
        "low_chars": bal["chars"] < cfg.get("warn_below_chars", 10000),
    }


# Overview and intake
def _voice_label(row: dict, ch_engine: str, ch_eleven: str, active_profile: str | None,
                 prof_names: dict, eleven_names: dict) -> str:
    """Tên giọng SẼ đọc tập này — phân giải TỪ ID lúc đọc (không chụp), nên đổi tên
    giọng/profile là lan toả sang mọi tập cũ. Thứ tự: lựa chọn riêng -> snapshot cũ -> kênh."""
    pick = row.get("voice_pick") or {}
    if pick.get("profile_id"):
        return prof_names.get(pick["profile_id"], pick["profile_id"])
    if pick.get("eleven_voice"):
        return eleven_names.get(pick["eleven_voice"]) or "giọng Eleven"
    if row.get("voice_profile_id"):
        return prof_names.get(row["voice_profile_id"], row["voice_profile_id"])
    if row.get("eleven_voice_id"):
        return eleven_names.get(row["eleven_voice_id"]) or "giọng Eleven"
    if ch_engine == "omnivoice":
        return prof_names.get(active_profile, "giọng kênh") if active_profile else "chưa chọn giọng"
    return eleven_names.get(ch_eleven) or "giọng kênh"


@app.get("/api/overview")
def api_overview():
    cfg = channel_cfg()
    rows = [episode_info(ep) for ep in episodes()]
    counts = {}
    for row in rows:
        counts[row["stage"]] = counts.get(row["stage"], 0) + 1
    report = intake.scan(root())
    active = voice_profiles.active_profile_id(root())
    engine = channel_engine()
    eleven_voice = channel_eleven_voice()
    profiles = voice_profiles.list_profiles(root())

    # Nhan giong cho luoi Xuong. Chi goi catalog() (co the cham) khi THAT SU can
    # ten giong Eleven — nhieu kenh dung Omni thi khoi dung toi.
    prof_names = {p["id"]: p.get("name", p["id"]) for p in profiles}
    needs_eleven = engine == "eleven" or any(
        (r.get("voice_pick") or {}).get("eleven_voice") or r.get("eleven_voice_id") for r in rows)
    eleven_names = {}
    if needs_eleven:
        try:
            import voice_catalog
            eleven_names = {v["id"]: v["name"] for v in voice_catalog.catalog(root())}
        except Exception:
            eleven_names = {}
    for row in rows:
        row["voice_label"] = _voice_label(row, engine, eleven_voice, active,
                                          prof_names, eleven_names)

    # San sang doc loi chua? Moi engine mot dieu kien khac nhau.
    ready = bool(active) if engine == "omnivoice" else bool(
        eleven_voice and os.environ.get("ELEVENLABS_API_KEY", "").strip())

    return {
        "channel": cfg.get("channel", {}).get("name", "?"),
        "episodes": rows,
        "counts": counts,
        # Dem VIDEO, khong dem FILE: mot file co the chua nhieu kich ban.
        "intake_pending": sum(p.get("count", 1) for p in report["pending"]),
        "intake_files": len(report["pending"]),
        "intake_invalid": len(report["invalid"]),
        "engine": engine,
        "eleven_voice_id": eleven_voice,
        "eleven_key": bool(os.environ.get("ELEVENLABS_API_KEY", "").strip()),
        "voice_ready": ready,
        "omnivoice_installed": omnivoice_installed(),
        "voice_profile_ready": bool(active),
        "voice_profile_active": active,
        "profiles": profiles,
    }


class VoiceSetup(BaseModel):
    engine: str | None = None
    eleven_voice_id: str | None = None


@app.put("/api/voice-setup")
def api_voice_setup(body: VoiceSetup):
    """Dat engine + giong ElevenLabs mac dinh cho kenh."""
    import tempfile

    import yaml
    if body.engine and body.engine not in ENGINES:
        raise HTTPException(400, f"Engine khong hop le: {body.engine}")

    path = P("content", "channel.yaml")
    cfg = channel_cfg()
    voice = cfg.setdefault("voice", {})
    if body.engine:
        voice["engine"] = body.engine
    if body.eleven_voice_id is not None:
        voice["eleven_voice_id"] = body.eleven_voice_id.strip()

    fd, tmp = tempfile.mkstemp(prefix=".channel-", suffix=".yaml",
                               dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False, width=100)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return {"engine": channel_engine(), "eleven_voice_id": channel_eleven_voice()}


@app.get("/api/intake")
def api_intake():
    report = intake.scan(root())
    report["intake_dir"] = intake.intake_dir(root())
    report["processed_dir"] = intake.processed_dir(root())
    report["failed_dir"] = intake.failed_dir(root())

    # File da nhap. Khong co danh sach nay, nguoi dung thay luoi "cho nhap"
    # rong sau khi import va tuong file bi mat — thuc ra no da chuyen sang
    # processed/ va thanh mot (hoac nhieu) tap.
    #
    # Ten file: "ep012--x.json" (1 tap) hoac "ep012-ep014--x.json" (nhieu tap).
    done = []
    folder = intake.processed_dir(root())
    if os.path.isdir(folder):
        for name in sorted(os.listdir(folder), reverse=True):
            if not name.endswith(".json") or "--" not in name:
                continue
            tag, _, source = name.partition("--")
            first, _, last = tag.partition("-")
            if not ep_lib.EPISODE_RE.fullmatch(first):
                continue
            span = [first]
            if last and ep_lib.EPISODE_RE.fullmatch(last):
                span = [f"ep{n:03d}" for n in range(int(first[2:]), int(last[2:]) + 1)]
            for ep in span:
                script = ep_lib.load_script(ep, root())
                # Tap da xoa -> BO KHOI LUOI luon.
                #
                # Truoc day van hien voi chu "da xoa". Nhung nguoi dung xoa tap
                # la de no BIEN MAT — de lai mot dong xam vo dung chi lam roi mat.
                # File goc van con trong intake/processed/, khong mat gi.
                if not script:
                    continue
                done.append({
                    "episode": ep,
                    "source_file": source,
                    "title": script.get("title", ""),
                    "exists": True,
                })
    report["processed"] = done[:20]
    return report


@app.post("/api/intake/upload")
async def api_intake_upload(files: list[UploadFile] = File(...)):
    """Nhan JSON tu trinh duyet, ghi vao intake/ cua kenh dang hoat dong.

    basename() + kiem duoi .json: ten file do nguoi dung dat, khong duoc phep
    thoat khoi intake/ bang '../' hay duong dan tuyet doi.
    """
    target = intake.intake_dir(root())
    os.makedirs(target, exist_ok=True)
    saved, rejected = [], []
    for upload in files:
        name = os.path.basename(upload.filename or "")
        if not name.lower().endswith(".json"):
            rejected.append({"name": name or "?", "error": "Chỉ nhận file .json"})
            continue
        raw = await upload.read()
        try:
            json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            rejected.append({"name": name, "error": f"JSON lỗi: {exc}"})
            continue
        path = os.path.join(target, name)
        if os.path.exists(path):
            stem, ext = os.path.splitext(name)
            name = f"{stem}-{uuid.uuid4().hex[:6]}{ext}"
            path = os.path.join(target, name)
        with open(path, "wb") as f:
            f.write(raw)
        saved.append(name)
    return {"saved": saved, "rejected": rejected}


class IntakeFiles(BaseModel):
    names: list[str]


@app.post("/api/intake/delete")
def api_intake_delete(body: IntakeFiles):
    target = intake.intake_dir(root())
    removed = []
    for raw_name in body.names:
        name = os.path.basename(raw_name)
        path = os.path.join(target, name)
        if os.path.isfile(path) and name.lower().endswith(".json"):
            os.remove(path)
            removed.append(name)
    return {"removed": removed}


@app.post("/api/intake/import")
def api_intake_import():
    report = intake.scan(root())
    if not report["pending"]:
        raise HTTPException(400, "Không có JSON hợp lệ nào trong intake/")

    # Giong phai san sang truoc khi tao tap — nhung theo ENGINE dang dung,
    # khong luon doi OmniVoice. intake._voice_state() la nguon su that duy nhat,
    # dung chung voi lenh nhap that -> khong the lech nhau.
    try:
        intake._voice_state(root())
    except ValueError as exc:
        raise HTTPException(400, str(exc))

    videos = sum(p.get("count", 1) for p in report["pending"])
    return push("nhap-kich-ban",
                f"Nhập {videos} video từ {len(report['pending'])} file",
                ["pipeline/intake.py", "--import-all"])


# Episodes
@app.get("/api/episodes")
def api_episodes():
    return {"episodes": [episode_info(ep) for ep in episodes()]}


@app.get("/api/episodes/{ep}")
def api_episode(ep: str):
    script = require_episode(ep)
    timing = read_json(ep_lib.timing_path(ep, root()), {})
    detail = []
    for index, beat in enumerate(script.get("beats", []), 1):
        image_idx = ep_lib.image_index(beat, index)
        marker = next((item for item in timing.get("beats", []) if item.get("index") == index), {})
        detail.append({
            "index": index, "image_idx": image_idx,
            "caption": beat.get("caption", ""), "voice": beat.get("voice", ""),
            "scene_prompt": beat.get("scene_prompt", ""),
            "has_image": os.path.isfile(ep_lib.scene_path(ep, image_idx, root())),
            "start": marker.get("start"), "end": marker.get("end"),
        })
    return {**episode_info(ep), "beats_detail": detail,
            "duration": timing.get("total_duration"), "timing": timing}


@app.post("/api/episodes/{ep}/art")
def api_art(ep: str):
    # Kiem giong TRUOC khi tieu credit ve tranh — theo ENGINE cua tap,
    # khong luon doi OmniVoice. Ban phat hanh nhe khong kem OmniVoice.
    script = require_episode(ep)
    narrate_command(ep, script)
    return push("ve-tranh", f"Vẽ tranh {ep}", ["pipeline/generate_scenes.py", "--episode", ep], ep)


class SceneRedraw(BaseModel):
    prompt: str | None = None


@app.post("/api/episodes/{ep}/scenes/{index}/redraw")
def api_redraw(ep: str, index: int, body: SceneRedraw):
    script = require_episode(ep)
    narrate_command(ep, script)
    if index < 1 or index > ep_lib.images_needed(script):
        raise HTTPException(400, "Canh khong ton tai")
    command = ["pipeline/generate_scenes.py", "--episode", ep, "--only", str(index)]
    if body.prompt and body.prompt.strip():
        command += ["--prompt", body.prompt.strip()]
    return push("ve-lai", f"Vẽ lại cảnh {index} của {ep}", command, ep)


@app.post("/api/episodes/{ep}/storyboard")
def api_storyboard(ep: str):
    require_episode(ep)
    return push("storyboard", f"Ghép storyboard {ep}", ["pipeline/build_storyboard.py", "--episode", ep], ep)


class Narrate(BaseModel):
    engine: str | None = None          # omnivoice | eleven. None = theo kenh/kich ban
    profile_id: str | None = None      # OmniVoice
    eleven_voice: str | None = None    # ElevenLabs


ENGINE_NAME = {"omnivoice": "OmniVoice", "eleven": "ElevenLabs"}


def _finish_steps(ep: str, engine: str, narrate_cmd: list) -> list:
    return [
        ("doc-loi", f"Đọc lời {ep} ({ENGINE_NAME[engine]})", narrate_cmd),
        ("ghep-video", f"Ghép video {ep}", ["pipeline/compose_video.py", "--episode", ep]),
        ("phu-de", f"Xuất phụ đề {ep}", ["pipeline/export_srt.py", "--episode", ep]),
        ("kiem-tra-audio", f"Kiểm tra audio {ep}", ["pipeline/check_audio.py", "--episode", ep]),
    ]


@app.post("/api/episodes/{ep}/narrate")
def api_narrate(ep: str, body: Narrate):
    script = require_episode(ep)
    engine, cmd = narrate_command(ep, script, body.engine, body.profile_id, body.eleven_voice)
    out = push_chain(_finish_steps(ep, engine, cmd), ep)
    out["engine"] = engine
    if engine == "eleven":
        out["chars"] = episode_chars(script)
    return out


@app.post("/api/episodes/{ep}/finish")
def api_finish(ep: str, body: Narrate | None = None):
    script = require_episode(ep)
    body = body or Narrate()
    engine, cmd = narrate_command(ep, script, body.engine, body.profile_id, body.eleven_voice)
    out = push_chain(_finish_steps(ep, engine, cmd), ep)
    out["engine"] = engine
    if engine == "eleven":
        out["chars"] = episode_chars(script)
    return out


class Bulk(BaseModel):
    episodes: list[str]
    engine: str | None = None
    profile_id: str | None = None
    eleven_voice: str | None = None


@app.post("/api/episodes/bulk/art")
def api_bulk_art(body: Bulk):
    """Ve tranh cho nhieu tap. Kiem TAT CA truoc khi xep bat ky viec nao —
    mot tap hong khong duoc phep de cac tap khac da tieu credit."""
    plans = []
    for ep in body.episodes:
        script = require_episode(ep)
        narrate_command(ep, script)      # giong san sang chua? fail truoc khi tieu credit
        plans.append((ep, ep_lib.images_needed(script)))
    jobs_out = [push("ve-tranh", f"Vẽ tranh {ep}",
                     ["pipeline/generate_scenes.py", "--episode", ep], ep)
                for ep, _ in plans]
    per = channel_cfg().get("budget", {}).get("credits_per_image", 600)
    return {"queued": len(jobs_out), "jobs": jobs_out,
            "images": sum(n for _, n in plans),
            "credits": sum(n for _, n in plans) * per}


@app.post("/api/episodes/bulk/finish")
def api_bulk_finish(body: Bulk):
    # Kiem TAT CA truoc. Mot tap thieu giong -> khong tap nao duoc chay,
    # de khong tieu ky tu ElevenLabs roi moi bao loi giua chung.
    plans, chars = [], 0
    for ep in body.episodes:
        script = require_episode(ep)
        engine, cmd = narrate_command(ep, script, body.engine, body.profile_id,
                                      body.eleven_voice)
        if engine == "eleven":
            chars += episode_chars(script)
        plans.append((ep, engine, cmd))

    chains = [push_chain(_finish_steps(ep, engine, cmd), ep)
              for ep, engine, cmd in plans]
    return {"queued": len(chains), "chains": chains, "chars": chars}


@app.get("/api/episodes/{ep}/cost")
def api_episode_cost(ep: str):
    """Bao truoc chi phi TRUOC khi bam. Khong de nguoi dung bat ngo het tien."""
    script = require_episode(ep)
    engine = channel_engine()          # theo kenh, khong theo snapshot tap
    per = channel_cfg().get("budget", {}).get("credits_per_image", 600)
    images = ep_lib.images_needed(script)
    done = ep_lib.images_done(ep, root())
    return {
        "engine": engine,
        "images_total": images,
        "images_done": min(done, images),
        "credits_to_draw": max(0, images - min(done, images)) * per,
        "chars": episode_chars(script) if engine == "eleven" else 0,
    }


@app.post("/api/episodes/bulk/delete")
def api_bulk_delete(body: Bulk):
    import shutil
    removed = []
    for ep in body.episodes:
        require_episode(ep)
        for path in (ep_lib.script_path(ep, root()), ep_lib.video_path(ep, root()),
                     P("storyboard", f"{ep}_storyboard.png")):
            if os.path.isfile(path):
                os.remove(path)
        for folder in (ep_lib.scenes_dir(ep, root()), ep_lib.voice_dir(ep, root()),
                       P("publish", ep)):
            if os.path.isdir(folder):
                shutil.rmtree(folder, ignore_errors=True)
        removed.append(ep)
    return {"removed": removed}


class SavePrompt(BaseModel):
    index: int
    scene_prompt: str


def _save_script(ep: str, script: dict) -> None:
    """Ghi script atomic — crash giua chung khong lam hong file."""
    import tempfile
    path = ep_lib.script_path(ep, root())
    fd, tmp = tempfile.mkstemp(prefix=".script-", suffix=".json", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(script, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


@app.patch("/api/episodes/{ep}/prompt")
def api_save_prompt(ep: str, body: SavePrompt):
    script = require_episode(ep)
    if not 1 <= body.index <= len(script.get("beats", [])):
        raise HTTPException(400, "Canh khong ton tai")
    script["beats"][body.index - 1]["scene_prompt"] = body.scene_prompt.strip()
    _save_script(ep, script)
    return {"ok": True}


class VoicePick(BaseModel):
    engine: str | None = None
    eleven_voice: str | None = None
    profile_id: str | None = None


@app.patch("/api/episodes/{ep}/voice")
def api_set_voice(ep: str, body: VoicePick):
    """Luu lua chon giong RIENG cho tap — chon TRUOC khi san xuat, ngay tren luoi.

    Lua chon CO CHU DICH nay thang engine kenh. Snapshot tu dong luc nhap thi
    khong (do la nguyen nhan bug 'chon Eleven ma ra Omni'). Bo chon = ve giong kenh.
    """
    script = require_episode(ep)
    if body.engine and body.engine not in ENGINES:
        raise HTTPException(400, "Engine không hợp lệ")
    pick = {}
    if body.engine:
        pick["engine"] = body.engine
    if body.eleven_voice:
        pick["eleven_voice"] = body.eleven_voice
    if body.profile_id:
        pick["profile_id"] = body.profile_id
    if pick:
        script["voice_pick"] = pick
    else:
        script.pop("voice_pick", None)
    _save_script(ep, script)
    return {"ok": True, "voice_pick": script.get("voice_pick")}


# Voice Lab
class ElevenPreview(BaseModel):
    voice_id: str
    text: str
    model: str = "eleven_v3"
    stability: float = 0.35
    style: float = 0.45
    speed: float = 0.95
    name: str = ""          # ten giong nguon (tu roster) -> giu dau vet trong draft


class OmniPreview(BaseModel):
    # None = lay tu pipeline/config.yaml. Nghe thu PHAI dung cung bo so voi
    # luc doc video that, neu khong ban nghe thu khong noi len dieu gi.
    draft_id: str
    step: int | None = None
    guidance: float | None = None
    threads: int | None = None


class ProfileSave(BaseModel):
    draft_id: str
    id: str
    name: str
    rights_confirmed: bool = False
    activate: bool = False


@app.get("/api/voice-lab/eleven-voices")
def api_eleven_voices(
    q: str = "",
    gender: str = "",
    use_case: str = "",
    deep_only: bool = False,
    show_hidden: bool = False,
    limit: int = 60,
    refresh: bool = False,
):
    """Kho giong: thu vien rieng + 600 giong Viet cong khai.

    Giong cong khai DUNG THANG DUOC — da kiem, khong can 'add to my voices'.
    Xep giong nam tram ke chuyen len truoc (xem voice_catalog.score).
    Giong da AN bi loai khoi luoi tru khi show_hidden=true (de xem/hien lai).
    """
    import voice_catalog
    try:
        rows = voice_catalog.catalog(root(), force=refresh)
    except Exception as exc:
        raise HTTPException(503, f"Không lấy được kho giọng: {exc}")

    needle = q.strip().lower()
    out = [
        v for v in rows
        if (not needle or needle in v["name"].lower())
        and (not gender or v["gender"] == gender)
        and (not use_case or v["use_case"] == use_case)
        and (not deep_only or v["deep"])
        # An khoi luoi tru khi nguoi dung bam "xem giong da an".
        and (show_hidden or not v.get("hidden"))
    ]
    return {
        "voices": out[:limit],
        "total": len(rows),
        "matched": len(out),
        "measured": sum(1 for v in rows if v.get("pitch_hz")),
        "hidden": sum(1 for v in rows if v.get("hidden")),
        "active": channel_eleven_voice(),
    }


class HideVoices(BaseModel):
    voice_ids: list[str]


@app.post("/api/voice-lab/hide")
def api_hide_voices(body: HideVoices):
    """An giong khoi luoi (giau bot cho do loan). Giu ban do — hien lai duoc."""
    import voice_catalog
    n = voice_catalog.hide(body.voice_ids, root())
    return {"hidden": n}


@app.post("/api/voice-lab/unhide")
def api_unhide_voices(body: HideVoices):
    """Bo an — hien lai giong tren luoi."""
    import voice_catalog
    n = voice_catalog.unhide(body.voice_ids, root())
    return {"hidden": n}


@app.get("/api/voices/roster")
def api_roster():
    """ROSTER — cổng DUY NHẤT giọng đang dùng, CẢ 2 engine. Thay '/voice-lab/measured'
    (cũ: giọng đã đo). Mọi nơi chọn giọng (modal sản xuất, Voice Lab) đọc từ đây.

    Chỉ liệt kê (miễn phí), không đọc/tính tiền. Bền offline: profile luôn có,
    giọng Eleven fallback tên alias nếu catalog lỗi. Xem docs/roster-giong-dung.md.
    """
    import voice_roster
    return {"voices": voice_roster.roster(root()),
            "engine": channel_engine(),
            "eleven_voice": channel_eleven_voice(),
            "active_profile": voice_profiles.active_profile_id(root())}


class RosterSave(BaseModel):
    refs: list[str]


@app.post("/api/voices/roster")
def api_roster_save(body: RosterSave):
    """Lưu tick — thay TOÀN BỘ roster. Chống kẹt: nếu bỏ tick HẾT (rỗng) thì tự giữ
    lại giọng mặc định kênh để dropdown không trống. Còn giọng khác thì cho bỏ tick
    thoải mái — kể cả giọng đang là mặc định (nó vẫn chạy khi chọn 'giọng mặc định kênh')."""
    import voice_roster
    refs = list(body.refs or [])
    # CHI khi rong moi giu giong mac dinh — khong ep khi da co giong khac.
    if not refs:
        engine = channel_engine()
        if engine == "omnivoice":
            active = voice_profiles.active_profile_id(root())
            must = f"profile:{active}" if active else None
        else:
            voice = channel_eleven_voice()
            must = f"eleven:{voice}" if voice else None
        if must and voice_roster.valid_ref(must):
            refs.append(must)
    saved = voice_roster.save_refs(refs, root())
    return {"ok": True, "count": len(saved), "voices": voice_roster.roster(root())}


class RenameVoice(BaseModel):
    voice_id: str
    name: str = ""


@app.post("/api/voice-catalog/rename")
def api_rename_voice(body: RenameVoice):
    """Đổi tên riêng cho 1 giọng Eleven (tên gốc 'nói dối'). name rỗng = về tên gốc.
    Lan toả mọi nơi vì catalog() áp alias tại một chỗ."""
    import voice_catalog
    try:
        voice_catalog.set_alias(body.voice_id, body.name, root())
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True}


class RenameProfile(BaseModel):
    name: str


@app.post("/api/voice-profiles/{profile_id}/rename")
def api_rename_profile(profile_id: str, body: RenameProfile):
    try:
        p = voice_profiles.rename(profile_id, body.name, root())
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "name": p["name"]}


class ProbeVoice(BaseModel):
    voice_id: str
    force: bool = False       # doc LAI du da co ban do (khi doi doan nghe thu)


@app.delete("/api/voice-lab/probe/{voice_id}")
def api_probe_forget(voice_id: str):
    """Xoa ban do cua mot giong. Do lai se goi API lai (ton ky tu)."""
    import voice_catalog
    if not re.fullmatch(r"[A-Za-z0-9]{10,40}", voice_id):
        raise HTTPException(400, "ID giọng không hợp lệ")
    voice_catalog.forget(voice_id, root())
    return {"ok": True}


class ProbeIds(BaseModel):
    voice_ids: list[str]


@app.post("/api/voice-lab/probe/forget-bulk")
def api_probe_forget_bulk(body: ProbeIds):
    """Xoa NHIEU ban do mot luot."""
    import voice_catalog
    n = 0
    for vid in dict.fromkeys(body.voice_ids):
        if re.fullmatch(r"[A-Za-z0-9]{10,40}", vid):
            voice_catalog.forget(vid, root())
            n += 1
    return {"removed": n}


@app.post("/api/voice-lab/probe")
def api_probe_voice(body: ProbeVoice):
    """Do cao do THAT cua mot giong, va giu lai ban do lam FILE MAU.

    Vi sao phai do: ten giong noi doi. 'David - Deep, Warm' (105k nguoi dung)
    do duoc 143 Hz — nam trung, khong tram. Con giong khong co chu 'deep' nao
    do duoc 80 Hz. Chi co so do that moi tin duoc.

    Ban do dai ~10 giay -> dung LUON lam reference OmniVoice, khong phai tao lai.
    """
    import voice_catalog
    try:
        return voice_catalog.probe(body.voice_id, root(), force=body.force)
    except Exception as exc:
        raise HTTPException(502, str(exc))


class ProbeBulk(BaseModel):
    voice_ids: list[str]
    force: bool = False       # doc LAI ca giong da co ban do


def _probe_state(text: str) -> dict:
    import voice_catalog
    return {
        "text": text,
        "chars": len(text),
        "min_chars": voice_catalog.PROBE_MIN_CHARS,
        # Du dai thi ban do dung LUON lam mau nhan ban OmniVoice.
        "usable_as_reference": len(text) >= voice_catalog.PROBE_MIN_CHARS,
        # Bao nhieu ban do dang doc doan CU -> nghe lai de so sanh la vo nghia.
        "stale": len(voice_catalog.stale_ids(root())),
    }


@app.get("/api/voice-lab/probe-text")
def api_probe_text_get():
    """Doan nghe thu cua kenh. Rong = nguoi dung chua nhap."""
    import voice_catalog
    return _probe_state(voice_catalog.probe_text(root()))


class ProbeText(BaseModel):
    text: str


@app.put("/api/voice-lab/probe-text")
def api_probe_text_set(body: ProbeText):
    """Luu doan nghe thu. Go xong la lu — lan sau mo len van con."""
    import voice_catalog
    return _probe_state(voice_catalog.save_probe_text(body.text, root()))


@app.post("/api/voice-lab/probe-bulk")
def api_probe_bulk(body: ProbeBulk):
    """Do NHIEU giong mot luot. Bao truoc TONG chi phi.

    force=False -> bo qua giong da do (khong ton ky tu lai)
    force=True  -> doc LAI tat ca. Can khi doi doan nghe thu: ban do cu doc
                   doan cu, de canh nhau khong so sanh duoc.
    """
    import voice_catalog

    # Chan SOM: chua nhap doan nghe thu thi khong xep viec nao het.
    text = voice_catalog.probe_text(root())
    if not text:
        raise HTTPException(400,
            "Chưa có đoạn nghe thử. Gõ một đoạn văn vào ô 'Đoạn nghe thử' trước.")

    done = voice_catalog.load_pitches(root())
    todo = [v for v in dict.fromkeys(body.voice_ids)      # bo trung, giu thu tu
            if re.fullmatch(r"[A-Za-z0-9]{10,40}", v)
            and (body.force or v not in done)]
    if not todo:
        raise HTTPException(400,
            "Tất cả giọng đã chọn đều đã đo rồi. Muốn đọc lại bằng đoạn mới "
            "thì bấm 'Đọc lại'.")

    # Ten giong trong nhan job — de nguoi dung theo doi duoc cai nao dang chay.
    names = {v["id"]: v["name"] for v in voice_catalog.catalog(root())}
    verb = "Đọc lại" if body.force else "Đo"
    cmd_extra = ["--force"] if body.force else []
    jobs_out = [
        push("do-giong",
             f"{verb} {i}/{len(todo)}: {names.get(vid, vid)[:32]}",
             ["pipeline/voice_catalog.py", "--voice", vid] + cmd_extra)
        for i, vid in enumerate(todo, 1)
    ]
    return {
        "queued": len(jobs_out),
        "skipped": len(body.voice_ids) - len(todo),
        "chars": len(todo) * len(text),
        "jobs": jobs_out,
    }


@app.get("/media/voice-probe/{voice_id}")
def media_voice_probe(voice_id: str):
    """Ban do cao do — nghe thu giong truoc khi chon."""
    import voice_catalog
    if not re.fullmatch(r"[A-Za-z0-9]{10,40}", voice_id):
        raise HTTPException(404)
    path = voice_catalog.pitch_path(voice_id, root())
    if not os.path.isfile(path):
        raise HTTPException(404, "Chưa đo giọng này")
    # no-cache: doc lai bang doan moi thi file bi ghi de. Neu de trinh duyet
    # cache, bam nghe lai van ra file cu -> tuong nhu tool bo qua doan moi.
    return FileResponse(path, media_type="audio/mpeg",
                        headers={"Cache-Control": "no-cache"})


@app.post("/api/voice-lab/eleven-preview")
def api_eleven_preview(body: ElevenPreview):
    draft_id = uuid.uuid4().hex
    try:
        voice_lab.create_draft(draft_id, body.text, body.voice_id, model=body.model,
                               stability=body.stability, style=body.style, speed=body.speed,
                               root=root(), name=body.name)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    job = push("eleven-preview", "Tạo sample ElevenLabs",
               ["pipeline/voice_lab.py", "eleven-preview", "--draft", draft_id])
    return {"draft_id": draft_id, "job": job}


@app.post("/api/voice-lab/omnivoice-preview")
def api_omnivoice_preview(body: OmniPreview):
    try:
        voice_lab.load_draft(body.draft_id, root())
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        raise HTTPException(404, str(exc))
    # Khong truyen --step/--guidance -> voice_lab.py lay tu config.yaml,
    # cung bo so voi luc doc video that.
    cmd = ["pipeline/voice_lab.py", "omnivoice-preview", "--draft", body.draft_id]
    if body.step is not None:
        cmd += ["--step", str(body.step)]
    if body.guidance is not None:
        cmd += ["--guidance", str(body.guidance)]
    if body.threads is not None:
        cmd += ["--threads", str(body.threads)]
    job = push("omnivoice-preview", "Nhân bản giọng bằng OmniVoice (chậm)", cmd)
    return {"draft_id": body.draft_id, "job": job}


@app.get("/api/voice-lab/samples")
def api_voice_samples():
    """Moi mau nghe duoc: draft Voice Lab + ban do cao do + file tu tai len."""
    return {"samples": voice_lab.list_samples(root())}


VIDEO_EXT = (".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v")


def _uniq_path(target: str, name: str) -> tuple[str, str]:
    """Ten khong dung -> them hau to ngau nhien de khong de len file cu."""
    path = os.path.join(target, name)
    if os.path.exists(path):
        stem, ext = os.path.splitext(name)
        name = f"{stem}-{uuid.uuid4().hex[:6]}{ext}"
        path = os.path.join(target, name)
    return name, path


@app.post("/api/voice-lab/samples/upload")
async def api_sample_upload(files: list[UploadFile] = File(...)):
    """Tai file giong CUA BAN len lam mau. Khong goi ElevenLabs, khong ton ky tu.
    Nhan ca AUDIO (.mp3 .wav ...) lan VIDEO (.mp4 .mov ...) — video thi tach tieng
    bang ffmpeg thanh .wav roi luu."""
    import subprocess
    import tempfile

    target = voice_lab.samples_dir(root())
    saved, rejected = [], []
    for upload in files:
        name = os.path.basename(upload.filename or "")
        low = name.lower()
        is_audio = low.endswith(voice_lab.AUDIO_EXT)
        is_video = low.endswith(VIDEO_EXT)
        if not (is_audio or is_video):
            rejected.append({"name": name or "?",
                             "error": "Chỉ nhận audio (.mp3 .wav .m4a .ogg .flac) hoặc video (.mp4 .mov .mkv .webm)"})
            continue
        raw = await upload.read()
        if len(raw) > 200 * 1024 * 1024:       # video co the nang hon audio
            rejected.append({"name": name, "error": "File quá 200 MB"})
            continue

        if is_audio:
            out_name, path = _uniq_path(target, name)
            with open(path, "wb") as f:
                f.write(raw)
            saved.append(out_name)
            continue

        # Video -> tach tieng thanh wav mono 44.1kHz (librosa doc de do cao do).
        stem = os.path.splitext(name)[0] or uuid.uuid4().hex[:6]
        out_name, path = _uniq_path(target, f"{stem}.wav")
        fd, tmp = tempfile.mkstemp(suffix=os.path.splitext(name)[1] or ".mp4")
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(raw)
            proc = subprocess.run(
                ["ffmpeg", "-y", "-v", "error", "-i", tmp,
                 "-vn", "-ac", "1", "-ar", "44100", path],
                capture_output=True, text=True)
            if proc.returncode != 0 or not os.path.isfile(path):
                rejected.append({"name": name,
                                 "error": "Không tách được tiếng từ video (cần ffmpeg)"})
                continue
            saved.append(out_name)
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
    return {"saved": saved, "rejected": rejected}


class UseSample(BaseModel):
    kind: str
    id: str
    name: str = ""          # ten mau (tu list) -> giu dau vet trong draft


@app.post("/api/voice-lab/samples/use")
def api_sample_use(body: UseSample):
    """Dung mau CO SAN lam reference — khong goi ElevenLabs, KHONG ton ky tu."""
    draft_id = uuid.uuid4().hex
    try:
        voice_lab.draft_from_sample(draft_id, body.kind, body.id, root(), name=body.name)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"draft_id": draft_id}


def _delete_sample(kind: str, ident: str) -> None:
    """Xoa mot mau. Moi loai xoa mot kieu:

      upload — xoa file cua nguoi dung
      probe  — xoa ban do (va so lieu cao do) cua giong do
      draft  — xoa ca thu muc ban nhap
    """
    import shutil

    if kind == "probe":
        import voice_catalog
        voice_catalog.forget(ident, root())
        return

    if kind == "draft":
        path = voice_lab.draft_dir(ident, root())      # tu validate ID
        shutil.rmtree(path, ignore_errors=True)
        return

    if kind == "upload":
        path = voice_lab.sample_path(kind, ident, root())
        if os.path.isfile(path):
            os.remove(path)
        return

    raise ValueError("Loại mẫu không hợp lệ")


@app.delete("/api/voice-lab/samples/{kind}/{ident}")
def api_sample_delete(kind: str, ident: str):
    try:
        _delete_sample(kind, ident)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True}


class SampleIds(BaseModel):
    items: list[dict]        # [{kind, id}, ...]


@app.post("/api/voice-lab/samples/delete-bulk")
def api_sample_delete_bulk(body: SampleIds):
    removed, failed = 0, []
    for it in body.items:
        try:
            _delete_sample(str(it.get("kind", "")), str(it.get("id", "")))
            removed += 1
        except (ValueError, OSError) as exc:
            failed.append({"id": it.get("id"), "error": str(exc)[:60]})
    return {"removed": removed, "failed": failed}


@app.get("/media/voice-sample/{kind}/{ident}")
def media_voice_sample(kind: str, ident: str):
    try:
        path = voice_lab.sample_path(kind, ident, root())
    except ValueError:
        raise HTTPException(404)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="audio/mpeg")


@app.get("/api/voice-profiles")
def api_voice_profiles():
    return {"profiles": voice_profiles.list_profiles(root()),
            "active_profile_id": voice_profiles.active_profile_id(root())}


@app.post("/api/voice-profiles")
def api_voice_profiles_create(body: ProfileSave):
    try:
        return voice_lab.save_profile(body.draft_id, body.id, body.name,
                                      rights_confirmed=body.rights_confirmed,
                                      activate=body.activate, root=root())
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/voice-profiles/{profile_id}/activate")
def api_voice_profile_activate(profile_id: str):
    try:
        return voice_profiles.activate(profile_id, root())
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@app.delete("/api/voice-profiles/{profile_id}")
def api_voice_profile_delete(profile_id: str):
    try:
        voice_profiles.delete(profile_id, root())
        return {"ok": True}
    except ValueError as exc:
        raise HTTPException(400, str(exc))


# Media: fixed resource IDs only
@app.get("/media/scene/{ep}/{index}")
def media_scene(ep: str, index: int):
    try:
        path = ep_lib.scene_path(ep, index, root())
    except ValueError:
        raise HTTPException(404)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, headers={"Cache-Control": "no-cache"})


@app.get("/media/video/{ep}")
def media_video(ep: str):
    try:
        path = ep_lib.video_path(ep, root())
    except ValueError:
        raise HTTPException(404)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="video/mp4")


@app.get("/media/audio/{ep}")
def media_audio(ep: str):
    try:
        path = os.path.join(ep_lib.voice_dir(ep, root()), "narration.mp3")
    except ValueError:
        raise HTTPException(404)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="audio/mpeg")


@app.get("/media/storyboard/{ep}")
def media_storyboard(ep: str):
    try:
        ep_lib.validate_episode_id(ep)
    except ValueError:
        raise HTTPException(404)
    path = P("storyboard", f"{ep}_storyboard.png")
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, headers={"Cache-Control": "no-cache"})


@app.get("/media/srt/{ep}")
def media_srt(ep: str):
    try:
        ep_lib.validate_episode_id(ep)
    except ValueError:
        raise HTTPException(404)
    path = P("publish", ep, f"{ep}.srt")
    if not os.path.isfile(path):
        raise HTTPException(404, "Chưa có phụ đề. Chạy hoàn tất trước.")
    return FileResponse(path, media_type="text/plain",
                        filename=f"{ep}.srt")


@app.get("/media/voice-profiles/{profile_id}/{artifact}")
def media_voice_profile(profile_id: str, artifact: str):
    try:
        if artifact == "reference":
            path = voice_profiles.reference_path(profile_id, root())
        elif artifact == "preview":
            path = voice_profiles.preview_path(profile_id, root())
        else:
            raise ValueError("artifact")
    except ValueError:
        raise HTTPException(404)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="audio/mpeg")


@app.get("/media/voice-lab/{draft_id}/{artifact}")
def media_voice_lab(draft_id: str, artifact: str):
    try:
        path = voice_lab.audio_path(draft_id, artifact, root())
    except ValueError:
        raise HTTPException(404)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="audio/mpeg")


# Jobs/SSE
@app.get("/api/jobs")
def api_jobs():
    return queue.snapshot()


@app.delete("/api/jobs/{jid}")
def api_job_cancel(jid: int):
    return {"ok": queue.cancel(jid)}


@app.post("/api/jobs/clear")
def api_jobs_clear():
    queue.clear_finished()
    return {"ok": True}


@app.get("/api/stream")
async def api_stream(request: Request):
    listener = queue.subscribe()

    async def events():
        try:
            yield f"data: {json.dumps({'type': 'hello', **queue.snapshot()})}\n\n"
            while not await request.is_disconnected():
                try:
                    event = await asyncio.wait_for(listener.get(), timeout=20)
                    yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    yield ": ping\n\n"
        finally:
            queue.unsubscribe(listener)

    return StreamingResponse(events(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ══════════════════════════════════════════════════════════════════
#  TAO ANH DANG FACEBOOK  (tab "Tao anh")
#
#  Khac video: KHONG intake, KHONG hang doi. Nguoi dung dien y tuong + chu,
#  chon model/mode/do phan giai (do tu 79ai) -> 79ai ve tranh -> PIL ghep chu
#  tieng Viet len tren. Dong bo: anh banana_pro ve nhanh (~10-30s).
#
#  Danh sach model do tu API (khong hardcode) — 79ai bat/tat model lien tuc.
# ══════════════════════════════════════════════════════════════════
_img_models = {"data": None, "at": 0.0}
_IMG_MODELS_TTL = 300


def _image_models(force: bool = False) -> list:
    now = time.time()
    if not force and _img_models["data"] and now - _img_models["at"] < _IMG_MODELS_TTL:
        return _img_models["data"]
    from gommo_client import GommoClient
    data = GommoClient().image_models()
    _img_models.update(data=data, at=now)
    return data


def _price_of(row: dict, mode: str | None, resolution: str | None):
    """Gia that theo (mode, resolution); khong khop thi lay gia goc."""
    for p in row.get("prices") or []:
        if p.get("mode") == mode and p.get("resolution") == resolution:
            return p.get("price")
    return row.get("price")


@app.get("/api/image-post/models")
def api_image_post_models(refresh: bool = False):
    try:
        models = _image_models(force=refresh)
    except Exception as exc:
        raise HTTPException(503, f"Không lấy được danh sách model 79AI: {exc}")
    return {
        "models": models,
        "platforms": image_post.platform_options(),   # Nền tảng: FB/TikTok/YouTube
        "purposes": image_post.purpose_options(),      # Mục đích: đại diện/bìa/bài đăng/story
        "sizes": {k: list(v) for k, v in image_post.SIZES.items()},   # key -> [w,h] (hiện px)
        # Mặc định: banana_pro mode vip 1k = 600cr (rẻ + ổn, khớp pipeline auto).
        "default": {"model": "google_image_gen_banana_pro", "mode": "vip", "resolution": "1k",
                    "platform": image_post.DEFAULT_PLATFORM, "purpose": image_post.DEFAULT_PURPOSE},
        "styles": image_post.style_options(),
    }


@app.get("/api/image-post/list")
def api_image_post_list():
    d = P("images")
    if not os.path.isdir(d):
        return {"images": []}
    names = sorted((n for n in os.listdir(d) if re.fullmatch(r"post_\d+\.png", n)),
                   reverse=True)
    return {"images": [{"name": n, "url": f"/media/imagepost/{n}"} for n in names]}


class ImagePost(BaseModel):
    idea: str = ""                               # ý tưởng; RỖNG khi có ảnh mẫu → AI tự phân tích
    text: str = ""                               # thơ -> CHI ghi len; RỖNG = ảnh không chữ (đại diện)
    style: str = image_post.DEFAULT_STYLE        # loại ảnh: hoạt hình / ảnh thật / anime ...
    model: str = "google_image_gen_banana_pro"
    mode: str | None = None
    resolution: str | None = None
    platform: str = image_post.DEFAULT_PLATFORM  # Nền tảng: facebook/tiktok/youtube
    purpose: str = image_post.DEFAULT_PURPOSE    # Mục đích: avatar/cover/post/story
    ratio: str | None = None                     # (cũ) key khổ trực tiếp — ưu tiên platform+purpose
    ref: str | None = None                       # ảnh mẫu (base64/dataURI) — tham chiếu, tùy chọn


_DESCRIBE_PROMPT = (
    "Look at this image and write ONE rich English art prompt to recreate it. Describe the main "
    "subject(s) (appearance, pose, clothing), the setting/background, key objects, the lighting, "
    "colors, mood and overall composition. Output ONLY the description, no preamble.")


def _describe_ref(ref: str) -> str:
    """AI (GPT-4o vision) phân tích ảnh mẫu -> câu prompt tiếng Anh. Thiếu key/lỗi -> ''."""
    try:
        import fb_remake
        b = ref.split(",", 1)[1] if ";base64," in ref else ref
        return fb_remake._openai_vision(_DESCRIBE_PROMPT, [b], max_tokens=350).strip()
    except Exception:
        return ""


@app.post("/api/image-post/create")
def api_image_post_create(body: ImagePost):
    from gommo_client import GommoClient, download
    import tempfile

    idea = (body.idea or "").strip()
    text = (body.text or "").strip()
    # Có ảnh mẫu mà KHÔNG nhập ý tưởng -> AI TỰ PHÂN TÍCH ảnh mẫu (vision) làm ý tưởng.
    if not idea and body.ref:
        idea = _describe_ref(body.ref) or (
            "Recreate this reference image faithfully: keep the same composition, subjects, "
            "clothing, setting, objects, lighting and mood.")
    if not idea:
        raise HTTPException(400, "Chưa nhập ý tưởng tranh (hoặc tải ảnh mẫu để AI tự phân tích).")
    # Khổ ảnh = Nền tảng × Mục đích (mỗi nền tảng kích thước RIÊNG); `ratio` cũ chỉ để tương thích.
    ratio_key = (body.ratio if (body.ratio and body.ratio in image_post.SIZES)
                 else image_post.size_key(body.platform, body.purpose))

    row = next((m for m in _image_models() if m["model"] == body.model), None)
    if not row:
        raise HTTPException(400, "Model không hợp lệ hoặc đang tắt. Bấm ↻ làm mới.")

    # Không chữ (ảnh đại diện) -> tranh phủ KÍN khung; có chữ -> khớp dải tranh 70%.
    illo_ratio = image_post.pick_illustration_ratio(
        [o["value"] for o in row["ratios"]], ratio_key, full=not text)
    prompt = image_post.build_prompt(idea, body.style)

    client = GommoClient()
    if body.ref:                                  # có ảnh mẫu -> vẽ bám ảnh tham chiếu (subjects)
        result = client.create_image_ref(model=body.model, prompt=prompt, ratio=illo_ratio,
                                          mode=body.mode or None, resolution=body.resolution or None,
                                          ref_b64=[body.ref])
    else:
        result = client.create_image(model=body.model, prompt=prompt, ratio=illo_ratio,
                                     mode=body.mode or None, resolution=body.resolution or None)
    if result.get("error"):
        raise HTTPException(502, f"79AI từ chối: {result.get('message') or result}")
    info = result.get("imageInfo") or result.get("data") or result
    id_base = info.get("id_base") or result.get("id_base")
    if not id_base:
        raise HTTPException(502, f"Không lấy được mã ảnh từ 79AI: {result}")

    try:
        done = client.wait_for_image(id_base)
    except Exception as exc:
        raise HTTPException(502, f"Vẽ ảnh thất bại: {exc}")

    name = f"post_{int(time.time())}.png"
    with tempfile.TemporaryDirectory() as td:
        raw = os.path.join(td, "illo.png")
        download(done["url"], raw)
        if text:
            image_post.compose_card(raw, text, P("images", name), ratio_key)
        else:
            image_post.compose_plain(raw, P("images", name), ratio_key)   # ảnh không chữ

    return {"name": name, "url": f"/media/imagepost/{name}",
            "cost": _price_of(row, body.mode or None, body.resolution or None)}


@app.get("/media/imagepost/{name}")
def media_imagepost(name: str):
    if not re.fullmatch(r"post_\d+\.png", name):
        raise HTTPException(404)
    path = P("images", name)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="image/png",
                        headers={"Cache-Control": "max-age=60"})


# ══════════════════════════════════════════════════════════════════
#  TAO VIDEO AI  (tab "Tao video AI") — montage clip i2v tu 79ai
#
#  Khac tab "Tao anh" (dong bo): video CHAM (vai phut/clip) -> chay qua HANG DOI
#  (pipeline/ai_video.py). Moi canh: 79ai ve anh -> cho chuyen dong (i2v) -> tai
#  clip -> video_montage ghep + nhac/giong. Ben vung: co clip roi thi bo qua.
#
#  Danh sach model VIDEO do tu API (khong hardcode) — 79ai bat/tat lien tuc.
# ══════════════════════════════════════════════════════════════════
_vid_models = {"data": None, "at": 0.0}
_VID_MODELS_TTL = 300
_AIVID_RE = re.compile(r"aivid_\d+")


def _video_models(force: bool = False) -> list:
    now = time.time()
    if not force and _vid_models["data"] and now - _vid_models["at"] < _VID_MODELS_TTL:
        return _vid_models["data"]
    from gommo_client import GommoClient
    data = GommoClient().video_models()
    _vid_models.update(data=data, at=now)
    return data


def _video_price(row: dict, mode, resolution, duration) -> int | None:
    """Gia 1 clip theo (duration[, mode, resolution]); khong khop thi gia goc."""
    for p in row.get("prices") or []:
        if str(p.get("duration")) != str(duration):
            continue
        if mode and p.get("mode") and p.get("mode") != mode:
            continue
        if resolution and p.get("resolution") and p.get("resolution") != resolution:
            continue
        return p.get("price")
    return row.get("price")


def _pick_dur(durations: list, need: float) -> str | None:
    vals = sorted(int(d["value"]) for d in durations if str(d["value"]).isdigit())
    if not vals:
        return None
    for v in vals:
        if v >= need - 0.01:
            return str(v)
    return str(vals[-1])


def _music_dir() -> str:
    d = P("assets", "music")
    os.makedirs(d, exist_ok=True)
    return d


@app.get("/api/ai-video/models")
def api_aivideo_models(refresh: bool = False):
    try:
        vmodels = _video_models(force=refresh)
        imodels = _image_models(force=refresh)
    except Exception as exc:
        raise HTTPException(503, f"Không lấy được danh sách model 79AI: {exc}")
    import voice_roster
    roster = voice_roster.roster(root())
    eleven = [v for v in roster if v.get("engine") == "eleven"]
    omni = [{"profile_id": (v.get("ref") or "").replace("profile:", ""),
             "name": v.get("name") or v.get("ref")}
            for v in roster if v.get("engine") == "omnivoice"]
    music = sorted(n for n in os.listdir(_music_dir())
                   if n.lower().endswith((".mp3", ".m4a", ".wav", ".ogg")))
    return {
        "video_models": vmodels,
        "image_models": [{"model": m["model"], "name": m["name"], "price": m["price"],
                          "modes": m["modes"], "resolutions": m["resolutions"]}
                         for m in imodels],
        "eleven_voices": eleven,
        "omni_voices": omni,
        "music": music,
        "default": {
            "image": {"model": "google_image_gen_banana_pro", "mode": "vip3", "resolution": "1k"},
            "ratio": "9:16",
        },
    }


class AiScene(BaseModel):
    prompt_img: str
    prompt_action: str = ""
    narration: str = ""
    seconds: int = 5


class AiVideoSpec(BaseModel):
    title: str = "video-ai"
    ratio: str = "9:16"
    audio_mode: str = "music"                 # music | voice
    image: dict = {}                          # {model, mode, resolution}
    video: dict = {}                          # {model, mode, resolution}
    music: str = ""                           # ten file trong assets/music/
    music_db: float = -12.0
    voice: dict = {}                          # {eleven_voice, stability, style, speed}
    voice_speed: float = 1.0                  # toc do doc (1.0=goc, >1 nhanh hon)
    batch: str = ""                           # ma me (gom nhom o Bang dieu khien)
    scenes: list[AiScene] = []


def _resolve_scene_costs(spec: AiVideoSpec) -> dict:
    vrow = next((m for m in _video_models() if m["model"] == (spec.video or {}).get("model")), None)
    irow = next((m for m in _image_models() if m["model"] == (spec.image or {}).get("model")), None)
    if not vrow:
        raise HTTPException(400, "Chưa chọn model video hợp lệ (bấm ↻ làm mới).")
    if not irow:
        raise HTTPException(400, "Chưa chọn model ảnh hợp lệ (bấm ↻ làm mới).")
    vmode = (spec.video or {}).get("mode") or None
    vres = (spec.video or {}).get("resolution") or None
    imode = (spec.image or {}).get("mode") or None
    ires = (spec.image or {}).get("resolution") or None
    img_price = _price_of(irow, imode, ires) or 0
    per, total = [], 0
    for sc in spec.scenes:
        if spec.audio_mode == "voice" and (sc.narration or "").strip():
            need = len(sc.narration.strip()) / 13.0        # uoc luong giay tu ky tu
            dur = _pick_dur(vrow["durations"], need) or str(sc.seconds)
        else:
            dur = str(sc.seconds)
        clip = _video_price(vrow, vmode, vres, dur) or 0
        cost = int(clip) + int(img_price)
        per.append({"duration": dur, "clip": int(clip), "image": int(img_price), "cost": cost})
        total += cost
    return {"total": total, "per_scene": per, "image_price": int(img_price)}


class GenScript(BaseModel):
    theme: str
    n_scenes: int = 8


@app.post("/api/ai-video/gen-script")
def api_aivideo_gen_script(body: GenScript):
    """Sinh kịch bản tự động từ chủ đề (Claude). Trả spec-lite để đổ vào bảng soạn
    cảnh — người dùng DUYỆT rồi mới tạo (tốn tiền). Chống trùng: nhắc Claude tránh
    các tiêu đề đã sinh (lưu trong assets/aivideo_scripts/)."""
    theme = (body.theme or "").strip()
    if not theme:
        raise HTTPException(400, "Chưa nhập chủ đề.")
    n = max(2, min(int(body.n_scenes or 8), 15))
    import script_gen

    log_dir = P("assets", "aivideo_scripts")
    os.makedirs(log_dir, exist_ok=True)
    avoid = []
    for fn in sorted(os.listdir(log_dir))[-40:]:
        d = read_json(os.path.join(log_dir, fn), {}) or {}
        if d.get("title"):
            avoid.append(d["title"])
    try:
        doc = script_gen.generate_script(theme, n, avoid_titles=avoid)
    except SystemExit as exc:                      # thiếu key
        raise HTTPException(400, str(exc))
    except Exception as exc:
        raise HTTPException(502, f"Sinh kịch bản thất bại: {exc}")

    char = (doc.get("character") or "").strip()
    scenes = []
    _IMG_SUFFIX = "cinematic, warm golden light, full bleed no border"
    for sc in doc.get("scenes", []):
        pi = (sc.get("prompt_img") or "").strip()
        if char and char.lower() not in pi.lower():   # khoá nhân vật vào mọi prompt ảnh
            pi = f"{char}. {pi}"
        # ÉP quy uoc ky thuat (LLM hay bo qua) — chong matte toi cua banana, giu dien anh
        if "full bleed" not in pi.lower():
            pi = pi.rstrip(". ") + ". " + _IMG_SUFFIX
        scenes.append({"prompt_img": pi,
                       "prompt_action": (sc.get("prompt_action") or "").strip(),
                       "narration": (sc.get("narration") or "").strip(),
                       "seconds": 5})
    out = {"id": f"scr_{int(time.time())}", "title": doc.get("title", theme),
           "theme": theme, "style": doc.get("style", ""),
           "character": char, "scenes": scenes}
    # Luu DAY DU (dung lai duoc) + chong trung lan sau.
    with open(os.path.join(log_dir, f"{out['id']}.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
    return out


_SCR_RE = re.compile(r"scr_\d+")


@app.get("/api/ai-video/scripts")
def api_aivideo_scripts():
    """Danh sach kich ban DA SINH (moi nhat truoc) — de dung lai."""
    d = P("assets", "aivideo_scripts")
    if not os.path.isdir(d):
        return {"scripts": []}
    out = []
    for fn in sorted((n for n in os.listdir(d) if _SCR_RE.fullmatch(n[:-5]) and n.endswith(".json")),
                     reverse=True):
        s = read_json(os.path.join(d, fn), {}) or {}
        sid = fn[:-5]
        try:
            created = time.strftime("%d/%m/%Y %H:%M", time.localtime(int(sid.split("_")[1])))
        except (ValueError, IndexError):
            created = ""
        out.append({"id": sid, "title": s.get("title", sid), "theme": s.get("theme", ""),
                    "n_scenes": len(s.get("scenes", [])), "created": created})
    return {"scripts": out}


@app.get("/api/ai-video/scripts/{sid}")
def api_aivideo_script_get(sid: str):
    if not _SCR_RE.fullmatch(sid):
        raise HTTPException(404)
    s = read_json(P("assets", "aivideo_scripts", f"{sid}.json"), None)
    if not s:
        raise HTTPException(404, "Không tìm thấy kịch bản.")
    return s


@app.delete("/api/ai-video/scripts/{sid}")
def api_aivideo_script_delete(sid: str):
    if not _SCR_RE.fullmatch(sid):
        raise HTTPException(404)
    fp = P("assets", "aivideo_scripts", f"{sid}.json")
    if os.path.isfile(fp):
        os.remove(fp)
    return {"ok": True}


@app.post("/api/ai-video/estimate")
def api_aivideo_estimate(spec: AiVideoSpec):
    if not spec.scenes:
        raise HTTPException(400, "Chưa có cảnh nào.")
    return _resolve_scene_costs(spec)


def _video_credit(spec_dict: dict):
    """Uoc tinh credit cua MOT video da luu (tu spec.json). Tra None neu model
    khong con ton tai (79ai tat model) -> UI hien '—' thay vi bao loi."""
    try:
        return _resolve_scene_costs(AiVideoSpec(**spec_dict))["total"]
    except (HTTPException, TypeError, ValueError, KeyError):
        return None


def _video_status(workdir: str, done: bool) -> str:
    """Trang thai 1 video: done | error | building | draft.
    - done   : da co file mp4
    - error  : state.json co canh 'loi' hoac status 'loi'
    - building: da bat dau (co state.json / co clip) nhung chua xong
    - draft  : chua dung lan nao"""
    if done:
        return "done"
    state = read_json(os.path.join(workdir, "state.json"), {}) or {}
    scenes = state.get("scenes", [])
    if state.get("status") == "loi" or any(s.get("status") == "loi" for s in scenes):
        return "error"
    if state or any(re.fullmatch(r"clip_\d+\.mp4", f) for f in os.listdir(workdir)):
        return "building"
    return "draft"


_BUDGET_FILE = "budget.json"


def _budget_load() -> dict:
    return read_json(os.path.join(P("videos-ai"), _BUDGET_FILE),
                     {"cap_month": 0, "warn_pct": 90}) or {"cap_month": 0, "warn_pct": 90}


def _spent_this_month() -> int:
    """Uoc tinh credit da tieu thang nay = tong credit cac video (done/building)
    tao trong thang. Dung de CHAN enqueue khi vuot ngan sach."""
    d = P("videos-ai")
    if not os.path.isdir(d):
        return 0
    now = time.localtime()
    total = 0
    for n in os.listdir(d):
        if not (_AIVID_RE.fullmatch(n) and os.path.isdir(os.path.join(d, n))):
            continue
        try:
            t = time.localtime(int(n.split("_")[1]))
        except (ValueError, IndexError):
            continue
        if t.tm_year != now.tm_year or t.tm_mon != now.tm_mon:
            continue
        wd = os.path.join(d, n)
        spec = read_json(os.path.join(wd, "spec.json"), {}) or {}
        if not spec:
            continue
        if _video_status(wd, os.path.isfile(os.path.join(d, f"{n}.mp4"))) == "draft":
            continue
        total += _video_credit(spec) or 0
    return total


@app.get("/api/ai-video/budget")
def api_aivideo_budget_get():
    return _budget_load()


class BudgetSave(BaseModel):
    cap_month: int = 0
    warn_pct: int = 90


@app.post("/api/ai-video/budget")
def api_aivideo_budget_set(body: BudgetSave):
    d = P("videos-ai")
    os.makedirs(d, exist_ok=True)
    cfg = {"cap_month": max(0, int(body.cap_month)),
           "warn_pct": min(100, max(50, int(body.warn_pct)))}
    with open(os.path.join(d, _BUDGET_FILE), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=1)
    return cfg


@app.post("/api/ai-video/create")
def api_aivideo_create(spec: AiVideoSpec):
    if not spec.scenes:
        raise HTTPException(400, "Chưa có cảnh nào.")
    for i, sc in enumerate(spec.scenes):
        if not (sc.prompt_img or "").strip():
            raise HTTPException(400, f"Cảnh {i + 1} chưa có mô tả tranh.")
    if spec.audio_mode == "voice" and not ((spec.voice or {}).get("eleven_voice")
                                            or (spec.voice or {}).get("profile_id")):
        raise HTTPException(400, "Chế độ giọng: chưa chọn giọng.")
    vrow = next((m for m in _video_models() if m["model"] == (spec.video or {}).get("model")), None)
    if not vrow:
        raise HTTPException(400, "Chưa chọn model video hợp lệ (bấm ↻ làm mới).")

    # --- CONG NGAN SACH: chan enqueue neu vuot cap thang ---
    budget = _budget_load()
    cap = budget.get("cap_month", 0)
    if cap > 0:
        est = _resolve_scene_costs(spec)["total"]
        spent = _spent_this_month()
        if spent + est > cap:
            raise HTTPException(400,
                f"Vượt ngân sách: đã tiêu ~{spent:,} + video này ~{est:,} > hạn mức {cap:,} credit tháng này. "
                f"Tăng hạn mức ở tab Ngân sách hoặc chờ tháng sau.")

    vid = f"aivid_{int(time.time())}"
    workdir = P("videos-ai", vid)
    os.makedirs(workdir, exist_ok=True)
    music_rel = ""
    if spec.music:
        if not re.fullmatch(r"[^/\\]+\.(mp3|m4a|wav|ogg)", spec.music, re.I) \
           or not os.path.isfile(os.path.join(_music_dir(), spec.music)):
            raise HTTPException(400, "File nhạc không hợp lệ.")
        music_rel = os.path.join("assets", "music", spec.music)

    doc = {
        "id": vid, "title": spec.title, "ratio": spec.ratio,
        "audio_mode": spec.audio_mode,
        "image": spec.image, "music": music_rel, "music_db": spec.music_db,
        "video": {**spec.video, "durations": [d["value"] for d in vrow["durations"]]},
        "voice": spec.voice, "voice_speed": spec.voice_speed,
        "batch": spec.batch,
        "scenes": [sc.model_dump() for sc in spec.scenes],
    }
    with open(os.path.join(workdir, "spec.json"), "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=1)

    job = push("tao-video-ai", f"Video AI: {spec.title}",
               ["pipeline/ai_video.py", "--spec", f"videos-ai/{vid}/spec.json"])
    return {"id": vid, "job": job, "n_scenes": len(spec.scenes)}


@app.post("/api/ai-video/regen/{vid}/{scene}")
def api_aivideo_regen(vid: str, scene: int):
    """Tao lai 1 canh: xoa clip canh do (khong xoa anh khung -> khong ve lai)
    roi chay lai job. Cac canh khac da co clip -> bo qua, khong ton them."""
    if not _AIVID_RE.fullmatch(vid):
        raise HTTPException(404)
    workdir = P("videos-ai", vid)
    spec_path = os.path.join(workdir, "spec.json")
    if not os.path.isfile(spec_path):
        raise HTTPException(404, "Không tìm thấy video.")
    # Xoa clip + ma job video (.vid) -> tao lai se NOP CLIP MOI (khong resume clip cu,
    # vi thuong regen do clip cu xau/ket). Giu anh khung dau -> khong ve (tra tien) lai.
    for suf in (f"clip_{scene:02d}.mp4", f"clip_{scene:02d}.vid"):
        fp = os.path.join(workdir, suf)
        if os.path.isfile(fp):
            os.remove(fp)
    job = push("tao-video-ai", f"Tạo lại cảnh {scene + 1}",
               ["pipeline/ai_video.py", "--spec", f"videos-ai/{vid}/spec.json"])
    return {"ok": True, "job": job}


@app.get("/api/ai-video/status/{vid}")
def api_aivideo_status(vid: str):
    if not _AIVID_RE.fullmatch(vid):
        raise HTTPException(404)
    workdir = P("videos-ai", vid)
    state = read_json(os.path.join(workdir, "state.json"), {}) or {}
    final = P("videos-ai", f"{vid}.mp4")
    return {"id": vid, "state": state,
            "done": os.path.isfile(final),
            "url": f"/media/aivideo/{vid}" if os.path.isfile(final) else ""}


@app.get("/api/ai-video/list")
def api_aivideo_list():
    d = P("videos-ai")
    if not os.path.isdir(d):
        return {"videos": []}
    # Duyet THU MUC (khong chi file mp4) -> gom ca video DANG DO (het tien/loi giua
    # chung): anh da ve luu trong thu muc -> tiep tuc duoc, khong ve lai.
    ids = sorted((n for n in os.listdir(d)
                  if _AIVID_RE.fullmatch(n) and os.path.isdir(os.path.join(d, n))),
                 reverse=True)
    out = []
    for vid in ids:
        wd = os.path.join(d, vid)
        spec = read_json(os.path.join(wd, "spec.json"), {}) or {}
        if not spec:
            continue
        nscene = len(spec.get("scenes", []))
        nframe = len([f for f in os.listdir(wd) if re.fullmatch(r"frame_\d+\.url", f)])
        nclip = len([f for f in os.listdir(wd) if re.fullmatch(r"clip_\d+\.mp4", f)])
        done = os.path.isfile(os.path.join(d, f"{vid}.mp4"))
        unix = 0
        try:
            unix = int(vid.split("_")[1])
            created = time.strftime("%d/%m/%Y %H:%M", time.localtime(unix))
        except (ValueError, IndexError):
            created = ""
        status = _video_status(wd, done)
        credit = _video_credit(spec)
        out.append({
            "id": vid, "url": f"/media/aivideo/{vid}" if done else "",
            "title": spec.get("title", vid), "created": created, "unix": unix,
            "audio_mode": spec.get("audio_mode", "music"),
            "music": os.path.basename(spec.get("music") or ""),
            "music_db": spec.get("music_db", -12),
            "voice_speed": spec.get("voice_speed", 1.0),
            "voice": spec.get("voice") or {},
            "video_model": (spec.get("video") or {}).get("model", ""),
            "batch": spec.get("batch") or "",
            "caption": (open(os.path.join(wd, "caption.txt"), encoding="utf-8").read()
                        if os.path.isfile(os.path.join(wd, "caption.txt")) else ""),
            "done": done, "status": status, "credit": credit,
            "n_scenes": nscene, "n_frame": nframe, "n_clip": nclip,
        })

    # ---- Tong quan (cho Bang dieu khien) -----------------------------------
    now = time.localtime()
    def _this_month(v):
        if not v.get("unix"):
            return False
        t = time.localtime(v["unix"])
        return t.tm_year == now.tm_year and t.tm_mon == now.tm_mon
    counts = {"done": 0, "building": 0, "error": 0, "draft": 0}
    for v in out:
        counts[v["status"]] = counts.get(v["status"], 0) + 1
    spent = sum((v["credit"] or 0) for v in out
                if _this_month(v) and v["status"] in ("done", "building"))
    budget = _budget_load()
    summary = {
        "total": len(out), "counts": counts,
        "spent_month": spent, "cap_month": budget.get("cap_month", 0),
        "warn_pct": budget.get("warn_pct", 90),
    }
    return {"videos": out, "summary": summary}


class AiVidIds(BaseModel):
    ids: list[str]


@app.post("/api/ai-video/delete")
def api_aivideo_delete(body: AiVidIds):
    """Xoa han 1 hoac nhieu video AI (ca thu muc lam viec + file mp4).
    Dung cho thao tac hang loat o Bang dieu khien."""
    import shutil
    d = P("videos-ai")
    removed, failed = [], []
    for vid in body.ids:
        if not _AIVID_RE.fullmatch(vid):
            failed.append(vid)
            continue
        wd = os.path.join(d, vid)
        try:
            if os.path.isdir(wd):
                shutil.rmtree(wd, ignore_errors=True)
            mp4 = os.path.join(d, f"{vid}.mp4")
            if os.path.isfile(mp4):
                os.remove(mp4)
            removed.append(vid)
        except OSError:
            failed.append(vid)
    return {"removed": removed, "failed": failed}


@app.post("/api/ai-video/caption/{vid}")
def api_aivideo_caption(vid: str):
    """Sinh TUS (caption) dang Facebook cho 1 video da tao — tu tieu de + loi doc.
    Luu caption.txt trong workdir (dung lai/sua duoc)."""
    if not _AIVID_RE.fullmatch(vid):
        raise HTTPException(404)
    spec = read_json(P("videos-ai", vid, "spec.json"), None)
    if not spec:
        raise HTTPException(404, "Không tìm thấy video.")
    title = spec.get("title", "")
    narr = "\n".join((s.get("narration") or "").strip()
                     for s in spec.get("scenes", []) if s.get("narration"))
    import script_gen
    try:
        cap = script_gen.generate_caption(title, narr)
    except SystemExit as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:
        raise HTTPException(502, f"Sinh tus thất bại: {exc}")
    with open(P("videos-ai", vid, "caption.txt"), "w", encoding="utf-8") as f:
        f.write(cap)
    return {"ok": True, "caption": cap}


@app.post("/api/ai-video/resume/{vid}")
def api_aivideo_resume(vid: str):
    """Chay lai video DANG DO (het tien/loi giua chung). BEN VUNG: anh + clip da co
    -> bo qua (khong ve/tra lai); chi lam phan con thieu."""
    if not _AIVID_RE.fullmatch(vid):
        raise HTTPException(404)
    if not os.path.isfile(P("videos-ai", vid, "spec.json")):
        raise HTTPException(404, "Không tìm thấy video.")
    job = push("tao-video-ai", f"Tiếp tục video: {vid}",
               ["pipeline/ai_video.py", "--spec", f"videos-ai/{vid}/spec.json"])
    return {"ok": True, "job": job, "id": vid}


class AiVideoEdit(BaseModel):
    audio_mode: str | None = None                 # music | voice
    voice: dict | str | None = None               # {engine, eleven_voice/profile_id} hoac id Eleven
    music: str | None = None                      # ten file trong assets/music/ ("" = bo nhac)
    music_db: float | None = None
    voice_speed: float | None = None              # toc do doc (ghep lai, khong doc lai)
    video: dict | None = None                     # {model, mode, resolution} — doi model -> lam lai clip


def _vkey(v: dict) -> str:
    v = v or {}
    return f"{v.get('engine', '')}:{v.get('eleven_voice') or v.get('profile_id') or ''}"


@app.post("/api/ai-video/edit/{vid}")
def api_aivideo_edit(vid: str, body: AiVideoEdit):
    """SUA am thanh video da tao: doi giong / doi-them nhac. Clip da cache ->
    chi doc lai giong (neu doi giong) + ghep lai -> gan nhu KHONG ton credit 79ai."""
    if not _AIVID_RE.fullmatch(vid):
        raise HTTPException(404)
    workdir = P("videos-ai", vid)
    spec_path = os.path.join(workdir, "spec.json")
    spec = read_json(spec_path, None)
    if not spec:
        raise HTTPException(404, "Không tìm thấy video.")

    old_voice = _vkey(spec.get("voice"))
    old_mode = spec.get("audio_mode", "music")

    if body.audio_mode in ("music", "voice"):
        spec["audio_mode"] = body.audio_mode
    if body.voice is not None:
        spec["voice"] = dict(body.voice) if isinstance(body.voice, dict) else \
            ({"engine": "eleven", "eleven_voice": body.voice} if body.voice else {})
    if body.music is not None:
        if body.music == "":
            spec["music"] = ""
        else:
            if not re.fullmatch(r"[^/\\]+\.(mp3|m4a|wav|ogg)", body.music, re.I) \
               or not os.path.isfile(os.path.join(_music_dir(), body.music)):
                raise HTTPException(400, "File nhạc không hợp lệ.")
            spec["music"] = os.path.join("assets", "music", body.music)
    if body.music_db is not None:
        spec["music_db"] = body.music_db
    if body.voice_speed is not None:               # doi toc do -> chi ghep lai (khong doc lai)
        spec["voice_speed"] = max(0.6, min(float(body.voice_speed), 1.6))
    if body.video:                                 # doi model video -> LAM LAI clip (giu anh)
        vrow = next((m for m in _video_models() if m["model"] == body.video.get("model")), None)
        if not vrow:
            raise HTTPException(400, "Model video không hợp lệ.")
        spec["video"] = {**body.video, "durations": [d["value"] for d in vrow["durations"]]}
        for f in os.listdir(workdir):              # xoa clip + ma job (giu frame_*.png/.url)
            if re.fullmatch(r"clip_\d+\.(mp4|vid)", f):
                os.remove(os.path.join(workdir, f))

    v = spec.get("voice") or {}
    if spec["audio_mode"] == "voice" and not (v.get("eleven_voice") or v.get("profile_id")):
        raise HTTPException(400, "Chế độ giọng: chưa chọn giọng.")

    # Doi giong / bat che do voice -> XOA giong cu de doc lai (mach moi).
    if spec["audio_mode"] == "voice" and (_vkey(v) != old_voice or old_mode != "voice"):
        for f in ("narration.mp3", "timing.json"):
            fp = os.path.join(workdir, f)
            if os.path.isfile(fp):
                os.remove(fp)

    with open(spec_path, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=1)

    job = push("tao-video-ai", f"Sửa video: {spec.get('title', vid)}",
               ["pipeline/ai_video.py", "--spec", f"videos-ai/{vid}/spec.json"])
    return {"ok": True, "job": job, "id": vid}


@app.post("/api/ai-video/music/upload")
async def api_aivideo_music_upload(files: list[UploadFile] = File(...)):
    saved = []
    for up in files:
        name = re.sub(r"[^\w.\-]+", "_", up.filename or "nhac")
        if not name.lower().endswith((".mp3", ".m4a", ".wav", ".ogg")):
            continue
        with open(os.path.join(_music_dir(), name), "wb") as f:
            f.write(await up.read())
        saved.append(name)
    return {"saved": saved}


@app.post("/api/ai-video/music/extract")
async def api_aivideo_music_extract(files: list[UploadFile] = File(...)):
    """Tach TIENG tu VIDEO thanh file nhac (.m4a stereo) -> vao kho nhac.
    Dung ffmpeg -vn giu tieng goc (co the kem giong doc — do la audio nguyen ban)."""
    import subprocess
    import tempfile

    saved, rejected = [], []
    md = _music_dir()
    for up in files:
        name = os.path.basename(up.filename or "")
        if not name.lower().endswith(VIDEO_EXT):
            rejected.append({"name": name or "?", "error": "Chỉ nhận video (.mp4 .mov .mkv .webm .avi .m4v)"})
            continue
        raw = await up.read()
        if len(raw) > 500 * 1024 * 1024:
            rejected.append({"name": name, "error": "File quá 500 MB"})
            continue
        stem = re.sub(r"[^\w.\-]+", "_", os.path.splitext(name)[0]) or uuid.uuid4().hex[:6]
        out_name, out_path = _uniq_path(md, f"{stem}.m4a")
        fd, tmp = tempfile.mkstemp(suffix=os.path.splitext(name)[1] or ".mp4")
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(raw)
            proc = subprocess.run(
                ["ffmpeg", "-y", "-v", "error", "-i", tmp,
                 "-vn", "-c:a", "aac", "-b:a", "192k", "-ac", "2", out_path],
                capture_output=True, text=True)
            if proc.returncode != 0 or not os.path.isfile(out_path):
                rejected.append({"name": name, "error": "Không tách được tiếng (video không có âm thanh?)"})
                continue
            saved.append(out_name)
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
    return {"saved": saved, "rejected": rejected}


@app.get("/media/music/{name}")
def media_music(name: str):
    if not re.fullmatch(r"[^/\\]+\.(mp3|m4a|wav|ogg)", name, re.I):
        raise HTTPException(404)
    path = os.path.join(_music_dir(), name)
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, headers={"Cache-Control": "max-age=60"})


@app.get("/media/aivideo/{vid}")
def media_aivideo(vid: str):
    if not _AIVID_RE.fullmatch(vid):
        raise HTTPException(404)
    path = P("videos-ai", f"{vid}.mp4")
    if not os.path.isfile(path):
        raise HTTPException(404)
    return FileResponse(path, media_type="video/mp4",
                        headers={"Cache-Control": "no-cache"})


# ══════════════════════════════════════════════════════════════════
#  API KEYS — dan/quan ly key ngay trong tab Cai dat
#
#  Luu vao keys.env (goc du an, da .gitignore) + set os.environ SONG -> hieu luc
#  NGAY, khong can khoi dong lai. Bien moi truong san co (nap tu loader) van uu tien.
# ══════════════════════════════════════════════════════════════════
_KEYS_ENV = os.path.join(os.path.dirname(APP_DIR), "keys.env")
MANAGED_KEYS = [
    {"name": "ANTHROPIC_API_KEY", "label": "Claude (Anthropic)",
     "help": "Sinh kịch bản tự động. Lấy ở console.anthropic.com → API Keys."},
    {"name": "GEMINI_API_KEY", "label": "Google Gemini",
     "help": "Xem NGUYÊN video gốc để phân tích nguồn + viết mô tả cảnh khi làm lại. Engine chính, bắt buộc. Lấy ở aistudio.google.com/apikey (cần bật billing dự án Google)."},
    {"name": "OPENAI_API_KEY", "label": "ChatGPT (OpenAI)",
     "help": "Tuỳ chọn — chỉ dùng cho chế độ story thủ công + phân tích ảnh mẫu. Luồng tự động dùng Gemini. Lấy ở platform.openai.com/api-keys."},
    {"name": "GOMMO_API_TOKEN", "label": "79AI (Gommo)",
     "help": "Vẽ ảnh + tạo video AI. Bắt buộc."},
    {"name": "ELEVENLABS_API_KEY", "label": "ElevenLabs",
     "help": "Giọng đọc có cảm xúc + mốc thời gian."},
    {"name": "ANTHROPIC_BASE_URL", "label": "Claude — Base URL (nếu dùng proxy)",
     "help": "Bỏ trống nếu gọi thẳng Anthropic."},
]
_KEY_NAMES = {k["name"] for k in MANAGED_KEYS}


def _mask(v: str) -> str:
    v = (v or "").strip()
    if not v:
        return ""
    if v.startswith(("http://", "https://")):
        return v                                  # base url: hien nguyen
    if len(v) <= 10:
        return "•" * len(v)
    return v[:4] + "•" * 8 + v[-4:]


def _write_key_env(name: str, value: str) -> None:
    """Upsert 1 dong KEY=value trong keys.env (giu cac dong khac)."""
    lines, found = [], False
    if os.path.isfile(_KEYS_ENV):
        with open(_KEYS_ENV, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
    out = []
    for ln in lines:
        if ln.strip().startswith(f"{name}="):
            found = True
            if value:
                out.append(f"{name}={value}")     # rong -> bo dong (xoa key)
        else:
            out.append(ln)
    if value and not found:
        out.append(f"{name}={value}")
    with open(_KEYS_ENV, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + ("\n" if out else ""))


@app.get("/api/settings/keys")
def api_settings_keys():
    return {"keys": [{"name": k["name"], "label": k["label"], "help": k["help"],
                      "set": bool(os.environ.get(k["name"], "").strip()),
                      "masked": _mask(os.environ.get(k["name"], ""))}
                     for k in MANAGED_KEYS]}


class KeySet(BaseModel):
    name: str
    value: str = ""


@app.post("/api/settings/keys")
def api_settings_key_set(body: KeySet):
    if body.name not in _KEY_NAMES:
        raise HTTPException(400, "Tên key không hợp lệ.")
    value = (body.value or "").strip()
    _write_key_env(body.name, value)
    if value:
        os.environ[body.name] = value             # hieu luc NGAY trong tien trinh
    else:
        os.environ.pop(body.name, None)
    return {"ok": True, "set": bool(value), "masked": _mask(value)}


# ══════════════════════════════════════════════════════════════════
#  ONBOARDING — nhap + TEST THAT tung key (chay-lan-dau khi sang may moi).
#  keys.env KHONG len git -> may moi trang key. Test THAT (goi API) tra
#  xanh/do; thieu key bat buoc -> khoa nut chay. Nut that so 1 (CLAUDE.md).
# ══════════════════════════════════════════════════════════════════
ONBOARDING_KEYS = [
    {"name": "GOMMO_API_TOKEN", "label": "79AI (Gommo)", "required": True,
     "help": "Vẽ ảnh + tạo clip AI. Bắt buộc."},
    {"name": "GEMINI_API_KEY", "label": "Google Gemini", "required": True,
     "help": "Xem nguyên video gốc → phân tích nguồn + viết mô tả cảnh. Engine chính, bắt buộc. Lấy ở aistudio.google.com/apikey (cần bật billing)."},
    {"name": "OPENAI_API_KEY", "label": "OpenAI (GPT-4o Vision)", "required": False,
     "help": "Tuỳ chọn — chỉ cho chế độ story thủ công + phân tích ảnh mẫu. Luồng tự động dùng Gemini."},
    {"name": "FB_SYS_TOKEN", "label": "Facebook System User token", "required": True,
     "help": "Đăng reel + lên lịch. Token vĩnh viễn ở business.facebook.com/settings/system-users."},
    {"name": "ELEVENLABS_API_KEY", "label": "ElevenLabs", "required": False,
     "help": "Chỉ cần khi làm lại GIỌNG mới (mode A). Giữ giọng gốc (mode B) thì không cần."},
]


def _key_is_set(name: str) -> bool:
    if name == "FB_SYS_TOKEN":
        return bool(fb_graph.load_token())
    return bool(os.environ.get(name, "").strip())


def _test_key(name: str, value: str = "") -> dict:
    """Goi API THAT de xac minh key (khong luu). Tra {ok, detail}."""
    import requests
    value = (value or "").strip()
    if not value:
        value = fb_graph.load_token() if name == "FB_SYS_TOKEN" else os.environ.get(name, "").strip()
    if not value:
        return {"ok": False, "detail": "Chưa nhập key."}
    try:
        if name == "GOMMO_API_TOKEN":
            old = os.environ.get(name)
            os.environ[name] = value
            try:
                from gommo_client import GommoClient
                cr = GommoClient().credits()
            finally:
                if old is None:
                    os.environ.pop(name, None)
                else:
                    os.environ[name] = old
            return {"ok": True, "detail": f"OK · còn {cr:,} credit"}
        if name == "ELEVENLABS_API_KEY":
            r = requests.get("https://api.elevenlabs.io/v1/user/subscription",
                             headers={"xi-api-key": value}, timeout=30)
            if r.status_code != 200:
                return {"ok": False, "detail": f"HTTP {r.status_code}: key sai hoặc hết hạn."}
            q = r.json()
            left = int(q.get("character_limit", 0)) - int(q.get("character_count", 0))
            return {"ok": True, "detail": f"OK · còn ~{left:,} ký tự"}
        if name == "GEMINI_API_KEY":
            r = requests.get("https://generativelanguage.googleapis.com/v1beta/models",
                             params={"key": value}, timeout=30)
            if r.status_code != 200:
                msg = "key sai" if r.status_code in (400, 403) else f"HTTP {r.status_code}"
                if r.status_code == 429:
                    msg = "quota=0 — cần bật billing dự án Google"
                return {"ok": False, "detail": msg}
            return {"ok": True, "detail": "OK · key hợp lệ"}
        if name == "OPENAI_API_KEY":
            base = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
            r = requests.get(f"{base}/models", headers={"Authorization": f"Bearer {value}"},
                             timeout=30)
            if r.status_code != 200:
                return {"ok": False, "detail": f"HTTP {r.status_code}: key sai hoặc hết hạn."}
            return {"ok": True, "detail": "OK · key hợp lệ"}
        if name == "ANTHROPIC_API_KEY":
            base = (os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com").rstrip("/")
            r = requests.get(f"{base}/v1/models",
                             headers={"x-api-key": value, "anthropic-version": "2023-06-01"},
                             timeout=30)
            if r.status_code != 200:
                return {"ok": False, "detail": f"HTTP {r.status_code}: key sai hoặc hết hạn."}
            return {"ok": True, "detail": "OK · key hợp lệ"}
        if name == "FB_SYS_TOKEN":
            if not value.startswith("EAA"):
                return {"ok": False, "detail": "Token phải bắt đầu bằng EAA…"}
            r = fb_graph.fetch_pages(value)
            if not r.get("ok"):
                return {"ok": False, "detail": f"Token lỗi: {r.get('error')}"}
            return {"ok": True, "detail": f"OK · {r.get('count', 0)} page ({r.get('me')})"}
    except Exception as exc:
        return {"ok": False, "detail": str(exc)[:200]}
    return {"ok": False, "detail": "Không rõ key này."}


class KeyTest(BaseModel):
    name: str
    value: str = ""


@app.post("/api/settings/keys/test")
def api_settings_key_test(body: KeyTest):
    return _test_key(body.name, body.value)


@app.get("/api/onboarding")
def api_onboarding():
    keys = [{**k, "set": _key_is_set(k["name"])} for k in ONBOARDING_KEYS]
    ready = all(k["set"] for k in keys if k["required"])
    return {"keys": keys, "ready": ready}


@app.post("/api/onboarding/save")
def api_onboarding_save(body: KeyTest):
    """Test THAT truoc, dung -> LUU (khong luu key hong)."""
    value = (body.value or "").strip()
    if not value:
        # Khong co gia tri moi -> chi test key da luu, TUYET DOI khong ghi rong (xoa key).
        return {**_test_key(body.name, ""), "saved": False}
    res = _test_key(body.name, value)
    if not res.get("ok"):
        return {"ok": False, "detail": res.get("detail"), "saved": False}
    if body.name == "FB_SYS_TOKEN":
        fb_graph.add_token("chính", value)
        _write_key_env("FB_SYS_TOKEN", value)
        os.environ["FB_SYS_TOKEN"] = value
        try:
            fb_graph.save_cache(fb_graph.fetch_all())
        except Exception:
            pass
    else:
        if body.name not in _KEY_NAMES:
            raise HTTPException(400, "Tên key không hợp lệ.")
        _write_key_env(body.name, value)
        os.environ[body.name] = value
    return {"ok": True, "detail": res.get("detail"), "saved": True}


# ══════════════════════════════════════════════════════════════════
#  TAI VIDEO/REEL FACEBOOK — Chrome quan ly (dang nhap tay) -> liet ke -> tai
#
#  Du lieu o <goc du an>/facebook/<slug>/ (KHONG theo kenh, da .gitignore).
#  Chrome quan ly la cua so RIENG (cong CDP 9333), khac trinh duyet xem app.
#  Xem docs/tinh-nang-tai-video-facebook.md.
# ══════════════════════════════════════════════════════════════════
FB_ROOT = os.path.join(os.path.dirname(APP_DIR), "facebook")
_FB_SLUG_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
_FB_ID_RE = re.compile(r"^\d+$")


@app.get("/api/fb/session")
def api_fb_session_status():
    alive = fb_session.is_alive()
    return {"alive": alive,
            "logged_in": fb_session.logged_in() if alive else False,
            "targets": len(fb_session.list_targets()) if alive else 0}


@app.post("/api/fb/session")
def api_fb_session_open():
    try:
        st = fb_session.open_session()
    except Exception as exc:
        raise HTTPException(400, str(exc))
    time.sleep(1.0)
    st["logged_in"] = fb_session.logged_in()
    return st


class FbListReq(BaseModel):
    url: str


@app.post("/api/fb/list")
def api_fb_list(body: FbListReq):
    url = (body.url or "").strip()
    if "facebook.com/" not in url:
        raise HTTPException(400, "Link page Facebook không hợp lệ.")
    if not fb_session.is_alive():
        raise HTTPException(400, "Chưa mở phiên Chrome. Bấm 'Mở Chrome & đăng nhập' trước.")
    slug = fb_lister.page_slug(url)
    job = push("tai-fb", f"Liệt kê reel: {slug}", ["pipeline/fb_lister.py", url])
    return {"job": job, "slug": slug}


@app.get("/api/fb/pages")
def api_fb_pages():
    out = []
    if os.path.isdir(FB_ROOT):
        for name in os.listdir(FB_ROOT):
            idxp = os.path.join(FB_ROOT, name, "index.json")
            if os.path.isfile(idxp):
                d = read_json(idxp, {}) or {}
                reels = d.get("reels", {})
                out.append({"slug": name, "count": len(reels),
                            "downloaded": sum(1 for r in reels.values() if r.get("downloaded")),
                            "scraped_at": d.get("scraped_at")})
    out.sort(key=lambda x: x.get("scraped_at") or 0, reverse=True)
    return {"pages": out}


@app.get("/api/fb/index")
def api_fb_index(slug: str):
    if not _FB_SLUG_RE.match(slug):
        raise HTTPException(404)
    d = read_json(os.path.join(FB_ROOT, slug, "index.json"), None)
    if not d:
        raise HTTPException(404, "Chưa liệt kê page này.")
    reels = list(d.get("reels", {}).values())
    reels.sort(key=lambda r: r.get("views") or 0, reverse=True)
    return {"slug": slug, "page_url": d.get("page_url"), "scraped_at": d.get("scraped_at"),
            "count": len(reels),
            "downloaded": sum(1 for r in reels if r.get("downloaded")),
            "reels": reels}


class FbDlReq(BaseModel):
    slug: str
    ids: list[str]
    quality: str = "best"


@app.post("/api/fb/download")
def api_fb_download(body: FbDlReq):
    if not _FB_SLUG_RE.match(body.slug):
        raise HTTPException(400, "slug không hợp lệ.")
    ids = [i for i in body.ids if _FB_ID_RE.match(i)]
    if not ids:
        raise HTTPException(400, "Chưa chọn reel nào.")
    if not fb_session.is_alive() or not fb_session.logged_in():
        raise HTTPException(400, "Chưa đăng nhập Facebook trong cửa sổ Chrome quản lý.")
    q = "720" if body.quality == "720" else "best"
    job = push("tai-fb", f"Tải {len(ids)} reel: {body.slug}",
               ["pipeline/fb_download.py", "--slug", body.slug,
                "--ids", ",".join(ids), "--quality", q])
    return {"job": job, "count": len(ids)}


def _fb_file(slug: str, rid: str, names: list):
    if not _FB_SLUG_RE.match(slug) or not _FB_ID_RE.match(rid):
        raise HTTPException(404)
    base = os.path.join(FB_ROOT, slug, "downloads", rid)
    for n in names:
        p = os.path.join(base, n)
        if os.path.isfile(p):
            return p
    raise HTTPException(404)


@app.get("/media/fb/{slug}/{rid}/video")
def media_fb_video(slug: str, rid: str):
    return FileResponse(_fb_file(slug, rid, ["video.mp4"]))


@app.get("/media/fb/{slug}/{rid}/thumb")
def media_fb_thumb(slug: str, rid: str):
    return FileResponse(_fb_file(slug, rid, ["thumb.jpg", "thumb.webp", "thumb.png"]))


@app.get("/media/fb-remake/{slug}/{fn}")
def media_fb_remake(slug: str, fn: str):
    """Phat video BAN LAM LAI (nut 'Xem lai' o pool 'Chua xep lich')."""
    if not _FB_SLUG_RE.match(slug or "") or "/" in fn or "\\" in fn or not fn.endswith(".mp4"):
        raise HTTPException(400, "tham so khong hop le")
    fp = os.path.abspath(os.path.join(FB_ROOT, slug, "remake", fn))
    if not os.path.isfile(fp):
        # Tuong thich NGUOC: video profile.php cu luu duoi facebook/auto/remake/ (bug _slug cu).
        alt = os.path.abspath(os.path.join(FB_ROOT, "auto", "remake", fn))
        if alt.startswith(os.path.abspath(FB_ROOT)) and os.path.isfile(alt):
            fp = alt
    if not (fp.startswith(os.path.abspath(FB_ROOT)) and os.path.isfile(fp)):
        raise HTTPException(404, "khong thay video")
    return FileResponse(fp)


# ══════════════════════════════════════════════════════════════════
#  ĐĂNG HÀNG LOẠT — đăng reel lên Page qua Graph API + lên lịch (FB-native)
#  Xem docs/quy-trinh-tham-khao-hoan-chinh.md. Token: keys.env FB_SYS_TOKEN.
# ══════════════════════════════════════════════════════════════════
_FB_WHITELIST = os.path.join(FB_ROOT, "_page_whitelist.json")


def _whitelist() -> list:
    return read_json(_FB_WHITELIST, []) or []


def _page_allowed(page_id: str) -> bool:
    wl = _whitelist()
    return (not wl) or (page_id in wl)     # rỗng = cho tất cả (kèm cảnh báo ở UI)


@app.get("/api/fb-post/pages")
def api_fbpost_pages():
    """Liệt kê page + quyền đăng + cờ 'allowed' (whitelist). KHÔNG kèm token.

    Live Graph có lúc bị chặn tạm ("API access blocked" khi gọi dồn) → FALLBACK về
    cache (_fb_pages.json) để UI/autopilot không trắng khi Graph hiccup."""
    r = fb_graph.refresh()
    if not r.get("pages"):                         # live rỗng/lỗi → dùng cache đã lưu
        cached = fb_graph.load_cache()
        if cached.get("pages"):
            cached = {k: v for k, v in cached.items() if k != "access_token"}
            cached["pages"] = [{k: v for k, v in p.items() if k != "access_token"}
                               for p in cached.get("pages", [])]
            cached["stale"] = True                 # đánh dấu dữ liệu cache (Graph tạm lỗi)
            r = cached
    wl = set(_whitelist())
    for p in r.get("pages", []):
        p["allowed"] = (not wl) or (p.get("id") in wl)
    r["whitelist_on"] = bool(wl)
    return r


_SUB_INFO_CACHE = {"t": 0.0, "data": None}


@app.get("/api/fb-post/subscription")
def api_fbpost_subscription(refresh: bool = False):
    """Goi thue bao 79AI + quota video/anh CON LAI (cache 60s de khoi goi API lien tuc)."""
    now = time.time()
    if not refresh and _SUB_INFO_CACHE["data"] is not None and now - _SUB_INFO_CACHE["t"] < 60:
        return _SUB_INFO_CACHE["data"]
    out = {"active": False}
    try:
        from gommo_client import GommoClient
        info = GommoClient().subscription()
        if info.get("status") == "ACTIVE":
            opt = info.get("options") or {}
            vm = int(opt.get("videoMonth") or 0); vu = int(opt.get("videoMonthUsage") or 0)
            im = int(opt.get("imageMonth") or 0); iu = int(opt.get("imageMonthUsage") or 0)
            out = {"active": True, "plan_name": info.get("plan_name"),
                   "video_month": vm, "video_used": vu, "video_left": max(0, vm - vu),
                   "image_month": im, "image_used": iu, "image_left": max(0, im - iu),
                   "concurrent": int(opt.get("concurrent") or 0),
                   "expired_time": info.get("expired_time")}
    except Exception as e:
        out = {"active": False, "error": str(e)[:120]}
    _SUB_INFO_CACHE.update(t=now, data=out)
    return out


@app.get("/api/app/version")
def api_app_version():
    """Phien ban tool hien tai (doc app/VERSION) + co dang chay duoi desktop khong."""
    v = "?"
    try:
        with open(os.path.join(APP_DIR, "VERSION"), encoding="utf-8") as f:
            v = f.read().strip() or "?"
    except Exception:
        pass
    return {"version": v, "under_desktop": bool(os.environ.get("CS_DESKTOP"))}


_APP_RESTART_FLAG = os.path.join(os.path.dirname(APP_DIR), "app-restart.flag")


@app.post("/api/app/restart")
def api_app_restart():
    """Nut 'Cap nhat & mo lai': ghi co -> desktop.py giam sat -> kill server con +
    os.execv desktop.py -> lan mo lai check_update() TU KEO ban moi tu GitHub -> nap code moi.
    will_restart=False khi chay DEV (khong co desktop) -> bao nguoi dung tu khoi dong lai."""
    under = bool(os.environ.get("CS_DESKTOP"))
    if under:
        try:
            with open(_APP_RESTART_FLAG, "w", encoding="utf-8") as f:
                f.write(str(int(time.time())))
        except Exception as e:
            raise HTTPException(500, "Không ghi được cờ khởi động lại: %s" % e)
    return {"ok": True, "will_restart": under}


@app.get("/api/fb-post/whitelist")
def api_fbpost_whitelist():
    return {"ids": _whitelist()}


class WhitelistReq(BaseModel):
    ids: list[str]


@app.post("/api/fb-post/whitelist")
def api_fbpost_whitelist_save(body: WhitelistReq):
    ids = [i for i in body.ids if _FB_ID_RE.match(i)]
    _write_json(_FB_WHITELIST, ids)
    return {"ok": True, "count": len(ids)}


@app.post("/api/fb-post/pages/refresh")
def api_fbpost_pages_refresh():
    """Nạp lại page từ token (mọi BM) — dùng khi vừa THÊM page vào BM.
    Fetch LIVE + lưu cache; page MỚI tự thêm vào whitelist (nếu đang bật whitelist)
    để dùng được NGAY, khỏi phải vào Page&Token tick tay."""
    old_ids = {p.get("id") for p in fb_graph.load_cache().get("pages", [])}
    r = fb_graph.refresh()                          # fetch_all (mọi token) + save_cache
    pages = r.get("pages", [])
    new_pages = [p for p in pages if p.get("id") and p.get("id") not in old_ids]
    # Nếu ĐANG bật whitelist (explicit) -> đảm bảo MỌI page đăng-được đều nằm trong đó
    # (token chỉ thấy page BM của mình) -> page vừa thêm dùng được NGAY. wl rỗng = đã allow-all.
    wl = _whitelist()
    added = []
    if wl:
        postable = [p["id"] for p in pages if p.get("can_post") and p.get("id")]
        merged = list(dict.fromkeys(wl + postable))
        if set(merged) != set(wl):
            missing = [p for p in pages if p.get("id") in set(merged) - set(wl)]
            added = [p.get("name") for p in missing]
            _write_json(_FB_WHITELIST, merged)
    return {"ok": bool(r.get("ok")), "count": r.get("count", 0), "me": r.get("me"),
            "new": [p.get("name") for p in new_pages], "whitelisted": added,
            "errors": r.get("errors", [])}


@app.get("/api/fb-post/videos")
def api_fbpost_videos():
    """Video sẵn sàng đăng: bản làm lại + reel đã tải."""
    out = []
    if os.path.isdir(FB_ROOT):
        for slug in os.listdir(FB_ROOT):
            rm = os.path.join(FB_ROOT, slug, "remake")
            if os.path.isdir(rm):
                for fn in os.listdir(rm):
                    # bo qua clip canh trung gian, chi lay video hoan chinh
                    if not fn.endswith(".mp4"):
                        continue
                    if fn.startswith(("scene", "canh1-", "_")) or "_clip" in fn:
                        continue
                    fp = os.path.join(rm, fn)
                    out.append({"label": f"{slug}/remake/{fn}", "path": fp,
                                "size": os.path.getsize(fp), "kind": "remake"})
    out.sort(key=lambda x: x["label"])
    return {"videos": out}


_TOK_DAYS = {"ts": 0, "data": {}}


def _token_days_by_bm() -> dict:
    """So ngay con lai cua token moi BM (debug_token). Cache 10' (tranh goi Graph doi).
    Gia tri: >0 so ngay | 0 sap het (<1 ngay) | -1 het han/khong hop le | 9999 vinh vien | None loi."""
    import urllib.parse as _up
    now = time.time()
    if now - _TOK_DAYS["ts"] < 600 and _TOK_DAYS["data"]:
        return _TOK_DAYS["data"]
    out = {}
    try:
        toks = fb_graph.load_tokens()
    except Exception:
        toks = []
    for tk in toks:
        name, token = tk.get("name"), tk.get("token")
        if not token:
            continue
        try:
            q = _up.quote(token)
            r = fb_graph._get("%s/debug_token?input_token=%s&access_token=%s"
                              % (fb_graph.GRAPH, q, q))
            data = r.get("data") or {}
            if data.get("is_valid") is False:
                out[name] = -1
            else:
                exp = data.get("expires_at") or 0
                out[name] = 9999 if not exp else int((exp - now) // 86400)
        except Exception:
            out[name] = None
    _TOK_DAYS["ts"] = now
    _TOK_DAYS["data"] = out
    return out


def _norm_pipe_status(it, now):
    """Nhan trang thai DONG NHAT cho 1 item pipeline — dung chung MOI bao cao
    (Tong quan page / Lich dang / San xuat) de khong lech nhau.
    Tra ve (code, label). 'da len lich' LUON phan giai thanh da_dang / chua_dang."""
    st = it.get("status") or ""
    when = it.get("when_ts") or 0
    if st == "error":     return ("loi", "Lỗi")
    if st == "queued":    return ("cho", "Chờ xử lý")
    if st == "downloading": return ("tai", "Đang tải nguồn")
    if st == "remaking":  return ("dung", "Đang dựng lại")
    if st == "scheduling": return ("lich", "Đang lên lịch")
    if st == "cancelled": return ("huy", "Đã hủy")
    if st == "done":
        if it.get("post_id"):
            if when and when > now:
                return ("chua_dang", "Chưa đăng")   # da len lich, cho toi gio
            return ("da_dang", "Đã đăng")
        return ("xong", "Xong · chưa lên lịch")
    return (st or "?", st or "?")


@app.get("/api/fb-post/fanpages")
def api_fbpost_fanpages():
    """Bang QUAN LY FANPAGE (giao dien moi): moi page = 1 dong gop
    nguon + backlog + nhip/ngay + kho dem + dang render + trang thai + autopilot.
    Gop tu nhieu nguon san co (KHONG goi Graph moi lan -> nhanh, ben)."""
    import fb_watch as _fw, fb_governor as _fg, fb_pipeline as _fp, fb_lister as _fl
    cache = fb_graph.load_cache()
    pages = cache.get("pages", []) or []
    wl = set(_whitelist())
    amap = {r.get("page_id"): r for r in (read_json(_FB_AUTOMAP, []) or [])}
    sched = read_json(_FB_SCHED, []) or []
    gov = _fg.load_config()
    per_page = int(gov.get("post_per_page_day", 2))
    est = int(gov.get("est_per_video", 7200))
    try:
        credit = _fg.can_produce(0).get("credit")
    except Exception:
        credit = None
    # video lam lai (kho dem) theo slug
    vids = []
    if os.path.isdir(FB_ROOT):
        for slug in os.listdir(FB_ROOT):
            rm = os.path.join(FB_ROOT, slug, "remake")
            if os.path.isdir(rm):
                for fn in os.listdir(rm):
                    if fn.endswith(".mp4") and not fn.startswith(("scene", "canh1-", "_")) \
                            and "_clip" not in fn and "SO-SANH" not in fn:
                        vids.append((slug, fn))
    sched_names = {s.get("video") for s in sched}
    try:
        pipe = _fp.recent(300)   # rộng hơn để đếm ĐÃ ĐĂNG / CHỜ / LỊCH đúng (cột hiển thị)
    except Exception:
        pipe = []
    tok_days = _token_days_by_bm()
    now = int(time.time())
    today = time.strftime("%Y-%m-%d")
    _src_index = {}   # cache slug -> {uid: reel} de map UID nguon -> views
    rows = []
    for p in pages:
        pid = p.get("id")
        if wl and pid not in wl:
            continue
        r = amap.get(pid, {})
        link = r.get("link", "")
        is_src = bool(link) and _fw.is_source(link)
        try:
            bl = _fw.backlog_status(link) if is_src else {}
        except Exception:
            bl = {}
        slug = _fl.page_slug(link) if link else ""
        today_ct = sum(1 for s in sched if s.get("page_id") == pid and s.get("when_ts")
                       and time.strftime("%Y-%m-%d", time.localtime(s["when_ts"])) == today)
        upcoming = sorted([{"when_ts": s.get("when_ts"), "video": s.get("video")}
                           for s in sched if s.get("page_id") == pid and (s.get("when_ts") or 0) > now],
                          key=lambda x: x["when_ts"] or 0)
        ahead = len(upcoming)
        # buf (thành phẩm chờ đăng) tính SAU khi có p_items — để loại file đã có item
        # pipeline (đã đăng / đã lịch / lỗi) ra khỏi "chờ đăng" (tránh số ẢO). Xem bên dưới.
        # "dang render" = co entry pipeline ACTIVE + moi cap nhat <20' (tranh entry cu
        # ket lai "remaking" khi process bi kill khong cap nhat -> bao render gia).
        prod_it = next((it for it in pipe if it.get("page_id") == pid and it.get("status")
                        in ("downloading", "remaking", "scheduling")
                        and (it.get("ts") or it.get("updated") or 0) > now - 1200), None)
        producing = bool(prod_it)
        days = tok_days.get(p.get("bm"))
        enabled = bool(r.get("enabled"))
        if not p.get("can_post"):
            st = "noperm"
        elif days is not None and days < 0:
            st = "token_exp"
        elif not link:
            st = "unset"
        elif producing:
            st = "producing"
        elif enabled:
            st = "running"
        else:
            st = "paused"
        # ── Danh sach "bai dang cao" cua page: pipeline loc theo page_id ──
        # Moi item: UID bai nguon + views nguon + log (step) + trang thai DONG NHAT.
        idx_reels = _src_index.get(slug)
        if idx_reels is None:
            idx_reels = ((read_json(os.path.join(FB_ROOT, slug, "index.json"), {}) or {}).get("reels", {}) or {}) if slug else {}
            _src_index[slug] = idx_reels
        # 1 reel nguon = 1 dong (gop cac lan thu lai) — giu trang thai QUAN TRONG NHAT.
        _rank = {"da_dang": 6, "chua_dang": 5, "tai": 4, "dung": 4, "lich": 4,
                 "cho": 3, "xong": 2, "loi": 1, "huy": 0}
        best, loose = {}, []
        for it in pipe:
            if it.get("page_id") != pid:
                continue
            code, label = _norm_pipe_status(it, now)
            uid = it.get("reel") or ""
            src = idx_reels.get(uid) or {}
            # File video da dung cho reel nay (neu co) -> nut ▶ xem lai.
            vfn = next((fn for (sl, fn) in vids if sl == slug and uid and fn.startswith(uid)), "") if slug else ""
            row = {
                "id": it.get("id"), "uid": uid, "link": it.get("link") or "",
                "status_code": code, "status_label": label,
                "step": it.get("step") or "", "error": it.get("error") or "",
                "post_id": it.get("post_id") or "", "video_id": it.get("video_id") or "",
                "when_ts": it.get("when_ts") or 0, "ts": it.get("ts") or 0,
                "kind": it.get("kind") or "auto", "pmode": it.get("pmode") or "",
                "views": src.get("views"), "thumb": src.get("thumbnail"),
                "video": vfn, "slug": slug,
            }
            if not uid:
                loose.append(row)
                continue
            prev = best.get(uid)
            if prev is None or (_rank.get(code, 0), row["ts"]) >= (_rank.get(prev["status_code"], 0), prev["ts"]):
                best[uid] = row
        p_items = list(best.values()) + loose
        p_items.sort(key=lambda x: x["ts"], reverse=True)
        # BUFFER = file thành phẩm KHÔNG có item pipeline (làm tay ở Xưởng) + chưa lịch.
        # File nào đã có item pipeline (uid trùng: đã đăng / đã lịch / lỗi) thì KHÔNG đếm ở
        # đây nữa — nó đã được p_items đại diện (chống số ẢO "chờ đăng" cho video đã đăng).
        tracked = {x["uid"] for x in p_items if x.get("uid")}
        buf_items = ([fn for (sl, fn) in vids if sl == slug and fn not in sched_names
                      and not any(fn.startswith(u) for u in tracked)] if slug else [])
        buf = len(buf_items)
        # 4 cột đều SUY TỪ pipeline (khớp đúng các sub-tab — không lấy số file đĩa rời).
        # CHỜ ĐĂNG (đăng luôn) vs ĐÃ LÊN LỊCH (hẹn giờ): đều là bài đã làm, lịch tương lai
        # (chua_dang), tách theo Ý ĐỊNH người dùng (pmode). Buffer làm-tay = chờ đăng.
        waiting = buf + sum(1 for x in p_items
                            if x["status_code"] == "chua_dang" and x.get("pmode") != "schedule")
        scheduled = sum(1 for x in p_items
                        if x["status_code"] == "chua_dang" and x.get("pmode") == "schedule")
        posted = sum(1 for x in p_items if x["status_code"] == "da_dang")
        # ĐÃ SẢN XUẤT = TỔNG thành phẩm cho page = đã đăng + đã lịch + chờ đăng
        # (mỗi cái đều tìm thấy trong 1 sub-tab → không còn số ảo).
        produced = posted + scheduled + waiting
        rows.append({
            "id": pid, "name": p.get("name"), "bm": p.get("bm"),
            "picture": p.get("picture"),
            "followers": p.get("followers_count") or p.get("fan_count"),
            "can_post": bool(p.get("can_post")), "token_days": days,
            "source": link, "source_slug": slug,
            "backlog_remain": bl.get("remain"), "backlog_total": bl.get("total"),
            "pace_today": today_ct, "pace_target": per_page, "ahead": ahead,
            "waiting": waiting, "scheduled": scheduled,
            "produced": produced, "posted": posted,
            "buffer": buf, "producing": producing, "render_step": (prod_it or {}).get("step"),
            "credit_est": est, "enabled": enabled, "status": st,
            "audio": r.get("audio", "B"), "clip": r.get("clip", "veo_3_1"),
            "automap_id": r.get("id"),
            "detail": {
                "buffer_items": [fn.replace("-lamlai.mp4", "").replace(".mp4", "") for fn in buf_items[:6]],
                "upcoming": upcoming[:5],
                "items": p_items[:40],
            },
        })
    return {"fanpages": rows, "credit": credit, "gov": gov,
            # thành phẩm chờ đăng = tổng "chờ đăng" các page (khớp cột — không đếm file đã đăng)
            "buffer_total": sum(r["waiting"] for r in rows),
            "whitelist_on": bool(wl)}


class FbScheduleReq(BaseModel):
    page_id: str
    video: str            # duong dan tuyet doi (tu /api/fb-post/videos)
    description: str = ""
    when_ts: int = 0      # unix giay; 0 = dang ngay


def _do_schedule(page_id: str, video: str, description: str, when_ts: int) -> dict:
    """Đẩy 1 job đăng reel + ghi kho lịch. Raise HTTPException nếu lỗi."""
    if not _FB_ID_RE.match(page_id):
        raise HTTPException(400, "page_id không hợp lệ.")
    vp = os.path.abspath(video)
    if not (vp.startswith(os.path.abspath(FB_ROOT)) and os.path.isfile(vp)):
        raise HTTPException(400, "File video không hợp lệ: " + os.path.basename(video))
    if when_ts and when_ts < int(time.time()) + 540:
        raise HTTPException(400, "Giờ lên lịch phải cách hiện tại ít nhất 10 phút.")
    pg = next((p for p in fb_graph.load_cache().get("pages", [])
               if p.get("id") == page_id), None)
    if not pg:
        raise HTTPException(400, "Page không có trong danh sách (bấm Làm mới).")
    if not pg.get("can_post"):
        raise HTTPException(400, "Page thiếu quyền đăng (CREATE_CONTENT).")
    if not _page_allowed(page_id):
        raise HTTPException(400, "Page không nằm trong danh sách ĐƯỢC DÙNG.")
    # Tus: neu khong nhap -> TU LAY caption cua reel nguon (facebook/<slug>/downloads/<rid>/caption.txt)
    desc = description or ""
    if not desc.strip():
        m = re.search(r"[/\\]([^/\\]+)[/\\]remake[/\\](\d+)-lamlai\.mp4$", vp)
        if m:
            cap = os.path.join(FB_ROOT, m.group(1), "downloads", m.group(2), "caption.txt")
            if os.path.isfile(cap):
                # Loc link Shopee + hashtag quang ba kenh nguon truoc khi dang lai
                desc = fb_publish.clean_caption(open(cap, encoding="utf-8").read())
    desc_dir = os.path.join(FB_ROOT, "_post_desc")
    os.makedirs(desc_dir, exist_ok=True)
    desc_file = os.path.join(desc_dir, f"{page_id}_{int(time.time()*1000)}.txt")
    with open(desc_file, "w", encoding="utf-8") as f:
        f.write(desc)
    cmd = ["pipeline/fb_publish.py", "--page-id", page_id, "--video", vp,
           "--desc-file", desc_file]
    if when_ts:
        cmd += ["--when-ts", str(int(when_ts))]
    when_lbl = ("lên lịch " + time.strftime("%H:%M %d/%m", time.localtime(when_ts))
                if when_ts else "đăng ngay")
    job = push("dang-fb", f"Đăng reel ({pg['name']}, {when_lbl})", cmd)
    sched = read_json(_FB_SCHED, []) or []
    sched.append({"id": f"s{int(time.time()*1000)}", "page_id": page_id,
                  "page": pg["name"], "video": os.path.basename(vp),
                  "when_ts": int(when_ts) if when_ts else 0,
                  "status": "scheduled", "created": int(time.time())})
    _write_json(_FB_SCHED, sched)
    return {"job": job, "page": pg["name"], "when": when_lbl}


@app.post("/api/fb-post/schedule")
def api_fbpost_schedule(body: FbScheduleReq):
    return _do_schedule(body.page_id, body.video, body.description, body.when_ts)


class ScheduleItem(BaseModel):
    page_id: str
    video: str
    description: str = ""
    when_ts: int = 0


@app.post("/api/fb-post/schedule/bulk")
def api_fbpost_schedule_bulk(items: list[ScheduleItem]):
    if not items:
        raise HTTPException(400, "Chưa chọn video nào.")
    done, errs = [], []
    for it in items:
        try:
            r = _do_schedule(it.page_id, it.video, it.description, it.when_ts)
            done.append(r["page"])
        except HTTPException as e:
            errs.append(f"{os.path.basename(it.video)}: {e.detail}")
    return {"done": len(done), "errors": errs}


_FB_SCHED = os.path.join(FB_ROOT, "_scheduled.json")


def _write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


@app.get("/api/fb-post/scheduled")
def api_fbpost_scheduled():
    items = read_json(_FB_SCHED, []) or []
    items.sort(key=lambda x: x.get("when_ts") or x.get("created") or 0)
    return {"items": items}


@app.get("/api/fb-post/summary")
def api_fbpost_summary():
    cache = fb_graph.load_cache()
    pages = cache.get("pages", [])
    postable = [p for p in pages if p.get("can_post")]
    vids = api_fbpost_videos()["videos"]
    sched = read_json(_FB_SCHED, []) or []
    now = int(time.time())
    upcoming = [s for s in sched if (s.get("when_ts") or 0) >= now]
    # dem reel da tai (nguon)
    downloaded = 0
    if os.path.isdir(FB_ROOT):
        for slug in os.listdir(FB_ROOT):
            idxp = os.path.join(FB_ROOT, slug, "index.json")
            if os.path.isfile(idxp):
                downloaded += len((read_json(idxp, {}) or {}).get("reels", {}))
    # ngan sach 79ai (neu doc duoc nhanh; None neu khong)
    return {
        "pages": len(pages), "postable": len(postable),
        "videos": len(vids), "downloaded": downloaded,
        "scheduled": len(upcoming), "scheduled_all": len(sched),
        "token_ok": cache.get("ok", False), "me": cache.get("me"),
        "cached_at": cache.get("cached_at"),
    }


# ── Ho so Chrome (dang nhap nhieu tai khoan FB) ──
@app.get("/api/fb-post/profiles")
def api_fbpost_profiles():
    return {"profiles": fb_profiles.list_profiles()}


class ProfileReq(BaseModel):
    name: str = ""


@app.post("/api/fb-post/profiles")
def api_fbpost_profile_create(body: ProfileReq):
    if not (body.name or "").strip():
        raise HTTPException(400, "Cần tên tài khoản.")
    p = fb_profiles.create(body.name)
    try:
        fb_profiles.open_profile(p["name"])
    except Exception as exc:
        raise HTTPException(400, str(exc))
    return p


@app.post("/api/fb-post/profiles/open")
def api_fbpost_profile_open(body: ProfileReq):
    try:
        return fb_profiles.open_profile(body.name)
    except Exception as exc:
        raise HTTPException(400, str(exc))


class TokenReq(BaseModel):
    token: str


@app.post("/api/fb-post/token")
def api_fbpost_token(body: TokenReq):
    """Lưu token 'chính' (keys.env) + thêm vào danh sách BM + làm mới cache."""
    tok = (body.token or "").strip()
    if not tok.startswith("EAA"):
        raise HTTPException(400, "Token không hợp lệ (phải bắt đầu EAA…).")
    r = fb_graph.add_token("chính", tok)
    if not r.get("ok"):
        raise HTTPException(400, "Token không dùng được: " + str(r.get("error")))
    _write_key_env("FB_SYS_TOKEN", tok)
    os.environ["FB_SYS_TOKEN"] = tok
    fb_graph.save_cache(fb_graph.fetch_all())
    return {"ok": True, "me": r.get("me"), "count": r.get("count")}


@app.get("/api/fb-post/tokens")
def api_fbpost_tokens():
    """Danh sách BM/token (KHÔNG kèm giá trị token)."""
    return {"tokens": [{"name": t.get("name")} for t in fb_graph.load_tokens()]}


# ── So lieu bai da dang (viral) — Graph /{page}/videos (do THAT, 1 call/page) ──
@app.get("/api/fb-post/insights")
def api_fbpost_insights():
    """Tong hop viral tu cache (KHONG goi Graph). Rong -> can bam Đồng bộ."""
    try:
        viral = int(_app_config().get("viral_views", 100000))
        pages = fb_graph.load_cache().get("pages", [])
        out = [fb_insights.page_summary(p["id"], viral) for p in pages if p.get("id")]
        return {"viral_views": viral, "pages": out}
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Đọc số liệu lỗi: {type(e).__name__}: {e}")


@app.get("/api/fb-post/insights/posts")
def api_fbpost_insights_posts(page_id: str = ""):
    """Bai da dang (tu cache) — cho Thu vien noi dung. page_id rong = gop MOI page."""
    try:
        viral = int(_app_config().get("viral_views", 100000))
        pages = fb_graph.load_cache().get("pages", [])
        if page_id:
            pages = [p for p in pages if p.get("id") == page_id]
        out = []
        for p in pages:
            d = fb_insights.page_posts(p["id"])
            for v in d.get("posts", []):
                out.append({**v, "page_id": p["id"], "page_name": p.get("name", "")})
        return {"viral_views": viral, "count": len(out),
                "pages": [{"id": p["id"], "name": p.get("name", "")} for p in fb_graph.load_cache().get("pages", [])],
                "posts": out}
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Đọc thư viện lỗi: {type(e).__name__}: {e}")


class InsightsSyncReq(BaseModel):
    page_id: str = ""


@app.post("/api/fb-post/insights/sync")
def api_fbpost_insights_sync(body: InsightsSyncReq):
    """Quet Graph /{page}/videos -> cache. page_id rong = quet TAT CA page."""
    try:
        viral = int(_app_config().get("viral_views", 100000))
        pages = fb_graph.load_cache().get("pages", [])
        if not pages:
            pr = fb_graph.fetch_pages()
            if pr.get("ok"):
                pages = pr["pages"]
        if not pages:
            raise HTTPException(400, "Chưa có page nào — dán token Facebook ở tab Cài đặt rồi Làm mới.")
        if body.page_id:
            pages = [p for p in pages if p.get("id") == body.page_id]
            if not pages:
                raise HTTPException(404, "Không thấy page.")
        return fb_insights.sync_all(pages, viral_views=viral, max_videos=200)
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Đồng bộ lỗi: {type(e).__name__}: {e}")


class BmTokenReq(BaseModel):
    name: str
    token: str


@app.post("/api/fb-post/tokens")
def api_fbpost_tokens_add(body: BmTokenReq):
    tok = (body.token or "").strip()
    if not tok.startswith("EAA"):
        raise HTTPException(400, "Token không hợp lệ (EAA…).")
    r = fb_graph.add_token(body.name or "BM", tok)
    if not r.get("ok"):
        raise HTTPException(400, "Token không dùng được: " + str(r.get("error")))
    fb_graph.save_cache(fb_graph.fetch_all())
    return r


@app.delete("/api/fb-post/tokens/{name}")
def api_fbpost_tokens_del(name: str):
    fb_graph.remove_token(name)
    fb_graph.save_cache(fb_graph.fetch_all())
    return {"ok": True}


# ── LẤY TOKEN BÁN TỰ ĐỘNG: mở đúng trang → user bấm Generate → app ĐỌC token từ ô ──
#  ĐO THẬT (xem fb_token_grab.py): token nhúng sẵn trong trang Meta là first-party,
#  Graph công khai từ chối → KHÔNG cào-rồi-đúc được. Cách chạy được: user bấm Generate
#  (thao tác OAuth phải người thật), app đọc token thật từ ô rồi kiểm + lưu.
@app.post("/api/fb-post/token/open-page")
def api_fbpost_token_openpage():
    """Mở Chrome quản lý + trang tạo System User token."""
    if not fb_session.is_alive():
        try:
            fb_session.open_session()
            time.sleep(1.0)
        except Exception as exc:
            raise HTTPException(400, "Không mở được Chrome quản lý: " + str(exc))
    try:
        fb_token_grab.open_token_page()
    except Exception as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "logged_in": fb_session.logged_in(),
            "url": fb_token_grab.TOKEN_PAGE}


class ReadTokenReq(BaseModel):
    name: str = "System User"


@app.post("/api/fb-post/token/read-browser")
def api_fbpost_token_readbrowser(body: ReadTokenReq):
    """Đọc token EAA từ ô trên trình duyệt → kiểm hợp lệ (Graph) → lưu. Không hết hạn."""
    if not fb_session.is_alive():
        raise HTTPException(400, "Chrome quản lý chưa mở — bấm 'Mở trang tạo token' trước.")
    r = fb_token_grab.read_tokens_from_browser()
    if not r.get("ok"):
        raise HTTPException(400, str(r.get("error")))
    toks = r.get("tokens", [])
    if not toks:
        raise HTTPException(400, "Chưa thấy token nào trên trình duyệt. Bấm 'Generate new token' "
                                 "trong cửa sổ Chrome (chọn App + tick pages_manage_posts) rồi thử lại.")
    # kiểm từng token, lấy cái Graph chấp nhận (bỏ token first-party bị từ chối)
    good, errs = None, []
    for tk in toks:
        chk = fb_graph.fetch_pages(tk)
        if chk.get("ok"):
            good = (tk, chk)
            break
        errs.append(str(chk.get("error")))
    if not good:
        raise HTTPException(400, "Đọc được token nhưng Graph từ chối (%s). Đảm bảo là token "
                                 "System User vừa Generate, có quyền pages_show_list." % "; ".join(errs[:2]))
    tok, chk = good
    name = (body.name or "System User").strip()
    add = fb_graph.add_token(name, tok)
    if not add.get("ok"):
        raise HTTPException(400, "Token hợp lệ nhưng lưu lỗi: " + str(add.get("error")))
    _write_key_env("FB_SYS_TOKEN", tok)
    os.environ["FB_SYS_TOKEN"] = tok
    fb_graph.save_cache(fb_graph.fetch_all())
    return {"ok": True, "me": add.get("me"), "count": add.get("count"), "name": name}


# ── XƯỞNG LÀM LẠI: reel đã tải → làm lại (không đăng) → ra video sẵn sàng lên lịch ──
_FB_REEL_RE = re.compile(r"/(?:reel|videos)/(\d+)")


def _link_reel_id(link: str) -> str:
    m = _FB_REEL_RE.search(link or "") or re.search(r"[?&]v=(\d+)", link or "")
    return m.group(1) if m else ""


def _link_slug(link: str) -> str:
    m = re.search(r"facebook\.com/([^/?#]+)", link or "")
    s = m.group(1) if m else "auto"
    return "auto" if s in ("reel", "watch", "profile.php", "share") else s


@app.get("/api/fb-post/remake/sources")
def api_fbpost_remake_sources():
    """Reel ĐÃ TẢI (có video.mp4) — nguồn để làm lại. Cờ 'remade' nếu đã có bản."""
    out = []
    if os.path.isdir(FB_ROOT):
        for slug in os.listdir(FB_ROOT):
            dl = os.path.join(FB_ROOT, slug, "downloads")
            if not os.path.isdir(dl):
                continue
            for rid in os.listdir(dl):
                vp = os.path.join(dl, rid, "video.mp4")
                if not os.path.isfile(vp):
                    continue
                caption = ""
                cp = os.path.join(dl, rid, "caption.txt")
                if os.path.isfile(cp):
                    caption = open(cp, encoding="utf-8").read().strip()
                rm = os.path.join(FB_ROOT, slug, "remake", f"{rid}-lamlai.mp4")
                out.append({
                    "slug": slug, "rid": rid, "size": os.path.getsize(vp),
                    "caption": caption[:140],
                    "remade": os.path.isfile(rm) and os.path.getsize(rm) > 1000,
                })
    out.sort(key=lambda x: (x["remade"], x["slug"], x["rid"]))
    return {"sources": out}


# Cac kieu anh hop le (khop fb_remake.STYLES — khong import fb_remake o top cho nhe).
_REMAKE_STYLES = {"real", "cartoon", "hoat_hinh", "chan_dung_dien_anh", "anime",
                  "mau_nuoc", "pixar_3d", "son_dau", "ngam_doi", "theo_mo_ta"}


class RemakeRunReq(BaseModel):
    slug: str = ""
    rid: str = ""
    link: str = ""            # thay cho slug/rid: dán link → tự tải rồi làm lại
    n_scenes: int = 6
    clip: str = "veo_3_1"     # veo_3_1 | wan_2_2
    audio: str = "B"          # B giữ tiếng gốc | A giọng + nhạc mới
    style: str = "real"       # kiểu ảnh vẽ lại (real/cartoon/...) — từ Danh Sách Nguồn hoặc tay


def _enqueue_remake(slug, rid, n, clip, audio, style, link=""):
    """Xep 1 job lam lai reel. Da tai -> job thang; chua tai -> chuoi tai+lam lai.
    Tra dict {item_id, downloaded, job/chain} hoac {item_id, error} (KHONG raise -> dung cho bulk)."""
    n = max(3, min(12, int(n)))
    clip = clip if clip in ("wan_2_2", "veo_3_1", "grok_video_heavy") else "veo_3_1"
    audio = "A" if audio == "A" else "B"
    style = style if style in _REMAKE_STYLES else "real"
    src = os.path.join(FB_ROOT, slug, "downloads", rid, "video.mp4")
    out = os.path.join(FB_ROOT, slug, "remake", f"{rid}-lamlai.mp4")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    item_id = f"r{int(time.time()*1000)}{rid[-3:]}"
    fb_pipeline.add(item_id, f"{slug}/{rid}", link or f"/reel/{rid}", reel=rid,
                    kind="remake", status="remaking", step="đang xếp hàng",
                    audio=audio, clip=clip, n_scenes=n)
    remake_cmd = ["pipeline/fb_remake.py", "--video", src, "--out", out,
                  "--scenes", str(n), "--clip", clip, "--audio", audio,
                  "--style", style, "--item-id", item_id]
    if os.path.isfile(src):
        job = push("lam-lai-fb", f"Làm lại: {slug}/{rid}", remake_cmd)
        return {"item_id": item_id, "downloaded": True, "job": job}
    if not (fb_session.is_alive() and fb_session.logged_in()):
        fb_pipeline.update(item_id, status="error",
                           error="Chưa tải reel & Chrome chưa đăng nhập để tải.")
        return {"item_id": item_id, "error": "chrome_offline"}
    ch = push_chain([
        ("tai-fb", f"Tải reel: {slug}/{rid}",
         ["pipeline/fb_download.py", "--slug", slug, "--ids", rid, "--quality", "best"]),
        ("lam-lai-fb", f"Làm lại: {slug}/{rid}", remake_cmd),
    ])
    return {"item_id": item_id, "downloaded": False, "chain": ch}


@app.post("/api/fb-post/remake/run")
def api_fbpost_remake_run(body: RemakeRunReq):
    """Làm lại 1 reel (KHÔNG đăng). Nguồn: slug/rid đã tải, hoặc link (tự tải trước)."""
    slug, rid, link = body.slug, body.rid, (body.link or "").strip()
    if link and not (slug and rid):
        rid = _link_reel_id(link)
        slug = _link_slug(link)
        if not rid:
            raise HTTPException(400, "Link không có reel id (dạng /reel/<số>).")
    if not (_FB_SLUG_RE.match(slug or "") and _FB_ID_RE.match(rid or "")):
        raise HTTPException(400, "Nguồn không hợp lệ (slug/reel id).")
    r = _enqueue_remake(slug, rid, body.n_scenes, body.clip, body.audio, body.style, link)
    if r.get("error") == "chrome_offline":
        raise HTTPException(400, "Reel chưa tải. Mở Chrome quản lý + đăng nhập, hoặc tải "
                                 "trước ở tab Tải video FB.")
    return {"ok": True, **r}


# ── DANH SÁCH NGUỒN — khâu trung gian cào→làm lại (docs/danh-sach-nguon-ke-hoach.md) ──
class SourceListReq(BaseModel):
    slug: str = ""


class SourcePushReq(BaseModel):
    slug: str
    rids: list[str] = []
    clip: str = "grok_video_heavy"
    style: str = "real"
    audio: str = "B"
    n_scenes: int = 7


@app.get("/api/fb-post/source-list")
def api_source_list(slug: str):
    """Lưới Danh Sách Nguồn 1 page: reels (từ index.json đã cào) + phân tích lô + ước tính."""
    if not _FB_SLUG_RE.match(slug or ""):
        raise HTTPException(400, "slug không hợp lệ.")
    g = fb_source_list.grid(slug)
    g["credit_per_reel"] = fb_source_list.credit_per_reel(
        (g.get("analysis") or {}).get("clip", "grok_video_heavy"), 7)
    return g


@app.get("/api/fb-post/source-list/all")
def api_source_list_all():
    """Phan tich + so reel MOI page nguon 1 luc (xem TAT CA, khong bam tung page)."""
    rows = read_json(_FB_AUTOMAP, []) or []
    store = fb_source_list.analyses()
    seen, out = set(), []
    for r in rows:
        link = (r.get("link") or "").strip()
        if not link:
            continue
        slug = fb_lister.page_slug(link)
        if slug in seen:
            continue
        seen.add(slug)
        idx = fb_lister.load_index(slug)
        a = store.get(slug)
        out.append({
            "slug": slug, "page_name": r.get("page_name", ""),
            "page_id": r.get("page_id", ""),
            "count": len(idx.get("reels") or {}),
            "analysis": a,
            "credit_per_reel": fb_source_list.credit_per_reel(
                (a or {}).get("clip", "grok_video_heavy"), 7) if a else None,
        })
    return {"pages": out}


@app.post("/api/fb-post/source-list/analyze")
def api_source_list_analyze(body: SourceListReq):
    """AI phân tích SÂU (nhiều khung + lời thoại) → sản xuất/định dạng/màu/kiểu ảnh/remakeable.
    TỰ ĐIỀN 'kiểu ảnh' (style) vào bảng Nguồn & Kho đệm (automap) — người dùng chỉnh lại được.
    Tải video mẫu (0 credit 79AI; video dùng lại lúc dựng); ~1 vision + 1 whisper/page."""
    if not _FB_SLUG_RE.match(body.slug or ""):
        raise HTTPException(400, "slug không hợp lệ.")
    try:
        a = fb_source_list.analyze_batch(body.slug)
    except Exception as e:
        raise HTTPException(400, f"Phân tích lỗi: {e}")
    # TU DIEN kieu anh vao automap (row co link -> slug == body.slug). Nguoi dung chinh lai + Luu.
    filled = 0
    style = a.get("kieu_anh")
    if style:
        rows = read_json(_FB_AUTOMAP, []) or []
        for r in rows:
            if fb_lister.page_slug(r.get("link", "")) == body.slug:
                r["style"] = style
                filled += 1
        if filled:
            _write_json(_FB_AUTOMAP, rows)
    return {"ok": True, "analysis": a, "style_filled": filled}


@app.post("/api/fb-post/source-list/push")
def api_source_list_push(body: SourcePushReq):
    """Đẩy reel đã tick sang Xưởng làm lại kèm preset (kiểu ảnh + model + audio)."""
    if not _FB_SLUG_RE.match(body.slug or ""):
        raise HTTPException(400, "slug không hợp lệ.")
    rids = [r for r in (body.rids or []) if _FB_ID_RE.match(r or "")]
    if not rids:
        raise HTTPException(400, "Chưa chọn reel hợp lệ.")
    enq, err = [], []
    for rid in rids:
        r = _enqueue_remake(body.slug, rid, body.n_scenes, body.clip, body.audio, body.style)
        (err if r.get("error") else enq).append(rid)
    if not enq and err:
        raise HTTPException(400, "Chrome chưa đăng nhập để tải reel chưa có sẵn — mở tab Tài khoản.")
    return {"ok": True, "enqueued": len(enq), "failed": len(err)}


class RemakeDelReq(BaseModel):
    slug: str
    rid: str


@app.post("/api/fb-post/remake/delete")
def api_fbpost_remake_delete(body: RemakeDelReq):
    """Xoá bản LÀM LẠI (giữ reel gốc đã tải). Dọn cả thư mục .work."""
    if not (_FB_SLUG_RE.match(body.slug or "") and _FB_ID_RE.match(body.rid or "")):
        raise HTTPException(400, "slug/rid không hợp lệ.")
    out = os.path.join(FB_ROOT, body.slug, "remake", f"{body.rid}-lamlai.mp4")
    removed = False
    if os.path.isfile(out):
        os.remove(out); removed = True
    work = out + ".work"
    if os.path.isdir(work):
        import shutil
        shutil.rmtree(work, ignore_errors=True)
    return {"ok": True, "removed": removed}


class RemakeDelFileReq(BaseModel):
    slug: str
    fn: str


@app.post("/api/fb-post/remake/delete-file")
def api_fbpost_remake_delete_file(body: RemakeDelFileReq):
    """Xoa 1 file lam lai theo TEN file (xu ly ca -FIX/SO-SANH/video-lam-lai.mp4
    ma delete theo rid khong nhan). Chi trong FB_ROOT/*/remake."""
    if not (_FB_SLUG_RE.match(body.slug or "") and body.fn and "/" not in body.fn
            and "\\" not in body.fn and body.fn.endswith(".mp4")):
        raise HTTPException(400, "slug/fn không hợp lệ.")
    fp = os.path.abspath(os.path.join(FB_ROOT, body.slug, "remake", body.fn))
    if not fp.startswith(os.path.abspath(FB_ROOT)):
        raise HTTPException(400, "đường dẫn không hợp lệ.")
    removed = False
    if os.path.isfile(fp):
        os.remove(fp); removed = True
    work = fp + ".work"
    if os.path.isdir(work):
        import shutil
        shutil.rmtree(work, ignore_errors=True)
    return {"ok": True, "removed": removed}


# ── Tự động theo page: mapping {page ↔ link nguồn} + chạy hàng loạt ──
_FB_AUTOMAP = os.path.join(FB_ROOT, "_automap.json")
# Trạng thái 1 lượt chạy (Star) mỗi page: {pid: {"since": ts_bắt_đầu, "target": số_bài}}
_FB_RUNSTATE = os.path.join(FB_ROOT, "_runstate.json")


# Cửa sổ đọc pipeline DÙNG CHUNG cho _run_made + active_pages (tránh lệch cửa sổ → đếm sai).
_PIPE_WINDOW = 500


def _run_made(pid: str, since: int) -> int:
    """Số bài ĐÃ LÀM cho page (từ lúc bắt đầu lượt) — không tính bài lỗi/hủy.
    Đếm theo `cts` (giờ TẠO bất biến), KHÔNG dùng `ts` (bị update ghi đè mỗi lần đổi trạng thái
    → job cũ hoàn tất sau khi bắt đầu lượt mới sẽ bị đếm nhầm)."""
    return sum(1 for it in fb_pipeline.recent(_PIPE_WINDOW)
               if it.get("page_id") == pid and (it.get("cts") or it.get("ts") or 0) >= since
               and it.get("status") not in ("error", "cancelled"))


def _hhmm_base(cfg: dict, since: int) -> int:
    """Mốc unix của giờ post_hhmm vào ngày (NGÀY BẮT ĐẦU LƯỢT `since` + day_offset).
    Neo theo `since` (không phải now) → nhiều bài trải qua nửa đêm vẫn đúng ngày đã chọn.
    Nếu đã qua → dời sang ngày kế tiếp cho hợp lệ FB."""
    from datetime import datetime, timedelta
    try:
        hh, mm = [int(x) for x in str(cfg.get("post_hhmm", "08:00")).split(":")]
    except Exception:
        hh, mm = 8, 0
    off = max(0, int(cfg.get("post_day_offset", 1)))
    anchor = datetime.fromtimestamp(since or int(time.time()))
    dt = (anchor + timedelta(days=off)).replace(hour=hh, minute=mm, second=0, microsecond=0)
    ts = int(dt.timestamp())
    now = int(time.time())
    while ts < now + 660:      # FB cần >=10' tương lai
        ts += 86400
    return ts


def _compute_slot(cfg: dict, since: int, made: int):
    """(post_mode_gửi_fb_auto, when_ts). Bài thứ `made` (0-based).
    now: bài đầu đăng ngay (0), bài sau = since + made*gap. schedule: hhmm(since) + made*gap."""
    now = int(time.time())
    gap = max(1, int(cfg.get("gap_min", 60))) * 60
    if cfg.get("post_mode") != "schedule":       # đăng luôn
        if made <= 0:
            return "now", 0                       # bài đầu: đăng ngay
        target = (since or now) + made * gap
    else:
        target = _hhmm_base(cfg, since) + made * gap
    if target < now + 660:
        target = now + 660
    return "schedule", int(target)


class AutoRow(BaseModel):
    id: str = ""
    page_id: str = ""
    page_name: str = ""
    link: str = ""
    audio: str = "B"          # A | B
    clip: str = "veo_3_1"   # veo_3_1 (mặc định, 1080p, gói bao free) | grok_video_heavy | wan_2_2
    style: str = "real"       # real (giống thật, MẶC ĐỊNH) | cartoon (hoạt hình màu nước)
    when_ts: int = 0
    desc: str = ""
    enabled: bool = False     # bật autopilot (cron) cho dòng này


@app.get("/api/fb-post/video-models")
def api_fbpost_video_models(refresh: bool = False):
    """Model VIDEO 79AI cho ô 'Kiểu video' (Nguồn & Kho đệm). Chỉ model i2v (nhận ảnh
    khung đầu = start_image) vì làm lại là image-to-video; model t2v/cần-video-vào bỏ qua
    (chọn cũng fail → rơi fallback). Giá = 1 clip ~6s (ước tính cho ô Credit)."""
    try:
        vmodels = _video_models(force=refresh)
    except Exception as exc:
        raise HTTPException(503, f"Không lấy được model video 79AI: {exc}")
    out = []
    for m in vmodels:
        if not m.get("start_image"):
            continue
        dur6 = _pick_dur(m.get("durations") or [], 6.0)
        modes = m.get("modes") or []
        res = m.get("resolutions") or []
        price = _video_price(m, modes[0]["value"] if modes else None,
                             res[0]["value"] if res else None, dur6 or 6)
        out.append({"model": m["model"], "name": m.get("name") or m["model"],
                    "price": price or m.get("price") or 0})
    out.sort(key=lambda x: (x["price"] or 0))
    return {"models": out}


@app.get("/api/fb-post/automap")
def api_fbpost_automap():
    return {"rows": read_json(_FB_AUTOMAP, []) or []}


@app.post("/api/fb-post/automap")
def api_fbpost_automap_save(rows: list[AutoRow]):
    data = [r.model_dump() for r in rows]
    for r in data:
        if not r.get("id"):
            r["id"] = f"m{int(time.time()*1000)}{data.index(r)}"
    _write_json(_FB_AUTOMAP, data)
    return {"ok": True, "count": len(data)}


def _sheet_csv_url(url: str) -> str:
    """URL Google Sheet (edit/share) -> URL export CSV. URL CSV/khac giu nguyen."""
    m = re.search(r"/spreadsheets/d/([A-Za-z0-9_\-]+)", url)
    if not m:
        return url
    sid = m.group(1)
    g = re.search(r"[#&?]gid=(\d+)", url)
    return f"https://docs.google.com/spreadsheets/d/{sid}/export?format=csv&gid={g.group(1) if g else '0'}"


class SheetSyncReq(BaseModel):
    url: str


@app.get("/api/fb-post/automap/sheet-url")
def api_automap_sheet_url():
    return {"url": _app_config().get("source_sheet_url", "")}


@app.post("/api/fb-post/automap/sync-sheet")
def api_automap_sync_sheet(body: SheetSyncReq):
    """Dong bo NGUON tu Google Sheet: moi dong [TEN (hoac ID) page, LINK nguon facebook.com] ->
    dien 'link' vao dong automap KHOP page_name (khong phan biet hoa/thuong) hoac page_id.
    Sheet phai chia se 'Ai co link deu XEM'. Cung nhan URL CSV / .csv truc tiep."""
    import csv as _csv
    import io as _io
    import requests as _rq
    url = _sheet_csv_url((body.url or "").strip())
    if not url.lower().startswith("http"):
        raise HTTPException(400, "URL không hợp lệ — dán link Google Sheet (đã chia sẻ) hoặc link CSV.")
    try:
        r = _rq.get(url, timeout=30)
        r.raise_for_status()
        text = r.content.decode("utf-8-sig", errors="replace")
    except Exception as e:
        raise HTTPException(400, "Không tải được Sheet (kiểm URL + đã chia sẻ 'Ai có link đều xem'): %s" % str(e)[:120])
    pairs = []                                        # (key = ten/id page, source_link)
    for row in _csv.reader(_io.StringIO(text)):
        cells = [c.strip() for c in row if c and c.strip()]
        src = next((c for c in cells if "facebook.com" in c.lower()), "")
        if not src:
            continue
        key = next((c for c in cells if c != src), "")
        if key:
            pairs.append((key, src))
    if not pairs:
        raise HTTPException(400, "Sheet chưa có dòng hợp lệ. Mỗi dòng cần: TÊN (hoặc ID) page + LINK nguồn facebook.com.")

    def _norm(s):
        return re.sub(r"\s+", " ", (s or "").strip().lower())

    def _match(r, key):
        return (key.isdigit() and key == str(r.get("page_id", ""))) or _norm(key) == _norm(r.get("page_name", ""))

    amap = read_json(_FB_AUTOMAP, []) or []
    matched = 0
    for r in amap:
        hit = next((src for key, src in pairs if _match(r, key)), "")
        if hit and "facebook.com" in hit:
            r["link"] = hit
            matched += 1
    unmatched = [key for key, _ in pairs if not any(_match(r, key) for r in amap)]
    _write_json(_FB_AUTOMAP, amap)
    cfg = _app_config()
    cfg["source_sheet_url"] = (body.url or "").strip()
    _save_app_config(cfg)
    return {"ok": True, "matched": matched, "total": len(amap),
            "sheet_pairs": len(pairs), "unmatched": unmatched[:20]}


class RunReq(BaseModel):
    ids: list[str]


def _enqueue_auto_row(r: dict):
    """Đẩy 1 job auto (tải→làm lại→ĐĂNG theo cách đã chọn) cho 1 dòng mapping. None nếu lỗi."""
    if not (_FB_ID_RE.match(r.get("page_id", "")) and "facebook.com" in r.get("link", "")):
        return None
    if not _page_allowed(r.get("page_id", "")):        # an toan: khong dang page ngoai whitelist
        return None
    desc_dir = os.path.join(FB_ROOT, "_post_desc")
    os.makedirs(desc_dir, exist_ok=True)
    df = os.path.join(desc_dir, f"auto_{r['id']}.txt")
    with open(df, "w", encoding="utf-8") as f:
        f.write(r.get("desc") or "")
    # CÁCH ĐĂNG (chọn ở hộp ▶ Star, lưu trong drip config): đăng luôn / hẹn giờ + số bài + giãn cách.
    # Giờ hẹn TUYỆT ĐỐI tính ở đây theo số bài đã làm (marching gap). fb_auto chỉ đăng theo when_ts.
    dcfg = fb_drip.load_config()
    rs = read_json(_FB_RUNSTATE, {}) or {}
    stt = rs.get(r["page_id"]) or {}
    since = int(stt.get("since") or 0) or int(time.time())
    # slot_bump: bulk retry/resume đẩy nhiều item CÙNG LÚC -> made giống nhau -> CÙNG giờ đăng.
    # Cho mỗi item chỉ số tăng dần (per-page) -> _compute_slot giãn theo gap -> KHÔNG trùng giờ.
    made = _run_made(r["page_id"], since) + int(r.get("slot_bump") or 0)
    post_mode, wt = _compute_slot(dcfg, since, made)
    umode = "schedule" if dcfg.get("post_mode") == "schedule" else "now"   # Ý ĐỊNH người dùng
    # Ép model/kiểu ảnh CẢ LƯỢT nếu hộp Star chọn (run_clip/run_style); '' = theo gán từng page.
    # Model do NGƯỜI DÙNG chọn: veo_3_1 | grok_video_heavy | kenburns (KHÔNG tự đổi/ rớt).
    style = dcfg.get("run_style") or r.get("style", "real")
    clip = dcfg.get("run_clip") or r.get("clip", "veo_3_1")
    item_id = f"p{int(time.time()*1000)}{r['id'][-4:]}"
    fb_pipeline.add(item_id, r.get("page_name", ""), r.get("link", ""),
                    page_id=r["page_id"], page_name=r.get("page_name", ""),
                    audio=r.get("audio", "B"), clip=clip, pmode=umode,
                    style=style, when_ts=wt)   # when_ts thật ghi lại lúc fb_auto ĐĂNG xong
    # Thứ tự chọn reel nguồn: 'oldest' (cũ nhất, mặc định) | 'random' (ngẫu nhiên) — hộp Star chọn.
    order = "random" if dcfg.get("run_order") == "random" else "oldest"
    # --lanes 1: mỗi page 1 i2v/lúc -> N page song song = N task 79 (<12) -> KHÔNG flood.
    cmd = ["pipeline/fb_auto.py", "--page-id", r["page_id"], "--link", r["link"],
           "--audio", r.get("audio", "B"), "--clip", clip, "--lanes", "1",
           "--style", style, "--post-mode", post_mode, "--order", order,
           "--desc-file", df, "--item-id", item_id]
    if r.get("reel_id"):                       # RETRY/RESUME: nhắm ĐÚNG reel cũ -> resume, KHÔNG chọn lại reel mới
        cmd += ["--reel-id", str(r["reel_id"])]
    if wt:
        cmd += ["--when-ts", str(int(wt))]
    return push("auto-fb", f"Auto: {r.get('page_name', '')}", cmd)


@app.post("/api/fb-post/automap/run")
def api_fbpost_automap_run(body: RunReq):
    rows = read_json(_FB_AUTOMAP, []) or []
    sel = [r for r in rows if r.get("id") in body.ids]
    if not sel:
        raise HTTPException(400, "Chưa chọn dòng nào.")
    jobs = [j for r in sel if (j := _enqueue_auto_row(r))]
    return {"jobs": jobs, "count": len(jobs)}


# ── Autopilot (cron): tự chạy vòng theo giờ. MẶC ĐỊNH TẮT (an toàn). ──
_FB_AUTOPILOT = os.path.join(FB_ROOT, "_autopilot.json")


def _autopilot_cycle() -> dict:
    """1 vòng cron (mô hình kho đệm): mỗi dòng BẬT → nếu governor cho phép (credit floor +
    trần an toàn tổng) VÀ page chưa đủ nhịp/ngày VÀ không có job đang chạy dở → đẩy 1 job
    (tự lấy reel CŨ NHẤT chưa làm; ĐĂNG theo "cách đăng" đã chọn — đăng luôn / hẹn sau).
    Nhịp/ngày/page giữ bằng cách đếm job đã đẩy hôm nay (không cần rải slot)."""
    # Gói thuê bao còn quota → video KHÔNG trừ credit (free theo quota) → BỎ QUA sàn credit.
    # Đường Star tay đã tính plan_free trong fb_auto; cổng cron này cũng phải nhất quán,
    # nếu không autopilot bị chặn "Credit < sàn" dù đã mua gói. Xem [[nhat-quan-moi-tab]].
    pf = False
    try:
        pf = fb_governor.sub_active()
    except Exception:
        pf = False
    st = fb_governor.status(plan_free=pf)
    if not st.get("can_produce"):
        return {"skipped": st.get("reason")}
    gov = fb_governor.load_config()
    ceiling = int(gov.get("video_per_day", 60)) - int(st.get("produced_today", 0))
    if ceiling <= 0:
        return {"skipped": "chạm trần an toàn tổng/ngày"}
    rows = read_json(_FB_AUTOMAP, []) or []
    rs = read_json(_FB_RUNSTATE, {}) or {}
    # Page DANG co job chay (chua xong) -> KHONG day them: chong day TRUNG reel/credit khi
    # bam Star 2 lan gan nhau hoac cron chong len. Cung dam bao lam TUAN TU tung bai/page.
    # NGUON SU THAT = HANG DOI (job PENDING/RUNNING khop --page-id), KHONG doan theo tuoi item
    # pipeline: item orphan (server restart/crash) hoac job da huy KHONG con chan Star oan.
    active_pages = _running_page_ids()
    done = 0
    changed = False
    for r in rows:
        if not r.get("enabled"):
            continue
        if done >= ceiling:
            break
        pid = r.get("page_id", "")
        if not _page_allowed(pid) or pid in active_pages:
            continue
        stt = rs.get(pid) or {}
        target = int(stt.get("target") or 0)
        since = int(stt.get("since") or 0) or int(time.time())
        # Đủ SỐ BÀI cần làm → DỪNG HẲN page này (Stop = dừng luôn, không "tạm dừng").
        if target and _run_made(pid, since) >= target:
            r["enabled"] = False
            changed = True
            continue
        if _enqueue_auto_row(r):
            active_pages.add(pid)                     # cùng vòng: 1 page 1 job (tuần tự)
            done += 1
    if changed:
        _write_json(_FB_AUTOMAP, rows)
    return {"enqueued": done}


_autopilot_lock = threading.Lock()


def _run_cycle_guarded() -> dict:
    """Chạy 1 vòng cycle NHƯNG khóa: đang có vòng chạy thì bỏ qua. Chống 2 lần Start gần
    nhau + cron chạy chồng lên nhau (mỗi cái tự quét lại rows) → đẩy trùng job."""
    if not _autopilot_lock.acquire(blocking=False):
        return {"skipped": "cycle đang chạy"}
    try:
        return _autopilot_cycle()
    finally:
        _autopilot_lock.release()


_FB_RESCAN_STATE = os.path.join(FB_ROOT, "_rescan_state.json")


def _autopilot_rescan(every_hours: int = 6) -> dict:
    """Định kỳ cào lại các NGUỒN (dòng BẬT) → append reel MỚI vào cuối backlog.
    Chỉ chạy khi Chrome đang login (KHÔNG tự mở Chrome trong cron). Tối đa 1 lần/every_hours."""
    if not (fb_session.is_alive() and fb_session.logged_in()):
        return {"skipped": "chrome chưa login"}
    stt = read_json(_FB_RESCAN_STATE, {}) or {}
    now = int(time.time())
    if now - int(stt.get("last", 0)) < every_hours * 3600:
        return {"skipped": "chưa tới hạn rescan"}
    rows = [r for r in (read_json(_FB_AUTOMAP, []) or []) if r.get("enabled")]
    seen, added = set(), 0
    for r in rows:
        link = r.get("link", "")
        if not fb_watch.is_source(link):
            continue                                # link reel cố định: không có gì rescan
        slug = fb_lister.page_slug(link)
        if slug in seen:
            continue
        seen.add(slug)
        try:
            added += fb_watch.build_backlog(link, refresh=True, max_scroll=12).get("added", 0)
        except Exception as exc:
            print(f"[rescan] {slug} lỗi: {exc}", flush=True)
    stt["last"] = now
    _write_json(_FB_RESCAN_STATE, stt)
    return {"rescanned": len(seen), "added": added}


async def _autopilot_loop():
    await asyncio.sleep(45)                       # chờ app ổn định
    while True:
        interval = 60
        try:
            cfg = read_json(_FB_AUTOPILOT, {"enabled": False, "interval_min": 60})
            interval = max(15, int(cfg.get("interval_min", 60)))
            if cfg.get("enabled"):
                loop = asyncio.get_running_loop()
                rsc = await loop.run_in_executor(None, _autopilot_rescan)
                if not rsc.get("skipped"):
                    print(f"[rescan] {rsc}", flush=True)
                res = await loop.run_in_executor(None, _run_cycle_guarded)
                print(f"[autopilot] {res}", flush=True)
        except Exception as exc:
            print(f"[autopilot] loi: {exc}", flush=True)
        await asyncio.sleep(interval * 60)


@app.get("/api/fb-post/autopilot")
def api_fbpost_autopilot():
    return read_json(_FB_AUTOPILOT, {"enabled": False, "interval_min": 60})


class AutopilotReq(BaseModel):
    enabled: bool = False
    interval_min: int = 60


@app.post("/api/fb-post/autopilot")
def api_fbpost_autopilot_save(body: AutopilotReq):
    d = {"enabled": bool(body.enabled), "interval_min": max(15, int(body.interval_min))}
    _write_json(_FB_AUTOPILOT, d)
    return d


# ── START / STOP GỘP 1 CHỖ (Tổng quan page) ──
# 1 nút Start / Stop cho các page đã tích. Start = BẬT autopilot cho page đó (dòng mapping
# enabled=true) + BẬT cron toàn cục (khỏi phải vào Cài đặt bật riêng) + chạy 1 vòng NGAY để
# thấy khởi động. Stop = TẮT autopilot page đó. Không đụng page khác (chạy là chạy, dừng là dừng).
class PagesRunReq(BaseModel):
    page_ids: list[str] = []
    on: bool = True
    post: dict | None = None      # cấu hình từ hộp ▶ Star (đăng luôn/hẹn giờ + số bài + giãn cách)


_INFLIGHT_ST = ("queued", "downloading", "remaking", "scheduling")


def _job_page_id(j) -> str:
    """page_id của 1 job auto-fb (đọc từ cmd --page-id). "" nếu không phải/không có."""
    if getattr(j, "kind", "") != "auto-fb":
        return ""
    cmd = getattr(j, "cmd", None) or []
    if "--page-id" in cmd:
        try:
            return cmd[cmd.index("--page-id") + 1]
        except (ValueError, IndexError):
            return ""
    return ""


def _running_page_ids() -> set:
    """Page ĐANG có job auto-fb (PENDING/RUNNING) trong HÀNG ĐỢI — nguồn SỰ THẬT để biết
    page nào đang bận. Dùng thay cho đoán-theo-tuổi-item (item orphan sau restart/crash KHÔNG
    còn chặn Star; job chết/hủy → page tự do NGAY)."""
    out = set()
    for j in list(queue.jobs.values()):
        if getattr(j, "status", "") not in (jobs.PENDING, jobs.RUNNING):
            continue
        pid = _job_page_id(j)
        if pid:
            out.add(pid)
    return out


def _stop_page_inflight(page_ids: set) -> dict:
    """Stop 1 page = DỪNG HẲN: hủy job auto-fb đang chạy/chờ của page (kill subprocess qua
    queue.cancel) + dọn item pipeline đang dở → cancelled (UI hết 'đang remake')."""
    killed = 0
    for j in list(queue.jobs.values()):
        if getattr(j, "status", "") not in (jobs.PENDING, jobs.RUNNING):
            continue
        if _job_page_id(j) in page_ids and queue.cancel(j.id):
            killed += 1
    cleaned = 0
    for it in fb_pipeline.recent(_PIPE_WINDOW):
        if it.get("page_id") in page_ids and it.get("status") in _INFLIGHT_ST:
            fb_pipeline.update(it["id"], status="cancelled", step="đã dừng")
            cleaned += 1
    return {"killed": killed, "cleaned": cleaned}


def _cleanup_orphan_pipeline() -> int:
    """Khi KHỞI ĐỘNG: hàng đợi trong RAM rỗng → mọi item pipeline còn ở trạng thái 'đang chạy'
    (queued/downloading/remaking/scheduling) là ORPHAN (tiến trình con chết cùng server cũ) →
    đánh error để UI hết kẹt 'đang remake' + không chặn Star. Đo THẬT: item remaking 7h sống
    dai qua mọi restart vì trước đây KHÔNG có bước dọn này."""
    n = 0
    for it in fb_pipeline.recent(_PIPE_WINDOW):
        if it.get("status") in _INFLIGHT_ST:
            fb_pipeline.update(it["id"], status="error", step="dừng khi khởi động lại")
            n += 1
    if n:
        print(f"[pipeline] don {n} item orphan khi khoi dong", flush=True)
    return n


@app.post("/api/fb-post/pages/run")
def api_fbpost_pages_run(body: PagesRunReq):
    # Lưu "cách đăng" đã chọn ở hộp Star (áp cho mọi page đang chạy).
    if body.on and body.post:
        fb_drip.save_config(body.post)
    dcfg = fb_drip.load_config()
    target = int(dcfg.get("run_target") or 0)
    # SỐ LUỒNG chạy song song (hộp Star). = số job auto ĐỒNG THỜI. Trần 10 (gói 79 đồng thời 12,
    # chừa 2). Mỗi job --lanes 1 -> N luồng = N task 79 -> KHÔNG flood. Áp NGAY (không restart).
    if body.on:
        threads = int(dcfg.get("threads") or 5)
        queue.set_max_concurrent(max(1, min(10, threads)))
    now = int(time.time())
    ids = set(body.page_ids)
    rows = read_json(_FB_AUTOMAP, []) or []
    rs = read_json(_FB_RUNSTATE, {}) or {}
    matched, ready = 0, 0
    for r in rows:
        if r.get("page_id") in ids:
            matched += 1
            was = bool(r.get("enabled"))
            r["enabled"] = bool(body.on)
            if body.on and r.get("link"):
                ready += 1
                # Chỉ MỞ lượt mới cho page CHƯA chạy (was=False) — page đang chạy giữ nguyên
                # `since` để không reset bộ đếm số bài (tránh làm quá / dừng non credit).
                if not was or r["page_id"] not in rs:
                    rs[r["page_id"]] = {"since": now, "target": target}
                else:
                    rs[r["page_id"]]["target"] = target   # cập nhật số bài, giữ mốc bắt đầu
            if not body.on:
                rs.pop(r["page_id"], None)                            # Stop = dừng hẳn lượt
    _write_json(_FB_AUTOMAP, rows)
    _write_json(_FB_RUNSTATE, rs)
    stopped = None
    if not body.on and ids:
        # DỪNG HẲN: kill job đang chạy + dọn item kẹt để Star lại chạy được NGAY (không
        # phải chờ 45' stale timeout). Xem _stop_page_inflight.
        stopped = _stop_page_inflight(ids)
    started = False
    if body.on and ready:
        ap = read_json(_FB_AUTOPILOT, {"enabled": False, "interval_min": 60}) or {}
        ap["enabled"] = True                      # 1 công tắc: Star bật luôn cron toàn cục
        _write_json(_FB_AUTOPILOT, ap)
        # Trần AN TOÀN/ngày (video_per_day) không được CHẶN batch người dùng chủ động chọn:
        # cần = số page × số bài. Nâng trần cho đủ (floor_credit vẫn phanh thật, =0 khi có gói).
        try:
            need = ready * max(1, target)
            gcfg = fb_governor.load_config()
            if int(gcfg.get("video_per_day", 60)) < need:
                gcfg["video_per_day"] = need
                fb_governor.save_config(gcfg)
        except Exception:
            pass
        threading.Thread(target=_run_cycle_guarded, daemon=True).start()   # chạy 1 vòng ngay (có khóa)
        started = True
    return {"ok": True, "on": bool(body.on), "matched": matched,
            "ready": ready, "started": started, "target": target, "stopped": stopped}


# ── Pipeline state (tiến trình auto) ──
@app.get("/api/fb-post/pipeline")
def api_fbpost_pipeline():
    return {"items": fb_pipeline.recent(60), "summary": fb_pipeline.summary()}


def _csv_response(rows: list, cols: list, filename: str) -> Response:
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(cols)
    for r in rows:
        w.writerow([r.get(c, "") for c in cols])
    return Response(content="﻿" + buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.get("/api/fb-post/export/pipeline.csv")
def api_fbpost_export_pipeline():
    rows = fb_pipeline.recent(500)
    for r in rows:
        r["time"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(r.get("ts", 0)))
    cols = ["time", "page", "bm", "reel", "link", "status", "step", "post_id", "video_id", "error"]
    return _csv_response(rows, cols, "tien-trinh-auto.csv")


@app.get("/api/fb-post/export/scheduled.csv")
def api_fbpost_export_scheduled():
    rows = read_json(_FB_SCHED, []) or []
    for r in rows:
        r["time"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(r.get("when_ts", 0))) \
            if r.get("when_ts") else "đăng ngay"
    cols = ["time", "page", "video", "status"]
    return _csv_response(rows, cols, "lich-dang.csv")


class RetryReq(BaseModel):
    id: str


@app.post("/api/fb-post/pipeline/retry")
def api_fbpost_pipeline_retry(body: RetryReq):
    it = fb_pipeline.get(body.id)
    if not it:
        raise HTTPException(404, "Không tìm thấy item.")
    if it.get("status") not in ("error",):
        raise HTTPException(400, "Chỉ thử lại item bị LỖI.")
    if not it.get("page_id"):
        raise HTTPException(400, "Item cũ thiếu thông tin để thử lại.")
    row = {"id": f"rt{int(time.time()*1000)}", "page_id": it["page_id"],
           "page_name": it.get("page_name", ""), "link": it.get("link", ""),
           "audio": it.get("audio", "B"), "clip": it.get("clip", "veo_3_1"),
           "style": it.get("style", "real"), "reel_id": it.get("reel", ""),
           "when_ts": it.get("when_ts", 0), "desc": ""}
    job = _enqueue_auto_row(row)
    if not job:
        raise HTTPException(400, "Không đẩy được (kiểm page/link/whitelist).")
    return {"job": job}


@app.post("/api/fb-post/pipeline/resume-stopped")
def api_fbpost_pipeline_resume_stopped(kind: str = "all"):
    """Làm lại việc còn dở, ĐẨY SONG SONG vào hàng đợi (chạy tối đa max_jobs cùng lúc). Nhắm ĐÚNG
    reel cũ (reel_id) → fb_auto tái dùng ảnh/clip/.task đã làm (0 credit thêm cho cảnh đã xong).
    kind: 'error' = chỉ item LỖI (status 'error') · 'stopped' = chỉ ĐÃ DỪNG (cancelled+step 'đã dừng')
    · 'all' = cả hai. Dedup theo (page_id, reel). Đánh dấu `_resumed` -> bấm lại KHÔNG nhân đôi (GIỮ
    message lỗi). Không có việc phù hợp -> resumed=0 (UI báo 'không có')."""
    want_err = kind in ("error", "all")
    want_stop = kind in ("stopped", "all")
    # Khôi phục trần luồng về "Số video chạy song song" (Cài đặt) — lần Star cuối có thể đã hạ
    # xuống thấp (vd 3) → bulk retry sẽ kẹt ở đó. Nâng lại để chạy đúng số cấu hình.
    conc = queue.set_max_concurrent(int(_app_config().get("max_jobs", 5)))
    resumed, failed, seen, idx = [], 0, set(), 0
    page_bump = {}                            # per-page: item thứ mấy trong lượt -> GIÃN giờ đăng (khỏi trùng)
    for it in fb_pipeline.recent(_PIPE_WINDOW):
        if it.get("_resumed"):                # đã đẩy thử lại rồi -> bỏ (item mới sinh ra mới sống)
            continue
        st, stp = it.get("status"), it.get("step") or ""
        is_err = (st == "error")
        is_stop = (st == "cancelled" and stp == "đã dừng")
        if not ((want_err and is_err) or (want_stop and is_stop)):
            continue
        pid, link = it.get("page_id", ""), it.get("link", "")
        if not (pid and link):
            continue
        key = (pid, it.get("reel") or link)   # dedup theo REEL (mỗi reel 1 lần; cùng page chung link)
        if key in seen:
            fb_pipeline.update(it["id"], _resumed=1)
            continue
        idx += 1
        bump = page_bump.get(pid, 0)          # 0,1,2... -> _compute_slot giãn theo gap -> KHÔNG trùng giờ
        row = {"id": f"rs{int(time.time()*1000)}{idx}", "page_id": pid,
               "page_name": it.get("page_name", ""), "link": link,
               "audio": it.get("audio", "B"), "clip": it.get("clip", "veo_3_1"),
               "style": it.get("style", "real"), "reel_id": it.get("reel", ""),
               "slot_bump": bump, "when_ts": it.get("when_ts", 0), "desc": ""}
        if _enqueue_auto_row(row):
            seen.add(key)
            page_bump[pid] = bump + 1
            resumed.append(it.get("page_name") or pid)
            fb_pipeline.update(it["id"], _resumed=1)   # đã đẩy -> bấm lại không nhân đôi (giữ message)
        else:
            failed += 1
    return {"resumed": len(resumed), "failed": failed, "pages": resumed, "concurrency": conc}


def _diag_error_step(it: dict) -> str:
    """Item lỗi ĐÃ ĐI TỚI BƯỚC NÀO — đọc file cache trong work dir (đúng nơi fb_auto tạo).
    Trả câu tiếng Việt để GHI vào step (hiện ở cột trạng thái tab Lỗi)."""
    import glob as _g
    import fb_auto as _fa
    link, rid = it.get("link", ""), it.get("reel", "")
    slug = _fa._slug(link) if link else ""
    if not (slug and rid):
        return "⚠ lỗi RẤT sớm — chưa xác định được reel nguồn (lỗi tải/nhận link)"
    base = os.path.join(FB_ROOT, slug, "remake")
    out = os.path.join(base, "%s-lamlai.mp4" % rid)
    work = out + ".work"
    if os.path.isfile(out) and os.path.getsize(out) > 1000:
        return "✓ đã DỰNG XONG video → chỉ kẹt bước LÊN LỊCH/đăng"
    dl = os.path.join(FB_ROOT, slug, "downloads", rid, "video.mp4")
    if not os.path.isdir(work):
        if not (os.path.isfile(dl) and os.path.getsize(dl) > 0):
            return "⚠ lỗi ở bước TẢI NGUỒN — chưa tải được video gốc (0 credit)"
        return "⚠ đã tải nguồn nhưng CHƯA bắt đầu dựng (lỗi đọc nguồn?)"
    nclip = len(_g.glob(os.path.join(work, "clip_*.mp4")))
    nimg = len(_g.glob(os.path.join(work, "img_*.txt")))
    ntask = len(_g.glob(os.path.join(work, "*.task")))
    ns = 0
    sp = os.path.join(work, "scenes.json")
    if os.path.isfile(sp):
        try:
            ns = len(json.load(open(sp, encoding="utf-8")))
        except Exception:
            ns = 0
    tail = (" (+%d clip đang chờ tải từ 79)" % ntask) if ntask else ""
    if nclip:
        if ns and nclip >= ns:
            return "✓ đã có ĐỦ %d/%d clip → kẹt ở GHÉP video cuối%s" % (nclip, ns, tail)
        return "⏳ đang tạo clip: %d/%s clip%s" % (nclip, ns or "?", tail)
    if ntask:
        return "⏳ đã gửi %d clip lên 79, chưa tải về clip nào" % ntask
    if nimg:
        return "⚠ có %d/%s ẢNH, chưa có clip → kẹt bước TẠO VIDEO từ ảnh (i2v)" % (nimg, ns or "?")
    if os.path.isfile(sp):
        return "⚠ đã viết mô tả cảnh, CHƯA vẽ ảnh nào → kẹt bước TẠO ẢNH (0 credit)"
    if os.path.isfile(os.path.join(work, "vbounds.json")):
        return "⚠ đã phân tích cảnh, chưa viết mô tả cảnh"
    if os.path.isfile(os.path.join(work, "transcript.json")):
        return "⚠ đã chép lời, lỗi khi PHÂN TÍCH cảnh video gốc"
    return "⚠ lỗi SỚM — đã tải nguồn nhưng CHƯA chép được lời (ffmpeg đọc nguồn lỗi)"


@app.post("/api/fb-post/pipeline/diagnose-errors")
def api_fbpost_pipeline_diagnose_errors():
    """Quét MỌI item LỖI 1 lượt → kiểm mỗi cái đã ĐẾN BƯỚC NÀO (đọc work dir) → GHI vào `step`
    (hiện ở cột trạng thái/log tab Lỗi). Không tốn credit — chỉ đọc file. Trả số item đã kiểm."""
    n = 0
    for it in fb_pipeline.recent(_PIPE_WINDOW):
        if it.get("status") != "error":
            continue
        try:
            fb_pipeline.update(it["id"], step=_diag_error_step(it))
            n += 1
        except Exception:
            pass
    return {"checked": n}


@app.post("/api/fb-post/pipeline/kill-nouid-errors")
def api_fbpost_pipeline_kill_nouid():
    """XOÁ HẲN item LỖI/ĐÃ HỦY mà KHÔNG có UID (reel) — chết rất sớm, không có reel để thử lại
    (rác trong danh sách). Chỉ xoá item terminal (error/cancelled) + thiếu reel → an toàn."""
    dead = [it["id"] for it in fb_pipeline.recent(_PIPE_WINDOW)
            if it.get("status") in ("error", "cancelled") and not (it.get("reel") or "").strip()]
    killed = fb_pipeline.delete(dead) if dead else 0
    return {"killed": killed}


@app.post("/api/fb-post/pipeline/cancel")
def api_fbpost_pipeline_cancel(body: RetryReq):
    it = fb_pipeline.get(body.id)
    if not it:
        raise HTTPException(404, "Không tìm thấy item.")
    vid = it.get("video_id") or ""
    if not (vid and it.get("page_id")):
        raise HTTPException(400, "Item không có video_id để hủy (chỉ hủy bài đã đăng/lịch qua auto).")
    tok = fb_graph.page_token(it["page_id"])
    if not tok:
        raise HTTPException(400, "Không có page token (Làm mới).")
    r = fb_publish.delete_reel(vid, tok)
    if not r.get("ok"):
        raise HTTPException(400, "Hủy lỗi: " + str(r.get("body") or r.get("exc")))
    fb_pipeline.update(body.id, status="cancelled", step="cancelled")
    return {"ok": True}


# ── Governor (bộ hãm ngân sách/nhịp) ──
@app.get("/api/fb-post/governor")
def api_fbpost_governor():
    return fb_governor.status()


class GovReq(BaseModel):
    enabled: bool = True
    floor_credit: int = 8000
    video_per_day: int = 2
    post_per_page_day: int = 2
    jitter_min: int = 25


@app.post("/api/fb-post/governor")
def api_fbpost_governor_save(body: GovReq):
    return fb_governor.save_config(body.model_dump())


# ── Watcher: quét nguồn tìm video mới ──
class ScanReq(BaseModel):
    link: str


@app.post("/api/fb-post/watch/scan")
def api_fbpost_watch_scan(body: ScanReq):
    if "facebook.com" not in (body.link or ""):
        raise HTTPException(400, "Link nguồn không hợp lệ.")
    if not fb_session.is_alive():
        raise HTTPException(400, "Chưa mở Chrome đăng nhập (tab Tài khoản).")
    if not fb_watch.is_source(body.link):
        raise HTTPException(400, "Đây là link reel cố định, không phải nguồn (page).")
    try:
        r = fb_watch.scan(body.link)
    except Exception as exc:
        raise HTTPException(400, f"Quét lỗi: {exc}")
    return {"slug": r["slug"], "new_count": r["new_count"], "total": r["total"],
            "done": r["done"], "new": r["new"][:12]}


# ── Backlog nguồn (cũ→mới): build/refresh + trạng thái + danh sách thu gọn ──
class BacklogReq(BaseModel):
    link: str


class BacklogBulkReq(BaseModel):
    links: list[str] = []


@app.post("/api/fb-post/backlog/build")
def api_fbpost_backlog_build(body: BacklogReq):
    """Cào nguồn + dựng/cập nhật backlog cũ→mới (qua HÀNG ĐỢI vì cào chậm)."""
    link = (body.link or "").strip()
    if "facebook.com" not in link:
        raise HTTPException(400, "Link nguồn không hợp lệ.")
    if not fb_watch.is_source(link):
        raise HTTPException(400, "Đây là link reel cố định, không phải nguồn (page).")
    if not (fb_session.is_alive() and fb_session.logged_in()):
        raise HTTPException(400, "Chrome chưa đăng nhập — mở ở tab Tài khoản / Tải video FB.")
    slug = fb_lister.page_slug(link)
    job = push("tai-fb", f"Cào nguồn (backlog): {slug}",
               ["pipeline/fb_watch.py", "build", link])
    return {"ok": True, "job": job, "slug": slug}


@app.post("/api/fb-post/backlog/build-bulk")
def api_fbpost_backlog_build_bulk(body: BacklogBulkReq):
    """Cào NHIỀU nguồn 1 lúc = 1 JOB cào SONG SONG (httpx 1 cookie, đo thật 20 luồng
    không throttle). Page bootstrap lỗi → tự rớt cuộn dự phòng. Xem docs/cao-song-song-1-cookie.md."""
    if not (fb_session.is_alive() and fb_session.logged_in()):
        raise HTTPException(400, "Chrome chưa đăng nhập — mở ở tab Tài khoản / Tải video FB.")
    links, skipped = [], []
    for raw in (body.links or []):
        link = (raw or "").strip()
        if "facebook.com" not in link or not fb_watch.is_source(link):
            skipped.append(link)
            continue
        links.append(link)
    if not links:
        raise HTTPException(400, "Không có nguồn hợp lệ để cào (chọn page nguồn có link).")
    job = push("tai-fb", f"Cào {len(links)} nguồn (song song)",
               ["pipeline/fb_watch.py", "build-many-parallel", *links])
    return {"ok": True, "job": job, "n": len(links), "skipped": skipped}


@app.get("/api/fb-post/backlog")
def api_fbpost_backlog(link: str):
    """Trạng thái backlog + danh sách reel THU GỌN (đọc file, không cần Chrome)."""
    if "facebook.com" not in (link or ""):
        raise HTTPException(400, "Link nguồn không hợp lệ.")
    slug = fb_lister.page_slug(link)
    if slug not in fb_watch._bl_load():
        fb_watch.build_backlog(link, refresh=False)      # dựng từ index có sẵn nếu có
    stt = fb_watch.backlog_status(link)
    bl = fb_watch._bl_load().get(slug, [])
    done = set(fb_watch._load().get(slug, []))
    reels = (fb_lister.load_index(slug).get("reels") or {})
    # thu gọn: cũ→mới, kèm view + thumb + đã làm chưa
    items = [{"id": rid, "done": rid in done,
              "view_text": (reels.get(rid) or {}).get("view_text"),
              "views": (reels.get(rid) or {}).get("views")}
             for rid in bl]
    return {"slug": slug, **stt, "items": items[:400]}


# ── Drip: tự rải giờ đăng ──
@app.get("/api/fb-post/drip")
def api_fbpost_drip():
    return fb_drip.load_config()


class DripCfg(BaseModel):
    slots: list[str] = ["08:00", "12:30", "19:30"]
    jitter_min: int = 25
    days: int = 14
    post_mode: str = "now"          # now (đăng luôn) | schedule (hẹn giờ)
    post_hhmm: str = "08:00"        # giờ đăng bài đầu (schedule)
    post_day_offset: int = 1        # 0=hôm nay, 1=ngày mai, ...
    run_target: int = 1             # số bài cần làm rồi dừng (mỗi page); 0 = liên tục
    gap_min: int = 60               # giãn cách giữa các bài (phút)


@app.post("/api/fb-post/drip")
def api_fbpost_drip_save(body: DripCfg):
    return fb_drip.save_config(body.model_dump())


class DripPlan(BaseModel):
    count: int


@app.post("/api/fb-post/drip/plan")
def api_fbpost_drip_plan(body: DripPlan):
    n = max(0, min(200, body.count))
    return {"times": fb_drip.plan(n)}


app.mount("/static", StaticFiles(directory=STATIC), name="static")


def asset_version() -> str:
    import hashlib
    digest = hashlib.md5()
    for name in ("app.js", "style.css"):
        path = os.path.join(STATIC, name)
        if os.path.exists(path):
            digest.update(str(os.path.getmtime(path)).encode())
            digest.update(str(os.path.getsize(path)).encode())
    return digest.hexdigest()[:8]


@app.get("/", response_class=HTMLResponse)
def index():
    with open(os.path.join(STATIC, "index.html"), encoding="utf-8") as f:
        page = f.read()
    return HTMLResponse(page.replace("__V__", asset_version()),
                        headers={"Cache-Control": "no-cache, no-store, must-revalidate"})


if __name__ == "__main__":
    import uvicorn
    print(f"\nMETEOR AUTO — {channels.active()['name']}\nhttp://127.0.0.1:8760\n")
    # DEV: tự khởi động lại khi sửa .py (app/ + pipeline/). Bật bằng CS_DEV=1 hoặc --reload.
    # Bản đóng gói exe KHÔNG bật (chạy desktop.py, không đặt biến này) -> giữ nguyên tốc độ.
    _dev = os.environ.get("CS_DEV") == "1" or "--reload" in sys.argv
    if _dev:
        _here = os.path.dirname(os.path.abspath(__file__))
        _pipe = os.path.join(os.path.dirname(_here), "pipeline")
        # tiến trình reloader (con) phải import được "server" + module trong pipeline/
        _pp = os.environ.get("PYTHONPATH", "")
        os.environ["PYTHONPATH"] = os.pathsep.join([p for p in (_here, _pipe, _pp) if p])
        print("  [DEV] tu reload khi sua .py trong app/ + pipeline/ (Ctrl+C de dung)\n")
        uvicorn.run("server:app", host="127.0.0.1", port=8760, log_level="warning",
                    reload=True, reload_dirs=[_here, _pipe])
    else:
        uvicorn.run(app, host="127.0.0.1", port=8760, log_level="warning")
